# Mettre Impara en ligne avec de vrais comptes (≈ 15 minutes, gratuit)

Vous allez utiliser deux services gratuits :

- **Supabase** : les comptes (e-mail + mot de passe) et la base de données des progressions ;
- **GitHub Pages** : l'hébergement du site, avec une adresse du type `https://votre-pseudo.github.io/impara/`.

> Pourquoi pas le lien Claude ? Les pages publiées sur Claude ne peuvent pas contacter de serveur extérieur. Ce lien continue de fonctionner, mais en **mode local** (sauvegarde dans le navigateur).

---

## Étape 1 — Créer le projet Supabase

1. Créez un compte sur **https://supabase.com** (bouton *Start your project*, connexion possible avec GitHub).
2. **New project** → nom : `impara`, choisissez un mot de passe de base de données (gardez-le de côté), région : **Europe (Frankfurt ou Stockholm)**.
3. Attendez environ 2 minutes que le projet soit prêt.

## Étape 2 — Créer la table des progressions

1. Menu de gauche → **SQL Editor** → **New query**.
2. Copiez tout le contenu du fichier `supabase/schema.sql`, collez-le, puis cliquez sur **Run**.
3. Vous devez voir *Success. No rows returned*. La table `progress` est créée, avec la sécurité ligne par ligne activée (chacun ne voit que sa propre progression).

## Étape 3 — Récupérer les deux clés

1. Cliquez sur le bouton **Connect** en haut du tableau de bord (ou **Project Settings → API Keys**).
2. Copiez :
   - l'**URL du projet** (`https://xxxxxxxx.supabase.co`) ;
   - la **clé publique** : *Publishable key* (`sb_publishable_…`) ou, sur les anciens projets, la clé `anon` `public` (`eyJ…`).
3. Ouvrez `js/config.js` et collez-les :

```js
export const SUPABASE_URL = "https://xxxxxxxx.supabase.co";
export const SUPABASE_ANON_KEY = "sb_publishable_xxxxxxxx";
```

⚠️ N'utilisez **jamais** la clé `service_role` / *Secret key* : elle contourne toute la sécurité. La clé publique, elle, peut être visible sans risque grâce aux règles de `schema.sql`.

## Étape 4 — Mettre le site en ligne sur GitHub Pages

1. Créez un compte sur **https://github.com**, puis **New repository** → nom `impara`, **Public** → *Create repository*.
2. Sur la page du dépôt : **Add file → Upload files**. Glissez **le contenu** du dossier du site (`index.html`, `css/`, `js/`, etc. — pas le dossier lui-même), puis **Commit changes**.
3. **Settings → Pages** → *Source* : **Deploy from a branch** → branche **main**, dossier **/ (root)** → **Save**.
4. Après 1 à 2 minutes, l'adresse apparaît en haut de la page : `https://votre-pseudo.github.io/impara/`.

## Étape 5 — Relier Supabase à votre adresse

Dans Supabase : **Authentication → URL Configuration** :

- **Site URL** : `https://votre-pseudo.github.io/impara/`
- **Redirect URLs** : ajoutez la même adresse.

C'est l'adresse vers laquelle renvoient les e-mails de confirmation et de « mot de passe oublié ».

**Confirmation par e-mail** (*Authentication → Sign In / Providers → Email → Confirm email*) :
- **activée** (par défaut, recommandé) : après l'inscription, la personne clique sur le lien reçu, puis se connecte ;
- **désactivée** : connexion immédiate après l'inscription, pratique pour tester.

> L'envoi d'e-mails intégré à Supabase est limité à quelques messages par heure : suffisant entre amis. Pour plus d'utilisateurs, branchez un service d'e-mails (Authentication → Emails → SMTP Settings).

## Étape 6 — Tester

1. Ouvrez votre adresse → une pastille **☁️ Se connecter** apparaît en haut à droite.
2. Créez un compte, faites une leçon, puis ouvrez le site sur votre téléphone et connectez-vous : la progression est là.
3. Dans Supabase → **Table Editor → progress**, vous voyez une ligne par compte et par langue.

---

## Fonctionnement en bref

| Situation | Ce qui se passe |
|---|---|
| Visiteur sans compte | Sauvegarde dans son navigateur, comme avant |
| Création de compte | La progression déjà faite en invité est rattachée au compte |
| Connexion sur un autre appareil | Progression récupérée et fusionnée (meilleurs scores, tout le vocabulaire) |
| Retour sur l'onglet | Récupère automatiquement ce qui a été fait ailleurs |
| Hors ligne | On continue normalement ; l'envoi se fait au retour du réseau |
| Déconnexion | La progression est retirée de l'appareil (ordinateur partagé) et reste sur le serveur |
| Italien / mandarin | Une sauvegarde par langue ; pseudo et avatar communs |

## Mettre à jour le site plus tard

Modifiez les fichiers puis renvoyez-les sur GitHub (*Add file → Upload files*, en remplaçant les anciens) : le site se met à jour en 1 à 2 minutes. Les progressions ne sont pas touchées, elles vivent dans Supabase.

## Supprimer un compte

Supabase → **Authentication → Users** → menu du compte → **Delete user** : ses progressions sont supprimées automatiquement (`on delete cascade`).

## Espace amis (amis, messages, défis)

Exécutez aussi `supabase/social.sql` dans le SQL Editor (après `schema.sql`). Il crée les noms d'utilisateur, les demandes d'ami, les messages (en temps réel) et les défis, avec leurs règles de sécurité :
- la progression d'une personne n'est visible que de ses amis ;
- on ne peut écrire qu'à un ami ;
- les scores de défi ne peuvent être envoyés qu'une fois, et seulement par le joueur concerné.
