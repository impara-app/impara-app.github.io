/* =====================================================================
   config.js — Connexion au serveur de comptes (Supabase)
   ---------------------------------------------------------------------
   Collez ici les deux valeurs de votre projet Supabase :
   Supabase → Project Settings → API (voir GUIDE-MISE-EN-LIGNE.md).

   - Laissées vides : le site fonctionne en mode local (sauvegarde dans
     le navigateur uniquement), exactement comme avant.
   - La clé « anon / publishable » est PUBLIQUE par conception : la
     sécurité est assurée par les règles RLS de supabase/schema.sql
     (chacun ne peut lire et modifier que sa propre progression).
     Ne mettez JAMAIS la clé « service_role / secret » ici.
   ===================================================================== */

export const SUPABASE_URL = "https://brfysaduoqeozqqazbaa.supabase.co";      // ex. "https://abcdefghijkl.supabase.co"
export const SUPABASE_ANON_KEY = "sb_publishable_MRf0gFM47XoLVO7QyCtOXA_xEtGFAlS"; // ex. "eyJhbGciOi..." ou "sb_publishable_..."
