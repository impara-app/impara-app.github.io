/* =====================================================================
   conjug-it.js — Conjugaison italienne (verbes réguliers + irréguliers
   courants). Seuls les verbes dont toutes les formes sont connues sont
   proposés : un verbe inconnu est ignoré plutôt que mal conjugué.
   ===================================================================== */

export const PERSONS = ["io", "tu", "lui/lei", "noi", "voi", "loro"];
export const TENSES = {
  presente: { label: "Présent", lesson: "a1-presente-are" },
  passato: { label: "Passé composé", lesson: "a2-passato" },
  imperfetto: { label: "Imparfait", lesson: "b1-imperfetto" },
  futuro: { label: "Futur", lesson: "b1-futuro" },
  condizionale: { label: "Conditionnel", lesson: "a2-condizionale" },
  congiuntivo: { label: "Subjonctif présent", lesson: "b1-congiuntivo-intro" },
};

/* Présent irrégulier */
const PRES = {
  essere: "sono sei è siamo siete sono", avere: "ho hai ha abbiamo avete hanno", fare: "faccio fai fa facciamo fate fanno",
  andare: "vado vai va andiamo andate vanno", venire: "vengo vieni viene veniamo venite vengono", dire: "dico dici dice diciamo dite dicono",
  stare: "sto stai sta stiamo state stanno", dare: "do dai dà diamo date danno", potere: "posso puoi può possiamo potete possono",
  volere: "voglio vuoi vuole vogliamo volete vogliono", dovere: "devo devi deve dobbiamo dovete devono", sapere: "so sai sa sappiamo sapete sanno",
  uscire: "esco esci esce usciamo uscite escono", bere: "bevo bevi beve beviamo bevete bevono", tenere: "tengo tieni tiene teniamo tenete tengono",
  rimanere: "rimango rimani rimane rimaniamo rimanete rimangono", salire: "salgo sali sale saliamo salite salgono",
  scegliere: "scelgo scegli sceglie scegliamo scegliete scelgono", piacere: "piaccio piaci piace piacciamo piacete piacciono",
};
/* Subjonctif présent irrégulier */
const SUBJ = {
  essere: "sia sia sia siamo siate siano", avere: "abbia abbia abbia abbiamo abbiate abbiano", fare: "faccia faccia faccia facciamo facciate facciano",
  andare: "vada vada vada andiamo andiate vadano", venire: "venga venga venga veniamo veniate vengano", dire: "dica dica dica diciamo diciate dicano",
  stare: "stia stia stia stiamo stiate stiano", dare: "dia dia dia diamo diate diano", potere: "possa possa possa possiamo possiate possano",
  volere: "voglia voglia voglia vogliamo vogliate vogliano", dovere: "debba debba debba dobbiamo dobbiate debbano", sapere: "sappia sappia sappia sappiamo sappiate sappiano",
  uscire: "esca esca esca usciamo usciate escano", bere: "beva beva beva beviamo beviate bevano", tenere: "tenga tenga tenga teniamo teniate tengano",
  rimanere: "rimanga rimanga rimanga rimaniamo rimaniate rimangano", salire: "salga salga salga saliamo saliate salgano",
  scegliere: "scelga scelga scelga scegliamo scegliate scelgano", piacere: "piaccia piaccia piaccia piacciamo piacciate piacciano",
};
/* Imparfait irrégulier (radical) */
const IMPF = { essere: null, fare: "face", dire: "dice", bere: "beve" };
/* Futur / conditionnel : radical irrégulier */
const FUT = {
  essere: "sar", avere: "avr", andare: "andr", fare: "far", dare: "dar", stare: "star", dire: "dir", potere: "potr", dovere: "dovr",
  sapere: "sapr", vedere: "vedr", vivere: "vivr", venire: "verr", volere: "vorr", tenere: "terr", rimanere: "rimarr", bere: "berr",
  cadere: "cadr", scadere: "scadr",
};
/* Participes passés irréguliers */
const PART = {
  essere: "stato", avere: "avuto", fare: "fatto", dire: "detto", venire: "venuto", stare: "stato", dare: "dato", bere: "bevuto",
  vedere: "visto", prendere: "preso", mettere: "messo", leggere: "letto", scrivere: "scritto", aprire: "aperto", chiudere: "chiuso",
  rispondere: "risposto", chiedere: "chiesto", perdere: "perso", decidere: "deciso", scegliere: "scelto", vincere: "vinto", nascere: "nato",
  rimanere: "rimasto", scendere: "sceso", spendere: "speso", correre: "corso", offrire: "offerto", vivere: "vissuto", succedere: "successo",
  accendere: "acceso", ridere: "riso", piangere: "pianto", rompere: "rotto", conoscere: "conosciuto", piacere: "piaciuto", muovere: "mosso",
  discutere: "discusso", permettere: "permesso", promettere: "promesso", scoprire: "scoperto", aggiungere: "aggiunto", assumere: "assunto",
  condividere: "condiviso", accorgere: "accorto", iscrivere: "iscritto", descrivere: "descritto", smettere: "smesso", raggiungere: "raggiunto",
  dipingere: "dipinto", spingere: "spinto", comprendere: "compreso", apprendere: "appreso", sorprendere: "sorpreso", esprimere: "espresso",
  crescere: "cresciuto", credere: "creduto", vendere: "venduto", ricevere: "ricevuto", cadere: "caduto", scadere: "scaduto", potere: "potuto",
  dovere: "dovuto", volere: "voluto", sapere: "saputo", tenere: "tenuto", ripetere: "ripetuto", temere: "temuto", battere: "battuto",
  combattere: "combattuto", uscire: "uscito", salire: "salito", andare: "andato",
};
/* Verbes en -ere dont le présent / l'imparfait / le subjonctif sont réguliers */
const ERE_OK = new Set(["prendere", "leggere", "scrivere", "vedere", "credere", "mettere", "chiudere", "vivere", "vendere", "ricevere", "perdere",
  "correre", "rispondere", "chiedere", "decidere", "conoscere", "ripetere", "vincere", "scendere", "spendere", "nascere", "crescere", "accendere",
  "ridere", "piangere", "rompere", "battere", "combattere", "cadere", "scadere", "temere", "muovere", "discutere", "permettere", "promettere", "aggiungere",
  "assumere", "condividere", "accorgere", "iscrivere", "descrivere", "smettere", "raggiungere", "dipingere", "spingere", "comprendere", "apprendere",
  "sorprendere", "esprimere"]);
/* -ire : avec ou sans -isc- */
const ISC = new Set(["capire", "finire", "preferire", "pulire", "spedire", "costruire", "suggerire", "restituire", "garantire", "colpire", "unire",
  "impedire", "sostituire", "diminuire", "fornire", "gestire", "guarire", "obbedire", "proibire", "stabilire", "trasferire", "contribuire", "distribuire", "definire"]);
const IRE_OK = new Set(["dormire", "partire", "sentire", "aprire", "offrire", "servire", "seguire", "vestire", "soffrire", "scoprire", "coprire",
  "bollire", "fuggire", "divertire", "mentire", "avvertire"]);
/* Auxiliaire « essere » (en plus des verbes pronominaux) */
const ESSERE = new Set(["essere", "andare", "venire", "stare", "uscire", "partire", "arrivare", "tornare", "entrare", "restare", "rimanere", "nascere",
  "morire", "diventare", "cadere", "scadere", "salire", "scendere", "succedere", "piacere", "sembrare", "riuscire", "costare", "durare", "crescere", "mancare", "dispiacere"]);
// Verbes impersonnels ou presque : pas proposés
const SKIP = new Set(["piovere", "piacere", "nevicare", "succedere", "dispiacere", "sembrare", "costare", "bisognare", "accadere", "scadere"]);

const words = (s) => s.split(" ");
const REFL = ["mi", "ti", "si", "ci", "vi", "si"];

/** Analyse d'un infinitif → { inf, base, group, refl } ou null si non pris en charge */
export function parseVerb(raw) {
  let v = String(raw || "").trim().toLowerCase();
  if (!/^[a-zàèéìòù]+$/.test(v)) return null;
  let refl = false;
  if (/(arsi|ersi|irsi)$/.test(v)) { refl = true; v = v.slice(0, -2) + "e"; }
  if (SKIP.has(v)) return null;
  const known = PRES[v] || FUT[v] && PART[v];
  if (/are$/.test(v)) {
    if (["inviare", "sciare", "spiare"].includes(v)) return null;
    return { inf: raw, base: v, group: "are", refl };
  }
  if (/ere$/.test(v)) return PRES[v] || ERE_OK.has(v) ? { inf: raw, base: v, group: "ere", refl } : null;
  if (/ire$/.test(v)) return PRES[v] || ISC.has(v) || IRE_OK.has(v) ? { inf: raw, base: v, group: ISC.has(v) ? "isc" : "ire", refl } : known ? { inf: raw, base: v, group: "ire", refl } : null;
  return null;
}

const stem = (v) => v.slice(0, -3);
/** -care/-gare : on ajoute un h devant i/e ; -ciare/-giare/-iare : on évite le double i */
function fixAre(st, end) {
  if (/[cg]$/.test(st) && /^[ie]/.test(end)) return st + "h" + end;
  if (/i$/.test(st) && /^i/.test(end)) return st + end.slice(1);
  return st + end;
}

function presente(p) {
  const v = p.base;
  if (PRES[v]) return words(PRES[v]);
  const s = stem(v);
  if (p.group === "are") return ["o", "i", "a", "iamo", "ate", "ano"].map((e) => fixAre(s, e));
  if (p.group === "ere") return ["o", "i", "e", "iamo", "ete", "ono"].map((e) => s + e);
  if (p.group === "isc") return ["isco", "isci", "isce", "iamo", "ite", "iscono"].map((e) => s + e);
  return ["o", "i", "e", "iamo", "ite", "ono"].map((e) => s + e);
}
function imperfetto(p) {
  const v = p.base;
  if (v === "essere") return words("ero eri era eravamo eravate erano");
  const r = IMPF[v] ? IMPF[v] : v.slice(0, -2);    // parla-, prende-, dormi-
  return ["vo", "vi", "va", "vamo", "vate", "vano"].map((e) => r + e);
}
function futStem(p) {
  const v = p.base;
  if (FUT[v]) return FUT[v];
  const s = stem(v);
  if (p.group === "are") {
    if (/[cg]i$/.test(s)) return s.slice(0, -1) + "er";       // mangiare → manger-, cominciare → comincer-
    if (/[cg]$/.test(s)) return s + "her";                     // cercare → cercher-
    return s + "er";
  }
  return s + (p.group === "ere" ? "er" : "ir");
}
const futuro = (p) => ["ò", "ai", "à", "emo", "ete", "anno"].map((e) => futStem(p) + e);
const condizionale = (p) => ["ei", "esti", "ebbe", "emmo", "este", "ebbero"].map((e) => futStem(p) + e);
function congiuntivo(p) {
  const v = p.base;
  if (SUBJ[v]) return words(SUBJ[v]);
  const s = stem(v);
  if (p.group === "are") return ["i", "i", "i", "iamo", "iate", "ino"].map((e) => fixAre(s, e));
  if (p.group === "isc") return ["isca", "isca", "isca", "iamo", "iate", "iscano"].map((e) => s + e);
  return ["a", "a", "a", "iamo", "iate", "ano"].map((e) => s + e);
}
function participio(p) {
  const v = p.base;
  if (PART[v]) return PART[v];
  if (p.group === "are") return stem(v) + "ato";
  if (p.group === "isc" || p.group === "ire") return IRE_OK.has(v) || ISC.has(v) ? stem(v) + "ito" : null;
  return null; // -ere : participe inconnu → on ne devine pas
}
function passato(p) {
  const part = participio(p);
  if (!part) return null;
  const ess = p.refl || ESSERE.has(p.base);
  const aux = ess ? words("sono sei è siamo siete sono") : words("ho hai ha abbiamo avete hanno");
  const pl = part.slice(0, -1);
  return aux.map((a, i) => (ess ? `${a} ${pl}${i < 3 ? "o/a" : "i/e"}` : `${a} ${part}`));
}
const FN = { presente, passato, imperfetto, futuro, condizionale, congiuntivo };

/**
 * Forme attendue : { show, answers } pour un verbe, un temps et une personne (0-5), ou null.
 * `answers` contient les variantes acceptées (avec ou sans pronom sujet, masculin / féminin).
 */
export function conjugate(raw, tense, person) {
  const p = parseVerb(raw);
  if (!p || !FN[tense]) return null;
  const forms = FN[tense](p);
  if (!forms) return null;
  let f = forms[person];
  if (p.refl) f = `${REFL[person]} ${f}`;
  // variantes : « andato/a » → andato | andata
  const expand = (s) => { const m = s.match(/(\S*?)(o\/a|i\/e)$/); return m ? [s.replace(/(o\/a|i\/e)$/, m[2][0]), s.replace(/(o\/a|i\/e)$/, m[2][2])] : [s]; };
  const base = expand(f);
  const answers = new Set(base);
  // sans « che » / avec ou sans pronom sujet
  for (const a of base) {
    const core = a.replace(/^che \S+ /, "");
    answers.add(core);
    for (const pr of PERSONS[person].split("/")) { answers.add(`${pr} ${core}`); answers.add(`che ${core}`); answers.add(`che ${pr} ${core}`); }
  }
  return { show: f, answers: [...answers] };
}
/** Le verbe est-il pris en charge pour ce temps ? */
export const supports = (raw, tense) => !!conjugate(raw, tense, 0);
