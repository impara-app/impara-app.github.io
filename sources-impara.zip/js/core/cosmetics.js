/* =====================================================================
   cosmetics.js — Cadres d'avatar et bannières de profil à débloquer
   Les conditions portent sur la progression TOUTES LANGUES confondues
   (sauvegardes locales de chaque langue + langue active).
   ===================================================================== */
import { state } from "./storage.js";
import { LANGS, code } from "./lang.js";

/* --------------------------- Progression globale --------------------------- */
function allStates() {
  const out = [state];
  for (const l of Object.values(LANGS)) {
    if (l.code === code) continue;
    try { const s = JSON.parse(localStorage.getItem(l.storageKey) || "null"); if (s) out.push(s); } catch {}
  }
  return out;
}
function longestRun(dayLog = {}) {
  const days = Object.keys(dayLog).filter((d) => dayLog[d] > 0).sort();
  let best = 0, run = 0, prev = null;
  for (const d of days) {
    const t = Date.parse(d + "T12:00:00");
    run = prev && Math.round((t - prev) / 864e5) === 1 ? run + 1 : 1;
    best = Math.max(best, run); prev = t;
  }
  return best;
}
let extra = { wins: 0 }; // fourni par le module social (défis gagnés)
export const setSocialStats = (s) => { extra = { ...extra, ...s }; };

export function progressStats() {
  const st = allStates();
  const sum = (f) => st.reduce((n, s) => n + (f(s) || 0), 0);
  const max = (f) => Math.max(0, ...st.map((s) => f(s) || 0));
  const perfect = (s) => Object.values(s.lessons || {}).filter((l) => l.passed && l.total && l.best >= l.total).length;
  return {
    xp: sum((s) => s.xp),
    streak: max((s) => Math.max(s.streak?.count || 0, longestRun(s.dayLog))),
    exams: sum((s) => Object.values(s.exams || {}).filter((e) => e.passed).length),
    words: sum((s) => Object.keys(s.vocab || {}).length),
    perfect: sum(perfect),
    langs: st.filter((s) => Object.values(s.lessons || {}).some((l) => l.passed)).length,
    stories: sum((s) => Object.values(s.stories || {}).filter((x) => x.done).length),
    wins: extra.wins || 0,
  };
}

/* --------------------------------- Cadres ---------------------------------- */
// need : [statistique, seuil, libellé]
export const FRAMES = [
  { id: "none", name: "Aucun", need: null },
  { id: "bronze", name: "Bronze", need: ["xp", 100, "Gagner 100 XP"] },
  { id: "silver", name: "Argent", need: ["streak", 7, "Une série de 7 jours"] },
  { id: "gold", name: "Or", need: ["exams", 1, "Valider un palier"] },
  { id: "laurel", name: "Laurier", need: ["perfect", 10, "10 leçons à 3 étoiles"] },
  { id: "rainbow", name: "Arc-en-ciel", need: ["words", 100, "Apprendre 100 mots"] },
  { id: "flame", name: "Flamme", need: ["streak", 30, "Une série de 30 jours"] },
  { id: "champion", name: "Champion", need: ["wins", 5, "Gagner 5 défis"] },
  { id: "polyglot", name: "Polyglotte", need: ["langs", 2, "Réussir une leçon dans les 2 langues"] },
  { id: "diamond", name: "Diamant", need: ["xp", 2000, "Gagner 2 000 XP"] },
  { id: "legend", name: "Légende", need: ["streak", 100, "Une série de 100 jours"] },
];
/* Avatars de série : débloqués par la régularité */
export const STREAK_AVATARS = [
  { id: "🌶️", name: "Piment", need: ["streak", 7, "Une série de 7 jours"] },
  { id: "☄️", name: "Comète", need: ["streak", 30, "Une série de 30 jours"] },
  { id: "🌟", name: "Étoile", need: ["streak", 100, "Une série de 100 jours"] },
];

/* -------------------------------- Bannières -------------------------------- */
export const BANNERS = [
  { id: "plain", name: "Couleur unie", need: null },
  { id: "sunset", name: "Coucher de soleil", bg: "linear-gradient(160deg,#ffd194 0%,#ff9a8b 55%,#c86dd7 100%)", ink: "#2b1d14", need: ["xp", 300, "Gagner 300 XP"] },
  { id: "ocean", name: "Océan", bg: "linear-gradient(160deg,#a8edea 0%,#5ab4e5 55%,#2d6fb7 100%)", ink: "#0d2236", need: ["streak", 5, "Une série de 5 jours"] },
  { id: "dots", name: "Pois", bg: "radial-gradient(rgba(255,255,255,.55) 18%,transparent 19%) 0 0/22px 22px,linear-gradient(135deg,#ffb3c7,#ffd6a5)", ink: "#3a2430", need: ["words", 50, "Apprendre 50 mots"] },
  { id: "aurora", name: "Aurore", bg: "linear-gradient(160deg,#43e97b 0%,#38f9d7 40%,#5b7cfa 100%)", ink: "#06281f", need: ["exams", 1, "Valider un palier"] },
  { id: "stars", name: "Nuit étoilée", bg: "radial-gradient(1.5px 1.5px at 20% 30%,#fff,transparent),radial-gradient(1px 1px at 70% 20%,#fff,transparent),radial-gradient(1.5px 1.5px at 40% 70%,#fff,transparent),radial-gradient(1px 1px at 85% 60%,#fff,transparent),radial-gradient(1px 1px at 10% 80%,#fff,transparent),radial-gradient(2px 2px at 60% 45%,#ffe9a8,transparent),linear-gradient(180deg,#0f1c3f,#2a3a7a)", ink: "#ffffff", need: ["wins", 3, "Gagner 3 défis"] },
  { id: "confetti", name: "Confettis", bg: "radial-gradient(circle at 15% 25%,#f5c64e 4px,transparent 5px),radial-gradient(circle at 75% 35%,#ef4444 4px,transparent 5px),radial-gradient(circle at 45% 75%,#3b82f6 4px,transparent 5px),radial-gradient(circle at 85% 80%,#22c55e 4px,transparent 5px),radial-gradient(circle at 30% 55%,#a855f7 3px,transparent 4px),linear-gradient(135deg,#fff7e6,#ffe8f0)", ink: "#2b2f36", need: ["xp", 1000, "Gagner 1 000 XP"] },
  { id: "galaxy", name: "Galaxie", bg: "radial-gradient(circle at 30% 40%,rgba(236,72,153,.55),transparent 45%),radial-gradient(circle at 70% 60%,rgba(99,102,241,.6),transparent 50%),radial-gradient(1px 1px at 20% 20%,#fff,transparent),radial-gradient(1px 1px at 80% 30%,#fff,transparent),radial-gradient(1.5px 1.5px at 50% 85%,#fff,transparent),linear-gradient(160deg,#120a2a,#2a1155)", ink: "#ffffff", need: ["streak", 20, "Une série de 20 jours"] },
  { id: "volcano", name: "Volcan", bg: "radial-gradient(circle at 50% 110%,#ffcf4a 0,#ff7a1a 22%,transparent 46%),linear-gradient(170deg,#2b1210 0%,#6b1f12 55%,#c2361b 100%)", ink: "#ffffff", need: ["streak", 100, "Une série de 100 jours"] },
  { id: "golden", name: "Or impérial", bg: "linear-gradient(160deg,#fff3c4 0%,#f5c64e 45%,#c8871b 100%)", ink: "#3a2a12", need: ["exams", 2, "Valider 2 paliers"] },
];

export const isUnlocked = (item, stats = progressStats()) => !item.need || (stats[item.need[0]] || 0) >= item.need[1];
export const progressOf = (item, stats = progressStats()) => (item.need ? `${Math.min(stats[item.need[0]] || 0, item.need[1])}/${item.need[1]}` : "");
export const frameById = (id) => FRAMES.find((f) => f.id === id) || FRAMES[0];
export const bannerById = (id) => BANNERS.find((b) => b.id === id) || null;

/** Classe CSS du cadre (vide si aucun) */
export const frameClass = (id) => (id && id !== "none" && FRAMES.some((f) => f.id === id) ? `frame frame-${id}` : "");
/** Style de bannière : motif débloqué, sinon couleur unie */
export function bannerStyle(bannerId) {
  const b = bannerById(bannerId);
  return b?.bg ? { bg: b.bg, ink: b.ink } : null;
}
/** Attributs d'une bannière : classe + style inline (couleur unie ou motif) */
export function bannerAttrs(bannerId, color, inkOf) {
  const b = bannerStyle(bannerId);
  const base = `--banner:${color};--banner-ink:${b ? b.ink : inkOf(color)}`;
  return b ? { cls: "has-pattern", style: `${base};--banner-bg:${b.bg}` } : { cls: "", style: base };
}
export const progressPct = (item, stats = progressStats()) => (item.need ? Math.min(100, Math.round(((stats[item.need[0]] || 0) / item.need[1]) * 100)) : 100);

/** Nouveaux objets débloqués depuis la dernière vérification (mémoire commune aux langues).
 *  Au tout premier appel, tout ce qui est déjà acquis est marqué « vu » sans annonce. */
const SEEN_KEY = "impara.seenUnlocks";
export function takeNewUnlocks() {
  const stats = progressStats();
  let seen = null;
  try { seen = JSON.parse(localStorage.getItem(SEEN_KEY) || "null"); } catch {}
  const all = [...FRAMES.filter((f) => f.need).map((f) => ({ ...f, kind: "cadre" })), ...BANNERS.filter((b) => b.need).map((b) => ({ ...b, kind: "bannière" })), ...STREAK_AVATARS.map((a) => ({ ...a, kind: "avatar" }))];
  const open = all.filter((x) => isUnlocked(x, stats));
  const key = (x) => `${x.kind}:${x.id}`;
  const fresh = seen ? open.filter((x) => !seen.includes(key(x))) : [];
  if (!seen || fresh.length) { try { localStorage.setItem(SEEN_KEY, JSON.stringify([...new Set([...(seen || []), ...open.map(key)])])); } catch {} }
  return fresh;
}
