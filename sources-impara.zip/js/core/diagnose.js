/* =====================================================================
   diagnose.js — Pourquoi la réponse est fausse ?
   Compare la réponse donnée à la réponse attendue la plus proche et
   renvoie une explication courte en français (ou "" si rien de clair) :
   - italien : masculin / féminin, singulier / pluriel, article,
     consonne double, personne du verbe, mot manquant ou en trop, ordre ;
   - mandarin : mauvais ton (« 2e au lieu du 3e »), syllabe proche
     (zh / z, -n / -ng…), caractère homophone, ordre des caractères.
   ===================================================================== */
import { L } from "./lang.js";
import { PINYIN_MAP } from "./pinyin.js";
import { conjugate, PERSONS } from "./conjug-it.js";
import { ALL_LESSONS } from "../data/curriculum.js";

const HAN = /[㐀-鿿]/;
const TONES = ["āēīōūǖ", "áéíóúǘ", "ǎěǐǒǔǚ", "àèìòùǜ"];
const strip = (s) => s.normalize("NFD").replace(/[̀-ͯ]/g, "").replace(/ü/g, "u");
const clean = (s) => String(s ?? "").toLowerCase().replace(/[’`´]/g, "'").replace(/[.,!?;:«»"¿¡()，。！？、；：“”‘’（）—…]/g, " ").replace(/\s+/g, " ").trim();
const words = (s) => clean(s).replace(/'/g, "' ").split(" ").filter(Boolean);
const ord = (t) => (t === 1 ? "1er" : `${t}e`);
const TONE_NAME = ["", "1er ton (plat, haut)", "2e ton (montant)", "3e ton (descendant-montant)", "4e ton (descendant)", "ton neutre"];

function lev(a, b) {
  const m = a.length, n = b.length; if (!m) return n; if (!n) return m;
  let prev = Array.from({ length: n + 1 }, (_, j) => j);
  for (let i = 1; i <= m; i++) {
    const cur = [i];
    for (let j = 1; j <= n; j++) cur[j] = Math.min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1));
    prev = cur;
  }
  return prev[n];
}
/** Mots communs dans l'ordre (plus longue sous-suite commune) → manquants / en trop */
function diffWords(g, a) {
  const m = g.length, n = a.length, T = Array.from({ length: m + 1 }, () => new Array(n + 1).fill(0));
  for (let i = m - 1; i >= 0; i--) for (let j = n - 1; j >= 0; j--) T[i][j] = g[i] === a[j] ? T[i + 1][j + 1] + 1 : Math.max(T[i + 1][j], T[i][j + 1]);
  const extra = [], missing = []; let i = 0, j = 0;
  while (i < m && j < n) { if (g[i] === a[j]) { i++; j++; } else if (T[i + 1][j] >= T[i][j + 1]) extra.push(g[i++]); else missing.push(a[j++]); }
  while (i < m) extra.push(g[i++]); while (j < n) missing.push(a[j++]);
  return { extra, missing };
}
const sameBag = (x, y) => x.length === y.length && [...x].sort().join("|") === [...y].sort().join("|");

/* ------------------------------- Italien ------------------------------ */
const ARTICLES = { il: "m", lo: "m", "l'": "?", la: "f", i: "mp", gli: "mp", le: "fp", un: "m", uno: "m", una: "f", "un'": "f" };
const GENDER = { m: "le masculin", f: "le féminin", mp: "le masculin pluriel", fp: "le féminin pluriel" };
const ENDING = { o: "m", a: "f", i: "mp", e: "fp" };
const PERS = [["iamo", "noi"], ["ate", "voi"], ["ete", "voi"], ["ite", "voi"], ["ano", "loro"], ["ono", "loro"], ["o", "io"], ["i", "tu"], ["a", "lui/lei"], ["e", "lui/lei"]];
const persOf = (w) => PERS.find(([e]) => w.endsWith(e) && w.length > e.length + 2);
/** Forme conjuguée connue ? → personne (io, tu…) ou null */
let INF = null;
const infinitives = () => (INF ||= new Set(ALL_LESSONS.flatMap((l) => (l.vocab || []).map((v) => String(v[0]).toLowerCase().trim())).filter((x) => /^[a-zàèéìòù]+(are|ere|ire|arre|urre|orre)(si)?$/.test(x)).map((x) => x.replace(/si$/, "e").replace(/ee$/, "e"))));
const SUBJ_PRON = ["io", "tu", "lui", "lei", "noi", "voi", "loro"];
function verbPerson(w) {
  if (w.length < 2 || SUBJ_PRON.includes(w)) return null;
  for (const inf of new Set([w.replace(/(iamo|ate|ete|ite|ano|ono|isco|isci|isce|iscono|o|i|a|e)$/, "") + "are", w.replace(/(iamo|ate|ete|ite|ano|ono|o|i|a|e)$/, "") + "ere", w.replace(/(iamo|ite|ono|isco|isci|isce|iscono|o|i|e)$/, "") + "ire"]))
    if (infinitives().has(inf)) for (let p = 0; p < 6; p++) if (conjugate(inf, "presente", p)?.show === w) return PERSONS[p];
  return null;
}
const FRENCH = /\b(je|j'|nous|vous|est|avec|pour|dans|c'est|bonjour|merci|très|aujourd'hui|être|avoir)\b|[çêœûî]/;

function wordIt(g, a) {
  if (SUBJ_PRON.includes(g) && SUBJ_PRON.includes(a)) return `Pronom : « ${a} » et non « ${g} ».`;
  // Article
  if (ARTICLES[g] && ARTICLES[a]) {
    const gg = ARTICLES[g], ga = ARTICLES[a];
    if (gg !== "?" && ga !== "?" && gg !== ga && GENDER[gg] && GENDER[ga]) return `Article : vous avez mis ${GENDER[gg]} (« ${g} ») au lieu du ${GENDER[ga].slice(3)} (« ${a} »).`;
    if (a === "lo" || a === "uno" || a === "gli") return `Article : « ${a} » devant un mot qui commence par s + consonne, z, gn, ps, x ou y.`;
    if (a === "l'" || a === "un'") return `Article : devant une voyelle, on élide : « ${a} ».`;
    return `Article : « ${a} » et non « ${g} ».`;
  }
  // Consonne double / simple
  const single = (s) => s.replace(/([a-z])\1/g, "$1");
  if (single(g) === single(a) && g !== a) {
    const m = a.match(/([a-z])\1/g) || [], mg = g.match(/([a-z])\1/g) || [];
    return m.length >= mg.length ? `Consonne double : « ${a} » s'écrit avec « ${m.find((d) => !mg.includes(d)) || m[0]} ».` : `Consonne simple : « ${a} » ne prend pas de double « ${mg.find((d) => !m.includes(d)) || mg[0]} ».`;
  }
  // c/ch, g/gh
  if (g.replace(/h/g, "") === a.replace(/h/g, "") && g !== a) return `Orthographe : « ${a} ». Devant e et i, « ch » / « gh » gardent le son dur (k / g), « c » / « g » le rendent doux.`;
  // Même radical, terminaison différente : accord ou conjugaison
  let k = 0; while (k < g.length && k < a.length && g[k] === a[k]) k++;
  const eg = g.slice(k), ea = a.slice(k);
  const vg = verbPerson(g), va = verbPerson(a);
  if (vg && va && vg !== va) return `Conjugaison : « ${a} » correspond à « ${va} » ; votre forme « ${g} » est celle de « ${vg} ».`;
  // amici / amiche, bianco / bianchi : on compare sans le « h » de ch / gh
  const soft = (s) => s.replace(/([cg])h([ie])$/, "$1$2");
  const hNote = soft(a) !== a || soft(g) !== g ? ` Attention au « h » : « ${a} ».` : "";
  const G2 = soft(g), A2 = soft(a);
  if (G2.length === A2.length && G2.slice(0, -1) === A2.slice(0, -1) && G2.length >= 4 && !(vg || va)) {
    const lg = G2.slice(-1), la = A2.slice(-1);
    if (ENDING[lg] && ENDING[la]) {
      const x = ENDING[lg], y = ENDING[la];
      if (x[0] !== y[0] && x.length === y.length) return `Accord : vous avez mis ${GENDER[x]} (…${lg}) au lieu du ${GENDER[y].slice(3)} (…${la}).${hNote}`;
      if (x[0] === y[0] && x.length !== y.length) return `Accord : il faut le ${y.length > 1 ? "pluriel" : "singulier"} (…${a.slice(-1)}), pas le ${x.length > 1 ? "pluriel" : "singulier"}.${hNote}`;
    }
  }
  if (k >= 3 && eg.length <= 4 && ea.length <= 4) {
    const lg = g.slice(-1), la = a.slice(-1);
    if (g.length === a.length && eg.length === 1 && ENDING[lg] && ENDING[la] && !(vg || va)) {
      const x = ENDING[lg], y = ENDING[la];
      if (x[0] !== y[0] && x.length === y.length) return `Accord : vous avez mis ${GENDER[x]} (…${lg}) au lieu du ${GENDER[y].slice(3)} (…${la}).`;
      if (x[0] === y[0] && x.length !== y.length) return `Accord : il faut le ${y.length > 1 ? "pluriel" : "singulier"} (…${la}), pas le ${x.length > 1 ? "pluriel" : "singulier"}.`;
    }
    const pg = persOf(g), pa = persOf(a);
    if (pg && pa && pg[1] !== pa[1]) return `Conjugaison : « ${a} » correspond à « ${pa[1]} » ; votre forme « ${g} » est celle de « ${pg[1]} ».`;
    return `Presque : la fin du mot n'est pas bonne (« …${ea || "∅"} » attendu, pas « …${eg || "∅"} »).`;
  }
  if (lev(g, a) === 1) return `Une lettre de différence : « ${a} ».`;
  return "";
}

function diagIt(given, ans) {
  const g = words(given), a = words(ans);
  if (!g.length) return "";
  if (FRENCH.test(clean(given)) && !FRENCH.test(clean(ans))) return `Votre réponse semble en français : il faut l'écrire en ${L.label.toLowerCase()}.`;
  if (g.join(" ") !== a.join(" ") && sameBag(g, a)) return "Les bons mots, mais pas dans le bon ordre.";
  const { extra, missing } = diffWords(g, a);
  if (!extra.length && missing.length) return `Il manque ${missing.length > 1 ? "des mots" : "un mot"} : « ${missing.join(" ")} ».`;
  if (!missing.length && extra.length) return `${extra.length > 1 ? "Mots en trop" : "Mot en trop"} : « ${extra.join(" ")} ».`;
  if (extra.length === 1 && missing.length === 1) return wordIt(extra[0], missing[0]) || `« ${missing[0]} » était attendu à la place de « ${extra[0]} ».`;
  if (extra.length <= 2 && missing.length <= 2 && extra.length === missing.length) {
    const notes = extra.map((x, i) => wordIt(x, missing[i])).filter(Boolean);
    if (notes.length) return notes.join(" ");
  }
  return "";
}

/* ------------------------------- Mandarin ----------------------------- */
let SYL = null;
const sylSet = () => (SYL ||= new Set(Object.values(PINYIN_MAP || {}).flatMap((v) => String(v).split(" ")).map((s) => strip(s.toLowerCase()).replace(/[^a-z]/g, "")).filter(Boolean)));
const toneOf = (s) => { for (let t = 0; t < 4; t++) if ([...s].some((c) => TONES[t].includes(c))) return t + 1; return 5; };
/** Découpe un pinyin (avec ou sans espaces) en syllables, en gardant les tons */
function syllables(p) {
  const out = [];
  for (const chunk of clean(p).split(" ")) {
    const bare = strip(chunk).replace(/[^a-z']/g, "");
    let i = 0, pos = 0; // pos : index dans chunk (mêmes longueurs : 1 lettre = 1 lettre)
    const letters = [...chunk].filter((c) => /[a-zāáǎàēéěèīíǐìōóǒòūúǔùǖǘǚǜü']/i.test(c));
    while (i < bare.length) {
      if (bare[i] === "'") { i++; pos++; continue; }
      let len = Math.min(6, bare.length - i), ok = 0;
      for (; len > 0; len--) if (sylSet().has(bare.slice(i, i + len)) && !(len > 1 && /^[aeiou]/.test(bare[i + len] || "") && /[ng]$/.test(bare.slice(i, i + len)) && sylSet().has(bare.slice(i, i + len - 1)))) { ok = len; break; }
      if (!ok) return null;
      out.push(letters.slice(pos, pos + ok).join(""));
      i += ok; pos += ok;
    }
  }
  return out;
}
const PAIRS = [["zh", "z", "zh (langue recourbée) et z sont deux sons différents"], ["ch", "c", "ch (langue recourbée) et c (« ts ») sont deux sons différents"], ["sh", "s", "sh (langue recourbée) et s sont deux sons différents"],
  ["ng", "n", "-ng (son nasal du fond, comme dans « parking ») et -n sont différents"], ["q", "ch", "q se prononce « tch » mouillé, devant i et ü"], ["x", "sh", "x se prononce « ch » mouillé, devant i et ü"], ["j", "zh", "j est mouillé (devant i et ü), zh est rétroflexe"], ["ü", "u", "ü (« u » français) et u (« ou ») sont différents"]];

function diagZh(given, ans) {
  const g = clean(given), a = clean(ans);
  if (!g) return "";
  // Caractères contre caractères
  if (HAN.test(g) && HAN.test(a)) {
    const G = [...g.replace(/\s/g, "")], A = [...a.replace(/\s/g, "")];
    if (G.join("") !== A.join("") && sameBag(G, A)) return "Les bons caractères, mais pas dans le bon ordre. En chinois, le moment et le lieu se placent avant le verbe.";
    if (G.length === A.length) {
      const diff = G.map((c, i) => [c, A[i]]).filter(([x, y]) => x !== y);
      if (diff.length === 1) {
        const [x, y] = diff[0], rx = PINYIN_MAP[x] || "", ry = PINYIN_MAP[y] || "";
        if (rx && ry && strip(rx) === strip(ry)) return `« ${x} » et « ${y} » se prononcent pareil (${ry}) mais ce ne sont pas les mêmes caractères : ici, c'est « ${y} ».`;
        return `Un caractère différent : « ${y} »${ry ? ` (${ry})` : ""} au lieu de « ${x} »${rx ? ` (${rx})` : ""}.`;
      }
    }
    const { extra, missing } = diffWords(G, A);
    if (!extra.length && missing.length) return `Il manque : « ${missing.join("")} ».`;
    if (!missing.length && extra.length) return `En trop : « ${extra.join("")} ».`;
    return "";
  }
  // Pinyin contre pinyin
  if (!HAN.test(g) && !HAN.test(a) && /[a-zāáǎàēéěèīíǐìōóǒòūúǔùǖǘǚǜü]/.test(a)) {
    const sg = syllables(g), sa = syllables(a);
    if (!sg) return /\b(le|la|les|de|est|je|tu|un|une)\b/.test(g) ? "Il faut répondre en chinois : en caractères ou en pinyin." : "";
    if (!sa) return "";
    const typedTones = sg.some((s) => toneOf(s) !== 5);
    if (sg.length === sa.length) {
      const notes = [];
      sg.forEach((s, i) => {
        const t = sa[i], bs = strip(s), bt = strip(t);
        if (bs === bt) { if (typedTones && toneOf(s) !== toneOf(t)) notes.push(`mauvais ton sur « ${bt} » : ${toneOf(s) === 5 ? "pas de ton" : ord(toneOf(s))} au lieu du ${TONE_NAME[toneOf(t)]}`); return; }
        const p = PAIRS.find(([x, y]) => (bs.replace(x, y) === bt.replace(x, y)) && (bs.includes(x) || bt.includes(x)) && bs !== bt);
        notes.push(p ? `« ${t} » et non « ${s} » : ${p[2]}` : `« ${t} » attendu, pas « ${s} »`);
      });
      if (notes.length) return notes.slice(0, 2).map((n, i) => (i ? n : n[0].toUpperCase() + n.slice(1))).join(" ; ") + ".";
    }
    if (strip(sg.join("")) !== strip(sa.join("")) && sameBag(sg.map(strip), sa.map(strip))) return "Les bonnes syllabes, mais pas dans le bon ordre.";
    const { extra, missing } = diffWords(sg.map(strip), sa.map(strip));
    if (!extra.length && missing.length) return `Il manque ${missing.length > 1 ? "des syllabes" : "une syllabe"} : « ${missing.join(" ")} ».`;
    if (!missing.length && extra.length) return `En trop : « ${extra.join(" ")} »${sa.length ? ` (il ne fallait écrire que « ${sa.join(" ")} »)` : ""}.`;
  }
  return "";
}

/* -------------------------------- API ---------------------------------- */
/** Choisit la réponse attendue la plus proche de la réponse donnée (même écriture : caractères / lettres) */
function closest(given, answers) {
  const g = clean(given), han = HAN.test(g);
  const pool = answers.filter((a) => HAN.test(String(a)) === han);
  const list = (pool.length ? pool : answers).map(String);
  // en pinyin : on préfère une réponse avec tons (pour pouvoir parler des tons)
  const toned = (s) => TONES.some((t) => [...s].some((c) => t.includes(c)));
  return list.reduce((best, a) => {
    const d = lev(strip(clean(a)).replace(/\s/g, ""), strip(g).replace(/\s/g, "")) - (toned(a) ? 0.5 : 0);
    return d < best.d ? { a, d } : best;
  }, { a: list[0], d: Infinity }).a;
}

/**
 * Explication d'une mauvaise réponse écrite (ou d'un mauvais choix).
 * @param {string} given  réponse de l'élève
 * @param {string[]} answers  réponses acceptées
 */
export function diagnose(given, answers) {
  try {
    const list = [].concat(answers || []).filter((x) => x != null && String(x).trim());
    if (!String(given ?? "").trim() || !list.length) return "";
    const target = closest(given, list);
    const expectsZh = HAN.test(target) || (L.code === "zh" && /[āáǎàēéěèīíǐìōóǒòūúǔùǖǘǚǜ]/.test(target));
    return expectsZh ? diagZh(given, target) : diagIt(given, target);
  } catch { return ""; }
}
