/* =====================================================================
   distract.js — Choisir de BONNES mauvaises réponses
   ---------------------------------------------------------------------
   Une question à choix n'a d'intérêt que si les mauvaises réponses
   ressemblent à la bonne. On note chaque candidat :
     - même nature (verbe / nom / phrase…), en français et dans la langue ;
     - même genre (italien), même nombre de caractères (mandarin) ;
     - même leçon, sinon même palier (vocabulaire du même thème) ;
     - longueur proche de la bonne réponse ;
     - à l'écoute : mots qui SONNENT pareil (même début, mêmes syllabes).
   On écarte les candidats qui pourraient aussi être justes (synonymes,
   sens qui se recoupent) pour ne jamais avoir deux bonnes réponses.
   Un peu de hasard garde des questions variées d'un essai à l'autre.
   ===================================================================== */
import { code } from "./lang.js";

const zh = () => code === "zh";
const HAN = /[㐀-鿿]/g;
const fold = (s) => String(s || "").normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase().replace(/[’]/g, "'");
const cleanFr = (fr) => String(fr || "").split(" — ")[0];
const ART_IT = /^(il|lo|la|i|gli|le|l'|un|uno|una|un')\s*/i;
const ART_FR = /^(le|la|les|l'|un|une|des|du)\s*/i;
const FEM_IT = /^(la|le|una|un')\s*/i;
const STOP = new Set("le la les l un une des du de d et ou a au aux en dans sur pour par avec sans ce cet cette ces se s ne pas plus que qui quoi est etre avoir faire tres bien chose quelque quelqu on il elle ils elles je tu nous vous me te lui leur y son sa ses mon ma mes ton ta tes".split(" "));

/** Nature d'un sens français : phrase, nom, verbe, adjectif/adverbe, expression */
function kindFr(fr) {
  const f = cleanFr(fr).trim();
  if (/…|\.\.\./.test(f) || /^(parce qu|bien qu|puisqu|pour qu|afin qu|alors|donc|mais|ou bien|si |même si|quand |lorsqu|depuis qu|avant qu|après qu|sans qu|à moins qu|dès qu|tandis qu|pourtant|cependant|néanmoins|ainsi|d'abord|ensuite|enfin|non seulement|ni |soit |plus .* plus|à la fois|c'est pourquoi|au contraire|en effet|en fait|par contre|or )/i.test(f)) return "liaison";
  if (/^(particule|cl\.|classificateur|marque|marqueur|suffixe|préfixe|mot de mesure|spécificatif)/i.test(f)) return "gram";
  if (/^(qui|que|quoi|où|quand|comment|pourquoi|combien|quel|quelle|lequel)\b/i.test(f) && !/[!.]$/.test(f)) return "question";
  if (/^(je|tu|il|elle|nous|vous|ils|elles|moi|toi|lui|eux|ce|cela|ça|ceci|celui|celle)$/i.test(f.split(/[,(]/)[0].trim())) return "pronom";
  if (/^(vraiment|seulement|rapidement|lentement|simplement|finalement|heureusement|malheureusement|probablement|évidemment|absolument|exactement|immédiatement|récemment|actuellement|généralement|longtemps|très|trop|assez|beaucoup|peu|déjà|encore|toujours|jamais|souvent|parfois|ici|là|bientôt|tôt|tard|aussi|seulement|surtout|presque|vraiment|plutôt|même|ensemble|maintenant|hier|demain|aujourd'hui)\b/i.test(f)) return "adverbe";
  if (/[?!.…]$/.test(f) && f.split(/\s+/).length > 1) return "phrase";
  if (ART_FR.test(f)) return "nom";
  if (/^\d|^(un|deux|trois|quatre|cinq|six|sept|huit|neuf|dix|onze|douze|vingt|trente|cent|mille)\b/i.test(f)) return "nombre";
  if (/^(lundi|mardi|mercredi|jeudi|vendredi|samedi|dimanche|janvier|février|mars|avril|mai|juin|juillet|août|septembre|octobre|novembre|décembre)\b/i.test(f)) return "date";
  if (isVerbFr(f)) return "verbe";
  if (f.split(/\s+/).length >= 4) return "expr";
  return "autre";
}
/* Verbe à l'infinitif ? (« heure », « novembre », « papier », « soir » n'en sont pas) */
const NOUN_EXC = new Set("hiver mer fer cher amer hier fier enfer super cancer poster ver plaisir désir loisir avenir saphir lettre mètre théâtre fenêtre centre autre quatre ministre titre montre rencontre votre notre spectre litre empire navire délire".split(" "));
const OIR_V = new Set("voir avoir savoir pouvoir vouloir devoir recevoir falloir valoir pleuvoir asseoir apercevoir émouvoir prévoir revoir décevoir concevoir".split(" "));
const IER_V = new Set("étudier oublier remercier apprécier publier copier crier marier prier plier confier envier lier nier skier sacrifier".split(" "));
function isVerbFr(f) {
  const t = fold(f).replace(/^(se |s'|ne pas |ne plus )/, "").split(/[\s,(;/]/)[0];
  const raw = String(f).toLowerCase().replace(/^(se |s'|ne pas |ne plus )/, "").split(/[\s,(;/]/)[0];
  if (!t || NOUN_EXC.has(raw)) return false;
  if (/oir$/.test(t)) return OIR_V.has(t) || OIR_V.has(raw);
  if (/ier$/.test(t)) return IER_V.has(raw) || /ifier$/.test(t);
  if (/(er|ir)$/.test(t)) return true;
  if (/(dre|ttre|aitre|oitre|ivre|uire|ire)$/.test(t)) return true;
  return /^(faire|plaire|taire|boire|croire|etre|vaincre|rompre|conclure|exclure|inclure|refaire|defaire)$/.test(t);
}
/** Nature d'un mot italien */
function kindIt(w) {
  const t = String(w).trim();
  if (/[?!.]$/.test(t) || t.split(/\s+/).length >= 4) return "phrase";
  if (ART_IT.test(t)) return "nom";
  if (/^[a-zàèéìòù']+(are|ere|ire|rre)(si|ci|ne)?(\s+(di|a|da|in|con|per|su))?$/i.test(t)) return "verbe";
  if (t.split(/\s+/).length >= 2) return "expr";
  return "autre";
}

const shapes = new Map();
function shape(x) {
  const k = `${x.zh}|${x.fr}`;
  let s = shapes.get(k);
  if (s) return s;
  const frc = cleanFr(x.fr);
  s = {
    kfr: kindFr(frc), kw: zh() ? "" : kindIt(x.zh),
    fem: !zh() && FEM_IT.test(x.zh), plural: !zh() && /^(i|gli|le)\s/i.test(x.zh),
    nch: zh() ? (String(x.zh).match(HAN) || []).length : 0, dots: /…|\.\.\./.test(x.zh),
    tok: new Set(fold(frc).replace(/\([^)]*\)/g, " ").split(/[^a-z0-9]+/).filter((t) => t.length > 2 && !STOP.has(t))),
    sound: zh() ? fold(x.py || "").replace(/[^a-z ]/g, "").trim() : fold(String(x.zh).replace(ART_IT, "")),
  };
  if (shapes.size > 6000) shapes.clear();
  shapes.set(k, s);
  return s;
}

/** Les deux sens se recoupent-ils (risque de deux bonnes réponses) ? */
function overlaps(a, b) {
  const A = shape(a).tok, B = shape(b).tok;
  for (const t of A) if (B.has(t)) return true;
  const fa = fold(cleanFr(a.fr)), fb = fold(cleanFr(b.fr));
  return fa === fb || (fa.length > 3 && fb.includes(fa)) || (fb.length > 3 && fa.includes(fb));
}

/** Ressemblance à l'oreille (0 à 1) : début commun, syllabes communes */
function soundLike(a, b) {
  const x = shape(a).sound, y = shape(b).sound;
  if (!x || !y) return 0;
  let p = 0; while (p < x.length && p < y.length && x[p] === y[p]) p++;
  let s = p / Math.max(x.length, y.length);
  if (zh()) {
    const sx = x.split(" "), sy = new Set(y.split(" "));
    s += sx.filter((t) => sy.has(t)).length / Math.max(sx.length, 1) * 0.8;
    if (sx.length === y.split(" ").length) s += 0.2;
  } else {
    if (x.slice(-3) === y.slice(-3)) s += 0.25;               // même terminaison (-are, -zione…)
    if (Math.abs(x.length - y.length) <= 2) s += 0.2;
  }
  return Math.min(1, s);
}

/**
 * Choisit n mauvaises réponses plausibles pour le mot w dans pool.
 * @param {object} w      le mot de la question { zh, py, fr, lessonId, levelId }
 * @param {object[]} pool mots candidats
 * @param {number} n
 * @param {object} o      key : ce qui est affiché (doit être différent de la bonne réponse)
 *                        mode : "fr" (on affiche les sens), "word" (les mots), "sound" (écoute)
 */
export function pickDistractors(w, pool, n, { key = (x) => x.zh, mode = "fr" } = {}) {
  const right = key(w), S = shape(w), lenR = String(right).length;
  const seen = new Set([fold(right)]);
  const scored = [];
  for (const x of pool) {
    if (!x || x === w || x.zh === w.zh) continue;
    const k = key(x);
    if (!k || seen.has(fold(k))) continue;
    if (overlaps(w, x)) continue;                                   // pourrait aussi être juste
    const T = shape(x);
    let s = 0;
    if (T.kfr === S.kfr) s += 3;
    if (zh()) {
      if (T.nch === S.nch) s += 3; else if (Math.abs(T.nch - S.nch) === 1) s += 1;
      if (T.dots !== S.dots) s -= 3;
    } else {
      if (T.kw === S.kw) s += 2.5;
      if (S.kw === "nom" && T.kw === "nom") s += (T.fem === S.fem ? 1 : 0) + (T.plural === S.plural ? 0.5 : 0);
    }
    if (w.lessonId && x.lessonId === w.lessonId) s += 2;
    else if (w.levelId && x.levelId === w.levelId) s += 1;
    const lk = String(k).length;
    s += 2 * (Math.min(lk, lenR) / Math.max(lk, lenR, 1));          // longueur proche
    if (mode === "sound" || mode === "word") s += (mode === "sound" ? 5 : 1.5) * soundLike(w, x);
    s += Math.random() * 1.6;                                       // variété
    scored.push([s, x, k]);
  }
  scored.sort((a, b) => b[0] - a[0]);
  const out = [];
  for (const [, x, k] of scored) {
    const f = fold(k);
    if (seen.has(f)) continue;
    // deux leurres qui se recoupent entre eux : on garde le premier
    if (out.some((y) => overlaps(x, y))) continue;
    seen.add(f); out.push(x);
    if (out.length === n) break;
  }
  return out;
}

/* ----------------------- Phrases (épreuve type CELI/HSK) ----------------------- */
const words = (s) => new Set(fold(s).split(/[^a-z0-9]+/).filter((t) => t.length > 3 && !STOP.has(t)));
/**
 * Traductions de phrases plausibles : longueur proche, même leçon si possible,
 * et assez différentes pour ne pas être justes aussi.
 * @param {{fr:string, ref?:string}} good
 */
export function pickSentenceDistractors(good, pool, n = 3) {
  const g = words(good.fr), L = good.fr.length;
  const scored = [];
  const seen = new Set([fold(good.fr)]);
  for (const x of pool) {
    if (!x.fr || seen.has(fold(x.fr))) continue;
    const xw = words(x.fr);
    let common = 0; for (const t of xw) if (g.has(t)) common++;
    if (common / Math.max(1, Math.min(g.size, xw.size)) > 0.5) continue; // trop proche : pourrait être juste
    let s = 3 * (Math.min(L, x.fr.length) / Math.max(L, x.fr.length));
    if (good.ref && x.ref === good.ref) s += 1.5;
    if (/\?$/.test(good.fr) === /\?$/.test(x.fr)) s += 1;
    if (common) s += 0.5;                                           // même sujet, sans être la même phrase
    s += Math.random() * 1.2;
    scored.push([s, x.fr]);
  }
  scored.sort((a, b) => b[0] - a[0]);
  const out = [];
  for (const [, fr] of scored) { const f = fold(fr); if (seen.has(f)) continue; seen.add(f); out.push(fr); if (out.length === n) break; }
  return out;
}
