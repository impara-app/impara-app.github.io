/* hanzi.js — Ordre des traits des caractères chinois (bibliothèque HanziWriter, chargée à la demande) */
let HW = null;
export const loadWriter = () => (HW ||= import("https://cdn.jsdelivr.net/npm/hanzi-writer@3.5.0/+esm").then((m) => m.default || m.HanziWriter));
const css = (v, d) => getComputedStyle(document.documentElement).getPropertyValue(v).trim() || d;

/**
 * Anime l'ordre des traits de chaque caractère de `word` dans `box`, l'un après l'autre.
 * Toucher un caractère relance son animation.
 */
export async function strokeAnim(box, word, { size = 88 } = {}) {
  const chars = [...word].filter((c) => /[㐀-鿿]/.test(c)).slice(0, 4);
  if (!chars.length || !box) return;
  box.innerHTML = `<p class="muted small">Ordre des traits…</p>`;
  let HanziWriter;
  try { HanziWriter = await loadWriter(); } catch { box.innerHTML = ""; return; }
  box.innerHTML = "";
  const writers = [];
  for (const c of chars) {
    const cell = document.createElement("button");
    cell.type = "button"; cell.className = "stroke-cell"; cell.setAttribute("aria-label", `Ordre des traits de ${c}`);
    box.appendChild(cell);
    const w = HanziWriter.create(cell, c, {
      width: size, height: size, padding: 6, showOutline: true, showCharacter: false,
      strokeColor: css("--ink", "#1d2733"), outlineColor: css("--line", "#e7e1d5"), radicalColor: "#c23b32",
      strokeAnimationSpeed: 1.4, delayBetweenStrokes: 140,
      onLoadCharDataError: () => cell.remove(),
    });
    cell.onclick = () => w.animateCharacter();
    writers.push(w);
  }
  for (const w of writers) { if (!box.isConnected) return; await new Promise((r) => w.animateCharacter({ onComplete: r })); }
}
