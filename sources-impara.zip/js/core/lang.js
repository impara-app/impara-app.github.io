/* =====================================================================
   lang.js — Registre des langues enseignées
   ---------------------------------------------------------------------
   Chaque langue fournit : son contenu (js/data/<code>.js), son thème,
   sa voix, son clavier de saisie et ses textes d'interface.
   Pour ajouter une langue (ex. espagnol) :
     1. créez js/data/es.js sur le modèle de it.js ;
     2. ajoutez une entrée « es » ci-dessous ;
     3. ajoutez son import dans js/data/curriculum.js.
   La langue active est mémorisée (localStorage, avec repli window.name)
   et chaque langue a sa propre sauvegarde de progression.
   ===================================================================== */
import "./migrate.js"; // doit passer avant toute lecture du localStorage
import { SPEAK_FILTER } from "./speechkey.js";

/** Petite étoile SVG (pour le drapeau chinois) */
function star(cx, cy, r, rot = -90) {
  const pts = [];
  for (let i = 0; i < 10; i++) {
    const a = ((rot + i * 36) * Math.PI) / 180, rr = i % 2 ? r * 0.4 : r;
    pts.push(`${(cx + rr * Math.cos(a)).toFixed(2)},${(cy + rr * Math.sin(a)).toFixed(2)}`);
  }
  return `<polygon fill="#ffde00" points="${pts.join(" ")}"/>`;
}

const FLAGS = {
  it: `<svg viewBox="0 0 3 2" aria-hidden="true"><rect width="1" height="2" fill="#1e8e5a"/><rect x="1" width="1" height="2" fill="#fff"/><rect x="2" width="1" height="2" fill="#d2483f"/></svg>`,
  zh: `<svg viewBox="0 0 30 20" aria-hidden="true"><rect width="30" height="20" fill="#de2910"/>${star(5, 5, 3)}${star(10, 2, 1, -60)}${star(12, 4, 1, -30)}${star(12, 7, 1, 0)}${star(10, 9, 1, 30)}</svg>`,
};
export const flagSVG = (code) => FLAGS[code] || "";

export const LANGS = {
  it: {
    code: "it", label: "Italien", native: "Italiano", brand: "Impara",
    title: "Impara — Apprendre l'italien de A1 à C2", themeColor: "#1e8e5a",
    storageKey: "impara.state.v1",
    speech: "it-IT", voice: "it", rate: 0.9, speakFilter: null,
    keyboard: "accents", wordClass: "", looseNote: "Attention aux accents",
    hello: "Ciao", heroEm: "l'italien courant", done: "complimenti !", goalDone: "bravissimo",
    onboardEyebrow: "Benvenuto · Bienvenue", onboardTitle: "Apprenez l'italien,",
    onboardLead: "6 paliers CECRL (A1 → C2), des mini-leçons claires, des quiz corrigés instantanément et un suivi de vos progrès.",
    start: "Iniziamo ! Commencer →", namePh: "ex. Giulia",
    cheers: ["Bravo !", "Perfetto !", "Esatto !", "Ottimo !"],
    resultHeads: ["Bravo !", "Perfetto !", "Ottimo lavoro !"], almost: "Presque !",
    finished: "Vous avez terminé tout le parcours. Complimenti !",
    trLabel: "Traduisez en italien", trPlaceholder: "Écrivez en italien…",
    search: "Rechercher (italien ou français)…", cardFront: "Italien", cardHint: "Touchez pour voir la traduction",
    tts: "Prononciation audio des mots (🔊)",
    avatars: ["🦊", "🐱", "🐼", "🦁", "🐸", "🦉", "🐙", "🍕", "🛵", "🎭", "🏛️", "🌋", "🍋", "⚽", "🎨", "🦄"],
    confetti: ["#1e8e5a", "#d2483f", "#f4f1ea", "#3b5b7a", "#e8b04b"],
  },
  zh: {
    code: "zh", label: "Mandarin", native: "中文", brand: "Xuéxí",
    title: "Xuéxí 学习 — Apprendre le mandarin du HSK 1 au HSK 6", themeColor: "#c23b32",
    storageKey: "xuexi.state.v1",
    speech: "zh-CN", voice: "zh", rate: 0.8,
    speakFilter: SPEAK_FILTER.zh, // on ne lit que les caractères
    keyboard: "tones", wordClass: "zh", looseNote: "Attention aux tons",
    hello: "你好", heroEm: "le chinois courant", done: "恭喜！", goalDone: "太棒了",
    onboardEyebrow: "欢迎 huānyíng · Bienvenue", onboardTitle: "Apprenez le mandarin,",
    onboardLead: "6 niveaux HSK (HSK 1 → HSK 6), caractères + pinyin, prononciation audio, quiz corrigés instantanément et suivi de vos progrès.",
    start: "开始吧 ! Commencer →", namePh: "ex. Léa",
    cheers: ["Bravo ! 很好！", "Parfait ! 太棒了！", "Exact ! 对了！", "Excellent ! 真棒！"],
    resultHeads: ["Bravo ! 好！", "Très bien ! 很好！", "Parfait ! 太棒了！"], almost: "Presque ! 差一点！",
    finished: "Vous avez terminé tout le parcours. 恭喜你！",
    trLabel: "Répondez en chinois (pinyin ou caractères)", trPlaceholder: "ex. nǐ hǎo ou 你好",
    search: "Rechercher (汉字, pinyin ou français)…", cardFront: "汉字 · Caractères", cardHint: "Touchez pour voir le pinyin et la traduction",
    tts: "Prononciation audio en mandarin (🔊)",
    avatars: ["🐼", "🐉", "🐯", "🦊", "🐒", "🐱", "🦉", "🐲", "🏮", "🥟", "🍵", "🎋", "🧧", "🌸", "🏯", "🪁"],
    confetti: ["#c23b32", "#d9a441", "#f6e3b4", "#2a8a66", "#8f2a23"],
  },
};

const PREF_KEY = "impara.lang";

function readLang() {
  try { const v = localStorage.getItem(PREF_KEY); if (v && LANGS[v]) return v; } catch {}
  const m = /(?:^|;)lang=(\w+)/.exec(window.name || "");
  return m && LANGS[m[1]] ? m[1] : "it";
}

/** Code et configuration de la langue active */
export const code = readLang();
export const L = LANGS[code];

/** Change de langue : mémorise le choix puis recharge l'application */
export function setLang(next, hash = "parcours") {
  if (!LANGS[next] || next === code) return;
  try { localStorage.setItem(PREF_KEY, next); } catch {}
  window.name = `lang=${next}`; // repli si localStorage est indisponible
  location.hash = hash;
  location.reload();
}

// Applique le thème et les métadonnées dès le chargement
document.documentElement.lang = "fr";
document.body.classList.add(`lang-${code}`);
document.title = L.title;
document.querySelector('meta[name="theme-color"]')?.setAttribute("content", L.themeColor);
