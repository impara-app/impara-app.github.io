/* =====================================================================
   mascot.js — Les mascottes d'Impara (dessins SVG originaux)
   - Italien  : Volpina, une petite renarde
   - Mandarin : Bao (宝), un petit panda
   Humeurs : idle · happy · cheer · sad · think
   ===================================================================== */
import { code } from "./lang.js";

export const MASCOTS = {
  it: { name: "Volpina", kind: "fox" },
  zh: { name: "Bao", kind: "panda" },
};
export const mascotName = () => (MASCOTS[code] || MASCOTS.it).name;

/* ------------------------------ Visage ------------------------------ */
function eyes(mood, ink, y = 60, dx = 15) {
  const L = 60 - dx, R = 60 + dx;
  if (mood === "happy" || mood === "cheer")
    return `<g class="m-eyes" fill="none" stroke="${ink}" stroke-width="4" stroke-linecap="round">
      <path d="M${L - 6},${y + 2} Q${L},${y - 6} ${L + 6},${y + 2}"/><path d="M${R - 6},${y + 2} Q${R},${y - 6} ${R + 6},${y + 2}"/></g>`;
  if (mood === "sad")
    return `<g class="m-eyes"><ellipse cx="${L}" cy="${y + 2}" rx="5" ry="5.5" fill="${ink}"/><ellipse cx="${R}" cy="${y + 2}" rx="5" ry="5.5" fill="${ink}"/>
      <path d="M${L - 8},${y - 5} L${L + 5},${y - 10}" stroke="${ink}" stroke-width="3" stroke-linecap="round"/><path d="M${R + 8},${y - 5} L${R - 5},${y - 10}" stroke="${ink}" stroke-width="3" stroke-linecap="round"/>
      <path d="M${R + 3},${y + 8} q3,6 0,9 q-3,-3 0,-9z" fill="#7cc4f2"/></g>`;
  const look = mood === "think" ? -3 : 0;
  return `<g class="m-eyes"><ellipse cx="${L}" cy="${y}" rx="5.5" ry="6.5" fill="${ink}"/><ellipse cx="${R}" cy="${y}" rx="5.5" ry="6.5" fill="${ink}"/>
    <circle cx="${L + 1.8}" cy="${y - 2.5 + look}" r="2" fill="#fff"/><circle cx="${R + 1.8}" cy="${y - 2.5 + look}" r="2" fill="#fff"/></g>`;
}
function mouth(mood, ink, y = 82) {
  if (mood === "sad") return `<path d="M52,${y + 4} Q60,${y - 3} 68,${y + 4}" fill="none" stroke="${ink}" stroke-width="3" stroke-linecap="round"/>`;
  if (mood === "think") return `<ellipse cx="62" cy="${y + 1}" rx="3.5" ry="3" fill="${ink}"/>`;
  if (mood === "happy" || mood === "cheer")
    return `<path d="M50,${y - 1} Q60,${y + 13} 70,${y - 1} Z" fill="${ink}"/><path d="M55,${y + 5} Q60,${y + 10} 65,${y + 5} Z" fill="#ff7b8a"/>`;
  return `<path d="M53,${y} Q60,${y + 6} 67,${y}" fill="none" stroke="${ink}" stroke-width="3" stroke-linecap="round"/>`;
}
const paws = (color, mood) => mood === "cheer"
  ? `<g class="m-paws"><ellipse cx="18" cy="70" rx="9" ry="12" fill="${color}" transform="rotate(-25 18 70)"/><ellipse cx="102" cy="70" rx="9" ry="12" fill="${color}" transform="rotate(25 102 70)"/>
     <text x="8" y="26" font-size="14">✨</text><text x="98" y="22" font-size="12">✨</text></g>` : "";

/* ------------------------------ Renarde ----------------------------- */
function fox(mood) {
  const ink = "#2b1d14";
  return `
  ${paws("#f08a2c", mood)}
  <g class="m-head">
    <path d="M22,48 L30,10 L52,34 Z" fill="#f08a2c"/><path d="M29,38 L33,19 L45,33 Z" fill="#3a2418"/>
    <path d="M98,48 L90,10 L68,34 Z" fill="#f08a2c"/><path d="M91,38 L87,19 L75,33 Z" fill="#3a2418"/>
    <ellipse cx="60" cy="66" rx="42" ry="38" fill="#f5913a"/>
    <path d="M18,66 Q34,104 60,104 Q86,104 102,66 Q86,76 72,72 Q60,86 48,72 Q34,76 18,66 Z" fill="#fff6ec"/>
    <ellipse cx="34" cy="80" rx="7" ry="4.5" fill="#ffb3a7" opacity=".7"/><ellipse cx="86" cy="80" rx="7" ry="4.5" fill="#ffb3a7" opacity=".7"/>
    ${eyes(mood, ink)}
    <ellipse cx="60" cy="74" rx="6" ry="4.5" fill="${ink}"/>
    ${mouth(mood, ink, 84)}
  </g>`;
}

/* ------------------------------- Panda ------------------------------ */
function panda(mood) {
  const ink = "#1f2328";
  return `
  ${paws("#2a2e33", mood)}
  <g class="m-head">
    <circle cx="28" cy="30" r="15" fill="#2a2e33"/><circle cx="92" cy="30" r="15" fill="#2a2e33"/>
    <circle cx="28" cy="30" r="7" fill="#4a4f56"/><circle cx="92" cy="30" r="7" fill="#4a4f56"/>
    <ellipse cx="60" cy="64" rx="44" ry="40" fill="#ffffff" stroke="#e3e6ea" stroke-width="2"/>
    <ellipse cx="43" cy="61" rx="12" ry="15" fill="#2a2e33" transform="rotate(25 43 61)"/>
    <ellipse cx="77" cy="61" rx="12" ry="15" fill="#2a2e33" transform="rotate(-25 77 61)"/>
    ${eyes(mood, "#ffffff", 60, 16).replace(/fill="#fff"/g, `fill="${ink}"`)}
    <ellipse cx="38" cy="82" rx="7" ry="4.5" fill="#ffb3c2" opacity=".75"/><ellipse cx="82" cy="82" rx="7" ry="4.5" fill="#ffb3c2" opacity=".75"/>
    <ellipse cx="60" cy="76" rx="6" ry="4.5" fill="${ink}"/>
    ${mouth(mood, ink, 86)}
    <path d="M52,16 q8,-10 16,0" fill="none" stroke="#3aa35c" stroke-width="3" stroke-linecap="round"/><ellipse cx="66" cy="12" rx="6" ry="3" fill="#3aa35c" transform="rotate(-20 66 12)"/>
  </g>`;
}

/**
 * SVG de la mascotte de la langue active.
 * @param {"idle"|"happy"|"cheer"|"sad"|"think"} mood
 */
export function mascot(mood = "idle", { size = 96, cls = "", lang = code } = {}) {
  const kind = (MASCOTS[lang] || MASCOTS.it).kind;
  return `<svg class="mascot m-${mood} ${cls}" width="${size}" height="${size}" viewBox="0 0 120 120" role="img" aria-label="${(MASCOTS[lang] || MASCOTS.it).name}">${kind === "panda" ? panda(mood) : fox(mood)}</svg>`;
}

/* ---------------------------- Répliques ----------------------------- */
const LINES = {
  welcome: { it: ["Ciao ! On continue ?", "Pronto ? Andiamo !", "Un petit pas chaque jour 🇮🇹"], zh: ["你好！On continue ?", "加油 jiāyóu ! Allez !", "Un caractère après l'autre 🐼"] },
  good: { it: ["Bravissimo !", "Perfetto !", "Ottimo !"], zh: ["太棒了 ! Super !", "对了 ! C'est ça !", "很好 !"] },
  bad: { it: ["Pas grave, on réessaie !", "Coraggio !", "Ça viendra 💪"], zh: ["没关系 ! Pas grave !", "加油 ! Courage !", "Ça viendra 💪"] },
  win: { it: ["Che bravo ! Je suis fière de toi !", "Leçon dans la poche !", "Fantastico !"], zh: ["太好了 ! Je suis fier de toi !", "Leçon réussie !", "厉害 lìhai ! Impressionnant !"] },
  fail: { it: ["Presque ! On la refait ensemble ?", "Relis la leçon, tu vas y arriver !"], zh: ["差一点 ! Presque !", "On révise et on recommence !"] },
  streak: { it: ["Ta série brûle 🔥", "Ne la laisse pas s'éteindre !"], zh: ["Ta série brûle 🔥", "Reviens demain, je t'attends !"] },
};
export const line = (key) => { const l = LINES[key]?.[code] || LINES[key]?.it || [""]; return l[Math.floor(Math.random() * l.length)]; };

/* ------------------- Mascotte le long du parcours ------------------- */
/* Accessoires dessinés (viewBox 0 0 64 64), posés à côté de la mascotte */
const PROPS = {
  suitcase: `<rect x="8" y="22" width="48" height="34" rx="7" fill="#c8794a"/><rect x="8" y="22" width="48" height="34" rx="7" fill="none" stroke="#8a4f2b" stroke-width="3"/>
    <path d="M24 22v-6a4 4 0 0 1 4-4h8a4 4 0 0 1 4 4v6" fill="none" stroke="#8a4f2b" stroke-width="4" stroke-linecap="round"/>
    <rect x="8" y="34" width="48" height="5" fill="#8a4f2b" opacity=".45"/><circle cx="20" cy="47" r="5" fill="#f5c64e"/><rect x="34" y="43" width="14" height="8" rx="2" fill="#3b82c4"/>`,
  book: `<path d="M6 16q13-6 26 2v38q-13-8-26-2z" fill="#3b82c4"/><path d="M58 16q-13-6-26 2v38q13-8 26-2z" fill="#5aa0e0"/>
    <path d="M10 22q9-3 18 2M10 30q9-3 18 2M36 24q9-5 18-2M36 32q9-5 18-2" stroke="#fff" stroke-width="2.5" stroke-linecap="round" opacity=".8" fill="none"/>`,
  camera: `<rect x="6" y="20" width="52" height="34" rx="8" fill="#2b3a4a"/><rect x="20" y="13" width="18" height="10" rx="3" fill="#2b3a4a"/>
    <circle cx="32" cy="37" r="11" fill="#9fc4e8" stroke="#fff" stroke-width="4"/><circle cx="35" cy="34" r="3" fill="#fff" opacity=".8"/><circle cx="49" cy="27" r="2.5" fill="#f5c64e"/>`,
  espresso: `<path d="M18 18q2-6 0-10M28 18q2-6 0-10M38 18q2-6 0-10" stroke="#b8c2cc" stroke-width="3" stroke-linecap="round" fill="none"/>
    <path d="M10 24h40l-4 22a8 8 0 0 1-8 7H22a8 8 0 0 1-8-7z" fill="#fff" stroke="#d9d2c5" stroke-width="2"/><ellipse cx="30" cy="25" rx="19" ry="3.5" fill="#6b3f22"/>
    <path d="M49 30h4a6 6 0 0 1 0 12h-6" fill="none" stroke="#d9d2c5" stroke-width="4"/><ellipse cx="30" cy="57" rx="24" ry="4" fill="#e7e1d5"/>`,
  gelato: `<path d="M20 30l12 30 12-30z" fill="#e3a65a"/><path d="M22 34l18 0M25 42l12 0M28 50l6 0" stroke="#b97a33" stroke-width="2" fill="none"/>
    <circle cx="25" cy="25" r="10" fill="#ff9fb8"/><circle cx="39" cy="25" r="10" fill="#bfe8b5"/><circle cx="32" cy="15" r="10" fill="#fff1c9"/><circle cx="34" cy="7" r="3" fill="#d2483f"/>`,
  pennant_it: `<path d="M12 6v54" stroke="#7a5a3a" stroke-width="4" stroke-linecap="round"/><path d="M14 8l42 14-42 14z" fill="#fff"/><path d="M14 8l14 4.7v18.6L14 36z" fill="#009246"/><path d="M42 17.3L56 22l-14 4.7z" fill="#ce2b37"/>`,
  tea: `<path d="M20 16q2-5 0-9M32 16q2-5 0-9" stroke="#b8c2cc" stroke-width="3" stroke-linecap="round" fill="none"/>
    <path d="M10 22h40l-5 26a8 8 0 0 1-8 6H23a8 8 0 0 1-8-6z" fill="#f4f1e8" stroke="#3a7d6a" stroke-width="2.5"/><path d="M14 31h32" stroke="#3a7d6a" stroke-width="3"/>
    <ellipse cx="30" cy="23" rx="19" ry="3.5" fill="#b9d98a"/><path d="M22 40q8 4 16 0" stroke="#c23b32" stroke-width="2.5" fill="none"/>`,
  lantern: `<path d="M32 2v8" stroke="#7a5a3a" stroke-width="3"/><rect x="24" y="9" width="16" height="5" rx="2" fill="#f2c14e"/>
    <ellipse cx="32" cy="32" rx="20" ry="19" fill="#d0152f"/><path d="M22 16q-6 16 0 32M42 16q6 16 0 32M32 13v38" stroke="#a90d24" stroke-width="2.5" fill="none"/>
    <rect x="24" y="49" width="16" height="5" rx="2" fill="#f2c14e"/><path d="M28 54v8M32 54v9M36 54v8" stroke="#f2c14e" stroke-width="2.5" stroke-linecap="round"/>`,
  bao: `<ellipse cx="32" cy="56" rx="26" ry="5" fill="#c9a77a"/><path d="M8 50q0-26 24-28q24 2 24 28z" fill="#fbf4e6" stroke="#e1d3b8" stroke-width="2"/>
    <path d="M32 22q-4 8 0 14q4-6 0-14M24 26q2 8 6 10M40 26q-2 8-6 10" stroke="#e1d3b8" stroke-width="2.5" fill="none" stroke-linecap="round"/><ellipse cx="22" cy="44" rx="4" ry="2.5" fill="#ffb3c2" opacity=".7"/>`,
};
const BUDDY_SETS = {
  it: [["suitcase", "happy"], ["espresso", "idle"], ["book", "think"], ["gelato", "happy"], ["camera", "idle"], ["pennant_it", "cheer"]],
  zh: [["suitcase", "happy"], ["tea", "idle"], ["book", "think"], ["lantern", "happy"], ["bao", "idle"], ["camera", "cheer"]],
};
/** Mascotte décorative du parcours (n = numéro d'apparition, pour varier l'accessoire) */
export function buddy(n, { lang = code } = {}) {
  const set = BUDDY_SETS[lang] || BUDDY_SETS.it;
  const [prop, mood] = set[n % set.length];
  return `${mascot(mood, { size: 92, lang, cls: "bd-m" })}<svg class="bd-prop" viewBox="0 0 64 64" width="50" height="50" aria-hidden="true">${PROPS[prop]}</svg>`;
}
