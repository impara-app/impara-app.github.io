/* =====================================================================
   migrate.js — Arrivée depuis l'ancienne adresse (thomasmzzzz.github.io/impara)
   L'ancienne page envoie tout son localStorage (compressé) dans l'ancre
   #migrate=… : on le recopie ici AVANT que l'appli ne lise ses données.
   Une donnée déjà présente ici n'est remplacée que si celle reçue est plus
   récente (updatedAt), pour ne jamais écraser une progression.
   ===================================================================== */
export const MOVED_KEY = "impara.movedNotice";

const b64dec = (s) => {
  const bin = atob(s.replace(/-/g, "+").replace(/_/g, "/") + "===".slice((s.length + 3) % 4));
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
};

if (location.hash.startsWith("#migrate=")) {
  const params = new URLSearchParams(location.hash.slice(1));
  const p = params.get("migrate") || "", then = params.get("then") || "";
  try {
    const bytes = b64dec(p.slice(1));
    const json = p[0] === "z"
      ? await new Response(new Blob([bytes]).stream().pipeThrough(new DecompressionStream("deflate-raw"))).text()
      : new TextDecoder().decode(bytes);
    const data = JSON.parse(json);
    for (const [k, v] of Object.entries(data)) {
      if (typeof v !== "string") continue;
      const cur = localStorage.getItem(k);
      if (cur == null) { localStorage.setItem(k, v); continue; }
      try {
        const a = JSON.parse(cur), b = JSON.parse(v);
        if (a && b && typeof a === "object" && typeof b === "object" && (b.updatedAt || 0) > (a.updatedAt || 0)) localStorage.setItem(k, v);
      } catch {}
    }
    localStorage.setItem(MOVED_KEY, "1");
  } catch (e) { console.warn("migration", e); }
  history.replaceState(null, "", location.pathname + location.search + (then ? `#${then}` : ""));
}
