/* =====================================================================
   offline.js — Télécharger un palier pour le hors-ligne
   Les pages de l'appli sont déjà gardées par le service worker ; ici on
   ajoute l'audio : toutes les phrases enregistrées d'un palier (mots,
   exemples, quiz, histoires) sont copiées sur l'appareil.
   ===================================================================== */
import { LEVELS } from "../data/curriculum.js";
import { L, code } from "./lang.js";
import { speechText } from "./speechkey.js";
import { mainVoice, otherVoice, clipsFor, downloadClips, removeClips } from "./audio.js";

const KEY = `offline.${code}`;
export function offlineState() { try { return JSON.parse(localStorage.getItem(KEY) || "{}"); } catch { return {}; } }
const save = (o) => { try { localStorage.setItem(KEY, JSON.stringify(o)); } catch {} };

/** Toutes les chaînes d'un objet (leçons, histoires) */
function strings(x, out) {
  if (typeof x === "string") { if (x.length < 400) out.push(x); }
  else if (Array.isArray(x)) x.forEach((y) => strings(y, out));
  else if (x && typeof x === "object") for (const k in x) if (k !== "fr" && k !== "py" && k !== "explain" && k !== "intro") strings(x[k], out);
  return out;
}

async function textsOf(levelId) {
  const lv = LEVELS.find((l) => l.id === levelId);
  const raw = strings([lv.lessons, lv.exam], []);
  const { STORIES } = await import("../data/stories.js");
  const ids = new Set(lv.lessons.map((l) => l.id));
  const stories = (STORIES[code] || []).filter((s) => ids.has(s.after));
  const storyTexts = stories.flatMap((s) => s.lines.filter((x) => x.t).map((x) => x.t));
  const norm = (arr) => [...new Set(arr.flatMap((t) => [t, ...String(t).split(/\s*[—|]\s*/)]).map((t) => speechText(t, L.speakFilter)).filter(Boolean))];
  return { main: norm([...raw, ...storyTexts]), stories: norm(storyTexts) };
}

/** Télécharge l'audio d'un palier ; onProgress(fait, total) */
export async function downloadLevel(levelId, onProgress) {
  const t = await textsOf(levelId);
  const v1 = mainVoice(), v2 = otherVoice();
  const a = await clipsFor(t.main, v1), b = v2 !== v1 ? await clipsFor(t.stories, v2) : [];
  const total = a.length + b.length;
  let size = 0;
  const r1 = await downloadClips(a, v1, (d) => onProgress?.(d, total)); size += r1.size;
  if (b.length) { const r2 = await downloadClips(b, v2, (d) => onProgress?.(a.length + d, total)); size += r2.size; }
  const o = offlineState();
  o[levelId] = { at: Date.now(), n: total, mb: Math.round(size / 1e5) / 10, ids: { [v1]: a, ...(b.length ? { [v2]: b } : {}) } };
  save(o);
  return o[levelId];
}

/** Supprime l'audio d'un palier (en gardant les phrases d'un autre palier téléchargé) */
export async function removeLevel(levelId) {
  const o = offlineState(), cur = o[levelId];
  if (!cur) return;
  delete o[levelId];
  for (const [v, ids] of Object.entries(cur.ids || {})) {
    const keep = new Set(Object.values(o).flatMap((x) => x.ids?.[v] || []));
    await removeClips(ids.filter((id) => !keep.has(id)), v);
  }
  save(o);
}
