/* =====================================================================
   Analyse de la voix (micro) : enregistrement, hauteur (YIN), découpage
   en syllabes et reconnaissance du ton mandarin de chaque syllabe.
   Fonctionne sans la reconnaissance vocale du navigateur.
   ===================================================================== */

export const RATE = 16000;          // fréquence de travail
const HOP = 160;                    // 10 ms
const WIN = 400;                    // 25 ms
const FMIN = 75, FMAX = 500;

/* --------------------------- Enregistreur --------------------------- */
/**
 * Démarre le micro. onLevel(0-1) est appelé en continu (vu-mètre),
 * onSilence() quand on s'est tu après avoir parlé.
 * Renvoie { stop(): Promise<Float32Array 16 kHz>, cancel() }.
 */
export async function startRecorder({ onLevel, onSilence, maxMs = 6000 } = {}) {
  const stream = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true } });
  const Ctx = window.AudioContext || window.webkitAudioContext;
  const ctx = new Ctx();
  if (ctx.state === "suspended") await ctx.resume().catch(() => {});
  const src = ctx.createMediaStreamSource(stream);
  const proc = ctx.createScriptProcessor(2048, 1, 1);
  const chunks = [];
  let spoke = false, quietMs = 0, noise = 0.004, done = false, startT = performance.now();
  proc.onaudioprocess = (e) => {
    if (done) return;
    const d = e.inputBuffer.getChannelData(0);
    chunks.push(new Float32Array(d));
    let s = 0; for (let k = 0; k < d.length; k++) s += d[k] * d[k];
    const rms = Math.sqrt(s / d.length), ms = (d.length / ctx.sampleRate) * 1000;
    if (!spoke) noise = noise * 0.9 + Math.min(rms, 0.02) * 0.1;
    const loud = rms > Math.max(0.012, noise * 3);
    if (loud) { spoke = true; quietMs = 0; } else if (spoke) quietMs += ms;
    onLevel?.(Math.min(1, rms * 12));
    if ((spoke && quietMs > 900) || performance.now() - startT > maxMs) onSilence?.();
  };
  src.connect(proc); proc.connect(ctx.destination);
  const close = () => {
    done = true;
    try { proc.disconnect(); src.disconnect(); } catch {}
    stream.getTracks().forEach((t) => t.stop());
    ctx.close().catch(() => {});
  };
  return {
    async stop() {
      const rate = ctx.sampleRate;
      close();
      let n = 0; for (const c of chunks) n += c.length;
      const all = new Float32Array(n); let o = 0; for (const c of chunks) { all.set(c, o); o += c.length; }
      return resample(all, rate, RATE);
    },
    cancel: close,
  };
}

export function resample(x, from, to) {
  if (from === to) return x;
  const r = from / to, n = Math.floor(x.length / r), out = new Float32Array(n);
  // moyenne sur la fenêtre (filtre anti-repliement simple)
  for (let i = 0; i < n; i++) {
    const a = Math.floor(i * r), b = Math.min(x.length, Math.floor((i + 1) * r));
    let s = 0; for (let k = a; k < b; k++) s += x[k];
    out[i] = s / Math.max(1, b - a);
  }
  return out;
}

/** WAV 16 bits pour réécouter l'enregistrement */
export function toWav(x, rate = RATE) {
  const buf = new ArrayBuffer(44 + x.length * 2), v = new DataView(buf);
  const w = (o, s) => { for (let i = 0; i < s.length; i++) v.setUint8(o + i, s.charCodeAt(i)); };
  let peak = 0.0001; for (let i = 0; i < x.length; i++) peak = Math.max(peak, Math.abs(x[i]));
  const g = Math.min(8, 0.9 / peak);   // on remonte le volume des voix faibles
  w(0, "RIFF"); v.setUint32(4, 36 + x.length * 2, true); w(8, "WAVE"); w(12, "fmt ");
  v.setUint32(16, 16, true); v.setUint16(20, 1, true); v.setUint16(22, 1, true);
  v.setUint32(24, rate, true); v.setUint32(28, rate * 2, true); v.setUint16(32, 2, true); v.setUint16(34, 16, true);
  w(36, "data"); v.setUint32(40, x.length * 2, true);
  for (let i = 0; i < x.length; i++) v.setInt16(44 + i * 2, Math.max(-1, Math.min(1, x[i] * g)) * 32767, true);
  return new Blob([buf], { type: "audio/wav" });
}

/* ------------------------------ Hauteur ------------------------------ */
/** Pour chaque trame de 10 ms : { f0 (Hz ou 0), e (énergie) } */
export function track(x) {
  const out = [];
  const tauMin = Math.floor(RATE / FMAX), tauMax = Math.ceil(RATE / FMIN);
  const W = WIN, d = new Float32Array(tauMax + 1);
  for (let start = 0; start + W + tauMax < x.length; start += HOP) {
    let e = 0; for (let k = 0; k < W; k++) e += x[start + k] * x[start + k];
    e = Math.sqrt(e / W);
    // YIN : différence cumulée normalisée
    d[0] = 1; let run = 0, tau = -1;
    for (let t = 1; t <= tauMax; t++) {
      let s = 0;
      for (let k = 0; k < W; k++) { const q = x[start + k] - x[start + k + t]; s += q * q; }
      run += s; d[t] = run ? (s * t) / run : 1;
    }
    for (let t = tauMin; t <= tauMax; t++) {
      if (d[t] < 0.25) { while (t + 1 <= tauMax && d[t + 1] < d[t]) t++; tau = t; break; }
    }
    if (tau < 0) {      // pas de creux net : minimum global s'il reste assez périodique
      let bt = tauMin; for (let t = tauMin; t <= tauMax; t++) if (d[t] < d[bt]) bt = t;
      if (d[bt] < 0.45) tau = bt;
    }
    if (tau >= tauMax) tau = -1;
    let f0 = 0;
    if (tau > 0) {
      const a = d[tau - 1], b = d[tau], c = d[tau + 1] ?? b;
      const p = tau + (a - c) / (2 * (a - 2 * b + c) || 1);
      f0 = RATE / p;
    }
    out.push({ f0, e });
  }
  return out;
}

const st = (f, ref) => 12 * Math.log2(f / ref);
const median = (a) => { const s = [...a].sort((p, q) => p - q); return s.length ? s[s.length >> 1] : 0; };

/** Nettoie la courbe : retire les sauts d'octave et les points isolés */
function clean(frames, emin) {
  const v = frames.map((f) => (f.e > emin && f.f0 ? f.f0 : 0));
  const med = median(v.filter(Boolean));
  for (let i = 0; i < v.length; i++) {
    if (!v[i]) continue;
    if (v[i] > med * 1.8) v[i] /= 2; else if (v[i] < med / 1.8) v[i] *= 2;
  }
  // continuité : un saut d'environ une octave d'une trame à l'autre est une erreur de mesure
  for (let i = 1; i < v.length; i++) {
    if (!v[i] || !v[i - 1]) continue;
    const r = v[i] / v[i - 1];
    if (r > 1.6) v[i] /= 2; else if (r < 0.62) v[i] *= 2;
  }
  for (let i = 1; i < v.length - 1; i++) if (v[i] && !v[i - 1] && !v[i + 1]) v[i] = 0;
  // médiane glissante sur 5 points
  const out = v.slice();
  for (let i = 0; i < v.length; i++) {
    if (!v[i]) continue;
    const w = v.slice(Math.max(0, i - 2), i + 3).filter(Boolean);
    out[i] = median(w);
  }
  return out;
}

/** Découpe la partie voisée en n syllabes (creux d'énergie ou de voisement) */
function segment(f0, e, n) {
  let a = f0.findIndex(Boolean), b = f0.length - 1 - [...f0].reverse().findIndex(Boolean);
  if (a < 0) return [];
  // morceaux voisés séparés par des trous
  const runs = [];
  for (let i = a, s = -1, gap = 0; i <= b + 1; i++) {
    if (i <= b && f0[i]) { if (s < 0) s = i; gap = 0; }
    else if (s >= 0) { gap++; if (gap >= 3 || i > b) { runs.push([s, i - gap]); s = -1; gap = 0; } }
  }
  // on écarte les bribes faibles ou très courtes (souffle, bruit, consonne)
  const en = ([s, t]) => { let m = 0; for (let i = s; i <= t; i++) m += e[i]; return m / (t - s + 1); };
  const top = Math.max(...runs.map(en));
  let segs = runs.filter((r) => r[1] - r[0] >= 4 && en(r) > top * 0.3);
  if (!segs.length) segs = runs;
  while (segs.length > n) {
    // une bribe bien plus « légère » que les autres (attaque, souffle) : on la retire plutôt que de la fusionner
    const mass = segs.map((r) => en(r) * (r[1] - r[0] + 1)), mx = Math.max(...mass);
    const k = mass.indexOf(Math.min(...mass));
    if (mass[k] > mx * 0.6) break;
    segs.splice(k, 1);
  }
  // trop de morceaux : on fusionne les plus proches
  while (segs.length > n) {
    let k = 0, g = Infinity;
    for (let i = 0; i < segs.length - 1; i++) { const gg = segs[i + 1][0] - segs[i][1]; if (gg < g) { g = gg; k = i; } }
    segs.splice(k, 2, [segs[k][0], segs[k + 1][1]]);
  }
  // pas assez : on coupe le plus long morceau au creux d'énergie le plus marqué
  while (segs.length < n) {
    let k = 0; for (let i = 1; i < segs.length; i++) if (segs[i][1] - segs[i][0] > segs[k][1] - segs[k][0]) k = i;
    const [s, t] = segs[k];
    if (t - s < 10) break;
    const parts = n - segs.length + 1, guess = s + Math.round((t - s) / parts);
    let cut = guess, low = Infinity;
    for (let i = Math.max(s + 5, guess - 12); i <= Math.min(t - 5, guess + 12); i++) {
      const v = (e[i - 1] + e[i] + e[i + 1]) / 3; if (v < low) { low = v; cut = i; }
    }
    segs.splice(k, 1, [s, cut - 1], [cut + 1, t]);
  }
  return segs;
}

/* -------------------------------- Tons -------------------------------- */
export const TONE_LABEL = { 1: "1er ton (plat, haut)", 2: "2e ton (montant)", 3: "3e ton (grave)", 4: "4e ton (descendant)", 5: "ton neutre" };

function resample9(a) {
  const out = [];
  for (let i = 0; i < 9; i++) {
    const p = (i / 8) * (a.length - 1), k = Math.floor(p), r = p - k;
    out.push(a[k] * (1 - r) + (a[Math.min(a.length - 1, k + 1)] ?? a[k]) * r);
  }
  return out;
}

/** Retire les points aberrants (voix qui craque, saut d'octave en fin de syllabe) */
function despike(p) {
  const out = [];
  for (let i = 0; i < p.length; i++) {
    const w = p.slice(Math.max(0, i - 3), i + 4).sort((a, b) => a - b), m = w[w.length >> 1];
    if (Math.abs(p[i] - m) <= 2.5) out.push(p[i]);
  }
  // un saut brutal dans le dernier tiers : on coupe la fin
  for (let i = Math.max(1, Math.floor(out.length * 0.66)); i < out.length; i++) if (Math.abs(out[i] - out[i - 1]) > 2.5) return out.slice(0, i);
  return out;
}

/**
 * Indices de chaque ton pour une courbe de 9 points (demi-tons par rapport au milieu de la voix).
 * lvl : poids du niveau (haut / grave), faible tant que la voix n'est pas encore connue.
 */
function toneScores(c, lvl) {
  const s = c[0], e = c[8], mx = Math.max(...c), mn = Math.min(...c);
  const mean = c.reduce((a, b) => a + b, 0) / 9, range = Math.max(...c.slice(2)) - Math.min(...c.slice(2));  // l'attaque glisse souvent
  const imn = c.indexOf(mn);
  const head = Math.max(...c.slice(0, 5)), early = Math.min(...c.slice(1, 6));
  const rise = e - early, fall = head - e;
  const dip = Math.min(s, e) - Math.min(...c.slice(2, 7));
  const drop = Math.max(...c.slice(0, imn + 1)) - mn;         // descente avant le point le plus bas
  return {
    1: 1.6 - range * 0.9 + lvl * (mean > -1 ? 0.6 : -0.4 * (-1 - mean)),
    2: (rise - 1.8) + (e >= mx - 1 ? 0.4 : -1) + (imn <= 5 ? 0 : -1) - Math.max(0, fall - 1.5)
       - Math.max(0, drop - 2) * 0.8 + Math.min(0, e - c[4] - 1),
    3: Math.max(dip - 1.2, 0) * 0.9 + (fall > 2 && head < 0.8 ? 0.6 + lvl * 0.8 : 0) + lvl * Math.max(0, -1.2 - mean) * 0.8
       - Math.max(0, rise - 3) * (imn < 3 ? 1 : 0) - (range < 1.2 ? 0.8 : 0) - lvl * Math.max(0, mean) * 0.6,
    4: (fall - 2) + (head >= 0.5 ? 0.5 * lvl : -1 * lvl) - Math.max(0, rise - 1.5),
  };
}

/**
 * Analyse un enregistrement (16 kHz) pour `tones` (ex. [3, 2] ; 5 = neutre).
 * ref : hauteur moyenne habituelle de la voix (Hz) si connue.
 * Renvoie { voiced, median, syl: [{ want, got, ok, curve: [demi-tons], from, to }] } ou null si rien entendu.
 */
export function analyse(x, tones, ref = 0) {
  const frames = track(x);
  if (!frames.length) return null;
  const emax = Math.max(...frames.map((f) => f.e));
  if (emax < 0.008) return null;
  const emin = Math.max(0.006, emax * 0.08);
  const f0 = clean(frames, emin), e = frames.map((f) => f.e);
  const voicedN = f0.filter(Boolean).length;
  if (voicedN < 8) return null;
  const med = median(f0.filter(Boolean));
  const base = ref ? Math.sqrt(ref * med) : med;        // milieu de la voix
  const segs = segment(f0, e, tones.length);
  // niveau (haut / grave) : fiable si la voix est connue ou s'il y a plusieurs syllabes
  const lvl = ref ? 1 : tones.length > 1 ? 0.7 : 0.3;
  const syl = tones.map((want, i) => {
    const sg = segs[i];
    if (!sg) return { want, got: 0, ok: false, curve: [] };
    // on garde le cœur de la syllabe (l'attaque et la fin sont instables)
    const len = sg[1] - sg[0] + 1, a = sg[0] + Math.floor(len * 0.1), b = sg[1] - Math.floor(len * 0.12);
    const raw = []; for (let k = a; k <= b; k++) if (f0[k]) raw.push(st(f0[k], base));
    const pts = despike(raw);
    if (pts.length < 3) return { want, got: 0, ok: want === 5, curve: pts, from: sg[0], to: sg[1] };
    const c = resample9(pts);
    const sc = toneScores(c, lvl);
    const got = +Object.keys(sc).sort((p, q) => sc[q] - sc[p])[0];
    // sans repère de hauteur, un 3e ton « coupé » (qui ne fait que descendre) ressemble à un 4e ton
    const unsure = lvl < 1 && ((want === 3 && got === 4) || (want === 4 && got === 3));
    const ok = want === 5 || got === want || sc[want] >= sc[got] - 0.3 || unsure;
    return { want, got, ok, curve: c, from: sg[0], to: sg[1] };
  });
  return { voiced: voicedN, median: med, syl };
}

/* ----------------------- Tons attendus (pinyin) ----------------------- */
const MARKS = { "̄": 1, "́": 2, "̌": 3, "̀": 4 };
/** "nǐ hǎo" → [3, 3] ; syllabe sans accent → 5 */
export function tonesOf(py) {
  const syls = String(py).toLowerCase().normalize("NFD").replace(/[^a-zǖ́̌̀\s'’]/g, " ").split(/[\s'’]+/).filter((s) => /[a-z]/.test(s));
  return syls.map((s) => { for (const ch of s) if (MARKS[ch]) return MARKS[ch]; return 5; });
}
/** Changements de ton à l'oral : 3-3 → 2-3, 不 et 一 devant un 4e ton → 2e ton, etc. */
export function sandhi(chars, tones) {
  const t = tones.slice();
  for (let i = 0; i < t.length - 1; i++) {
    if (t[i] === 3 && t[i + 1] === 3) t[i] = 2;
    if (chars[i] === "不" && t[i + 1] === 4) t[i] = 2;
    if (chars[i] === "一" && tones[i] === 1) t[i] = t[i + 1] === 4 ? 2 : t[i + 1] === 5 ? 1 : 4;
  }
  return t;
}
