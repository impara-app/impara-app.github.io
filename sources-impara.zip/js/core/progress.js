/* =====================================================================
   progress.js — Règles de progression, déblocage, XP et erreurs
   ---------------------------------------------------------------------
   Toute la « logique métier » pédagogique est ici, séparée de l'UI :
   - une leçon se termine par un quiz de 10 questions, validé à 80 % ;
   - un test de mi-palier (25 questions) se valide sans faute (100 %) ;
   - un examen de palier (50 questions) se valide sans faute et débloque le palier suivant ;
   - une erreur quitte le cahier après 2 bonnes réponses consécutives.
   ===================================================================== */

import { state, commit } from "./storage.js";
import { LEVELS, ALL_LESSONS } from "../data/curriculum.js";
import { tri } from "./ui.js";
import { historyExtras, trackMany } from "./stats.js";
import { LANGS, code as LANG_CODE } from "./lang.js";

export const PASS_LESSON = 0.8;
export const LESSON_QUIZ_N = 10;
export const PASS_EXAM = 1;          // examen de fin de palier : sans faute
export const PASS_CHECKPOINT = 1;    // test de mi-palier : sans faute
export const CHECKPOINT_N = 25;
export const EXAM_N = 50;
/** Jokers : fautes de frappe pardonnées (une lettre) pendant l'examen / le test de mi-palier */
export const JOKERS_EXAM = 3, JOKERS_CHECKPOINT = 2;
/** Clé du résultat de mi-palier. « @25 » : format à 25 questions (nov. 2026) ;
 *  les réussites de l'ancien test à 10 questions ne comptent plus et doivent être refaites. */
export const ckKey = (levelId) => `${levelId}@25`;
export const XP_PER_CORRECT = 10;
export const MASTERY_STREAK = 2;

/* ----------------------------- Dates ------------------------------- */
const dayKey = (d = new Date()) =>
  `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
const yesterdayKey = () => { const d = new Date(); d.setDate(d.getDate() - 1); return dayKey(d); };
/**
 * Semaine du classement : « 2026-W45 ».
 * Calculée en heure universelle (UTC) pour que tous les amis changent de
 * semaine au même instant, quel que soit leur fuseau horaire.
 */
export function weekKey(d = new Date()) {
  const t = new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate()));
  const day = t.getUTCDay() || 7;
  t.setUTCDate(t.getUTCDate() + 4 - day);
  const y = t.getUTCFullYear(), w = Math.ceil(((t - Date.UTC(y, 0, 1)) / 864e5 + 1) / 7);
  return `${y}-W${String(w).padStart(2, "0")}`;
}
/** XP de la semaine retrouvés dans l'historique (progression faite avant l'ajout du compteur) */
function historyWeekXp(s) {
  const week = weekKey();
  return (s.history || []).filter((h) => h.date && weekKey(new Date(h.date)) === week).reduce((n, h) => n + (
    h.kind === "practice" ? h.score * 5
    : h.score * XP_PER_CORRECT + (h.passed && h.kind !== "review" ? 20 : 0)), 0);
}
/** Prochaine remise à zéro du classement (lundi 0 h UTC), à afficher dans l'heure locale */
export function nextWeekReset(now = new Date()) {
  const d = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate()));
  d.setUTCDate(d.getUTCDate() + ((8 - (d.getUTCDay() || 7)) % 7 || 7));
  return d;
}
/** XP d'un jour retrouvés dans l'historique (avant l'ajout du journal quotidien) */
function historyDayXp(s, day) {
  return (s.history || []).filter((h) => h.date && dayKey(new Date(h.date)) === day).reduce((n, h) => n + (
    h.kind === "practice" ? h.score * 5 : h.score * XP_PER_CORRECT + (h.passed && h.kind !== "review" ? 20 : 0)), 0);
}
/** XP des 7 derniers jours (du plus ancien à aujourd'hui) : { "2026-11-02": 30, … } */
export function last7Days() {
  const out = {};
  for (let i = 6; i >= 0; i--) {
    const d = dayKey(new Date(Date.now() - i * 864e5));
    out[d] = state.dayLog?.[d] ?? historyDayXp(state, d);
  }
  return out;
}
export const weeklyXp = () => (state.weekly?.week === weekKey() ? state.weekly.xp : historyWeekXp(state));

/** Série gagnée aujourd'hui, à célébrer une seule fois (null sinon) */
let pendingStreak = null;
export function takeStreakCelebration() { const n = pendingStreak; pendingStreak = null; return n; }
export const hasStreakCelebration = () => pendingStreak != null;
export { dayKey };

/** XP, objectif du jour, XP de la semaine et série (partagé par quiz et entraînements) */
function addXp(s, xp) {
  const today = dayKey(), week = weekKey();
  s.xp += xp;
  s.daily = s.daily.date === today ? { date: today, xp: s.daily.xp + xp } : { date: today, xp };
  s.weekly = s.weekly?.week === week ? { week, xp: s.weekly.xp + xp } : { week, xp: historyWeekXp(s) + xp };
  // Journal des XP par jour (graphique « bilan hebdomadaire »), 30 derniers jours
  const log = { ...(s.dayLog || {}) };
  if (!(today in log)) log[today] = historyDayXp(s, today);
  log[today] += xp;
  const limit = dayKey(new Date(Date.now() - 400 * 864e5)); // ~1 an (calendrier de pratique)
  Object.keys(log).forEach((d) => { if (d < limit) delete log[d]; });
  s.dayLog = log;
  if (s.streak.last !== today && xp > 0) {
    // Déjà actif aujourd'hui dans l'autre langue ? La série commune a déjà été fêtée
    const before = otherStates().some((o) => (o.dayLog?.[today] || 0) > 0 || o.streak?.last === today);
    const n = unionStreak(s);
    s.streak = { count: n, last: today };
    if (!before) {
      // Un gel de série gagné tous les 7 jours
      if (n % FREEZE_EVERY === 0) s.streakFreezes = Math.min(FREEZE_MAX, (s.streakFreezes || 0) + 1);
      pendingStreak = n; // première activité du jour : écran de série à afficher
    }
  }
}

/* -------- Entraînements : XP une seule fois par 24 h et par exercice -------- */
/** XP bonus (coffre des quêtes du jour) */
export function grantXp(xp) { if (xp > 0) commit((s) => addXp(s, xp)); }

export const PRACTICE_COOLDOWN = 24 * 3600 * 1000;
/** Moment où l'exercice redonnera des XP (0 = maintenant) */
export function practiceReadyAt(key) {
  const last = state.practiceXp?.[key] || 0;
  return last && Date.now() - last < PRACTICE_COOLDOWN ? last + PRACTICE_COOLDOWN : 0;
}
/** « 5 h 12 » / « 18 min » avant le prochain gain d'XP */
export function waitLabel(at) {
  const min = Math.max(1, Math.ceil((at - Date.now()) / 6e4)), h = Math.floor(min / 60), m = min % 60;
  return h ? `${h} h ${String(m).padStart(2, "0")}` : `${m} min`;
}

/**
 * Entraînement libre (écoute, tons, tracé, flashcards, histoires, prononciation) :
 * historique toujours, XP seulement si l'exercice (key) n'a pas déjà rapporté
 * d'XP dans les dernières 24 h.
 */
// Exercices hors quiz : leurs réponses comptent aussi pour le radar de compétences
const PRACTICE_SKILL = [[/^(prononciation|repeter)$/, "oral"], [/^(dictee|listen:)/, "ecoute"], [/^(story:|dialogue:)/, "lecture"], [/^conjugaison$/, "gram"], [/^ecriture$/, "ecriture"]];
export function recordPractice({ label, score, total, xpPer = 5, key = null }) {
  const sk = key && total ? PRACTICE_SKILL.find(([re]) => re.test(key)) : null;
  if (sk) trackMany(sk[1], Math.min(score, total), Math.min(total, 60));
  const readyAt = key ? practiceReadyAt(key) : 0;
  const capped = !!readyAt;
  const xpGained = capped ? 0 : score * xpPer;
  commit((s) => {
    addXp(s, xpGained);
    if (key && !capped && xpGained > 0) s.practiceXp = { ...(s.practiceXp || {}), [key]: Date.now() };
    // Nettoyage : on oublie les exercices de plus de 2 jours
    if (s.practiceXp) for (const [k, t] of Object.entries(s.practiceXp)) if (Date.now() - t > 2 * PRACTICE_COOLDOWN) delete s.practiceXp[k];
    if (total) { s.history.unshift({ date: Date.now(), label, score, total, kind: "practice", passed: score / total >= PASS_LESSON, ...historyExtras() }); s.history = s.history.slice(0, 30); }
  });
  return { score, total, ratio: total ? score / total : 0, xpGained, capped, readyAt };
}

/**
 * Leçons déjà validées dont le vocabulaire a été complété depuis (ex. tous les
 * mois ajoutés) : les nouveaux mots rejoignent le carnet et les flashcards.
 * Renvoie le nombre de mots ajoutés.
 */
export function syncLessonVocab() {
  let n = 0;
  // Nettoyage des sens empilés (une fois, puis seulement si besoin)
  const messy = Object.values(state.vocab || {}).filter((w) => String(w.fr).includes(" ; ") && cleanMeaning(w.fr) !== w.fr);
  if (messy.length) commit((s) => { messy.forEach((w) => { if (s.vocab[w.zh]) s.vocab[w.zh].fr = cleanMeaning(w.fr); }); });
  const missing = ALL_LESSONS.filter((l) => state.lessons[l.id]?.passed && !state.lessons[l.id].placed).flatMap((l) => l.vocab.map(tri).filter(([zh]) => !state.vocab[zh]).map((v) => [l, v]));
  if (!missing.length) return 0;
  commit((s) => {
    missing.forEach(([lesson, [zh, py, fr]]) => {
      if (!s.vocab[zh]) { s.vocab[zh] = { zh, py, fr, levelId: lesson.levelId, lessonId: lesson.id, added: Date.now() }; n++; }
    });
  });
  return n;
}

/* ---------------- Sens d'un mot : éviter les doublons ---------------- */
const STOP = new Set(["les", "des", "une", "est", "qui", "que", "pour", "par", "dans", "avec", "sur", "pas", "aux", "son", "ses", "fam", "soutenu", "oral", "écrit"]);
const tokens = (t) => new Set(String(t).toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/\([^)]*\)/g, " ").split(/[^a-z']+/).filter((w) => w.length >= 3 && !STOP.has(w)));
/** Deux traductions disent-elles la même chose ? (au moins un mot important en commun) */
export function sameMeaning(a, b) {
  const A = tokens(a), B = tokens(b);
  const bare = (t) => String(t).replace(/\([^)]*\)/g, "").trim().toLowerCase();
  if (!A.size || !B.size) return bare(a) === bare(b) || bare(a).includes(bare(b)) || bare(b).includes(bare(a));
  for (const w of A) if (B.has(w)) return true;
  return false;
}
/** Nettoie un sens déjà enregistré : « peut-être ; si seulement, peut-être » → un seul sens par idée */
export function cleanMeaning(fr) {
  const parts = String(fr).split(" ; "), out = [];
  parts.forEach((p) => { if (!out.some((q) => sameMeaning(q, p))) out.push(p); });
  return out.slice(0, 2).join(" ; ");
}

/* --------------------------- Déblocage ----------------------------- */
export const isLessonDone = (id) => !!state.lessons[id]?.passed;
export const isExamPassed = (levelId) => !!state.exams[levelId]?.passed;

/* ------------------------ Test de mi-palier ------------------------ */
/** Indice de la première leçon de la 2e moitié du palier (le test se place juste avant) */
export const checkpointIndex = (level) => Math.ceil(level.lessons.length / 2);
/** Validé ? (ou déjà dépassé par une progression faite avant l'ajout du test) */
export function isCheckpointPassed(level) {
  if (state.checkpoints?.[ckKey(level.id)]?.passed || isExamPassed(level.id)) return true;
  // Ancien test (10 questions) déjà tenté : il faut repasser le nouveau
  if (state.checkpoints?.[level.id]) return false;
  // Progression faite avant l'ajout du test : on ne bloque pas
  return level.lessons.slice(checkpointIndex(level)).some((l) => isLessonDone(l.id));
}
export function isCheckpointUnlocked(levelIndex) {
  const lvl = LEVELS[levelIndex];
  return isLevelUnlocked(levelIndex) && lvl.lessons.slice(0, checkpointIndex(lvl)).every((l) => isLessonDone(l.id));
}
/** Lien et libellé de la prochaine étape (leçon, test de mi-palier ou examen) */
export const stepHref = (n) => (n.kind === "lesson" ? `lecon-${n.lesson.id}` : n.kind === "checkpoint" ? `mipalier-${n.level.id}` : `examen-${n.level.id}`);

export function isLevelUnlocked(levelIndex) {
  return levelIndex === 0 || isExamPassed(LEVELS[levelIndex - 1].id);
}

export function isLessonUnlocked(lesson) {
  if (!isLevelUnlocked(lesson.levelIndex)) return false;
  if (lesson.index === 0) return true;
  const lvl = LEVELS[lesson.levelIndex];
  const prev = lvl.lessons[lesson.index - 1];
  if (!isLessonDone(prev.id)) return false;
  // 2e moitié du palier : il faut le test de mi-palier (sauf leçon déjà faite)
  return lesson.index < checkpointIndex(lvl) || isCheckpointPassed(lvl) || isLessonDone(lesson.id);
}

export function isExamUnlocked(levelIndex) {
  return isLevelUnlocked(levelIndex) && LEVELS[levelIndex].lessons.every((l) => isLessonDone(l.id)) && isCheckpointPassed(LEVELS[levelIndex]);
}

/* --------------------------- Statistiques -------------------------- */
export function levelProgress(levelIndex) {
  const lvl = LEVELS[levelIndex];
  const total = lvl.lessons.length + 1; // +1 pour l'examen
  const done = lvl.lessons.filter((l) => isLessonDone(l.id)).length + (isExamPassed(lvl.id) ? 1 : 0);
  return { done, total, pct: Math.round((done / total) * 100) };
}

export function globalProgress() {
  const total = ALL_LESSONS.length + LEVELS.length;
  const done = ALL_LESSONS.filter((l) => isLessonDone(l.id)).length + LEVELS.filter((l) => isExamPassed(l.id)).length;
  return { done, total, pct: Math.round((done / total) * 100) };
}

/** Niveau CECRL actuel = le plus haut palier débloqué */
export function currentLevel() {
  let idx = 0;
  LEVELS.forEach((_, i) => { if (isLevelUnlocked(i)) idx = i; });
  return LEVELS[idx];
}

/** Prochaine étape recommandée (leçon ou examen) */
export function nextStep() {
  for (let i = 0; i < LEVELS.length; i++) {
    if (!isLevelUnlocked(i)) break;
    const lvl = LEVELS[i];
    const lesson = lvl.lessons.find((l) => !isLessonDone(l.id));
    if ((!lesson || lesson.index >= checkpointIndex(lvl)) && !isCheckpointPassed(lvl)) return { kind: "checkpoint", level: lvl };
    if (lesson) return { kind: "lesson", lesson, level: lvl };
    if (!isExamPassed(lvl.id)) return { kind: "exam", level: lvl };
  }
  return null; // parcours terminé 🎉
}

export const starsFor = (ratio) => (ratio >= 1 ? 3 : ratio >= 0.9 ? 2 : ratio >= PASS_LESSON ? 1 : 0);
/** Étoiles d'une leçon déjà validée (au moins 1, même validée avec l'ancien seuil) */
export const lessonStars = (rec) => (rec?.passed ? Math.max(1, starsFor(rec.best / rec.total)) : 0);
export const dailyXp = () => (state.daily.date === dayKey() ? state.daily.xp : 0);
/* ----------------------- Gel de série 🧊 -----------------------
   Un gel s'obtient tous les 7 jours de série (2 au maximum). S'il manque
   UN seul jour, un gel est utilisé automatiquement et la série continue. */
export const FREEZE_MAX = 2, FREEZE_EVERY = 7;
const twoDaysAgoKey = () => { const d = new Date(); d.setDate(d.getDate() - 2); return dayKey(d); };
let frozeNotice = null;
/** À l'ouverture de l'appli : sauve la série avec un gel si un seul jour a été manqué */
export function applyStreakFreeze() {
  // Hier manqué (dans toutes les langues), avant-hier actif : un gel sauve la série
  const days = activeDays(), y = yesterdayKey();
  if (days.has(y) || days.has(dayKey()) || !days.has(twoDaysAgoKey()) || !(state.streakFreezes > 0)) return false;
  commit((s) => {
    s.streakFreezes = Math.max(0, (s.streakFreezes || 0) - 1);
    s.streak = { ...s.streak, last: y };
    s.frozenDays = [...(s.frozenDays || []), y].slice(-30);
  });
  frozeNotice = { count: unionStreak(), left: state.streakFreezes };
  return true;
}
export function takeFreezeNotice() { const n = frozeNotice; frozeNotice = null; return n; }
/** Paliers de série et leur récompense (cadres, avatars, bannières) */
export const STREAK_REWARDS = [[7, "le cadre Argent et l'avatar 🌶️"], [20, "la bannière Galaxie"], [30, "le cadre Flamme et l'avatar ☄️"], [100, "le cadre Légende, l'avatar 🌟 et la bannière Volcan"]];
export const nextStreakReward = (n = streakCount()) => STREAK_REWARDS.find(([d]) => d > n) || null;

/* ---------------- Série commune aux deux langues ----------------
   Un jour compte dès qu'on a gagné des XP dans N'IMPORTE QUELLE langue.
   Les données de l'autre langue sont lues dans le stockage de l'appareil. */
let otherCache = { t: 0, list: [] };
function otherStates() {
  if (Date.now() - otherCache.t < 15000) return otherCache.list;
  const list = [];
  for (const [c, l] of Object.entries(LANGS)) {
    if (c === LANG_CODE) continue;
    try { const o = JSON.parse(localStorage.getItem(l.storageKey) || "null"); if (o && o.profile) list.push(o); } catch {}
  }
  otherCache = { t: Date.now(), list };
  return list;
}
/** Jours actifs (XP gagnés ou jour gelé), toutes langues confondues */
export function activeDays(s = state) {
  const days = new Set();
  for (const x of [s, ...otherStates()]) {
    Object.entries(x.dayLog || {}).forEach(([k, v]) => { if (v > 0) days.add(k); });
    (x.frozenDays || []).forEach((k) => days.add(k));
    if (x.streak?.last) days.add(x.streak.last);
  }
  return days;
}
/** Série en cours (jours consécutifs jusqu'à aujourd'hui, ou hier si rien n'est encore fait aujourd'hui) */
export function unionStreak(s = state) {
  const days = activeDays(s), d = new Date();
  if (!days.has(dayKey(d))) d.setDate(d.getDate() - 1);
  let n = 0;
  while (days.has(dayKey(d))) { n++; d.setDate(d.getDate() - 1); }
  // Séries plus anciennes que le journal par jour : on garde la valeur enregistrée si elle est plus grande
  const legacy = [s, ...otherStates()].map((x) => (x.streak?.last === dayKey() || x.streak?.last === yesterdayKey() ? x.streak.count : 0));
  return Math.max(n, ...legacy);
}
/** Dernier jour actif, toutes langues confondues */
export const lastActiveDay = () => [...activeDays()].sort().pop() || null;
export const streakCount = () => unionStreak();

/* ------------------------ Enregistrement --------------------------- */
/**
 * Enregistre le résultat d'un quiz et met à jour tout l'état.
 * @param {{kind:'lesson'|'exam'|'review', id:string, label:string,
 *          results:{ref:string, correct:boolean, given?:string}[]}} p
 * @returns résumé utilisé par l'écran de résultats
 */
export function recordQuiz({ kind, id, label, results }) {
  const score = results.filter((r) => r.correct).length;
  const total = results.length;
  const ratio = total ? score / total : 0;
  const passMark = kind === "exam" ? PASS_EXAM : kind === "checkpoint" ? PASS_CHECKPOINT : PASS_LESSON;
  const passed = ratio >= passMark;
  const xpGained = score * XP_PER_CORRECT + (passed && kind !== "review" ? 20 : 0);
  let newWords = 0, firstPass = false, mastered = 0;

  commit((s) => {
    // 1. Résultat de la leçon / de l'examen (on garde le meilleur score)
    if (kind === "checkpoint") s.checkpoints ||= {};
    if (kind === "lesson" || kind === "exam" || kind === "checkpoint") {
      const bucket = kind === "lesson" ? s.lessons : kind === "exam" ? s.exams : s.checkpoints;
      const key = kind === "checkpoint" ? ckKey(id) : id;
      const prev = bucket[key] || { best: 0, attempts: 0, passed: false };
      firstPass = passed && !prev.passed;
      bucket[key] = {
        best: Math.max(prev.best, score), total, attempts: prev.attempts + 1,
        passed: prev.passed || passed, date: new Date().toISOString(),
      };
    }

    // 2. Carnet de vocabulaire : ajouté quand la leçon est validée
    if (kind === "lesson" && passed) {
      const lesson = ALL_LESSONS.find((l) => l.id === id);
      lesson?.vocab.map(tri).forEach(([zh, py, fr]) => {
        const old = s.vocab[zh];
        if (!old) { s.vocab[zh] = { zh, py, fr, levelId: lesson.levelId, lessonId: id, added: Date.now() }; newWords++; }
        // Même mot vu avec un VRAI autre sens (ex. « come » = comment / comme) : on garde les deux sens,
        // mais pas une simple variante (« pourquoi, parce que » / « pourquoi ; parce que »)
        else if (!sameMeaning(old.fr, fr) && !old.fr.includes(" ; ") && (old.fr + fr).length < 70) {
          old.fr = `${old.fr} ; ${fr}`;
        }
      });
    }

    // 3. Cahier d'erreurs intelligent
    results.forEach((r) => {
      if (String(r.ref).includes(":gen:")) return; // question générée : pas de fiche à revoir
      const e = s.errors[r.ref];
      if (!r.correct) {
        s.errors[r.ref] = { ref: r.ref, count: (e?.count || 0) + 1, streak: 0, lastAnswer: r.given ?? "", lastWrong: Date.now() };
      } else if (e) {
        e.streak += 1;
        if (e.streak >= MASTERY_STREAK) { delete s.errors[r.ref]; s.mastered += 1; mastered++; }
      }
    });

    // 4. XP, objectif du jour, semaine, série
    addXp(s, xpGained);

    // 5. Historique (20 dernières activités)
    s.history.unshift({ date: Date.now(), label, score, total, kind, passed, ...historyExtras() });
    s.history = s.history.slice(0, 30);
    // Records : quiz parfaits
    if (total >= 5 && score === total) { s.records ||= {}; s.records.perfect = (s.records.perfect || 0) + 1; s.records.perfectAt = Date.now(); }
  });

  return { score, total, ratio, passed, passMark, xpGained, newWords, firstPass, mastered, stars: starsFor(ratio) };
}
