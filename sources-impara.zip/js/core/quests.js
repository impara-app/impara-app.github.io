/* =====================================================================
   quests.js — Quêtes du jour
   Trois mini-objectifs tirés chaque jour (les mêmes toute la journée,
   différents d'un jour à l'autre). Les trois réussis : un coffre à ouvrir
   (20 à 50 XP, parfois un gel de série).
   ===================================================================== */
import { state, commit } from "./storage.js";
import * as P from "./progress.js";
import { today, minutesOn, dayKey } from "./stats.js";
import { code } from "./lang.js";

const hash = (s) => { let h = 2166136261; for (const c of s) h = Math.imul(h ^ c.charCodeAt(0), 16777619); return h >>> 0; };

const lessonsToday = () => (state.history || []).filter((h) => h.kind === "lesson" && h.passed && dayKey(new Date(h.date)) === dayKey()).length;

/** [id, emoji, texte(n), cibles possibles, valeur actuelle, lien] */
const POOL = [
  ["xp", "⚡", (n) => `Gagner ${n} XP`, [30, 50, 80], () => P.dailyXp(), "#seance"],
  ["lecon", "📘", () => "Réussir une leçon", [1], lessonsToday, "#parcours"],
  ["rev", "🃏", (n) => `Réviser ${n} flashcards`, [10, 15, 20], () => today().rev, "#reviser"],
  ["ok", "✅", (n) => `Donner ${n} bonnes réponses`, [15, 25, 40], () => today().ok, "#entrainement"],
  ["ec", "🎧", (n) => `Réussir ${n} questions d'écoute`, [4, 6, 8], () => today().ec, "#ecoute"],
  ["run", "🔥", (n) => `Enchaîner ${n} bonnes réponses d'affilée`, [5, 8, 10], () => today().best, "#entrainement"],
  ["min", "⏱️", (n) => `Étudier ${n} minutes`, [5, 10, 15], () => minutesOn(dayKey()), "#seance"],
];

export function questsOfDay(d = dayKey()) {
  const pool = [...POOL];
  const out = [];
  let h = hash(`${code}:${d}`);
  while (out.length < 3) {
    const k = h % pool.length;
    const [id, emoji, text, targets, value, href] = pool.splice(k, 1)[0];
    const n = targets[(h >>> 8) % targets.length];
    const v = Math.min(n, value() || 0);
    out.push({ id, emoji, text: text(n), n, v, done: v >= n, href });
    h = hash(String(h));
  }
  return out;
}

export const chestOpened = () => state.quests?.day === dayKey() && state.quests.opened;
export const allDone = () => questsOfDay().every((q) => q.done);

/** Ouvre le coffre : renvoie la récompense */
export function openChest() {
  if (chestOpened() || !allDone()) return null;
  const h = hash(`${code}:${dayKey()}:coffre`);
  const xp = 20 + (h % 7) * 5; // 20 à 50 XP
  const freeze = h % 5 === 0 && (state.streakFreezes || 0) < P.FREEZE_MAX;
  commit((s) => {
    s.quests = { day: dayKey(), opened: true, xp, freeze };
    if (freeze) s.streakFreezes = (s.streakFreezes || 0) + 1;
  });
  P.grantXp(xp);
  return { xp, freeze };
}
