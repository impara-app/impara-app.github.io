/* =====================================================================
   quiz-engine.js — Moteur de quiz générique et réutilisable
   ---------------------------------------------------------------------
   Utilisé par : quiz de leçon, examen de palier, révision des erreurs.
   Chaque type de question est un petit « composant » qui expose :
     mount(area, q, onReady) -> { check(): { correct, given, expected, note } }
   Pour ajouter un type (ex. dictée audio), ajoutez une entrée à TYPES.
   ===================================================================== */

import { esc, shuffle, speak, pair, plain, modal, prefetchSpeech } from "./ui.js";
import { L, code as LANG } from "./lang.js";
import { ruby, wantPinyin } from "./pinyin.js";

/** Texte d'une question : avec pinyin au-dessus des caractères si demandé */
const tx = (q, s) => (q._py ? ruby(s) : esc(s));
const tile = (q, s) => (String(s).includes("|") || !q._py ? pair(s) : ruby(s));

/* ------------------- Animations de réponse ------------------------- */
import { sfx, haptic } from "./fx.js";
import { icon } from "./icons.js";
import { mascot } from "./mascot.js";
import { reportButton, setReportContext } from "./report.js";
import { diagnose } from "./diagnose.js";
import { trackAnswer, flushStats, setLastResults } from "./stats.js";
/** Bonne réponse : étoiles, « +XP », combo ; mauvaise : la carte tremble */
function celebrateAnswer(root, ok, { xp = 0, combo = 0, progress = 0 } = {}) {
  const card = root.querySelector(".quiz-card"), bar = root.querySelector(".bar span"), btn = root.querySelector(".quiz-action");
  const replay = (el, cls) => { if (!el) return; el.classList.remove(cls); void el.offsetWidth; el.classList.add(cls); };
  if (!ok) { replay(card, "shake"); haptic([60, 40, 60]); sfx("bad"); return; }
  const big = combo >= 3 && combo % 3 === 0;
  haptic(big ? [18, 50, 18, 50, 30] : [14, 30, 22]); sfx(big ? "combo" : "good");
  replay(card, "pop");
  if (bar) { bar.style.width = `${progress * 100}%`; replay(bar.parentElement, "pulse"); }
  if (matchMedia?.("(prefers-reduced-motion: reduce)").matches || document.documentElement.classList.contains("reduce-motion")) return;
  // Gerbe d'étoiles autour du bouton
  const r = (btn || card).getBoundingClientRect(), cx = r.left + r.width / 2, cy = r.top - 34;
  const layer = document.createElement("div");
  layer.className = "burst-layer";
  const glyphs = ["⭐", "✨", "🌟", "●", "●", "●"];
  for (let k = 0; k < 14; k++) {
    const s = document.createElement("span");
    const a = (Math.PI * 2 * k) / 14 + Math.random() * .4, d = 60 + Math.random() * 70;
    s.textContent = glyphs[k % glyphs.length];
    s.className = "burst-p" + (s.textContent === "●" ? " dot" : "");
    s.style.cssText = `left:${cx}px;top:${cy}px;--dx:${Math.cos(a) * d}px;--dy:${Math.sin(a) * d - 40}px;--rot:${Math.random() * 360}deg;animation-delay:${Math.random() * 60}ms`;
    layer.appendChild(s);
  }
  if (xp) { const f = document.createElement("b"); f.className = "xp-float"; f.textContent = `+${xp} XP`; f.style.cssText = `left:${cx}px;top:${cy - 10}px`; layer.appendChild(f); }
  if (combo >= 3) { const c = document.createElement("b"); c.className = "combo-float"; c.textContent = `🔥 ${combo} d'affilée !`; c.style.cssText = `left:${cx}px;top:${cy - 50}px`; layer.appendChild(c); }
  document.body.appendChild(layer);
  setTimeout(() => layer.remove(), 1400);
}

/* ---------------------- Normalisation du texte --------------------- */
export const normalize = (s) =>
  String(s).toLowerCase()
    .replace(/[’`´]/g, "'").replace(/'\s+/g, "'")
    .replace(/[.,!?;:«»"¿¡()，。！？、；：“”‘’（）—]/g, " ")
    .replace(/\s+/g, "").trim(); // espaces ignorés : « ni hao » = « nihao »
const stripAccents = (s) => s.normalize("NFD").replace(/[̀-ͯ]/g, "");

/** Compare une saisie libre à la liste des réponses acceptées */
export function checkText(given, answers) {
  const g = normalize(given);
  if (answers.some((a) => normalize(a) === g)) return { correct: true };
  const loose = answers.find((a) => stripAccents(normalize(a)) === stripAccents(g));
  if (loose) return { correct: true, note: `${L.looseNote} : « ${loose} »` };
  return { correct: false };
}

/**
 * Faute de frappe ? Une seule lettre fausse, en trop, manquante ou deux lettres
 * inversées par rapport à une réponse acceptée (accents ignorés). Seulement pour
 * des réponses écrites en lettres d'au moins 4 caractères (pas les caractères chinois).
 * @returns la réponse acceptée la plus proche, ou null
 */
export function typoOf(given, answers) {
  const g = stripAccents(normalize(given));
  if (g.length < 3 || /[\u3400-\u9fff]/.test(g)) return null;
  for (const a of [].concat(answers || [])) {
    const t = stripAccents(normalize(a));
    if (t.length < 4 || /[\u3400-\u9fff]/.test(t)) continue;
    if (Math.abs(t.length - g.length) <= 1 && editDist1(g, t)) return a;
  }
  return null;
}
/** Distance de Damerau-Levenshtein ≤ 1 (une substitution, insertion, suppression ou inversion) */
function editDist1(a, b) {
  if (a === b) return true;
  let i = 0;
  while (i < a.length && i < b.length && a[i] === b[i]) i++;
  if (a.length === b.length) {
    if (a.slice(i + 1) === b.slice(i + 1)) return true;                                   // une lettre fausse
    return a[i] === b[i + 1] && a[i + 1] === b[i] && a.slice(i + 2) === b.slice(i + 2);   // deux lettres inversées
  }
  return a.length > b.length ? a.slice(i + 1) === b.slice(i) : a.slice(i) === b.slice(i + 1); // lettre en trop / manquante
}

/* --------------------- Revue des erreurs (fin de quiz) --------------------- */
const HAN_RE = /[\u3400-\u9fff]/;
/** Texte à faire écouter pour une erreur : le mot entendu, sinon la réponse ou le mot cité s'ils sont dans la langue étudiée */
function sayOf(r) {
  const q = r.q || {}, exp = String(r.expected ?? "");
  if (q.say) return q.say;
  if (q.type === "match") return "";
  if (L.code === "zh") {
    if (HAN_RE.test(exp)) return exp;
    const m = String(r.prompt || "").match(/[\u3400-\u9fff][\u3400-\u9fff，。？！、\s]*/);
    return m ? m[0] : "";
  }
  // Italien : « Que signifie « X » ? » → on fait écouter X ; sinon la réponse attendue (si ce n'est pas du français)
  const quoted = String(r.prompt || "").match(/«\s*([^»]+?)\s*»/);
  if (/^(que (signifie|veut dire)|traduisez en français)/i.test(String(r.prompt || "")) && quoted) return quoted[1];
  if (q.type === "translate" && /français/i.test(r.label || "")) return "";
  return exp;
}
/**
 * Bloc « Vos erreurs » : pour chaque mauvaise réponse, la question, votre réponse,
 * la bonne réponse et un bouton pour l'écouter. Vide si tout est juste.
 */
export function mistakesHtml(results, { open = true } = {}) {
  const wrong = (results || []).filter((r) => !r.correct && r.q);
  if (!wrong.length) return "";
  const show = (r, s) => (r.q?._py ? ruby(String(s)) : esc(String(s)));
  return `<details class="mistakes card" ${open ? "open" : ""}>
    <summary><b>Vos erreurs</b><span class="mk-n">${wrong.length}</span></summary>
    <ol class="mk-list">${wrong.map((r) => {
      const say = sayOf(r);
      const prompt = String(r.prompt || "").replace(/___/g, "…");
      return `<li class="mk">
        <p class="mk-q"><small>${esc(r.label || "")}</small>${show(r, prompt)}</p>
        ${r.given != null && String(r.given).trim() !== "" && r.q.type !== "match" ? `<p class="mk-a no"><span>Votre réponse</span><s>${esc(String(r.given))}</s></p>` : ""}
        <p class="mk-a yes"><span>Bonne réponse</span><b>${show(r, r.expected ?? "")}</b>${say ? `<button type="button" class="speak mk-say" data-speak="${esc(say)}" aria-label="Écouter « ${esc(say)} »">${icon("volume", { size: 18 })}</button>` : ""}</p>
        ${r.why ? `<p class="mk-x why">🔎 ${esc(r.why)}</p>` : ""}
        ${r.q.explain ? `<p class="mk-x">${show(r, r.q.explain)}</p>` : ""}
      </li>`;
    }).join("")}</ol>
  </details>`;
}

/* ---------------------- Clavier de tons ---------------------------
   Tapez la syllabe (ex. « hao ») puis cliquez sur un ton : la marque
   est placée sur la bonne voyelle selon les règles du pinyin
   (a/e en priorité, « ou » → o, sinon la dernière voyelle).          */
const TONED = {
  a: "āáǎà", e: "ēéěè", i: "īíǐì", o: "ōóǒò", u: "ūúǔù", "ü": "ǖǘǚǜ",
};
const BASE = {};
Object.entries(TONED).forEach(([v, s]) => [...s].forEach((c) => (BASE[c] = v)));

export function applyTone(before, tone) {
  const m = before.match(/[a-zāáǎàēéěèīíǐìōóǒòūúǔùǖǘǚǜü]+$/i);
  if (!m) return before;
  let syl = [...m[0]].map((c) => BASE[c.toLowerCase()] ? (c === c.toUpperCase() && c !== c.toLowerCase() ? BASE[c.toLowerCase()].toUpperCase() : BASE[c.toLowerCase()]) : c).join("");
  if (tone === 0) return before.slice(0, -m[0].length) + syl; // ton neutre : on retire la marque
  const low = syl.toLowerCase();
  let idx = low.indexOf("a");
  if (idx < 0) idx = low.indexOf("e");
  if (idx < 0 && low.includes("ou")) idx = low.indexOf("o");
  if (idx < 0) { for (let k = low.length - 1; k >= 0; k--) if ("iouü".includes(low[k])) { idx = k; break; } }
  if (idx < 0) return before;
  const ch = TONED[low[idx]][tone - 1];
  const out = syl.slice(0, idx) + (syl[idx] !== low[idx] ? ch.toUpperCase() : ch) + syl.slice(idx + 1);
  return before.slice(0, -m[0].length) + out;
}

/** Noms et courbes des 4 tons (affichés dans l'exercice des tons) */
const TONE_NAMES = ["1er · haut et plat", "2e · montant", "3e · descend et remonte", "4e · descendant"];
const TONE_PATHS = ["M5 7 H43", "M5 21 L43 5", "M5 11 Q17 27 30 19 T43 7", "M5 5 L43 23"];
const TONE_CURVE = (t) => `<svg class="tone-curve t${t}" viewBox="0 0 48 28" width="48" height="28" aria-hidden="true"><path d="${TONE_PATHS[t - 1]}"/></svg>`;

function toneBar(input) {
  const bar = document.createElement("div");
  bar.className = "accent-bar";
  bar.innerHTML = `
    <button type="button" tabindex="-1" data-t="1" title="1er ton">ā</button>
    <button type="button" tabindex="-1" data-t="2" title="2e ton">á</button>
    <button type="button" tabindex="-1" data-t="3" title="3e ton">ǎ</button>
    <button type="button" tabindex="-1" data-t="4" title="4e ton">à</button>
    <button type="button" tabindex="-1" data-t="0" title="Ton neutre">a</button>
    <button type="button" tabindex="-1" data-ins="ü" title="Insérer ü">ü</button>
    <span class="tone-hint">Tapez la syllabe puis le ton · ou écrivez directement en caractères</span>`;
  bar.onclick = (e) => {
    const b = e.target.closest("button"); if (!b) return;
    const { selectionStart: s, selectionEnd: en, value } = input;
    let before = value.slice(0, s);
    before = b.dataset.ins ? before + b.dataset.ins : applyTone(before, +b.dataset.t);
    input.value = before + value.slice(en);
    input.focus(); input.setSelectionRange(before.length, before.length);
    input.dispatchEvent(new Event("input"));
  };
  return bar;
}

/* ------------------ Clavier d'accents (italien) -------------------- */
function italianBar(input) {
  const bar = document.createElement("div");
  bar.className = "accent-bar";
  bar.innerHTML = ["à", "è", "é", "ì", "ò", "ù"].map((a) => `<button type="button" tabindex="-1">${a}</button>`).join("");
  bar.onclick = (e) => {
    if (e.target.tagName !== "BUTTON") return;
    const { selectionStart: s, selectionEnd: en, value } = input;
    input.value = value.slice(0, s) + e.target.textContent + value.slice(en);
    input.focus(); input.setSelectionRange(s + 1, s + 1);
    input.dispatchEvent(new Event("input"));
  };
  return bar;
}

/** Clavier adapté à la langue active */
export const accentBar = (input) => (L.keyboard === "tones" ? toneBar(input) : italianBar(input));

/* --------------------------- Types --------------------------------- */
/**
 * Son joué tout seul à l'affichage d'une question d'écoute. Annulé si la question
 * a déjà changé ; si l'appareil bloque le son (iPhone ouvert depuis une notification,
 * avant tout toucher), le bouton « Écouter » clignote pour inviter à le toucher.
 */
function autoPlay(area, play, btn) {
  setTimeout(() => {
    if (!area.isConnected || area._locked) return;
    Promise.resolve(play()).then((st) => { if (st === "blocked" && btn.isConnected) btn.classList.add("nudge"); });
  }, 200);
}

const TYPES = {
  /* Écoute : le mot est prononcé, on choisit la bonne réponse (🔊 rejoue, 🐢 lentement) */
  listen: {
    label: "Écoutez bien",
    mount(area, q, onReady) {
      area.innerHTML = `<div class="listen-bar">
          <button type="button" class="listen-btn" data-play aria-label="Réécouter">🔊<span>Écouter</span></button>
          <button type="button" class="listen-btn slow" data-play-slow aria-label="Écouter lentement">🐢<span>Lentement</span></button>
        </div><div class="listen-opts"></div>`;
      const play = (slow) => speak(q.say, { slow, force: true });
      const btn = area.querySelector("[data-play]");
      btn.onclick = () => { btn.classList.remove("nudge"); play(false); };
      area.querySelector("[data-play-slow]").onclick = () => { btn.classList.remove("nudge"); play(true); };
      autoPlay(area, () => play(false), btn);
      const sub = area.querySelector(".listen-opts");
      // Dictée d'un mot (q.write) : on écrit ce qu'on entend ; sinon on choisit
      const api = q.write ? TYPES.translate.mount(sub, q, onReady) : TYPES.mcq.mount(sub, q, onReady);
      area._keys = (e) => { if (e.key === " " && e.target === document.body) { e.preventDefault(); play(false); } else sub._keys?.(e); };
      return { check() { const r = api.check(); return { ...r, note: q.reveal ? `On entendait : ${q.reveal}` : r.note }; } };
    },
  },

  /* Tons (mandarin) : la syllabe est dite posément ; chaque réponse
     montre la syllabe avec son ton et la courbe de la voix, et un 🔊 permet de
     COMPARER avec un autre caractère prononcé sur ce ton (ex. 妈 mā / 麻 má…). */
  tone: {
    label: "Écoutez le ton",
    mount(area, q, onReady) {
      const play = (slow) => speak(q.say, { slow, force: true, factor: 0.85 });
      area.innerHTML = `<div class="listen-bar">
          <button type="button" class="listen-btn" data-play aria-label="Réécouter">🔊<span>Écouter</span></button>
          <button type="button" class="listen-btn slow" data-play-slow aria-label="Écouter lentement">🐢<span>Lentement</span></button>
        </div>
        <div class="tone-grid">${[1, 2, 3, 4].map((t) => `<div class="tone-cell">
          <button type="button" class="option tone-opt" data-i="${t - 1}"><kbd>${t}</kbd>${TONE_CURVE(t)}<b>${esc(applyTone(q.syl, t))}</b><small>${TONE_NAMES[t - 1]}</small></button>
          ${q.cmp?.[t - 1] ? (([c, py]) => `<button type="button" class="tone-cmp" data-cmp="${esc(c)}" aria-label="Comparer : ${esc(c)} se prononce avec le ${t === 1 ? "1er" : t + "e"} ton">🔊<span>${esc(c)}</span>${py ? `<small>${esc(py)}</small>` : ""}</button>`)(q.cmp[t - 1]) : ""}
        </div>`).join("")}</div>
        ${q.cmp ? `<p class="tone-help small muted">Touchez 🔊 sous un ton pour l'écouter sur un autre caractère et comparer.</p>` : ""}`;
      const btn = area.querySelector("[data-play]");
      btn.onclick = () => { btn.classList.remove("nudge"); play(false); };
      area.querySelector("[data-play-slow]").onclick = () => { btn.classList.remove("nudge"); play(true); };
      area.querySelectorAll("[data-cmp]").forEach((b) => (b.onclick = () => speak(b.dataset.cmp, { force: true, factor: 0.85 })));
      autoPlay(area, () => play(false), btn);
      let picked = null;
      const btns = [...area.querySelectorAll(".tone-opt")];
      const pick = (b) => { if (area._locked) return; btns.forEach((x) => x.classList.remove("selected")); b.classList.add("selected"); picked = +b.dataset.i; haptic(8); onReady(true); };
      btns.forEach((b) => (b.onclick = () => pick(b)));
      area._keys = (e) => {
        if (e.key === " " && e.target === document.body) { e.preventDefault(); play(false); return; }
        const n = +e.key; if (n >= 1 && n <= 4) pick(btns[n - 1]);
      };
      return {
        check() {
          area._locked = true;
          btns.forEach((b) => { b.disabled = true; if (+b.dataset.i === q.answer) b.classList.add("correct"); else if (+b.dataset.i === picked) b.classList.add("wrong"); });
          const label = (i) => `${applyTone(q.syl, i + 1)} (${TONE_NAMES[i]})`;
          return { correct: picked === q.answer, given: picked == null ? "" : label(picked), expected: label(q.answer), note: q.reveal ? `On entendait : ${q.reveal}` : "" };
        },
      };
    },
  },

  /* Remettre les mots dans l'ordre : on touche les étiquettes pour construire
     la phrase ; on retouche un mot placé pour le renvoyer dans la réserve. */
  order: {
    label: "Remettez dans l'ordre",
    mount(area, q, onReady) {
      const sep = L.code === "zh" ? "" : " ";
      let bank = shuffle(q.tiles.map((t, i) => ({ t, i })));
      // Jamais déjà dans le bon ordre
      for (let k = 0; k < 5 && bank.map((x) => x.t).join(sep) === q.tiles.join(sep); k++) bank = shuffle(bank);
      const line = [];
      area.innerHTML = `${q.fr ? `<p class="ord-fr">« ${esc(q.fr)} »</p>` : ""}
        <div class="ord-line" aria-label="Votre phrase"><span class="ord-ph">Touchez les mots dans l'ordre</span></div>
        <div class="ord-bank"></div>`;
      const lineEl = area.querySelector(".ord-line"), bankEl = area.querySelector(".ord-bank");
      const tile = (x, where) => `<button type="button" class="ord-tile ${L.wordClass}" data-i="${x.i}" data-where="${where}">${tx(q, x.t)}</button>`;
      const paint = () => {
        lineEl.innerHTML = line.length ? line.map((x) => tile(x, "line")).join("") : `<span class="ord-ph">Touchez les mots dans l'ordre</span>`;
        bankEl.innerHTML = bank.map((x) => tile(x, "bank")).join("");
        onReady(!bank.length);
      };
      area.onclick = (e) => {
        const b = e.target.closest(".ord-tile");
        if (!b || area._locked) return;
        const i = +b.dataset.i;
        haptic(6);
        if (b.dataset.where === "bank") { const k = bank.findIndex((x) => x.i === i); line.push(bank.splice(k, 1)[0]); }
        else { const k = line.findIndex((x) => x.i === i); bank.push(line.splice(k, 1)[0]); }
        paint();
      };
      paint();
      return {
        check() {
          area._locked = true;
          const given = line.map((x) => x.t).join(sep), want = q.tiles.join(sep);
          const correct = given === want || (q.answer || []).includes(given);
          lineEl.classList.add(correct ? "correct" : "wrong");
          if (q.say) speak(q.say, { force: true });
          return { correct, given, expected: want };
        },
      };
    },
  },

  mcq: {
    label: "Choisissez la bonne réponse",
    mount(area, q, onReady) {
      // Vrai / Faux : toujours dans cet ordre ; sinon, réponses mélangées
      const tf = q.keepOrder || (q.options.length === 2 && /vrai/i.test(q.options[0]) && /faux/i.test(q.options[1]));
      const order = tf ? q.options.map((_, i) => i) : shuffle(q.options.map((_, i) => i));
      let picked = null;
      area.innerHTML = `<div class="options">${order
        .map((i, k) => `<button class="option" data-i="${i}"><kbd>${k + 1}</kbd><span>${tx(q, q.options[i])}</span></button>`)
        .join("")}</div>`;
      const btns = [...area.querySelectorAll(".option")];
      const pick = (b) => { btns.forEach((x) => x.classList.remove("selected")); b.classList.add("selected"); picked = +b.dataset.i; haptic(8); onReady(true); };
      btns.forEach((b) => (b.onclick = () => pick(b)));
      area._keys = (e) => { const n = +e.key; if (n >= 1 && n <= btns.length && !area._locked) pick(btns[n - 1]); };
      return {
        check() {
          area._locked = true;
          btns.forEach((b) => {
            b.disabled = true;
            if (+b.dataset.i === q.answer) b.classList.add("correct");
            else if (+b.dataset.i === picked) b.classList.add("wrong");
          });
          return { correct: picked === q.answer, given: q.options[picked], expected: q.options[q.answer] };
        },
      };
    },
  },

  fill: {
    label: "Complétez la phrase",
    mount(area, q, onReady) {
      const [before, after = ""] = q.q.split("___");
      area.innerHTML = `<p class="fill-sentence">${tx(q, before)}<input class="fill-input" autocomplete="off" autocapitalize="off" spellcheck="false" aria-label="Réponse">${tx(q, after)}</p>`;
      const input = area.querySelector("input");
      area.appendChild(accentBar(input));
      input.oninput = () => onReady(input.value.trim().length > 0);
      setTimeout(() => input.focus(), 50);
      return {
        check() {
          input.disabled = true;
          const res = checkText(input.value, q.answer);
          input.classList.add(res.correct ? "correct" : "wrong");
          return { ...res, given: input.value, expected: q.answer[0] };
        },
      };
    },
    // la phrase est affichée dans la zone de réponse, pas dans le titre
    title: () => "Complétez avec le mot manquant",
  },

  translate: {
    get label() { return L.trLabel; },
    mount(area, q, onReady) {
      area.innerHTML = `<textarea class="tr-input" rows="2" autocomplete="off" autocapitalize="off" spellcheck="false" placeholder="${esc(L.trPlaceholder)}" aria-label="Traduction"></textarea>`;
      const input = area.querySelector("textarea");
      area.appendChild(accentBar(input));
      input.oninput = () => onReady(input.value.trim().length > 0);
      input.onkeydown = (e) => { if (e.key === "Enter") e.preventDefault(); };
      setTimeout(() => input.focus(), 50);
      return {
        check() {
          input.disabled = true;
          const res = checkText(input.value, q.answer);
          input.classList.add(res.correct ? "correct" : "wrong");
          return { ...res, given: input.value, expected: q.answer[0] };
        },
      };
    },
  },

  match: {
    label: "Associez les paires",
    mount(area, q, onReady) {
      const left = shuffle(q.pairs.map((p, i) => ({ t: p[0], i })));
      const right = shuffle(q.pairs.map((p, i) => ({ t: p[1], i })));
      let sel = null, found = 0, mistakes = 0;
      area.innerHTML = `<div class="match">
        <div class="match-col">${left.map((x) => `<button class="tile" data-side="L" data-i="${x.i}" data-say="${esc(x.t)}">${tile(q, x.t)}</button>`).join("")}</div>
        <div class="match-col">${right.map((x) => `<button class="tile" data-side="R" data-i="${x.i}">${tile(q, x.t)}</button>`).join("")}</div>
      </div>`;
      area.querySelectorAll(".tile").forEach((t) => (t.onclick = () => {
        if (t.classList.contains("done")) return;
        if (t.dataset.side === "L") speak(t.dataset.say);
        if (!sel || sel.dataset.side === t.dataset.side) {
          area.querySelectorAll(".tile.sel").forEach((x) => x.classList.remove("sel"));
          sel = t; t.classList.add("sel"); return;
        }
        if (sel.dataset.i === t.dataset.i) {
          [sel, t].forEach((x) => { x.classList.remove("sel"); x.classList.add("done"); x.disabled = true; });
          if (++found === q.pairs.length) onReady(true);
        } else {
          mistakes++;
          [sel, t].forEach((x) => { x.classList.remove("sel"); x.classList.add("shake"); setTimeout(() => x.classList.remove("shake"), 400); });
        }
        sel = null;
      }));
      return {
        check() {
          return {
            correct: mistakes === 0,
            given: mistakes ? `${mistakes} erreur(s) d'association` : "",
            expected: q.pairs.map((p) => `${plain(p[0])} = ${plain(p[1])}`).join(" · "),
            note: mistakes ? null : "Sans aucune erreur !",
          };
        },
      };
    },
  },
};

/* --------------------------- Lecteur ------------------------------- */
/**
 * Lance un quiz dans `root`.
 * @param {HTMLElement} root
 * @param {{ title:string, questions:{ref:string,q:object}[],
 *           onFinish:(results)=>void, onQuit:()=>void }} opts
 */
/* ---------------- Reprise d'un quiz interrompu ----------------
   Après chaque réponse, l'avancement est gardé (par langue) : si l'appli
   est fermée ou qu'on quitte le quiz, on propose de reprendre à la même
   question pendant 48 h. */
const RESUME_KEY = `quiz.resume.${LANG}`;
const RESUME_TTL = 48 * 36e5;
export function savedQuiz(key) {
  try {
    const r = JSON.parse(localStorage.getItem(RESUME_KEY) || "null");
    if (!r || r.key !== key || Date.now() - r.ts > RESUME_TTL || !(r.i > 0) || r.i >= r.questions.length) return null;
    return r;
  } catch { return null; }
}
/** Quiz en cours, quel qu'il soit (carte « Reprendre » du parcours) */
export function pendingQuiz() {
  try { const r = JSON.parse(localStorage.getItem(RESUME_KEY) || "null"); return r && r.hash && savedQuiz(r.key) ? r : null; } catch { return null; }
}
export function clearSavedQuiz() { try { localStorage.removeItem(RESUME_KEY); } catch {} }
/** Propose de reprendre : renvoie la sauvegarde choisie, ou null pour recommencer */
export async function offerResume(key) {
  const r = savedQuiz(key);
  if (!r) return null;
  const v = await modal({
    title: "Reprendre où vous en étiez ?",
    body: `<p>Vous aviez répondu à <b>${r.i} question${r.i > 1 ? "s" : ""} sur ${r.questions.length}</b> (${r.results.filter((x) => x.correct).length} bonne${r.results.filter((x) => x.correct).length > 1 ? "s" : ""}).</p>`,
    actions: [{ label: "Recommencer", value: "new" }, { label: "▶ Reprendre", value: "go", kind: "primary" }],
    dismissable: false,
  });
  if (v === "go") return r;
  clearSavedQuiz();
  return null;
}

export function runQuiz(root, { title, questions, onFinish, onQuit, onAnswer, xpPerAnswer = 0, stopWhen = null, countText = null, jokers = 0, silent = false, deadline = 0, saveKey = "", resume = null }) {
  // silent : pas de correction après chaque réponse (conditions d'examen) ; deadline : fin forcée à cette heure (ms)
  // saveKey : avancement gardé pour une reprise ; resume : sauvegarde à reprendre (offerResume)
  if (resume) { questions = resume.questions; jokers = resume.jokers ?? jokers; }
  let i = resume ? resume.i : 0, phase = "answer", api = null, current = null, combo = 0, ended = false;
  const jokersMax = resume?.jokersMax ?? jokers;
  const results = resume ? resume.results.map((r, k) => ({ ...r, q: questions[k]?.q || r.q })) : [];
  const save = () => {
    if (!saveKey) return;
    try {
      localStorage.setItem(RESUME_KEY, JSON.stringify({ key: saveKey, hash: location.hash, title, ts: Date.now(), i: results.length, questions, jokers, jokersMax,
        results: results.map(({ q, ...r }) => r) }));
    } catch {}
  };

  root.innerHTML = `
    <section class="quiz" aria-live="polite">
      <header class="quiz-top">
        <button class="icon-btn quiz-quit" aria-label="Quitter le quiz">✕</button>
        <div class="bar"><span></span></div>
        <span class="quiz-count"></span>
        ${jokers ? `<span class="joker-pill" title="Jokers : une faute de frappe (une lettre) est pardonnée" aria-label="Jokers restants"></span>` : ""}
        ${deadline ? `<span class="timer-pill" aria-label="Temps restant"></span>` : ""}
        ${reportButton()}
      </header>
      <p class="quiz-title">${questions[0] && wantPinyin(questions[0].ref) ? ruby(title) : esc(title)}</p>
      <div class="quiz-card">
        <p class="q-label"></p>
        <h2 class="q-text"></h2>
        <div class="q-area"></div>
      </div>
      <footer class="quiz-foot">
        <div class="feedback" hidden></div>
        <button class="btn primary big quiz-action" disabled>Vérifier</button>
      </footer>
    </section>`;

  const el = (s) => root.querySelector(s);
  const action = el(".quiz-action"), feedback = el(".feedback"), area = el(".q-area");
  // ⚑ Signaler : la question affichée (et la réponse, une fois vérifiée) part avec le signalement
  let lastRes = null;
  const expectedOf = (q) => (q.options && Number.isInteger(q.answer) ? q.options[q.answer] : Array.isArray(q.answer) ? q.answer[0] : q.pairs ? q.pairs.map((p) => p.join(" = ")).join(" · ") : "");
  setReportContext(() => {
    const q = current || {};
    return {
      place: `${title} · question ${i + 1}/${questions.length}`, ref: questions[i]?.ref,
      question: [q.q, q.fr && q.fr !== q.q ? `(${q.fr})` : "", q.options ? `Choix : ${q.options.join(" / ")}` : ""].filter(Boolean).join(" "),
      expected: lastRes?.expected ?? expectedOf(q), given: lastRes?.given ?? "", audio: q.say || q.audio || "",
    };
  });

  const paintJokers = () => {
    const p = root.querySelector(".joker-pill");
    if (p) { p.textContent = `🃏 ${jokers}/${jokersMax}`; p.classList.toggle("empty", !jokers); }
  };
  function show() {
    paintJokers();
    const { ref } = questions[i];
    const q = questions[i].q._py === undefined && wantPinyin(ref) ? { ...questions[i].q, _py: true } : questions[i].q;
    current = q;
    const type = TYPES[q.type];
    phase = "answer";
    el(".bar span").style.width = `${(i / questions.length) * 100}%`;
    el(".quiz-count").textContent = countText ? countText(i, questions.length) : `${i + 1} / ${questions.length}`;
    el(".q-label").textContent = type.label;
    el(".q-text").innerHTML = tx(q, type.title ? type.title(q) : q.q);
    feedback.hidden = true; feedback.className = "feedback"; feedback.innerHTML = "";
    root.querySelector(".quiz-foot").className = "quiz-foot";
    action.textContent = silent ? "Valider" : "Vérifier"; action.disabled = true;
    area._locked = false; area._keys = null; lastRes = null;
    api = type.mount(area, q, (ready) => { if (phase === "answer") action.disabled = !ready; });
    // Le son de la question suivante est préparé pendant qu'on répond à celle-ci
    const nq = questions[i + 1]?.q;
    if (nq?.say) setTimeout(() => prefetchSpeech(nq.say), 400);
  }

  function check() {
    const { ref } = questions[i];
    const q = current;
    const res = api.check();
    // Joker : une faute de frappe (une seule lettre) est acceptée tant qu'il en reste
    if (!res.correct && jokers > 0 && typeof res.given === "string") {
      const near = typoOf(res.given, q.answer);
      if (near) {
        jokers--;
        res.correct = true; res.joker = true;
        res.note = `🃏 Joker utilisé : petite faute de frappe, la bonne orthographe est « ${near} ». ${jokers ? `Il vous reste ${jokers} joker${jokers > 1 ? "s" : ""}.` : "C'était votre dernier joker."}`;
        area.querySelector(".wrong")?.classList.replace("wrong", "correct");
        paintJokers();
      }
    } else if (!res.correct && jokersMax && !jokers && typeof res.given === "string" && typoOf(res.given, q.answer)) {
      res.note = "Plus de joker : même une faute de frappe compte comme une erreur.";
    }
    // Pourquoi c'est faux : explication tirée de la comparaison avec la bonne réponse
    if (!res.correct && !res.why && ["fill", "translate", "listen", "order", "mcq"].includes(q.type) && typeof res.given === "string") {
      const opts = q.type === "mcq" || (q.type === "listen" && !q.write) ? [res.expected] : [].concat(q.answer ?? res.expected);
      const skip = q.type !== "fill" && q.type !== "translate" && !q.write && q.type !== "order" && opts.some((o) => /[+·]/.test(String(o)) || String(o).length > 60);
      if (!skip) res.why = diagnose(res.given, opts);
    }
    lastRes = res;
    const type = TYPES[q.type];
    results.push({
      ref, correct: res.correct, given: res.given, joker: !!res.joker,
      // pour la revue des erreurs en fin de quiz
      why: res.why || "", q, prompt: q.type === "fill" ? q.q : q.type === "order" && q.fr ? `« ${q.fr} »` : (type.title ? type.title(q) : q.q), label: type.label, expected: res.expected ?? expectedOf(q),
    });
    trackAnswer(q, res.correct, ref);
    save();
    onAnswer?.({ index: i, q, correct: res.correct, given: res.given, expected: res.expected });
    if (silent) { haptic(12); return next(); }
    phase = "feedback";
    const foot = root.querySelector(".quiz-foot");
    foot.classList.add(res.correct ? "is-correct" : "is-wrong");
    feedback.hidden = false;
    combo = res.correct ? combo + 1 : 0;
    celebrateAnswer(root, res.correct, { xp: xpPerAnswer, combo, progress: (i + 1) / questions.length });
    feedback.innerHTML = `<span class="fb-mascot">${mascot(res.correct ? "happy" : "sad", { size: 58 })}</span><div class="fb-txt">` + (res.correct
      ? `<strong>✓ ${tx(q, L.cheers[i % L.cheers.length])}</strong>${res.note ? `<p>${tx(q, res.note)}</p>` : ""}${q.explain ? `<p class="muted">${tx(q, q.explain)}</p>` : ""}`
      : `<strong>✗ Pas tout à fait…</strong>
         <p>Bonne réponse : <b>${tx(q, res.expected)}</b></p>
         ${res.why ? `<p class="why">🔎 ${tx(q, res.why)}</p>` : ""}
         ${res.note ? `<p class="muted small">${tx(q, res.note)}</p>` : ""}
         ${q.explain ? `<p class="explain">💡 ${tx(q, q.explain)}</p>` : ""}
         <p class="muted small">Cette question est ajoutée à votre cahier d'erreurs.</p>`) + `</div>`;
    // Fin anticipée possible (mort subite : première erreur)
    ended = !!stopWhen?.(results);
    action.textContent = ended || i === questions.length - 1 ? "Voir mes résultats" : "Continuer";
    action.disabled = false;
    action.focus();
  }

  function next() {
    if (!ended && ++i < questions.length) show();
    else { el(".bar span").style.width = "100%"; cleanup(); flushStats(); if (saveKey) clearSavedQuiz(); setLastResults(results); onFinish(results); }
  }

  action.onclick = () => (phase === "answer" ? check() : next());
  el(".quiz-quit").onclick = () => { cleanup(); flushStats(); onQuit(); };

  const onKey = (e) => {
    if (e.key === "Enter" && !action.disabled && e.target !== action) { e.preventDefault(); action.click(); }
    else area._keys?.(e);
  };
  document.addEventListener("keydown", onKey);
  let timer = 0;
  const cleanup = () => { document.removeEventListener("keydown", onKey); clearInterval(timer); };
  root._cleanup = cleanup;
  if (deadline) {
    const pill = root.querySelector(".timer-pill");
    const tick = () => {
      if (ended === "time") return;
      const left = Math.max(0, deadline - Date.now()), s = Math.ceil(left / 1000);
      pill.textContent = `⏱ ${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}`;
      pill.classList.toggle("warn", s <= 60);
      if (left > 0) return;
      // Temps écoulé : les questions restantes comptent comme non répondues
      ended = "time";
      for (let k = results.length; k < questions.length; k++) {
        const q = questions[k].q, type = TYPES[q.type];
        results.push({ ref: questions[k].ref, correct: false, given: "", timeout: true, q, prompt: q.type === "fill" ? q.q : (type.title ? type.title(q) : q.q), label: type.label, expected: expectedOf(q) });
      }
      cleanup(); flushStats(); setLastResults(results); onFinish(results);
    };
    timer = setInterval(tick, 500); tick();
  }

  show();
}
