/* =====================================================================
   social.js — Amis, messages et défis (Supabase)
   ---------------------------------------------------------------------
   - Nom d'utilisateur unique (table `profiles`).
   - Demandes d'ami : envoyées par nom d'utilisateur, acceptées par
     l'autre personne ; une fois amis, chacun voit la progression de
     l'autre (table `user_stats`, un résumé par langue).
   - Messages privés entre amis, reçus en temps réel.
   - Défis : l'un lance, l'autre accepte, puis chacun répond à des
     questions de SA langue ; le meilleur score gagne (puis le temps).
   Le schéma et les règles de sécurité sont dans supabase/social.sql.
   ===================================================================== */

import { wotdList } from "./wotd.js";
import { state, subscribe, commit } from "./storage.js";
import { code, LANGS } from "./lang.js";
import { cloudInfo, onCloud, getClient, isConfigured } from "./cloud.js";
import * as P from "./progress.js";
import { setSocialStats } from "./cosmetics.js";
import { lvlLabel, LEVELS } from "../data/curriculum.js";

export const USERNAME_RE = /^[a-z0-9_]{3,20}$/;

/* --------------------------- État partagé -------------------------- */
const S = {
  ready: false,          // données chargées au moins une fois
  me: null,              // { id, username, pseudo, avatar } ou null (pas encore de nom d'utilisateur)
  profiles: {},          // { [id]: profil }
  friendships: [],       // lignes brutes
  stats: {},             // { [userId]: { [lang]: résumé } }
  challenges: [],
  unread: {},            // { [friendId]: nombre }
};
export const social = () => S;
const listeners = new Set();
export const onSocial = (fn) => (listeners.add(fn), () => listeners.delete(fn));
const emit = (what = "all", detail) => [...listeners].forEach((fn) => fn(what, detail));

const uid = () => cloudInfo().user?.id || null;
export const isAvailable = () => isConfigured() && !!uid();

/* ------------------------------ Erreurs ---------------------------- */
const ERRORS = {
  not_found: "Aucun utilisateur ne porte ce nom.",
  self: "C'est votre propre nom d'utilisateur 🙂",
  already_friends: "Vous êtes déjà amis.",
  already_sent: "Demande déjà envoyée : elle attend sa réponse.",
  no_profile: "Choisissez d'abord votre nom d'utilisateur.",
  not_friends: "Vous devez être amis pour faire cela.",
  challenge_not_playable: "Ce défi n'est pas (ou plus) jouable.",
  already_played: "Vous avez déjà joué ce défi.",
  invalid_n: "Nombre de questions non disponible.",
};
export function socialError(e) {
  const m = String(e?.message || e || "");
  for (const [k, v] of Object.entries(ERRORS)) if (m.includes(k)) return v;
  if (/duplicate key|unique/i.test(m)) return "Ce nom d'utilisateur est déjà pris.";
  if (/Failed to fetch|NetworkError|Load failed/i.test(m)) return "Serveur injoignable. Vérifiez votre connexion.";
  return m || "Une erreur est survenue.";
}
const check = ({ data, error }) => { if (error) throw error; return data; };

/* ------------------------------ Chargement ------------------------- */
let loading = null;
export function refresh() {
  if (!isAvailable()) return Promise.resolve();
  if (loading) return loading;
  loading = (async () => {
    const sb = await getClient();
    const me = uid();
    const [mine, fr, ch, unread] = await Promise.all([
      sb.from("profiles").select("*").eq("id", me).maybeSingle().then(check),
      sb.from("friendships").select("*").then(check),
      sb.from("challenges").select("*").order("created_at", { ascending: false }).limit(60).then(check),
      sb.from("messages").select("sender").eq("recipient", me).is("read_at", null).then(check),
    ]);
    S.me = mine;
    S.friendships = fr;
    S.challenges = ch;
    S.unread = {};
    unread.forEach((m) => (S.unread[m.sender] = (S.unread[m.sender] || 0) + 1));

    const ids = [...new Set(fr.flatMap((f) => [f.requester, f.addressee]).concat(ch.flatMap((c) => [c.challenger, c.opponent])))].filter((x) => x !== me);
    if (mine) S.profiles[me] = mine;
    if (ids.length) {
      const [profs, stats] = await Promise.all([
        sb.from("profiles").select("id, username, pseudo, avatar, color, frame, banner").in("id", ids).then(check),
        sb.from("user_stats").select("user_id, lang, summary, updated_at").in("user_id", [...ids, me]).then(check),
      ]);
      profs.forEach((p) => (S.profiles[p.id] = p));
      S.stats = {};
      stats.forEach((r) => ((S.stats[r.user_id] ||= {})[r.lang] = { ...r.summary, updated_at: r.updated_at }));
    } else {
      const stats = await sb.from("user_stats").select("user_id, lang, summary, updated_at").eq("user_id", me).then(check);
      S.stats = {};
      stats.forEach((r) => ((S.stats[r.user_id] ||= {})[r.lang] = { ...r.summary, updated_at: r.updated_at }));
    }
    S.ready = true;
    setSocialStats({ wins: record().win });
    emit("all");
  })().finally(() => (loading = null));
  return loading;
}

/* --------------------------- Vues dérivées ------------------------- */
const other = (f, me = uid()) => (f.requester === me ? f.addressee : f.requester);
export function friends() {
  return S.friendships.filter((f) => f.status === "accepted")
    .map((f) => ({ ...S.profiles[other(f)], friendshipId: f.id, since: f.created_at }))
    .filter((p) => p.id)
    .sort((a, b) => (S.unread[b.id] || 0) - (S.unread[a.id] || 0) || (a.pseudo || a.username).localeCompare(b.pseudo || b.username));
}
export const incoming = () => S.friendships.filter((f) => f.status === "pending" && f.addressee === uid()).map((f) => ({ ...f, from: S.profiles[f.requester] }));
export const outgoing = () => S.friendships.filter((f) => f.status === "pending" && f.requester === uid()).map((f) => ({ ...f, to: S.profiles[f.addressee] }));
export const friendByUsername = (u) => friends().find((f) => f.username === u);
export const profileOf = (id) => S.profiles[id];
export const statsOf = (id) => S.stats[id] || {};

/** Mode « vitesse » : 100 points par bonne réponse, −3 points par seconde */
export const SPEED_PER_GOOD = 100, SPEED_PER_SEC = 3;
export function challengePoints(r, mode) {
  if (mode !== "speed" || !r) return null;
  return Math.max(0, r.score * SPEED_PER_GOOD - Math.round((r.ms || 0) / 1000) * SPEED_PER_SEC);
}
/** Nombre de mots appris d'un ami (sa langue la plus avancée), ou null si inconnu */
export function friendWords(id) {
  const s = Object.values(statsOf(id));
  return s.length ? Math.max(...s.map((x) => x?.words || 0)) : null;
}

/** Point de vue de l'utilisateur sur un défi */
export function view(c) {
  const me = uid();
  const iAmChallenger = c.challenger === me;
  const side = iAmChallenger ? "challenger" : "opponent", oside = iAmChallenger ? "opponent" : "challenger";
  const mine = c[`${side}_score`] != null ? { score: c[`${side}_score`], total: c[`${side}_total`], ms: c[`${side}_ms`], lang: c[`${side}_lang`] } : null;
  const theirs = c[`${oside}_score`] != null ? { score: c[`${oside}_score`], total: c[`${oside}_total`], ms: c[`${oside}_ms`], lang: c[`${oside}_lang`] } : null;
  let stage;
  if (c.status === "declined") stage = "declined";
  else if (c.status === "cancelled") stage = "cancelled";
  else if (c.status === "pending") stage = iAmChallenger ? "waiting_accept" : "to_accept";
  else if (!mine) stage = "to_play";
  else if (!theirs) stage = "waiting_play";
  else stage = "done";
  let outcome = null;
  if (mine) mine.points = challengePoints(mine, c.mode);
  if (theirs) theirs.points = challengePoints(theirs, c.mode);
  if (stage === "done") {
    const a = mine.score / mine.total, b = theirs.score / theirs.total;
    if (c.mode === "survival") outcome = mine.score > theirs.score ? "win" : mine.score < theirs.score ? "lose" : mine.ms < theirs.ms ? "win" : mine.ms > theirs.ms ? "lose" : "draw";
    else if (c.mode === "speed") outcome = mine.points > theirs.points ? "win" : mine.points < theirs.points ? "lose" : "draw";
    else if (c.mode === "precision") outcome = a > b ? "win" : a < b ? "lose" : "draw";
    else outcome = a > b ? "win" : a < b ? "lose" : mine.ms < theirs.ms ? "win" : mine.ms > theirs.ms ? "lose" : "draw"; // anciens défis
  }
  return { ...c, iAmChallenger, friend: S.profiles[iAmChallenger ? c.opponent : c.challenger], mine, theirs, stage, outcome };
}
export const challengesWith = (friendId) => S.challenges.filter((c) => c.challenger === friendId || c.opponent === friendId).map(view);
export const allChallenges = () => S.challenges.map(view);

/** Nombre d'actions en attente (pastille de l'onglet Amis) */
export function badgeCount() {
  if (!isAvailable() || !S.ready) return 0;
  const unread = Object.values(S.unread).reduce((a, b) => a + b, 0);
  const todo = allChallenges().filter((c) => c.stage === "to_accept" || c.stage === "to_play").length;
  return incoming().length + unread + todo;
}

/* ------------------------------ Actions ---------------------------- */
async function rpc(name, args) { const sb = await getClient(); return check(await sb.rpc(name, args)); }

export async function createProfile(username) {
  const u = username.trim().toLowerCase();
  if (!USERNAME_RE.test(u)) throw new Error("3 à 20 caractères : lettres minuscules, chiffres ou _ (sans espace ni accent).");
  const sb = await getClient();
  try {
    check(await sb.from("profiles").insert({ id: uid(), username: u, pseudo: state.profile?.pseudo || u, avatar: state.profile?.avatar || "👤" }));
  } catch (e) { throw new Error(socialError(e)); }
  await refresh();
  pushStats(true);
}

export async function addFriend(username) {
  const r = await rpc("send_friend_request", { p_username: username.trim().toLowerCase().replace(/^@/, "") }).catch((e) => { throw new Error(socialError(e)); });
  if (r !== "sent" && r !== "accepted") throw new Error(socialError(r));
  await refresh();
  return r;
}
export async function acceptFriend(id) { await rpc("accept_friend_request", { p_id: id }); await refresh(); }
export async function removeFriendship(id) {
  const sb = await getClient();
  check(await sb.from("friendships").delete().eq("id", id));
  await refresh();
}

export async function loadMessages(friendId, limit = 80) {
  const sb = await getClient();
  const me = uid();
  const rows = check(await sb.from("messages").select("*")
    .or(`and(sender.eq.${me},recipient.eq.${friendId}),and(sender.eq.${friendId},recipient.eq.${me})`)
    .order("created_at", { ascending: false }).limit(limit));
  return rows.reverse();
}
/** Envoie un message ; options : replyTo (id cité), kind ("text" | "word"), meta (carte de mot) */
export async function sendMessage(friendId, body, { replyTo = null, kind = "text", meta = null } = {}) {
  const text = body.trim().slice(0, 1000);
  if (!text) return null;
  const sb = await getClient();
  const row = { sender: uid(), recipient: friendId, body: text };
  if (replyTo) row.reply_to = replyTo;
  if (kind !== "text") { row.kind = kind; row.meta = meta; }
  try { return check(await sb.from("messages").insert(row).select().single()); }
  catch (e) { throw new Error(socialError(e)); }
}
export const MSG_REACTIONS = ["❤️", "😂", "👏", "😮", "🔥"];
/** Réagir à un message (emoji = null pour retirer) ; renvoie les réactions à jour */
export async function reactMessage(id, emoji) { return rpc("react_message", { p_id: id, p_emoji: emoji }); }

/** Boîte de réception : dernière conversation avec chaque ami (+ non-lus) */
export async function loadInbox() {
  const sb = await getClient();
  const me = uid();
  const rows = check(await sb.from("messages").select("id, sender, recipient, body, kind, created_at, read_at")
    .or(`sender.eq.${me},recipient.eq.${me}`).order("created_at", { ascending: false }).limit(400));
  const conv = new Map();
  for (const m of rows) {
    const other = m.sender === me ? m.recipient : m.sender;
    let c = conv.get(other);
    if (!c) { c = { friendId: other, last: m, unread: 0 }; conv.set(other, c); }
    if (m.recipient === me && !m.read_at) c.unread++;
  }
  return [...conv.values()];
}

/** « … est en train d'écrire » : petit canal de diffusion propre à la conversation */
export async function typingChannel(friendId, onTyping) {
  const sb = await getClient();
  const me = uid();
  if (!sb.channel) return { ping() {}, leave() {} };
  const ch = sb.channel(`typing-${[me, friendId].sort().join("-")}`, { config: { broadcast: { self: false } } })
    .on("broadcast", { event: "typing" }, ({ payload }) => { if (payload?.from === friendId) onTyping(!!payload.on); });
  ch.subscribe();
  let last = 0;
  return {
    ping(on = true) {
      const now = Date.now();
      if (on && now - last < 2500) return;
      last = on ? now : 0;
      try { ch.send({ type: "broadcast", event: "typing", payload: { from: me, on } }); } catch {}
    },
    leave() { try { sb.removeChannel?.(ch); } catch {} },
  };
}
/** Marque comme lus les messages reçus de cet ami (force : même si le compteur local est à zéro) */
export async function markRead(friendId, force = false) {
  if (!S.unread[friendId] && !force) return;
  delete S.unread[friendId];
  emit("unread");
  await rpc("mark_messages_read", { p_friend: friendId }).catch(() => {});
}

export async function createChallenge(friendId, n = 10, mode = "speed", live = false, { words = null, rematch = null } = {}) {
  const id = await rpc("create_challenge", { p_opponent: friendId, p_n: mode === "survival" ? 50 : n, p_mode: mode, p_live: !!live, p_words: words, p_rematch: rematch }).catch((e) => { throw new Error(socialError(e)); });
  await refresh();
  return id;
}
export async function respondChallenge(id, accept) { await rpc("respond_challenge", { p_id: id, p_accept: accept }).catch((e) => { throw new Error(socialError(e)); }); await refresh(); }
export async function cancelChallenge(id) { await rpc("cancel_challenge", { p_id: id }).catch((e) => { throw new Error(socialError(e)); }); await refresh(); }
export async function submitChallenge(id, { score, total, ms, recap = null }) {
  await rpc("submit_challenge", { p_id: id, p_lang: code, p_score: score, p_total: total, p_ms: Math.round(ms), p_recap: recap })
    .catch((e) => { throw new Error(socialError(e)); });
  await refresh();
}
export async function getChallenge(id) {
  const sb = await getClient();
  const c = check(await sb.from("challenges").select("*").eq("id", id).maybeSingle());
  if (c) { const i = S.challenges.findIndex((x) => x.id === id); if (i >= 0) S.challenges[i] = c; else S.challenges.unshift(c); }
  return c ? view(c) : null;
}

/* ------------------- Résumé de progression partagé ----------------- */
export function mySummary() {
  const g = P.globalProgress(), lvl = P.currentLevel();
  return {
    xp: state.xp, streak: P.streakCount(), level: lvlLabel(lvl), levelName: lvl.name,
    pct: g.pct, done: g.done, total: g.total,
    lessons: Object.values(state.lessons).filter((l) => l.passed).length,
    words: Object.keys(state.vocab).length,
    week: P.weekKey(), weekXp: P.weeklyXp(),
    days: P.last7Days(),
    // Rappel de série (notification du soir) : jour local de la dernière activité et fuseau horaire
    lastDay: P.lastActiveDay(), streakRaw: P.unionStreak() || 0,
    tz: (() => { try { return Intl.DateTimeFormat().resolvedOptions().timeZone || "UTC"; } catch { return "UTC"; } })(),
    remind: state.settings.streakReminder !== false,
    remindHour: state.settings.remindHour || 20,
    notif: state.settings.notif || {},
    // Mot du jour : les mots des prochains jours, pour la notification du matin (9 h par défaut)
    wotd: wotdList(30), wotdHour: state.settings.wotdHour || 9,
  };
}
let lastSent = "", statsTimer = null;
export async function pushStats(force = false) {
  if (!isAvailable() || !S.me || !state.profile) return;
  // Mots les plus ratés : servent aux défis « sur son terrain » lancés par ses amis (module chargé à la demande)
  const { weakWords } = await import("./challenge-gen.js");
  const sum = { ...mySummary(), ...(() => { const w = weakWords(); return { weak: w.list, weakReal: w.real }; })() }, pr0 = state.profile || {}, key = JSON.stringify([sum, pr0.pseudo, pr0.avatar, pr0.color, pr0.frame, pr0.banner]);
  if (!force && key === lastSent) return;
  lastSent = key;
  const sb = await getClient();
  const { error } = await sb.from("user_stats").upsert({ user_id: uid(), lang: code, summary: sum, updated_at: new Date().toISOString() });
  if (error) { lastSent = ""; return; }
  (S.stats[uid()] ||= {})[code] = { ...sum, updated_at: new Date().toISOString() };
  // Historique du classement : XP de la semaine en cours
  if (sum.weekXp > 0) await sb.from("weekly_xp").upsert({ user_id: uid(), week: sum.week, lang: code, xp: sum.weekXp, updated_at: new Date().toISOString() });
  // Pseudo / avatar modifiés dans le profil : on les recopie
  const pr = state.profile || {};
  const color = pr.color || null, frame = pr.frame && pr.frame !== "none" ? pr.frame : null, banner = pr.banner && pr.banner !== "plain" ? pr.banner : null;
  if (state.profile && (S.me.pseudo !== pr.pseudo || S.me.avatar !== pr.avatar || (S.me.color || null) !== color || (S.me.frame || null) !== frame || (S.me.banner || null) !== banner)) {
    const { error: e2 } = await sb.from("profiles").update({ pseudo: pr.pseudo, avatar: pr.avatar, color, frame, banner }).eq("id", uid());
    if (!e2) Object.assign(S.me, { pseudo: pr.pseudo, avatar: pr.avatar, color, frame, banner });
  }
}

/* --------------------------- Temps réel ---------------------------- */
let channel = null, poll = null, startedFor = null;

async function start() {
  const me = uid();
  if (!me || startedFor === me) return;
  stop();
  startedFor = me;
  await refresh().catch(() => {});
  pushStats(true);
  checkMilestones();
  const sb = await getClient();
  if (sb.channel) {
    channel = sb.channel(`social-${me}`)
      .on("postgres_changes", { event: "INSERT", schema: "public", table: "messages", filter: `recipient=eq.${me}` }, (p) => {
        const m = p.new;
        S.unread[m.sender] = (S.unread[m.sender] || 0) + 1;
        emit("message", m);
        if (!S.profiles[m.sender]) refresh();
      })
      // Mes messages lus par l'ami : on affiche « Vu à … » tout de suite
      .on("postgres_changes", { event: "UPDATE", schema: "public", table: "messages", filter: `sender=eq.${me}` }, (p) => emit("msgupdate", p.new))
      .on("postgres_changes", { event: "UPDATE", schema: "public", table: "messages", filter: `recipient=eq.${me}` }, (p) => emit("msgupdate", p.new))
      .on("postgres_changes", { event: "*", schema: "public", table: "challenges" }, () => refresh())
      .on("postgres_changes", { event: "*", schema: "public", table: "friendships" }, () => refresh())
      .on("postgres_changes", { event: "*", schema: "public", table: "activities" }, () => reloadFeed())
      .on("postgres_changes", { event: "*", schema: "public", table: "activity_reactions" }, () => reloadFeed())
      .on("postgres_changes", { event: "*", schema: "public", table: "user_stats" }, (p) => {
        // Progression d'un ami mise à jour : classement et fiches rafraîchis tout de suite
        const r = p.new;
        if (r?.user_id && r.user_id !== uid()) { (S.stats[r.user_id] ||= {})[r.lang] = { ...r.summary, updated_at: r.updated_at }; emit("all"); }
      })
      .subscribe();
  }
  // Filet de sécurité si le temps réel est coupé (réseau mobile…)
  poll = setInterval(() => { if (document.visibilityState === "visible") refresh().catch(() => {}); }, 30000);
}
function stop() {
  if (channel) { getClient().then((sb) => sb.removeChannel?.(channel)); channel = null; }
  clearInterval(poll); poll = null; startedFor = null;
  Object.assign(S, { ready: false, me: null, profiles: {}, friendships: [], stats: {}, challenges: [], unread: {}, feed: null });
  for (const k in H2H) delete H2H[k];
  HIST = null;
  emit("all");
}

export function initSocial() {
  if (!isConfigured()) return;
  onCloud((i) => { if (i.user) start(); else if (startedFor) stop(); });
  if (uid()) start();
  subscribe(() => { clearTimeout(statsTimer); statsTimer = setTimeout(() => { pushStats(); checkMilestones(); }, 4000); });
  document.addEventListener("visibilitychange", () => { if (document.visibilityState === "visible" && uid()) refresh().catch(() => {}); });
}

/** Classement de la semaine : moi + mes amis, XP gagnés depuis lundi (toutes langues) */
export function leaderboard() {
  const week = P.weekKey();
  const total = (id, override) => Object.entries({ ...statsOf(id), ...(override || {}) })
    .reduce((n, [, s]) => n + (s?.week === week ? s.weekXp || 0 : 0), 0);
  const all = (id, override) => Object.values({ ...statsOf(id), ...(override || {}) }).reduce((n, s) => n + (s?.xp || 0), 0);
  const mine = { [code]: mySummary() };
  const me = S.me ? [{ ...S.me, isMe: true, xp: total(S.me.id, mine), allXp: all(S.me.id, mine) }] : [];
  return [...me, ...friends().map((f) => ({ ...f, xp: total(f.id), allXp: all(f.id) }))].sort((a, b) => b.xp - a.xp || b.allXp - a.allXp);
}

/** Lundi (UTC) d'une semaine « 2026-W45 » */
export function weekStart(week) {
  const [y, w] = week.split("-W").map(Number);
  const jan4 = new Date(Date.UTC(y, 0, 4));
  const monday = new Date(jan4); monday.setUTCDate(jan4.getUTCDate() - ((jan4.getUTCDay() || 7) - 1) + (w - 1) * 7);
  return monday;
}

/**
 * Historique du classement : pour chaque semaine passée, le total d'XP de
 * moi et de mes amis (toutes langues), du meilleur au moins bon.
 * @returns {Promise<{week:string, start:Date, ranking:{id, xp, isMe, profile}[]}[]>}
 */
export async function weeklyHistory(limit = 12) {
  if (!isAvailable()) return [];
  const sb = await getClient();
  const ids = [uid(), ...friends().map((f) => f.id)];
  const current = P.weekKey();
  const { data, error } = await sb.from("weekly_xp").select("user_id, week, xp").in("user_id", ids).lt("week", current).order("week", { ascending: false }).limit(1000);
  if (error) throw error;
  const byWeek = new Map();
  for (const r of data || []) {
    const m = byWeek.get(r.week) || new Map();
    m.set(r.user_id, (m.get(r.user_id) || 0) + r.xp);
    byWeek.set(r.week, m);
  }
  return [...byWeek.entries()].sort((a, b) => b[0].localeCompare(a[0])).slice(0, limit).map(([week, m]) => ({
    week, start: weekStart(week),
    ranking: [...m.entries()].map(([id, xp]) => ({ id, xp, isMe: id === uid(), profile: id === uid() ? S.me : S.profiles[id] }))
      .filter((r) => r.profile && r.xp > 0).sort((a, b) => b.xp - a.xp),
  })).filter((w) => w.ranking.length);
}

/** Bilan des défis contre un ami (ou contre tout le monde) */
export function record(friendId = null) {
  return rivalry(friendId);
}

/* ------------------------- Bilan de rivalité ------------------------ */
// Historique complet des défis terminés avec un ami (la liste générale s'arrête aux 60 derniers)
const H2H = {}; // { [friendId]: lignes brutes }
let HIST = null;  // tous mes défis joués (chargés à la demande)

/** Charge tous mes défis acceptés (pour l'historique filtrable, les records et les stats) */
export async function loadHistory() {
  const me = uid();
  if (!me) return [];
  const sb = await getClient();
  const q = (col) => sb.from("challenges").select("*").eq(col, me).eq("status", "accepted").order("updated_at", { ascending: false }).limit(500);
  const [x, y] = await Promise.all([q("challenger"), q("opponent")]);
  if (!x.error && !y.error) HIST = [...(x.data || []), ...(y.data || [])];
  return history();
}
export const historyLoaded = () => HIST !== null;
/** Mes défis (historique chargé + liste récente), du plus récent au plus ancien */
export function history() {
  const byId = new Map();
  (HIST || []).forEach((c) => byId.set(c.id, c));
  Object.values(H2H).flat().forEach((c) => byId.set(c.id, c));
  S.challenges.forEach((c) => byId.set(c.id, c));
  return [...byId.values()].map(view).sort((a, b) => new Date(b.updated_at || b.created_at) - new Date(a.updated_at || a.created_at));
}

/** Déroulé des réponses d'un défi : { [userId]: [{ q, e, g, c, t }] } */
export async function loadRecaps(id) {
  const sb = await getClient();
  const { data, error } = await sb.from("challenge_recaps").select("*").eq("challenge_id", id);
  if (error) return {};
  return Object.fromEntries((data || []).map((r) => [r.user_id, r.recap]));
}

/**
 * Records personnels (sur les défis joués, sauf celui qu'on exclut) :
 * meilleure série en mort subite, meilleur score en vitesse, sans-faute le plus rapide…
 */
export function records(excludeId = null) {
  const mine = history().filter((c) => c.mine && c.id !== excludeId);
  const best = (list, f) => list.reduce((b, c) => (b == null || f(c) > f(b) ? c : b), null);
  const sv = best(mine.filter((c) => c.mode === "survival"), (c) => c.mine.score);
  const sp = best(mine.filter((c) => c.mode === "speed"), (c) => c.mine.points || 0);
  const ls = best(mine.filter((c) => c.mode === "listen" && c.mine.total >= 5), (c) => c.mine.score / c.mine.total * 1000 - c.mine.ms / 1e6);
  // Sans-faute le plus rapide : temps moyen par question sur un défi parfait d'au moins 5 questions
  const perfect = mine.filter((c) => c.mode !== "survival" && c.mine.total >= 5 && c.mine.score === c.mine.total && c.mine.ms > 0);
  const fast = best(perfect, (c) => -c.mine.ms / c.mine.total);
  const longest = best(mine.filter((c) => c.mode !== "survival" && c.mine.score === c.mine.total), (c) => c.mine.total);
  return {
    survival: sv ? { value: sv.mine.score, c: sv } : null,
    speed: sp && sp.mine.points ? { value: sp.mine.points, c: sp } : null,
    listen: ls ? { value: Math.round((ls.mine.score / ls.mine.total) * 100), c: ls } : null,
    fastest: fast ? { value: fast.mine.ms / fast.mine.total, c: fast } : null,
    perfect: longest ? { value: longest.mine.total, c: longest } : null,
  };
}
/** Nouveaux records battus par un défi qu'on vient de jouer (il faut un record précédent à battre) */
export function newRecords(c) {
  if (!c?.mine) return [];
  const before = records(c.id), out = [];
  const m = c.mine;
  if (c.mode === "survival" && m.score > 0 && (before.survival && m.score > before.survival.value)) out.push(["survival", `Meilleure série en mort subite : ${m.score}`]);
  if (c.mode === "speed" && m.points > 0 && (before.speed && m.points > before.speed.value)) out.push(["speed", `Meilleur score en vitesse : ${m.points} pts`]);
  if (c.mode === "listen" && m.total >= 5) { const p = Math.round((m.score / m.total) * 100); if (p > 0 && (before.listen && p > before.listen.value)) out.push(["listen", `Meilleur score à l'écoute : ${p} %`]); }
  if (c.mode !== "survival" && m.total >= 5 && m.score === m.total && m.ms > 0 && (before.fastest && m.ms / m.total < before.fastest.value)) out.push(["fastest", `Sans-faute le plus rapide : ${(m.ms / m.total / 1000).toFixed(1).replace(".", ",")} s par question`]);
  return out;
}
/** Taux de victoire par mode */
export function modeStats() {
  const out = {};
  history().filter((c) => c.stage === "done").forEach((c) => {
    const k = c.mode || "speed";
    const o = (out[k] ||= { win: 0, lose: 0, draw: 0, total: 0 });
    o[c.outcome]++; o.total++;
  });
  return out;
}
export async function loadRivalry(friendId) {
  const me = uid();
  if (!me || !friendId) return rivalry(friendId);
  const sb = await getClient();
  const q = (a, b) => sb.from("challenges").select("*").eq("challenger", a).eq("opponent", b).eq("status", "accepted").order("updated_at", { ascending: false }).limit(300);
  const [x, y] = await Promise.all([q(me, friendId), q(friendId, me)]);
  if (x.error || y.error) return rivalry(friendId);
  H2H[friendId] = [...(x.data || []), ...(y.data || [])];
  return rivalry(friendId);
}
/**
 * Bilan face à un ami (ou contre tout le monde si friendId est vide) :
 * victoires, défaites, nuls, série en cours et dernier défi terminé.
 */
export function rivalry(friendId = null) {
  const byId = new Map();
  (HIST || []).forEach((c) => { if (!friendId || c.challenger === friendId || c.opponent === friendId) byId.set(c.id, c); });
  if (friendId && H2H[friendId]) H2H[friendId].forEach((c) => byId.set(c.id, c));
  S.challenges.forEach((c) => { if (!friendId || c.challenger === friendId || c.opponent === friendId) byId.set(c.id, c); }); // les plus frais l'emportent
  const list = [...byId.values()].map(view).filter((c) => c.stage === "done" && (!friendId || c.friend?.id === friendId))
    .sort((a, b) => new Date(b.updated_at || b.created_at) - new Date(a.updated_at || a.created_at));
  const n = (o) => list.filter((c) => c.outcome === o).length;
  let streak = { outcome: null, count: 0 };
  for (const c of list) {
    if (c.outcome === "draw") break;
    if (!streak.outcome) streak = { outcome: c.outcome, count: 1 };
    else if (c.outcome === streak.outcome) streak.count++;
    else break;
  }
  return { win: n("win"), lose: n("lose"), draw: n("draw"), total: list.length, streak, last: list[0] || null };
}

export const langLabel = (c) => LANGS[c]?.label || c;


/* =====================================================================
   Fil d'activité : les grandes étapes de chacun, visibles par ses amis
   ===================================================================== */
export const REACTIONS = ["👏", "🔥", "💪", "😮", "❤️"];
const STREAKS = [3, 7, 14, 30, 50, 100, 200, 365], WORDS = [25, 50, 100, 200, 300, 500, 1000], XPS = [500, 1000, 2500, 5000, 10000, 25000];
const langName = (l) => (LANGS[l]?.label || "").toLowerCase();

/** Texte d'une activité (sans le nom de la personne) */
export function activityText(a) {
  const d = a.data || {}, lang = langName(a.lang);
  switch (a.kind) {
    case "exam": return { icon: "🎓", text: `a terminé le niveau <b>${d.level}</b> en ${lang}` };
    case "streak": return { icon: "🔥", text: `a une série de <b>${d.n} jours</b> d'affilée` };
    case "words": return { icon: "📒", text: `a appris <b>${d.n} mots</b> en ${lang}` };
    case "xp": return { icon: "⚡", text: `a dépassé <b>${d.n} XP</b> en ${lang}` };
    case "start": return { icon: "🌱", text: `a commencé à apprendre le ${lang}` };
    case "lesson": return { icon: "📘", text: `a terminé la leçon <b>${d.title || ""}</b>` };
    case "recap": return { icon: "📊", text: "a publié son bilan de la semaine" };
    case "defi_win": return { icon: "⚔️", text: `a gagné un défi${d.vs ? ` contre <b>@${d.vs}</b>` : ""} (${d.score}${d.mode === "speed" ? " pts" : ""})` };
    default: return { icon: "✨", text: "a franchi une nouvelle étape" };
  }
}

async function post(kind, data = {}, lang = code) {
  const sb = await getClient();
  const { error } = await sb.from("activities").insert({ user_id: uid(), kind, lang, data });
  if (error) throw error;
}

/** Étapes atteintes dans la langue active (clé unique → activité à publier) */
function milestones() {
  const out = [];
  LEVELS.forEach((l) => { if (P.isExamPassed(l.id)) out.push([`exam-${l.id}`, "exam", { level: lvlLabel(l) }]); });
  const streak = P.streakCount();
  STREAKS.forEach((n) => { if (streak >= n) out.push([`streak-${n}`, "streak", { n }]); });
  const words = Object.keys(state.vocab).length;
  WORDS.forEach((n) => { if (words >= n) out.push([`words-${n}`, "words", { n }]); });
  XPS.forEach((n) => { if (state.xp >= n) out.push([`xp-${n}`, "xp", { n }]); });
  if (Object.values(state.lessons).some((l) => l.passed)) out.push(["start", "start", {}]);
  // Leçons réussies (regroupées par jour dans le fil)
  LEVELS.forEach((l) => l.lessons.forEach((les) => { if (state.lessons[les.id]?.passed) out.push([`lesson-${les.id}`, "lesson", { title: les.title }]); }));
  // Victoires en défi (récentes)
  allChallenges().filter((c) => c.stage === "done" && c.outcome === "win" && Date.now() - new Date(c.updated_at || c.created_at) < 7 * 864e5)
    .forEach((c) => out.push([`win-${c.id}`, "defi_win", { vs: c.friend?.username || "", score: c.mode === "speed" ? c.mine.points : c.mode === "survival" ? `${c.mine.score} d'affilée` : `${c.mine.score}/${c.mine.total}`, mode: c.mode || null }]));
  return out;
}

let checking = false;
/** Publie les nouvelles étapes (une seule fois chacune ; la série peut revenir après 60 jours) */
export async function checkMilestones() {
  if (checking || !isAvailable() || !S.me || !state.profile) return;
  checking = true;
  try {
    const sent = state.feedSent || {}, now = Date.now(), list = milestones();
    // Première fois : on ne publie pas tout l'historique d'un coup
    if (!state.feedInit) {
      const init = {}; list.forEach(([k]) => (init[k] = now));
      commit((st) => { st.feedSent = { ...init, ...(st.feedSent || {}) }; st.feedInit = true; st.feedLessonsInit = true; });
      return;
    }
    // Mise à jour du fil (leçons) : les leçons déjà réussies avant ne sont pas republiées
    if (!state.feedLessonsInit) {
      const init = {}; list.forEach(([k]) => { if (k.startsWith("lesson-") && !sent[k]) init[k] = now; });
      commit((st) => { st.feedSent = { ...(st.feedSent || {}), ...init }; st.feedLessonsInit = true; });
      Object.assign(sent, init);
    }
    const fresh = list.filter(([k]) => !sent[k] || (k.startsWith("streak-") && now - sent[k] > 60 * 864e5));
    if (!fresh.length) return;
    // Pour la série, on ne garde que le palier le plus haut
    const best = fresh.filter(([k]) => !k.startsWith("streak-")).concat(fresh.filter(([k]) => k.startsWith("streak-")).slice(-1));
    for (const [, kind, data] of best.slice(0, 6)) await post(kind, data).catch(() => {});
    commit((st) => { const m = { ...(st.feedSent || {}) }; fresh.forEach(([k]) => (m[k] = now)); st.feedSent = m; });
    reloadFeed();
  } finally { checking = false; maybeRecap().catch(() => {}); }
}

/* Bilan de la semaine : publié une fois, le dimanche, toutes langues confondues */
const RECAP_KEY = "impara.recapSent";
function weekStats() {
  const week = P.weekKey(), states = [state];
  for (const l of Object.values(LANGS)) {
    if (l.code === code) continue;
    try { const o = JSON.parse(localStorage.getItem(l.storageKey) || "null"); if (o) states.push(o); } catch {}
  }
  const start = new Date(); start.setHours(0, 0, 0, 0); start.setDate(start.getDate() - ((start.getDay() + 6) % 7)); // lundi
  const t0 = start.getTime();
  let xp = 0, words = 0, lessons = 0, streak = 0;
  for (const st of states) {
    xp += st === state ? P.weeklyXp() : st.weekly?.week === week ? st.weekly.xp || 0 : 0;
    words += Object.values(st.vocab || {}).filter((w) => (w.added || 0) >= t0).length;
    lessons += Object.values(st.lessons || {}).filter((r) => r.passed && r.date && Date.parse(r.date) >= t0).length;
    streak = Math.max(streak, st === state ? P.streakCount() : st.streak?.count || 0);
  }
  return { week, xp, words, lessons, streak };
}
async function maybeRecap() {
  if (new Date().getDay() !== 0 || new Date().getHours() < 12 || !isAvailable() || !S.me) return;   // dimanche, à partir de midi
  const w = weekStats();
  let sent = ""; try { sent = localStorage.getItem(RECAP_KEY) || ""; } catch {}
  if (sent === w.week || w.xp <= 0) return;
  try { localStorage.setItem(RECAP_KEY, w.week); } catch {}
  await post("recap", { week: w.week, xp: w.xp, words: w.words, lessons: w.lessons, streak: w.streak }, null).catch(() => {});
  reloadFeed();
}

/** Charge le fil : mes activités et celles de mes amis, avec les réactions */
export async function loadFeed(limit = 50) {
  const sb = await getClient();
  const ids = [uid(), ...friends().map((f) => f.id)];
  const acts = check(await sb.from("activities").select("*").in("user_id", ids).order("created_at", { ascending: false }).limit(limit));
  const reacts = acts.length ? check(await sb.from("activity_reactions").select("*").in("activity_id", acts.map((a) => a.id))) : [];
  S.feed = acts.map((a) => ({ ...a, who: a.user_id === uid() ? S.me : S.profiles[a.user_id], mine: a.user_id === uid(), reactions: reacts.filter((r) => r.activity_id === a.id) }));
  emit("feed");
  return S.feed;
}
let feedTimer = null;
function reloadFeed() { if (!S.feed) return; clearTimeout(feedTimer); feedTimer = setTimeout(() => loadFeed().catch(() => {}), 400); }
export const feed = () => S.feed;

/** Réagir (ou retirer / changer sa réaction) */
export async function react(activityId, emoji) {
  const sb = await getClient();
  const a = S.feed?.find((x) => x.id === activityId);
  const mine = a?.reactions.find((r) => r.user_id === uid());
  if (mine && mine.emoji === emoji) check(await sb.from("activity_reactions").delete().eq("id", mine.id));
  else if (mine) check(await sb.from("activity_reactions").update({ emoji }).eq("id", mine.id));
  else check(await sb.from("activity_reactions").insert({ activity_id: activityId, user_id: uid(), emoji }));
  await loadFeed();
}

/* =====================================================================
   Duel en direct : présence + diffusion (Supabase Realtime)
   ===================================================================== */
export async function joinDuel(id, { onPresence, onStart, onProgress }) {
  const sb = await getClient();
  const me = uid();
  const ch = sb.channel(`duel-${id}`, { config: { broadcast: { self: false }, presence: { key: me } } });
  let meta = { ready: false, t: Date.now() };
  const others = () => {
    const st = ch.presenceState?.() || {};
    return Object.entries(st).filter(([k]) => k !== me).map(([k, v]) => ({ id: k, ...(v[v.length - 1] || {}) }));
  };
  ch.on("presence", { event: "sync" }, () => onPresence?.(others()))
    .on("broadcast", { event: "start" }, ({ payload }) => onStart?.(payload))
    .on("broadcast", { event: "progress" }, ({ payload }) => onProgress?.(payload));
  await new Promise((ok) => ch.subscribe((status) => { if (status === "SUBSCRIBED") { ch.track(meta); ok(); } }));
  return {
    others,
    ready: (r = true) => { meta = { ...meta, ready: r }; return ch.track(meta); },
    start: (payload) => ch.send({ type: "broadcast", event: "start", payload }),
    progress: (payload) => ch.send({ type: "broadcast", event: "progress", payload }),
    leave: () => { try { ch.untrack?.(); sb.removeChannel?.(ch); } catch {} },
  };
}

/* ------------------------------ Découvrir -------------------------- */
// Chiffres de la communauté et classement général (joueurs qui ont choisi d'apparaître)
export async function discoverOverview() {
  return rpc("discover_overview", { p_lang: code, p_week: P.weekKey() }).catch((e) => { throw new Error(socialError(e)); });
}
/** Profil public : null (inconnu), { hidden: true } (ne s'affiche pas), sinon le profil et ses stats par langue */
export async function discoverProfile(username) {
  return rpc("discover_profile", { p_username: username }).catch((e) => { throw new Error(socialError(e)); });
}
/** Apparaître (ou non) dans Découvrir */
export async function setDiscoverable(on) {
  const sb = await getClient();
  check(await sb.from("profiles").update({ discover: !!on }).eq("id", uid()));
  if (S.me) S.me.discover = !!on;
  emit("me");
}
