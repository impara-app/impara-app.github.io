/* =====================================================================
   srs.js — Répétition espacée des mots du carnet (système de Leitner)
   ---------------------------------------------------------------------
   Chaque mot a une « boîte » (0 à 6). Plus on le connaît, plus il monte
   et plus il revient tard : 1, 2, 4, 8, 16, 32 jours.
   - « À revoir »  : retour en boîte 0, on le revoit dans la séance ;
   - « Difficile » : on reste dans la même boîte, retour demain ;
   - « Je savais » : boîte suivante, intervalle de plus en plus long.
   Les mots jamais révisés sont « nouveaux » et dus immédiatement.
   ===================================================================== */

import { state, commit } from "./storage.js";

const INTERVALS = [0, 1, 2, 4, 8, 16, 32]; // jours, par boîte
export const MAX_BOX = INTERVALS.length - 1;

const dayKey = (d = new Date()) =>
  `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
const addDays = (n) => { const d = new Date(); d.setDate(d.getDate() + n); return dayKey(d); };

export const cardOf = (w) => state.srs?.[w.zh] || null;
export const isDue = (w) => { const c = cardOf(w); return !c || c.due <= dayKey(); };
export const dueWords = (list) => list.filter(isDue);
export const isNew = (w) => !cardOf(w);

/** Enregistre la réponse à une carte : "again" | "hard" | "good" */
export function grade(w, answer) {
  commit((s) => {
    s.srs ||= {};
    const c = s.srs[w.zh] || { box: 0, reps: 0 };
    if (answer === "again") { c.box = 0; c.due = dayKey(); c.lapses = (c.lapses || 0) + 1; }
    else if (answer === "hard") { c.box = Math.max(1, c.box); c.due = addDays(1); }
    else { c.box = Math.min(MAX_BOX, c.box + 1); c.due = addDays(INTERVALS[c.box]); }
    c.reps = (c.reps || 0) + 1;
    // Révisions de la semaine (Suivi › objectif de la semaine)
    const st = (s.stats ||= {}), now = new Date(); now.setHours(12, 0, 0, 0); now.setDate(now.getDate() - ((now.getDay() + 6) % 7));
    const wk = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}-${String(now.getDate()).padStart(2, "0")}`;
    st.rev ||= {}; st.rev[wk] = (st.rev[wk] || 0) + 1;
    c.last = Date.now();
    s.srs[w.zh] = c;
  });
}

/** Libellé du prochain passage pour chaque bouton (affiché sous les boutons) */
export function preview(w) {
  const c = cardOf(w) || { box: 0 };
  const label = (n) => (n <= 0 ? "maintenant" : n === 1 ? "demain" : `dans ${n} j`);
  return { again: label(0), hard: label(1), good: label(INTERVALS[Math.min(MAX_BOX, c.box + 1)]) };
}

/** Répartition pour l'en-tête : à réviser / nouveaux / maîtrisés (boîte ≥ 4) */
export function srsStats(list) {
  let due = 0, fresh = 0, known = 0;
  list.forEach((w) => { const c = cardOf(w); if (!c) fresh++; else { if (c.due <= dayKey()) due++; if (c.box >= 4) known++; } });
  return { due, fresh, known, todo: due + fresh };
}
