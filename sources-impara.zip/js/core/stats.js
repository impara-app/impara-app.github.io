/* =====================================================================
   stats.js — Mesures pour le Suivi
   - réponses par compétence (écoute, lecture, écriture, oral, vocabulaire,
     grammaire), par semaine et par heure de la journée ;
   - plus longue suite de bonnes réponses, nombre total de questions ;
   - temps d'étude réel (secondes actives par jour) ;
   - révisions de flashcards par semaine ;
   - dernières erreurs d'un exercice (pour l'historique cliquable).
   Les réponses sont regroupées en mémoire puis enregistrées par paquets.
   ===================================================================== */
import { state, commit } from "./storage.js";
import { getLesson } from "../data/curriculum.js";

export const SKILLS = [
  ["ecoute", "Écoute", "🎧", "#ecoute"], ["lecture", "Lecture", "📖", "#histoires"], ["ecriture", "Écriture", "✍️", "#dictee"],
  ["oral", "Oral", "🗣️", "#prononciation"], ["vocab", "Vocabulaire", "📒", "#reviser"], ["gram", "Grammaire", "🧩", "#revision"],
];

const pad = (n) => String(n).padStart(2, "0");
export const dayKey = (d = new Date()) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
/** Semaine locale commençant le lundi : clé = date du lundi */
export function weekStart(d = new Date()) { const x = new Date(d); x.setHours(12, 0, 0, 0); x.setDate(x.getDate() - ((x.getDay() + 6) % 7)); return dayKey(x); }

/** Compétence travaillée par une question */
export function skillOf(q = {}, ref = "") {
  const src = String(ref).split(":")[0];
  const mod = getLesson(src)?.module;
  if (q.type === "listen" || q.type === "tone" || q.say) return "ecoute";
  if (q.type === "order") return "gram";
  if (q.type === "match") return "vocab";
  if (q.type === "translate") return /français/i.test(q.label || "") || /^traduisez en français/i.test(q.q || "") ? "lecture" : "ecriture";
  if (q.type === "fill") return mod === "vocab" || mod === "expr" || mod === "nombres" ? "vocab" : "gram";
  if (String(ref).includes(":gen:") || mod === "vocab" || mod === "nombres") return "vocab";
  if (mod === "gram" || mod === "conj" || mod === "temps") return "gram";
  return "lecture";
}

/* -------------------------- Réponses -------------------------- */
const pending = [];
export function trackAnswer(q, ok, ref, skill = null) {
  pending.push({ s: skill || skillOf(q, ref), ok: !!ok, t: Date.now() });
  if (pending.length >= 10) flushStats();
}
/** Plusieurs réponses d'un coup (exercices hors quiz : prononciation, dictée…) */
export function trackMany(skill, ok, total) {
  for (let i = 0; i < total; i++) pending.push({ s: skill, ok: i < ok, t: Date.now() });
  flushStats();
}
export function flushStats() {
  if (!pending.length) return;
  const items = pending.splice(0);
  commit((s) => {
    const st = (s.stats ||= {});
    st.w ||= {}; st.h ||= {}; st.run ||= 0; st.best ||= 0; st.total ||= 0;
    for (const it of items) {
      const d = new Date(it.t), wk = weekStart(d), hr = d.getHours();
      const W = (st.w[wk] ||= {}), K = (W[it.s] ||= [0, 0]);
      K[1]++; if (it.ok) K[0]++;
      const H = (st.h[hr] ||= [0, 0]); H[1]++; if (it.ok) H[0]++;
      st.total++;
      st.run = it.ok ? st.run + 1 : 0;
      if (st.run > st.best) { st.best = st.run; st.bestAt = it.t; }
      // Jour par jour (quêtes du jour) : bonnes réponses, total, suite, écoute
      const D = day(st, dayKey(d));
      D.n++; if (it.ok) D.ok++;
      D.run = it.ok ? D.run + 1 : 0; if (D.run > D.best) D.best = D.run;
      if (it.s === "ecoute" && it.ok) D.ec++;
    }
    // On garde 26 semaines
    const keys = Object.keys(st.w).sort();
    keys.slice(0, Math.max(0, keys.length - 26)).forEach((k) => delete st.w[k]);
  });
}

/** Compteurs du jour (14 jours gardés) */
export function day(st, k = dayKey()) {
  st.d ||= {};
  if (!st.d[k]) {
    st.d[k] = { ok: 0, n: 0, run: 0, best: 0, ec: 0, rev: 0 };
    const keys = Object.keys(st.d).sort();
    keys.slice(0, Math.max(0, keys.length - 14)).forEach((x) => delete st.d[x]);
  }
  return st.d[k];
}
export const today = () => state.stats?.d?.[dayKey()] || { ok: 0, n: 0, run: 0, best: 0, ec: 0, rev: 0 };

/* ----------------------- Temps d'étude réel ----------------------- */
let lastInput = 0, acc = 0;
export function startTimeTracking() {
  const bump = () => { lastInput = Date.now(); };
  ["pointerdown", "keydown", "touchstart", "wheel"].forEach((e) => addEventListener(e, bump, { passive: true, capture: true }));
  document.addEventListener("visibilitychange", () => { if (document.hidden) saveTime(); });
  setInterval(() => {
    // une seconde compte si l'appli est visible et qu'on a touché l'écran il y a moins de 90 s
    if (!document.hidden && Date.now() - lastInput < 90000) acc += 5;
    if (acc >= 60) saveTime();
  }, 5000);
}
function saveTime() {
  if (!acc || !state.profile) return;
  const add = acc; acc = 0;
  commit((s) => {
    const t = (s.studyTime ||= {}), k = dayKey();
    t[k] = (t[k] || 0) + add;
    const limit = dayKey(new Date(Date.now() - 120 * 864e5));
    Object.keys(t).forEach((d) => { if (d < limit) delete t[d]; });
  });
}
/** Minutes d'étude d'un jour */
export const minutesOn = (k) => Math.round((state.studyTime?.[k] || 0) / 60);

/* -------------- Dernières erreurs (historique cliquable) -------------- */
let last = null;
export function setLastResults(results) {
  last = {
    at: Date.now(), hash: location.hash,
    mistakes: (results || []).filter((r) => !r.correct && r.q).slice(0, 12).map((r) => ({
      p: String(r.prompt || "").replace(/___/g, "…").slice(0, 140), g: String(r.given ?? "").slice(0, 80),
      e: String(r.expected ?? "").slice(0, 100), w: String(r.why || "").slice(0, 160),
    })),
  };
}
/** Données à joindre à une entrée d'historique (lien pour refaire + erreurs) */
export function historyExtras() {
  const fresh = last && Date.now() - last.at < 15000;
  const href = (fresh ? last.hash : location.hash) || "";
  const out = {};
  if (href && !/^#(parcours|entrainement|tableau)?$/.test(href)) out.href = href;
  if (fresh && last.mistakes.length) out.mistakes = last.mistakes;
  last = null;
  return out;
}
