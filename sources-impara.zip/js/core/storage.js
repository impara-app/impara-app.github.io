/* =====================================================================
   storage.js — Persistance de l'état utilisateur
   ---------------------------------------------------------------------
   - Sauvegarde dans localStorage (clé versionnée).
   - Repli en mémoire si localStorage est indisponible (navigation
     privée, iframe sandboxée…) : l'app reste utilisable.
   - Petit système d'abonnement : les vues se mettent à jour après
     chaque `commit()`.
   - Pour passer à une base de données plus tard, il suffit de
     remplacer `readRaw()` / `writeRaw()` par des appels API.
   ===================================================================== */

import { L, LANGS } from "./lang.js";

const KEY = L.storageKey; // une sauvegarde distincte par langue
const SCHEMA_VERSION = 1;

/** Forme de l'état par défaut (documente aussi le modèle de données) */
export function defaultState() {
  return {
    version: SCHEMA_VERSION,
    profile: null,            // { pseudo, avatar, dailyGoal, createdAt }
    settings: { tts: true, voiceSpeed: 1, pinyinQuiz: "auto", streakReminder: true, sfx: true, haptics: true },  // lecture audio des exemples ; vitesse de la voix (1 = normale)
    lessons: {},              // { [lessonId]: { best, total, passed, attempts, date } }
    exams: {},                // { [levelId]: { best, total, passed, attempts, date } }
    checkpoints: {},          // { [levelId]: { best, total, passed, attempts, date } } tests de mi-palier
    vocab: {},                // { [mot]: { zh (mot étudié), py (pinyin, optionnel), fr, levelId, lessonId, added } }
    errors: {},               // { [ref]: { ref, count, streak, lastAnswer, lastWrong } }
    mastered: 0,              // nombre d'erreurs corrigées
    xp: 0,
    streak: { count: 0, last: null },   // série de jours actifs
    daily: { date: null, xp: 0 },       // XP gagnés aujourd'hui
    weekly: { week: null, xp: 0 },      // XP gagnés cette semaine (classement entre amis)
    stories: {},              // { [histoireId]: { done, best, total, date } }
    srs: {},                  // { [mot]: { box, due, reps, last } } répétition espacée des flashcards
    dayLog: {},               // { [jour]: xp } 30 derniers jours (graphique entre amis)
    history: [],              // [{ date, label, score, total, kind }]
    owner: null,              // id du compte propriétaire de cette copie locale (null = invité)
    updatedAt: 0,             // horodatage de la dernière modification (synchronisation)
  };
}

let storageOK = true;
let memoryCopy = null;

function readRaw() {
  try {
    return localStorage.getItem(KEY);
  } catch {
    storageOK = false;
    return memoryCopy;
  }
}

function writeRaw(str) {
  memoryCopy = str;
  try {
    localStorage.setItem(KEY, str);
  } catch {
    storageOK = false;
  }
}

/** Fusionne un état chargé avec les valeurs par défaut (migrations douces) */
function hydrate(obj) {
  const base = defaultState();
  if (!obj || typeof obj !== "object") return base;
  return {
    ...base,
    ...obj,
    settings: { ...base.settings, ...(obj.settings || {}) },
    streak: { ...base.streak, ...(obj.streak || {}) },
    daily: { ...base.daily, ...(obj.daily || {}) },
    weekly: { ...base.weekly, ...(obj.weekly || {}) },
    srs: { ...(obj.srs || {}) },
    dayLog: { ...(obj.dayLog || {}) },
    version: SCHEMA_VERSION,
  };
}

function load() {
  let s;
  try {
    const raw = readRaw();
    s = hydrate(raw ? JSON.parse(raw) : null);
  } catch {
    s = defaultState();
  }
  // Migration : anciens mots enregistrés sous la forme { it, fr }
  Object.values(s.vocab).forEach((w) => { if (w.zh == null) { w.zh = w.it; w.py = ""; } });
  // Profil partagé : si l'on découvre une nouvelle langue, on reprend
  // pseudo, avatar et objectif déjà choisis dans une autre langue.
  if (!s.profile) {
    for (const lang of Object.values(LANGS)) {
      if (lang.storageKey === KEY) continue;
      try {
        const other = JSON.parse(localStorage.getItem(lang.storageKey) || "null");
        if (other?.profile) { s.profile = { ...other.profile, createdAt: Date.now() }; break; }
      } catch {}
    }
  }
  return s;
}

/** L'état vivant de l'application (objet unique, muté via commit) */
export const state = load();

const listeners = new Set();
export const subscribe = (fn) => (listeners.add(fn), () => listeners.delete(fn));

/**
 * Modifie l'état puis sauvegarde et notifie.
 * @param {(s: object) => void} mutator
 */
export function commit(mutator, { touch = true } = {}) {
  mutator(state);
  if (touch) state.updatedAt = Date.now();
  writeRaw(JSON.stringify(state));
  [...listeners].forEach((fn) => fn(state));
}

/** Remplace tout l'état (import d'une sauvegarde / réinitialisation) */
export function replaceState(next, opts) {
  const fresh = hydrate(next);
  Object.keys(state).forEach((k) => delete state[k]);
  Object.assign(state, fresh);
  commit(() => {}, opts);
}

export const exportState = () => JSON.stringify(state, null, 2);
export const isPersistent = () => storageOK;
