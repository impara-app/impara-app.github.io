/* =====================================================================
   theme.js — Mode clair / sombre / automatique
   Le choix est propre à chaque appareil (localStorage). Le script en tête
   de index.html l'applique avant l'affichage ; ce module gère le
   changement en direct et le suivi du réglage du système.
   ===================================================================== */
const KEY = "impara.theme";
const media = window.matchMedia ? matchMedia("(prefers-color-scheme: dark)") : null;

export function getTheme() { try { return localStorage.getItem(KEY) || "auto"; } catch { return "auto"; } }
export const isDark = () => document.documentElement.classList.contains("dark");

export function applyTheme(t = getTheme()) {
  const h = new Date().getHours();
  const dark = t === "dark" || (t === "night" && (h >= 21 || h < 7)) || (t === "auto" && !!media?.matches);
  document.documentElement.classList.toggle("dark", dark);
  // Couleur de la barre du navigateur / de l'appli installée
  document.querySelector('meta[name="theme-color"]')?.setAttribute("content", dark ? "#11151b" : document.body.classList.contains("lang-zh") ? "#c23b32" : "#1e8e5a");
}
export function setTheme(t) { try { localStorage.setItem(KEY, t); } catch {} applyTheme(t); }
export function initTheme() {
  document.documentElement.classList.toggle("lang-theme", getLangTheme());
  applyTheme();
  media?.addEventListener?.("change", () => { if (getTheme() === "auto") applyTheme(); });
  setInterval(() => { if (getTheme() === "night") applyTheme(); }, 5 * 60000); // passe en sombre à 21 h, en clair à 7 h
}

/* Taille du texte (s, m, l, xl) et animations réduites : propres à l'appareil */
export function getTextSize() { try { return localStorage.getItem("impara.textSize") || "m"; } catch { return "m"; } }
export function setTextSize(v) {
  try { localStorage.setItem("impara.textSize", v); } catch {}
  ["s", "l", "xl"].forEach((k) => document.documentElement.classList.toggle(`ts-${k}`, k === v));
}
export function getReduceMotion() { try { return localStorage.getItem("impara.motion") === "reduce"; } catch { return false; } }
export function setReduceMotion(on) {
  try { localStorage.setItem("impara.motion", on ? "reduce" : "full"); } catch {}
  document.documentElement.classList.toggle("reduce-motion", on);
}

/* Thème de la langue (univers italien / chinois) : désactivé par défaut */
const LT_KEY = "impara.langTheme";
export function getLangTheme() { try { return localStorage.getItem(LT_KEY) === "on"; } catch { return false; } }
export function setLangTheme(on) {
  try { localStorage.setItem(LT_KEY, on ? "on" : "off"); } catch {}
  document.documentElement.classList.toggle("lang-theme", on);
}
