/* =====================================================================
   wotd.js — Mot du jour : un mot du palier en cours (ou déjà appris),
   le même pour tout le monde le même jour dans une langue, avec un
   exemple tiré des leçons. Aussi envoyé en notification le matin.
   ===================================================================== */
import { LEVELS } from "../data/curriculum.js";
import { state } from "./storage.js";
import { code } from "./lang.js";
import { tri } from "./ui.js";
import * as P from "./progress.js";

const hash = (s) => { let h = 2166136261; for (const c of s) { h ^= c.codePointAt(0); h = Math.imul(h, 16777619) >>> 0; } return h; };
const local = (d) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;

/** Mots candidats : ceux des paliers débloqués (au moins le premier palier) */
function pool() {
  let maxLevel = 0;
  LEVELS.forEach((_, i) => { if (P.isLevelUnlocked(i)) maxLevel = i; });
  const words = [], seen = new Set();
  LEVELS.slice(0, maxLevel + 1).forEach((lv) => lv.lessons.forEach((l) => (l.vocab || []).map(tri).forEach(([w, py, fr]) => {
    const k = String(w).split(/\s*\/\s*/)[0].trim();
    if (!k || seen.has(k) || k.length > 24) return;
    seen.add(k); words.push({ w: k, py: py || "", fr: String(fr), levelId: lv.id, lessonId: l.id });
  })));
  return words;
}
/** Une phrase d'exemple des leçons qui contient le mot */
function exampleFor(w) {
  const re = code === "zh" ? null : new RegExp(`(^|[^\\p{L}])${w.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}([^\\p{L}]|$)`, "iu");
  for (const lv of LEVELS) for (const l of lv.lessons) for (const s of l.sections || []) for (const ex of s.examples || []) {
    const [t, py, fr] = tri(ex);
    if (String(t).length > 90) continue;
    if (code === "zh" ? String(t).includes(w) && t !== w : re.test(t)) return { t, py, fr };
  }
  return null;
}
/** Mot du jour pour une date (par défaut aujourd'hui) */
export function wordOfDay(date = new Date()) {
  const list = pool();
  if (!list.length) return null;
  const day = local(date);
  const x = list[hash(`${code}:${day}`) % list.length];
  return { ...x, day, ex: exampleFor(x.w), known: !!state.vocab?.[x.w] };
}
/** Les mots des 7 prochains jours (pour la notification du matin, envoyée par le serveur) */
export function wotdList(n = 7) {
  const out = [];
  for (let i = 0; i < n; i++) {
    const d = new Date(); d.setDate(d.getDate() + i);
    const x = wordOfDay(d);
    if (x) out.push({ d: x.day, w: x.w, py: x.py, fr: x.fr.slice(0, 80) });
  }
  return out;
}
