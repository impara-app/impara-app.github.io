/* =====================================================================
   Nouveautés (Paramètres › Nouveautés)
   À chaque mise à jour : ajouter une entrée EN HAUT de la liste, avec la
   date et l'heure de mise en ligne (heure de Paris), un titre court et
   ce qui change pour l'utilisateur (pas de détails techniques).
   lang : "it" / "zh" si la nouveauté ne concerne qu'une langue.
   ===================================================================== */
export const CHANGELOG = [
  {
    at: "2026-11-11T02:43", emoji: "🫧", title: "Animations plus fluides",
    items: ["Les bulles des mascottes du parcours (et le menu des messages) apparaissent directement à leur place, sans glisser de la droite vers la gauche.", "Flashcards : la carte suit le doigt sans à-coup, part plus ou moins vite selon la vivacité du geste (un petit coup sec suffit), et la carte suivante attend déjà derrière et avance quand la première s'envole. Plus de petite pause entre deux cartes."],
  },
  {
    at: "2026-11-11T02:35", emoji: "📊", title: "Un Suivi complètement repensé",
    items: ["Bilan de la semaine : XP, temps d'étude, leçons, nouveaux mots, réussite et jours actifs, comparés aux mêmes jours de la semaine dernière. Partageable en image à vos amis.", "Objectif de la semaine : choisissez un défi (leçons, XP, cartes révisées ou minutes) et suivez-le jusqu'à dimanche.", "Mon vrai niveau : votre niveau estimé en compréhension et en production, d'après vos examens, vos épreuves type CELI/HSK et le test de niveau.", "Mes compétences : un radar écoute, lecture, écriture, oral, vocabulaire et grammaire, avec un bouton pour travailler la plus faible.", "Prévision : la date à laquelle vous atteindrez le prochain niveau à votre rythme, et combien de jours vous gagnez avec 10 minutes de plus par jour.", "Ma précision : l'évolution de vos bonnes réponses semaine après semaine.", "Temps d'étude réel (sans les pauses) et votre moment idéal de la journée, avec un bouton pour y régler votre rappel.", "Mon vocabulaire : la courbe de vos mots avec des caps (500 mots : une conversation simple…), et les révisions de flashcards prévues sur 7 jours.", "Mes records : meilleure journée, plus longue série, quiz parfaits, bonnes réponses d'affilée… Chaque nouveau record est fêté.", "Activité récente : touchez une activité pour revoir ses erreurs (avec l'explication) ou la refaire."],
  },
  {
    at: "2026-11-11T01:37", emoji: "⚡", title: "Une appli plus fluide",
    items: ["Ouverture plus rapide : la page de démarrage pèse 20 fois moins, le style est gardé en mémoire sur l'appareil.", "Les pages glissent dans le sens de la navigation, et en revenant en arrière vous retrouvez l'endroit exact où vous étiez dans la page.", "Pendant un chargement, une silhouette de la page s'affiche au lieu d'une roue.", "Appli installée : glissez depuis le bord gauche de l'écran pour revenir en arrière. Les fenêtres (fiche d'un mot, confirmations) se ferment en les tirant vers le bas.", "Pendant un quiz, le bouton Vérifier reste visible au-dessus du clavier du téléphone.", "Vibrations plus fines : un petit toc à chaque choix, une vibration différente pour une bonne ou une mauvaise réponse, et pour les séries.", "Les messages s'affichent un par un, en haut de l'écran, au lieu de s'empiler (touchez-en un pour le fermer)."],
  },
  {
    at: "2026-11-11T01:37", emoji: "🧭", title: "Entraînement réorganisé et progression du palier",
    items: ["Entraînement : « Recommandé pour toi » propose 3 exercices adaptés, puis tous les exercices sont rangés en 4 blocs dépliables (Écoute et oral, Écriture et grammaire, Vocabulaire, Examens). L'appli retient ceux que vous laissez ouverts.", "Accueil : une barre montre où vous en êtes dans le palier (leçons faites, repère du test de mi-palier) et le prochain cap."],
  },
  {
    at: "2026-11-11T01:37", emoji: "🔠", title: "Taille du texte, animations et thème de nuit",
    items: ["Paramètres › Préférences › Lecture et confort : quatre tailles de texte, et une option pour réduire les animations (moins de confettis et d'effets).", "Nouveau thème « La nuit » : sombre de 21 h à 7 h, clair le reste du temps, automatiquement."],
  },
  {
    at: "2026-11-11T00:48", emoji: "🔎", title: "Pourquoi c'est faux ?",
    items: ["Quand une réponse est fausse, l'appli explique l'erreur en plus de donner la bonne réponse : masculin au lieu du féminin, singulier au lieu du pluriel, mauvais article (il / lo / la), consonne double oubliée, verbe conjugué à la mauvaise personne, mot manquant ou en trop, mots dans le désordre…", "En mandarin : « mauvais ton sur ye : 2e au lieu du 3e », zh / z, -n / -ng, caractère homophone (他 / 她), caractères dans le désordre.", "L'explication apparaît aussi dans « Vos erreurs » à la fin du quiz."],
  },
  {
    at: "2026-11-11T00:48", emoji: "📒", title: "Mes mots : fiches détaillées et classement par thème",
    items: ["Touchez un mot de la liste pour ouvrir sa fiche : prononciation normale et lente, phrases d'exemple tirées des leçons, état de révision et lien vers la leçon.", "Italien : la conjugaison complète des verbes (présent, passé composé, imparfait, futur, conditionnel, subjonctif) avec chaque pronom, et le genre des noms.", "Mandarin : chaque caractère avec son pinyin, son sens, l'animation de ses traits et ses clés.", "La liste est rangée par thème : les nombres, les jours, les couleurs… restent ensemble et dans l'ordre. Classement aussi possible par date d'ajout ou de A à Z."],
  },
  {
    at: "2026-11-10T00:37", emoji: "📒", title: "« Mots » et « Carnet » réunis : Mes mots",
    items: ["Entraînement › Mes mots regroupe tout : la liste avec recherche, les flashcards et la révision du jour, au même endroit.", "En mandarin, le pinyin est toujours affiché dans Mes mots : dans la liste et sur le recto des flashcards, avec les caractères."],
  },
  {
    at: "2026-11-09T20:12", emoji: "🏠", title: "Nouvelle adresse : impara-app.github.io",
    items: ["Le site s'ouvre maintenant sur impara-app.github.io. L'ancien lien redirige automatiquement et transfère votre progression.", "Si l'appli était installée sur l'écran d'accueil, réinstallez-la depuis la nouvelle adresse, puis réactivez les notifications dans Paramètres."],
  },
  {
    at: "2026-11-09T19:36", emoji: "🔄", title: "Quiz de leçon plus variés",
    items: ["Les questions tournent : les mots et les questions les moins souvent vus passent en priorité, pour que tous les mots d'une leçon reviennent au fil des essais au lieu des mêmes à chaque fois.", "Plus on refait une leçon, plus le quiz contient de questions nouvelles sur l'ensemble de ses mots.", "Leçons sur les nombres, les jours et les mois complétées : tous les mois (février, mars…), tous les jours et les nombres de 0 à 19 font maintenant partie du vocabulaire, en italien comme en mandarin.", "Si vous aviez déjà validé ces leçons, les nouveaux mots sont ajoutés automatiquement à votre carnet et à vos flashcards."],
  },
  {
    at: "2026-11-09T19:16", emoji: "✓", title: "Mot du jour : le cocher pour le masquer",
    items: ["Un bouton ✓ en haut de la carte du mot du jour : une fois vu, il disparaît de l'accueil jusqu'au lendemain."],
  },
  {
    at: "2026-11-09T18:23", emoji: "🛠️", title: "Corrections",
    items: ["Défis en mandarin : plus de trou au milieu d'un mot (« ___天 » pour 明天), la phrase à compléter porte toujours sur un mot entier.", "Après une mise à jour, une page qui ne se chargeait plus se recharge toute seule au lieu d'afficher « Page indisponible »."],
  },
  {
    at: "2026-11-09T18:23", emoji: "⏱️", title: "Épreuve en conditions réelles",
    items: ["Entraînement › Épreuve type CELI (italien) ou HSK (mandarin) : compréhension orale, compréhension écrite et production écrite, chaque section chronométrée, sans correction pendant l'épreuve.", "À la fin : une note sur 100, le détail par section et la revue de vos erreurs. Aussi accessible depuis chaque palier du parcours."],
  },
  {
    at: "2026-11-09T18:23", emoji: "🔥", title: "Récompenses de série et gel de série",
    items: ["Tous les 7 jours de série, vous gagnez un 🧊 gel (2 au maximum) : si vous oubliez un jour, il protège automatiquement votre série.", "À 7, 30 et 100 jours : nouveaux cadres (Argent, Flamme, Légende), avatars exclusifs 🌶️ ☄️ 🌟 et la bannière Volcan. La page Série indique la prochaine récompense."],
  },
  {
    at: "2026-11-09T18:23", emoji: "✨", title: "Le mot du jour",
    items: ["Chaque jour, un mot de votre niveau sur l'écran d'accueil, avec sa prononciation et un exemple, à ajouter au carnet en un geste.", "Et en notification le matin vers 9 h (désactivable dans Paramètres › Notifications)."],
  },
  {
    at: "2026-11-09T18:23", emoji: "📒", title: "Vos propres mots dans le carnet",
    items: ["Carnet › « Ajouter un mot à moi » : ajoutez n'importe quel mot, la traduction (et le pinyin en mandarin) est proposée automatiquement, avec la prononciation.", "Ils sont révisés en flashcards comme les autres et se suppriment d'un geste."],
  },
  {
    at: "2026-11-09T18:23", emoji: "🎵", lang: "zh", title: "Paires de tons",
    items: ["Entraînement › Paires de tons : écoutez un mot de deux syllabes et reconnaissez la combinaison (3e + neutre, 2e + 4e…), avec la règle du double 3e ton expliquée."],
  },
  {
    at: "2026-11-09T18:23", emoji: "🏛️", lang: "it", title: "C1 et C2 enrichis",
    items: ["6 nouvelles leçons C1 : come se et magari, verbes comme farcela et andarsene, concessives, langue des journaux, réunions, démarches administratives.", "6 nouvelles leçons C2 : constructions implicites, conditionnel journalistique, registres, italien régional, grands classiques, orthographe fine."],
  },
  {
    at: "2026-11-09T18:23", emoji: "🏮", lang: "zh", title: "HSK 5 et HSK 6 enrichis",
    items: ["6 nouvelles leçons HSK 5 : connecteurs de l'écrit (由于, 以便, 何况), nuances (简直, 未必, 毕竟), double négation, travail, santé, études et 高考.", "6 nouvelles leçons HSK 6 : chinois classique (之, 其, 所), presse, parler avec tact, dialectes et caractères traditionnels, poèmes Tang, langue d'internet (内卷, 躺平)."],
  },
  {
    at: "2026-11-05T11:46", emoji: "🔊", title: "Réglage du volume",
    items: ["Paramètres › Préférences › Son : un curseur pour le volume de la voix et un autre pour les effets sonores (indépendants du volume du téléphone)."],
  },
  {
    at: "2026-11-05T03:31", emoji: "🗣️", lang: "zh", title: "Mandarin : mots seuls plus naturels",
    items: ["Les 2 441 mots et petites expressions lus seuls (« 你好 », « 儿子 »…) sont réenregistrés avec Xiaoxiao et Yunxi : tons plus justes et fin de mot qui n'est plus coupée."],
  },
  {
    at: "2026-11-05T00:15", emoji: "🎓", title: "Passage de palier célébré",
    items: ["Valider l'examen d'un palier ouvre un grand écran de fête avec le badge du nouveau niveau, vos chiffres et un bouton pour le partager à vos amis."],
  },
  {
    at: "2026-11-05T00:15", emoji: "📋", title: "Fiches de grammaire",
    items: ["Entraînement › Fiches de grammaire : toutes les explications de vos leçons, rangées par thème, avec une recherche (« subjonctif », « 了 »…)."],
  },
  {
    at: "2026-11-05T00:15", emoji: "🎧", title: "Écoute longue",
    items: ["Entraînement › Écoute longue : une histoire entière lue à deux voix, sans le texte, puis les questions de compréhension."],
  },
  {
    at: "2026-11-05T00:15", emoji: "⏱️", lang: "it", title: "Conjugaison chrono",
    items: ["60 secondes pour conjuguer vos verbes : présent, passé composé, imparfait, futur, conditionnel, subjonctif (selon vos leçons). Record et liste des erreurs à la fin."],
  },
  {
    at: "2026-11-05T00:15", emoji: "✍️", lang: "zh", title: "Caractères : écrire et voir les traits",
    items: ["Nouvel exercice « Écrire de mémoire » : le sens et le pinyin s'affichent, vous tracez le caractère au doigt, corrigé trait par trait.", "Dans les leçons, les caractères sont plus grands ; touchez un mot pour voir l'ordre de ses traits animé."],
  },
  {
    at: "2026-11-05T00:15", emoji: "👋", title: "Premiers pas guidés",
    items: ["Les nouveaux joueurs commencent directement par la première leçon, puis trois bulles d'aide présentent la séance du jour, la série et les XP."],
  },
  {
    at: "2026-11-05T00:15", emoji: "🛠️", title: "Rapport de bug automatique",
    items: ["Si une page plante, l'appli envoie elle-même un signalement technique pour que le problème soit corrigé plus vite."],
  },
  {
    at: "2026-11-04T23:54", emoji: "📋", title: "Vos erreurs en fin de quiz",
    items: [
      "À la fin d'un quiz, d'un examen ou d'un entraînement : la liste de vos erreurs avec votre réponse, la bonne réponse, l'explication et un bouton pour l'écouter.",
    ],
  },
  {
    at: "2026-11-04T23:54", emoji: "🎨", title: "Nouvelles icônes",
    items: [
      "Les petits symboles de l'interface (son, série, XP, cadenas, réglages…) sont maintenant des icônes dessinées, identiques sur tous les appareils.",
    ],
  },
  {
    at: "2026-11-04T23:24", emoji: "🃏", title: "Jokers pour les fautes de frappe",
    items: [
      "Examen de fin de palier : 3 jokers. Test de mi-palier : 2 jokers.",
      "Une réponse écrite avec une seule lettre fausse, en trop, manquante ou deux lettres inversées est acceptée et utilise un joker. Les jokers restants s'affichent en haut.",
    ],
  },
  {
    at: "2026-11-04T17:50", emoji: "🛡️", title: "Tests de palier plus exigeants",
    items: [
      "Test de mi-palier : 25 questions, sans aucune faute.",
      "Examen de fin de palier : 50 questions, sans aucune faute (l'examen blanc suit le même format).",
      "Les tests de mi-palier réussis avec l'ancien format (10 questions) sont à repasser.",
    ],
  },
  {
    at: "2026-11-04T17:50", emoji: "🛠️", title: "Corrections suite à vos signalements",
    items: [
      "Défi « sur son terrain » entre langues différentes : l'appli propose de passer dans la langue des mots du défi (avant, aucun mot n'était prononcé).",
      "Italien : la fin des mots courts n'est plus coupée net (« salve », « grazie »…), avec Sara comme avec Nicola.",
    ],
  },
  {
    at: "2026-11-04T16:45", emoji: "🃏", title: "Flashcards repensées",
    items: [
      "La carte est au centre de l'écran : glissez-la à droite si vous savez, à gauche si vous ne savez pas (ou touchez ✓ / ✕).",
      "Un seul bouton pour choisir le palier ; les réglages des cartes sont rangés sous la carte.",
    ],
  },
  {
    at: "2026-11-04T16:45", emoji: "🧭", title: "Test de niveau",
    items: [
      "Déjà des bases ? Un test de quelques minutes vous place directement au bon palier.",
      "Proposé à l'inscription, sur le parcours et dans Paramètres › Cours. Votre progression n'est jamais effacée.",
    ],
  },
  {
    at: "2026-11-04T16:45", emoji: "🚀", lang: "it", title: "Niveau B2 complet",
    items: [
      "12 nouvelles leçons : subjonctif passé, hypothèse dans le passé, conditionnel passé, futur antérieur, passif, gérondif, relatifs, verbes à préposition, e-mail formel, actualité, culture…",
      "Examen B2 enrichi, 2 nouvelles histoires et 2 nouveaux dialogues (réclamation à l'hôtel, location d'appartement).",
    ],
  },
  {
    at: "2026-11-04T16:45", emoji: "🚀", lang: "zh", title: "Niveau HSK 4 complet",
    items: [
      "13 nouvelles leçons : 无论 / 即使 / 既然, compléments potentiels, questions rhétoriques, 竟然 / 难怪, probabilité, connecteurs, voyage, numérique, société, fêtes, expressions orales…",
      "Examen HSK 4 enrichi, 2 nouvelles histoires et 2 nouveaux dialogues (réclamation à l'hôtel, location d'appartement).",
    ],
  },
  {
    at: "2026-11-04T14:30", emoji: "📣", title: "Page « Nouveautés »",
    items: ["Retrouvez ici chaque mise à jour de l'appli, avec sa date et son heure.", "Une pastille signale les nouveautés que vous n'avez pas encore vues."],
  },
  {
    at: "2026-11-04T14:13", emoji: "⚑", title: "Signaler un problème",
    items: [
      "Un bouton ⚑ en haut des leçons, quiz, défis, entraînements, histoires, dialogues, dictées et exercices de prononciation.",
      "Choisissez : mauvaise traduction, phrase mal formulée, mauvaise prononciation, réponse refusée à tort ou bug, et ajoutez un commentaire.",
      "La question affichée est envoyée avec le signalement pour pouvoir la corriger.",
    ],
  },
  {
    at: "2026-11-04T13:50", emoji: "🗣️", lang: "it", title: "Italien : mots courts bien prononcés",
    items: [
      "Les 1 616 mots et petites expressions (« uno », « chi », « piccolo », « la nonna »…) sont maintenant prononcés aussi naturellement que dans les phrases, avec Sara comme avec Nicola.",
    ],
  },
  {
    at: "2026-11-04T05:37", emoji: "🎶", lang: "zh", title: "Mandarin : voix plus naturelles",
    items: ["Plus de petit son parasite en fin de mot (« ni hao-é »).", "La hauteur de la voix reste stable sur les mots courts (儿子…)."],
  },
  {
    at: "2026-11-04T04:24", emoji: "⚔️", title: "Défis de 75 et 100 questions",
    items: ["Deux nouveaux formats : « Endurance » (75) et « Légende » (100).", "iPhone : un double appui ne zoome plus sur la page."],
  },
  {
    at: "2026-11-04T04:09", emoji: "🧩", title: "Exercices plus justes",
    items: ["Les petits dialogues des leçons (« Di dove sei? — Sono francese. ») sont séparés : chaque réplique a sa propre traduction, on peut donc toujours deviner la réponse."],
  },
  {
    at: "2026-11-04T03:36", emoji: "🔈", title: "Choix de la voix",
    items: ["Paramètres › Préférences › Son : « Voix utilisée » enregistrée ou voix de l'appareil (iPhone…).", "Mandarin : les versions d'origine des voix restent disponibles."],
  },
  {
    at: "2026-11-04T03:03", emoji: "🎙️", lang: "it", title: "Italien : nouvelle voix Nicola",
    items: ["Une voix d'homme en plus de Sara, au choix comme voix principale.", "Dans les dialogues et les histoires, chaque personnage a sa voix."],
  },
  {
    at: "2026-11-04T01:33", emoji: "🧭", title: "Onglet « Découvrir »",
    items: ["Nombre de joueurs, classement général d'XP et de la semaine, profils des autres joueurs.", "À activer dans Paramètres › Compte ; vous n'apparaissez dans le classement que si vous le choisissez."],
  },
  {
    at: "2026-11-04T00:33", emoji: "🀄", lang: "zh", title: "Mandarin : tons corrigés et nouvelle voix Yunxi",
    items: ["Les tons des enregistrements sont maintenant justes.", "Nouvelle voix d'homme Yunxi ; dans les dialogues et histoires, deux voix différentes."],
  },
  {
    at: "2026-11-03T21:49", emoji: "🎤", title: "Prononciation repensée",
    items: ["Mandarin : analyse de vos tons syllabe par syllabe, avec votre courbe à côté de la courbe attendue.", "Texte affiché en direct pendant que vous parlez, et bouton pour réécouter votre voix."],
  },
  {
    at: "2026-11-03T21:18", emoji: "📖", title: "Histoires plus confortables",
    items: ["La traduction s'affiche bien sous la phrase.", "La voix ne s'arrête plus quand on touche l'écran."],
  },
  {
    at: "2026-11-03T21:08", emoji: "⚙️", title: "Nouveaux paramètres",
    items: ["Paramètres rangés par catégories : Compte, Notifications, Préférences, Cours.", "Notifications au choix : messages, demandes d'ami, défis, réactions, rappel de série à l'heure voulue."],
  },
  {
    at: "2026-11-03T20:47", emoji: "🔊", title: "Voix naturelles enregistrées",
    items: ["Toutes les phrases du cours sont lues par une voix naturelle, identique sur tous les appareils."],
  },
  {
    at: "2026-11-03T17:33", emoji: "💬", title: "Dialogues et nombres",
    items: ["Dialogues à choix : répondez dans des situations de la vie réelle.", "Exercices sans fin sur les nombres, l'heure, les dates et les prix."],
  },
  {
    at: "2026-11-03T17:09", emoji: "🔑", title: "Nouveaux outils d'apprentissage",
    items: ["Mots cliquables pour voir leur traduction.", "Phrases à remettre dans l'ordre, exercice « Répéter ».", "Mandarin : les clés des caractères pour les retenir."],
  },
  {
    at: "2026-11-03T13:20", emoji: "🏆", title: "Défis enrichis",
    items: ["Mode Écoute, déroulé de la partie, records, statistiques par mode et historique filtrable."],
  },
  {
    at: "2026-11-03T02:31", emoji: "🔁", title: "Duels entre amis",
    items: ["Bilan de rivalité, revanche en un clic, mode mort subite, défi « sur son terrain »."],
  },
  {
    at: "2026-11-03T02:09", emoji: "🎓", title: "Niveau B1 / HSK 3",
    items: ["25 nouvelles leçons, examens enrichis et nouvelles histoires."],
  },
];

/** Date lisible : « mar. 4 nov. 2026 · 14 h 13 » */
// Les heures sont notées à l'heure de Paris (hiver : +01:00) ; on les affiche dans le fuseau de l'appareil.
export const atDate = (at) => new Date(/[+-]\d\d:\d\d$|Z$/.test(at) ? at : `${at}:00+01:00`);
export function whenLabel(at) {
  const d = atDate(at);
  return `${d.toLocaleDateString("fr-FR", { weekday: "short", day: "numeric", month: "short", year: "numeric" })} · ${d.toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" }).replace(":", " h ")}`;
}
