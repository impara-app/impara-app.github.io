/* =====================================================================
   curriculum.js — Façade : charge le contenu de la langue active
   ---------------------------------------------------------------------
   Toutes les vues importent ce module ; elles n'ont donc pas besoin
   de savoir quelle langue est enseignée.
   ===================================================================== */

import { code } from "../core/lang.js";

const SOURCES = {
  it: () => import("./it.js"),
  zh: () => import("./zh.js"),
};

const mod = await (SOURCES[code] || SOURCES.it)();

export const { LEVELS, MODULES, ALL_LESSONS, getLevel, getLesson, getQuestion, refLabel } = mod;

/** Libellé affiché d'un palier : « HSK 1 » en mandarin, « A1 » en italien. */
export const lvlLabel = (lvlOrId) => {
  const l = typeof lvlOrId === "string" ? LEVELS.find((x) => x.id === lvlOrId) : lvlOrId;
  return l?.label || l?.id || lvlOrId;
};
/** Contenu de la pastille ronde : « HSK » en petit au-dessus du chiffre. */
export const lvlBadge = (l) => {
  const lab = lvlLabel(l);
  const m = /^HSK\s*(.+)$/.exec(lab);
  return m ? `<span class="badge-pre">HSK</span>${m[1]}` : lab;
};
