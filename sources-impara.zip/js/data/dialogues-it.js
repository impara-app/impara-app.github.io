/* =====================================================================
   Dialogues à choix — italien
   À chaque tour où c'est à vous, 3 répliques :
   ok: 2 = juste et naturelle · 1 = compréhensible mais maladroite · 0 = fausse
   « why » explique pourquoi (affiché après le choix).
   ===================================================================== */
export default [
  {
    id: "it-d-bar", after: "a1-cibo", level: "A1", emoji: "☕", title: "Al bar",
    intro: "Vous entrez dans un bar à Rome pour prendre un petit-déjeuner. Le barista vous accueille.",
    npc: "Barista",
    turns: [
      { npc: "Buongiorno! Cosa prende?", fr: "Bonjour ! Qu'est-ce que vous prenez ?" },
      { choices: [
        { t: "Un cappuccino e un cornetto, per favore.", fr: "Un cappuccino et un croissant, s'il vous plaît.", ok: 2, why: "Parfait : poli et naturel. « Per favore » à la fin, comme en français." },
        { t: "Voglio un cappuccino.", fr: "Je veux un cappuccino.", ok: 1, why: "Compréhensible, mais « voglio » (je veux) sonne sec. On dit plutôt « prendo » ou « vorrei »." },
        { t: "Sono un cappuccino.", fr: "Je suis un cappuccino.", ok: 0, why: "« Sono » veut dire « je suis » ! Pour commander : « prendo » ou « vorrei »." },
      ] },
      { npc: "Il cornetto vuoto o alla crema?", fr: "Le croissant nature ou à la crème ?" },
      { choices: [
        { t: "Alla crema, grazie.", fr: "À la crème, merci.", ok: 2, why: "Simple et naturel : on reprend juste le choix proposé." },
        { t: "Sì.", fr: "Oui.", ok: 0, why: "C'était un choix entre deux options : répondre « oui » ne dit pas lequel !" },
        { t: "Crema.", fr: "Crème.", ok: 1, why: "On vous comprend, mais un seul mot fait un peu brusque. « Alla crema, grazie » est plus poli." },
      ] },
      { npc: "Ecco a lei. Altro?", fr: "Voilà pour vous. Autre chose ?" },
      { choices: [
        { t: "No, basta così. Quant'è?", fr: "Non, ce sera tout. C'est combien ?", ok: 2, why: "« Basta così » (ça suffit) et « Quant'è ? » (c'est combien ?) : exactement ce qu'on entend au bar." },
        { t: "No, grazie. Quanti anni ha?", fr: "Non, merci. Quel âge avez-vous ?", ok: 0, why: "« Quanti anni ha ? » demande l'âge ! Pour le prix : « Quant'è ? » ou « Quanto costa ? »." },
        { t: "Niente. Il prezzo?", fr: "Rien. Le prix ?", ok: 1, why: "Compréhensible mais télégraphique. Préférez « No, grazie, basta così. Quant'è ? »." },
      ] },
      { npc: "Sono tre euro e venti.", fr: "Ça fait trois euros vingt." },
      { choices: [
        { t: "Ecco. Buona giornata!", fr: "Voilà. Bonne journée !", ok: 2, why: "Parfait pour partir : « Buona giornata ! » (bonne journée)." },
        { t: "Ecco. Buonanotte!", fr: "Voilà. Bonne nuit !", ok: 0, why: "« Buonanotte » ne se dit qu'avant d'aller dormir. Le matin : « Buona giornata ! »." },
        { t: "Ecco. Ciao!", fr: "Voilà. Salut !", ok: 1, why: "« Ciao » passe dans un bar détendu, mais avec un inconnu « Buona giornata » ou « Arrivederci » est plus correct." },
      ] },
      { npc: "Grazie, altrettanto!", fr: "Merci, à vous aussi !" },
    ],
  },
  {
    id: "it-d-stazione", after: "a2-viaggi", level: "A2", emoji: "🚆", title: "Alla stazione",
    intro: "Vous êtes à la gare de Milan et voulez aller à Florence. Vous allez au guichet.",
    npc: "Impiegato",
    turns: [
      { npc: "Buongiorno, mi dica.", fr: "Bonjour, je vous écoute." },
      { choices: [
        { t: "Buongiorno, vorrei un biglietto per Firenze.", fr: "Bonjour, je voudrais un billet pour Florence.", ok: 2, why: "« Vorrei » (je voudrais) est la formule polie idéale, et « per » indique la destination." },
        { t: "Buongiorno, vorrei un biglietto a Firenze.", fr: "Bonjour, je voudrais un billet à Florence.", ok: 1, why: "On vous comprend, mais un billet « pour » une ville se dit « per Firenze »." },
        { t: "Buongiorno, dove va Firenze?", fr: "Bonjour, où va Florence ?", ok: 0, why: "La phrase ne veut rien dire. Demandez un billet : « Vorrei un biglietto per Firenze »." },
      ] },
      { npc: "Solo andata o andata e ritorno?", fr: "Aller simple ou aller-retour ?" },
      { choices: [
        { t: "Andata e ritorno, per favore. Torno domenica.", fr: "Aller-retour, s'il vous plaît. Je reviens dimanche.", ok: 2, why: "Réponse claire, et vous donnez la date du retour : parfait." },
        { t: "Ritorno solo.", fr: "Retour seulement.", ok: 0, why: "On part d'ici : c'est « solo andata » (aller simple) ou « andata e ritorno » (aller-retour)." },
        { t: "Tutti e due.", fr: "Les deux.", ok: 1, why: "Compréhensible, mais le terme attendu est « andata e ritorno »." },
      ] },
      { npc: "C'è un Frecciarossa alle dieci e un regionale alle dieci e mezza.", fr: "Il y a un Frecciarossa à dix heures et un régional à dix heures et demie." },
      { choices: [
        { t: "Quanto ci mette il regionale?", fr: "Combien de temps met le régional ?", ok: 2, why: "« Metterci » = mettre (du temps) : la question parfaite pour comparer les trains." },
        { t: "Quanto è lungo il regionale?", fr: "Quelle est la longueur du régional ?", ok: 1, why: "Ça demande la longueur du train ! Pour la durée : « Quanto ci mette ? »." },
        { t: "A che ora sono le dieci?", fr: "À quelle heure est-il dix heures ?", ok: 0, why: "La question n'a pas de sens. Pour l'heure de départ : « A che ora parte ? »." },
      ] },
      { npc: "Il regionale ci mette tre ore, il Frecciarossa un'ora e quaranta.", fr: "Le régional met trois heures, le Frecciarossa une heure quarante." },
      { choices: [
        { t: "Allora prendo il Frecciarossa. Da quale binario parte?", fr: "Alors je prends le Frecciarossa. Il part de quel quai ?", ok: 2, why: "Vous choisissez et demandez le quai (« binario ») : vous êtes prêt à partir." },
        { t: "Il Frecciarossa. Dov'è il treno?", fr: "Le Frecciarossa. Où est le train ?", ok: 1, why: "Compréhensible, mais en gare on demande le quai : « Da quale binario parte ? »." },
        { t: "Prendo tre ore.", fr: "Je prends trois heures.", ok: 0, why: "Vous ne choisissez pas un train mais une durée ! « Prendo il Frecciarossa »." },
      ] },
      { npc: "Dal binario sette. Sono quarantacinque euro. Buon viaggio!", fr: "Du quai sept. Ça fait quarante-cinq euros. Bon voyage !" },
    ],
  },
  {
    id: "it-d-medico", after: "a2-salute", level: "A2", emoji: "🩺", title: "Dal medico",
    intro: "Vous ne vous sentez pas bien depuis deux jours. Vous consultez un médecin.",
    npc: "Dottoressa",
    turns: [
      { npc: "Buongiorno. Mi dica, cosa si sente?", fr: "Bonjour. Dites-moi, que ressentez-vous ?" },
      { choices: [
        { t: "Ho mal di gola e un po' di febbre.", fr: "J'ai mal à la gorge et un peu de fièvre.", ok: 2, why: "« Avere mal di… » + partie du corps : la structure exacte. Clair et précis." },
        { t: "Sono mal di gola.", fr: "Je suis mal de gorge.", ok: 0, why: "Avec la douleur, on utilise « avere » : « Ho mal di gola »." },
        { t: "Gola male.", fr: "Gorge mal.", ok: 1, why: "La médecin comprend, mais il manque le verbe : « Ho mal di gola »." },
      ] },
      { npc: "Da quanto tempo?", fr: "Depuis combien de temps ?" },
      { choices: [
        { t: "Da due giorni.", fr: "Depuis deux jours.", ok: 2, why: "« Da » + durée = depuis. Exactement ce qu'il faut." },
        { t: "Due giorni fa.", fr: "Il y a deux jours.", ok: 1, why: "Compréhensible, mais « fa » situe un moment passé. Pour une durée qui continue : « da due giorni »." },
        { t: "Per due giorni.", fr: "Pendant deux jours.", ok: 0, why: "« Per » donne une durée terminée ou à venir. Ici ça dure encore : « da due giorni »." },
      ] },
      { npc: "Prende qualche medicina? Ha allergie?", fr: "Vous prenez des médicaments ? Vous avez des allergies ?" },
      { choices: [
        { t: "No, non prendo niente e non ho allergie.", fr: "Non, je ne prends rien et je n'ai pas d'allergies.", ok: 2, why: "Double négation correcte (« non… niente ») et réponse complète aux deux questions." },
        { t: "No niente.", fr: "Non rien.", ok: 1, why: "Ça répond à moitié : on ne sait pas pour les allergies." },
        { t: "Sì, sono allergia.", fr: "Oui, je suis allergie.", ok: 0, why: "On dit « sono allergico/allergica a… » ou « ho un'allergia a… »." },
      ] },
      { npc: "È un'influenza. Prenda questo sciroppo tre volte al giorno e stia a riposo.", fr: "C'est une grippe. Prenez ce sirop trois fois par jour et restez au repos." },
      { choices: [
        { t: "Va bene. Devo prenderlo prima o dopo i pasti?", fr: "D'accord. Je dois le prendre avant ou après les repas ?", ok: 2, why: "Très bonne question à poser, avec le pronom « lo » collé à l'infinitif." },
        { t: "Va bene. Tre volte al giorno, posso andare in palestra?", fr: "D'accord. Trois fois par jour, je peux aller à la salle de sport ?", ok: 1, why: "La phrase est correcte, mais elle vient de vous dire de rester au repos…" },
        { t: "Va bene. Prendo tre sciroppi adesso.", fr: "D'accord. Je prends trois sirops maintenant.", ok: 0, why: "Contresens : c'est trois fois par jour, pas trois flacons d'un coup !" },
      ] },
      { npc: "Dopo i pasti. Se tra tre giorni non sta meglio, torni da me. Guarisca presto!", fr: "Après les repas. Si dans trois jours ça ne va pas mieux, revenez me voir. Bon rétablissement !" },
    ],
  },
  {
    id: "it-d-negozio", after: "a2-negozi", level: "A2", emoji: "👟", title: "In un negozio di scarpe",
    intro: "Vous cherchez des chaussures de marche pour un voyage. Une vendeuse s'approche.",
    npc: "Commessa",
    turns: [
      { npc: "Buongiorno, posso aiutarla?", fr: "Bonjour, je peux vous aider ?" },
      { choices: [
        { t: "Sì, grazie. Cerco delle scarpe comode per camminare.", fr: "Oui, merci. Je cherche des chaussures confortables pour marcher.", ok: 2, why: "« Cerco » (je cherche) + votre besoin précis : la vendeuse sait quoi vous montrer." },
        { t: "Sì. Scarpe.", fr: "Oui. Chaussures.", ok: 1, why: "Compréhensible, mais très sec. Précisez avec « Cerco delle scarpe… »." },
        { t: "No, grazie, cerco delle scarpe.", fr: "Non merci, je cherche des chaussures.", ok: 0, why: "Contradictoire : vous refusez l'aide puis demandez quelque chose. « Sì, grazie… »." },
      ] },
      { npc: "Che numero porta?", fr: "Quelle pointure faites-vous ?" },
      { choices: [
        { t: "Porto il quarantadue.", fr: "Je fais du quarante-deux.", ok: 2, why: "On « porte » un numéro en italien : « Porto il 42 »." },
        { t: "Ho quarantadue anni.", fr: "J'ai quarante-deux ans.", ok: 0, why: "C'est votre âge ! La pointure : « Porto il 42 »." },
        { t: "Il quarantadue, credo.", fr: "Du quarante-deux, je crois.", ok: 2, why: "Tout à fait naturel aussi." },
      ] },
      { npc: "Ecco, le provi. Come le vanno?", fr: "Voilà, essayez-les. Comment vous vont-elles ?" },
      { choices: [
        { t: "Mi stanno un po' strette. Ha il numero più grande?", fr: "Elles sont un peu serrées. Vous avez la pointure au-dessus ?", ok: 2, why: "« Stare stretto » (être serré) + demande précise : parfait." },
        { t: "Sono piccole io.", fr: "Je suis petites.", ok: 0, why: "Sujet et accord mélangés. « Mi stanno strette » ou « Sono un po' piccole »." },
        { t: "Non va bene. Altre?", fr: "Ça ne va pas. D'autres ?", ok: 1, why: "Compréhensible, mais dites pourquoi pour qu'elle vous aide : trop serrées, trop grandes…" },
      ] },
      { npc: "Ecco il quarantatré. Costano novanta euro, ma oggi c'è lo sconto del venti per cento.", fr: "Voici le 43. Elles coûtent 90 euros, mais aujourd'hui il y a 20 % de réduction." },
      { choices: [
        { t: "Perfetto, allora le prendo. Posso pagare con la carta?", fr: "Parfait, alors je les prends. Je peux payer par carte ?", ok: 2, why: "« Le prendo » (je les prends, « le » = les chaussures) et la question du paiement : impeccable." },
        { t: "Perfetto, lo prendo.", fr: "Parfait, je le prends.", ok: 1, why: "Presque : « scarpe » est féminin pluriel, donc « le prendo »." },
        { t: "Novanta per cento? Troppo caro!", fr: "Quatre-vingt-dix pour cent ? Trop cher !", ok: 0, why: "Vous avez mélangé : 90 € de prix, 20 % de réduction, donc 72 €." },
      ] },
      { npc: "Certo. Sono settantadue euro. Grazie e buona giornata!", fr: "Bien sûr. Ça fait 72 euros. Merci et bonne journée !" },
    ],
  },
  {
    id: "it-d-colloquio", after: "b1-lavoro", level: "B1", emoji: "💼", title: "Il colloquio di lavoro",
    intro: "Vous passez un entretien pour un stage dans une entreprise à Turin. Le recruteur vous pose des questions.",
    npc: "Selezionatore",
    turns: [
      { npc: "Buongiorno, si accomodi. Mi parli un po' di lei.", fr: "Bonjour, asseyez-vous. Parlez-moi un peu de vous." },
      { choices: [
        { t: "Sono uno studente di commercio internazionale e ho già fatto due stage all'estero.", fr: "Je suis étudiant en commerce international et j'ai déjà fait deux stages à l'étranger.", ok: 2, why: "Présentation claire, passé composé correct (« ho fatto ») et un atout mis en avant." },
        { t: "Mi chiamo Thomas, ho vent'anni, mi piace il calcio e la pizza.", fr: "Je m'appelle Thomas, j'ai vingt ans, j'aime le foot et la pizza.", ok: 1, why: "Correct, mais trop personnel pour un entretien : parlez de vos études et expériences." },
        { t: "Parlo di me: sono studiato commercio.", fr: "Je parle de moi : je suis étudié commerce.", ok: 0, why: "« Studiare » prend « avere » : « Ho studiato commercio »." },
      ] },
      { npc: "Perché vorrebbe lavorare con noi?", fr: "Pourquoi voudriez-vous travailler avec nous ?" },
      { choices: [
        { t: "Perché la vostra azienda esporta in tutta Europa e vorrei mettere in pratica le mie lingue.", fr: "Parce que votre entreprise exporte dans toute l'Europe et je voudrais mettre en pratique mes langues.", ok: 2, why: "Argument lié à l'entreprise + conditionnel « vorrei » : convaincant et poli." },
        { t: "Perché ho bisogno di uno stage per la scuola.", fr: "Parce que j'ai besoin d'un stage pour l'école.", ok: 1, why: "C'est honnête et correct, mais peu motivant pour le recruteur." },
        { t: "Perché vorrebbe.", fr: "Parce qu'il voudrait.", ok: 0, why: "Vous répétez le verbe à la mauvaise personne : « vorrei » (je voudrais)." },
      ] },
      { npc: "Quali sono i suoi punti deboli?", fr: "Quels sont vos points faibles ?" },
      { choices: [
        { t: "A volte sono troppo perfezionista, ma sto imparando a organizzarmi meglio.", fr: "Parfois je suis trop perfectionniste, mais j'apprends à mieux m'organiser.", ok: 2, why: "Défaut assumé + progrès en cours (« sto imparando ») : réponse classique et efficace." },
        { t: "Non ho punti deboli.", fr: "Je n'ai pas de points faibles.", ok: 1, why: "Grammaticalement correct, mais ça sonne arrogant en entretien." },
        { t: "Sono debole di punti.", fr: "Je suis faible de points.", ok: 0, why: "La phrase ne veut rien dire. « Il mio punto debole è… »." },
      ] },
      { npc: "Bene. Ha domande per noi?", fr: "Bien. Vous avez des questions pour nous ?" },
      { choices: [
        { t: "Sì: come si svolgerebbe una giornata tipo durante lo stage?", fr: "Oui : comment se déroulerait une journée type pendant le stage ?", ok: 2, why: "Question intéressée et au conditionnel : excellente impression." },
        { t: "Quanto mi pagate?", fr: "Combien vous me payez ?", ok: 1, why: "Légitime, mais trop direct comme première question. « Il tirocinio è retribuito ? » est plus diplomate." },
        { t: "No, ho finito le domande.", fr: "Non, j'ai fini les questions.", ok: 0, why: "C'est vous qui êtes interrogé : ne pas avoir de question donne l'impression d'un manque d'intérêt." },
      ] },
      { npc: "Ottima domanda. Le faremo sapere entro venerdì. Grazie per essere venuto!", fr: "Excellente question. Nous vous ferons savoir d'ici vendredi. Merci d'être venu !" },
    ],
  },
  {
    id: "it-d-reclamo", after: "b2-email-formale", level: "B2", emoji: "🏨", title: "Un reclamo in albergo",
    intro: "Votre chambre d'hôtel à Naples est bruyante et la climatisation ne marche pas. Vous allez voir la directrice. Restez poli et formel (Lei).",
    npc: "Direttrice",
    turns: [
      { npc: "Buonasera, sono la direttrice. Mi hanno detto che voleva parlarmi.", fr: "Bonsoir, je suis la directrice. On m'a dit que vous vouliez me parler." },
      { choices: [
        { t: "Sì, grazie per essere venuta. Purtroppo ci sono alcuni problemi con la mia camera.", fr: "Oui, merci d'être venue. Malheureusement, il y a quelques problèmes avec ma chambre.", ok: 2, why: "Remerciement + « purtroppo » : on annonce le problème poliment, avec le bon registre." },
        { t: "Sì. La camera fa schifo.", fr: "Oui. La chambre est dégoûtante.", ok: 0, why: "Beaucoup trop familier et agressif pour une réclamation formelle." },
        { t: "Sì, ciao, la camera ha problemi.", fr: "Oui, salut, la chambre a des problèmes.", ok: 1, why: "Compréhensible, mais « ciao » ne convient pas : on vouvoie (Lei) et on dit « buonasera »." },
      ] },
      { npc: "Mi dispiace molto. Di che cosa si tratta, esattamente?", fr: "J'en suis vraiment désolée. De quoi s'agit-il exactement ?" },
      { choices: [
        { t: "L'aria condizionata non funziona e la finestra dà sulla strada: non sono riuscito a dormire.", fr: "La climatisation ne marche pas et la fenêtre donne sur la rue : je n'ai pas réussi à dormir.", ok: 2, why: "Faits précis et conséquence (« non sono riuscito a dormire ») : une réclamation efficace." },
        { t: "Si tratta che non mi piace.", fr: "Il s'agit que je n'aime pas.", ok: 0, why: "Construction incorrecte et trop vague : décrivez les problèmes concrets." },
        { t: "Fa caldo.", fr: "Il fait chaud.", ok: 1, why: "C'est vrai, mais trop vague : précisez que la climatisation ne fonctionne pas." },
      ] },
      { npc: "Capisco. Purtroppo stasera l'albergo è al completo. Potrei mandarle un tecnico domattina.", fr: "Je comprends. Malheureusement ce soir l'hôtel est complet. Je pourrais vous envoyer un technicien demain matin." },
      { choices: [
        { t: "Le sarei grato se potesse almeno farmi uno sconto per questa notte.", fr: "Je vous serais reconnaissant si vous pouviez au moins me faire une réduction pour cette nuit.", ok: 2, why: "Conditionnel + subjonctif imparfait (« se potesse ») : demande à la fois ferme et très polie." },
        { t: "Voglio un'altra camera subito!", fr: "Je veux une autre chambre tout de suite !", ok: 1, why: "La demande est légitime, mais « voglio » + impératif sonne brutal ; préférez « vorrei » ou « le sarei grato se… »." },
        { t: "Se potrebbe farmi uno sconto…", fr: "Si vous pourriez me faire une réduction…", ok: 0, why: "Après « se » hypothétique, pas de conditionnel : « se potesse »." },
      ] },
      { npc: "Certamente. Le offro la notte di oggi e la colazione. Le va bene?", fr: "Bien sûr. Je vous offre la nuit d'aujourd'hui et le petit-déjeuner. Cela vous convient ?" },
      { choices: [
        { t: "Sì, la ringrazio della disponibilità. Spero che il tecnico possa risolvere il problema.", fr: "Oui, je vous remercie de votre disponibilité. J'espère que le technicien pourra régler le problème.", ok: 2, why: "Remerciement formel + « spero che » suivi du subjonctif : parfait." },
        { t: "Ok, va bene, ciao.", fr: "Ok, ça va, salut.", ok: 1, why: "Accepter est bien, mais restez dans le registre formel jusqu'au bout." },
        { t: "Spero che il tecnico può risolvere.", fr: "J'espère que le technicien peut résoudre.", ok: 0, why: "« Spero che » demande le subjonctif : « possa »." },
      ] },
      { npc: "Si figuri. Le chiedo ancora scusa per l'inconveniente. Buona serata.", fr: "Je vous en prie. Je m'excuse encore pour ce désagrément. Bonne soirée." },
    ],
  },
  {
    id: "it-d-affitto", after: "b2-verbi-preposizioni", level: "B2", emoji: "🔑", title: "Affittare un appartamento",
    intro: "Vous visitez un appartement à Bologne pour l'année universitaire. La propriétaire vous pose des questions et vous négociez.",
    npc: "Signora",
    turns: [
      { npc: "Ecco, questo è il soggiorno. Che ne pensa?", fr: "Voilà, c'est le séjour. Qu'en pensez-vous ?" },
      { choices: [
        { t: "È molto luminoso. Posso chiederle se le spese sono comprese nell'affitto?", fr: "Il est très lumineux. Puis-je vous demander si les charges sont comprises dans le loyer ?", ok: 2, why: "Un compliment, puis une question utile introduite poliment." },
        { t: "Bello. Quanto costa?", fr: "Joli. Combien ça coûte ?", ok: 1, why: "Correct mais un peu sec ; le prix est déjà annoncé, demandez plutôt ce qu'il comprend." },
        { t: "Penso di è bello.", fr: "Je pense de est joli.", ok: 0, why: "« Pensare che » + subjonctif : « Penso che sia bello »." },
      ] },
      { npc: "Le spese di condominio sì, ma luce e gas no. Lei è studente?", fr: "Les charges de copropriété oui, mais pas l'électricité ni le gaz. Vous êtes étudiant ?" },
      { choices: [
        { t: "Sì, mi sono iscritto a ingegneria e conto di restare almeno due anni.", fr: "Oui, je me suis inscrit en ingénierie et je compte rester au moins deux ans.", ok: 2, why: "« Iscriversi a » et « contare di » : les bonnes prépositions, et une info rassurante pour la propriétaire." },
        { t: "Sì, studio a ingegneria.", fr: "Oui, j'étudie à ingénierie.", ok: 1, why: "On dit « studio ingegneria » (sans préposition)." },
        { t: "Sì, conto a restare.", fr: "Oui, je compte à rester.", ok: 0, why: "« Contare DI + infinitif » : « conto di restare »." },
      ] },
      { npc: "Bene. L'affitto è di cinquecento euro al mese, più due mesi di cauzione.", fr: "Bien. Le loyer est de cinq cents euros par mois, plus deux mois de caution." },
      { choices: [
        { t: "Sarebbe possibile ridurre la cauzione a un mese? In cambio potrei firmare per due anni.", fr: "Serait-il possible de réduire la caution à un mois ? En échange, je pourrais signer pour deux ans.", ok: 2, why: "Négociation au conditionnel avec une contrepartie : convaincant et poli." },
        { t: "È troppo, non pago.", fr: "C'est trop, je ne paie pas.", ok: 0, why: "Aucune négociation possible avec cette réponse ; proposez quelque chose au conditionnel." },
        { t: "Va bene, ma la cauzione è alta.", fr: "D'accord, mais la caution est élevée.", ok: 1, why: "Vous signalez le problème sans rien proposer : formulez une demande concrète." },
      ] },
      { npc: "Mah… se firma per due anni, posso accettare un mese di cauzione.", fr: "Bon… si vous signez pour deux ans, je peux accepter un mois de caution." },
      { choices: [
        { t: "Perfetto, la ringrazio. Quando potremmo firmare il contratto?", fr: "Parfait, je vous remercie. Quand pourrions-nous signer le contrat ?", ok: 2, why: "Remerciement et étape suivante au conditionnel : vous concluez l'affaire." },
        { t: "Ci penso.", fr: "J'y réfléchis.", ok: 1, why: "Possible, mais après avoir négocié, mieux vaut conclure." },
        { t: "Grazie per accettare.", fr: "Merci pour accepter.", ok: 0, why: "« Grazie per » + infinitif passé : « grazie per aver accettato »." },
      ] },
      { npc: "Anche domani, se vuole. Porti un documento e il codice fiscale.", fr: "Dès demain, si vous voulez. Apportez une pièce d'identité et votre code fiscal." },
    ],
  },
];
