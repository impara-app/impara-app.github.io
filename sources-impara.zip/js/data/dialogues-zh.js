/* =====================================================================
   Dialogues à choix — mandarin
   ok: 2 = juste et naturelle · 1 = compréhensible mais maladroite · 0 = fausse
   ===================================================================== */
export default [
  {
    id: "zh-d-cafe", after: "a1-manger", level: "A1", emoji: "🧋", title: "在奶茶店", titlePy: "zài nǎichá diàn",
    intro: "Vous entrez dans une boutique de thé au lait à Shanghai.",
    npc: "服务员",
    turns: [
      { npc: "你好！你要喝什么？", py: "Nǐ hǎo! Nǐ yào hē shénme?", fr: "Bonjour ! Qu'est-ce que vous voulez boire ?" },
      { choices: [
        { t: "我要一杯奶茶。", py: "Wǒ yào yì bēi nǎichá.", fr: "Je voudrais un thé au lait.", ok: 2, why: "« 我要 » + quantité + 杯 (verre/tasse) : la façon naturelle de commander." },
        { t: "我要奶茶一个。", py: "Wǒ yào nǎichá yí gè.", fr: "Je veux thé au lait un.", ok: 1, why: "On vous comprend, mais le nombre et le classificateur se placent AVANT le nom : 一杯奶茶." },
        { t: "我是奶茶。", py: "Wǒ shì nǎichá.", fr: "Je suis un thé au lait.", ok: 0, why: "是 veut dire « être » ! Pour commander : 我要…" },
      ] },
      { npc: "要大杯还是中杯？", py: "Yào dà bēi háishi zhōng bēi?", fr: "Grand ou moyen ?" },
      { choices: [
        { t: "中杯，谢谢。", py: "Zhōng bēi, xièxie.", fr: "Moyen, merci.", ok: 2, why: "On reprend simplement l'option choisie : parfait." },
        { t: "是。", py: "Shì.", fr: "Oui.", ok: 0, why: "还是 pose une question à choix : il faut choisir, pas répondre « oui »." },
        { t: "中。", py: "Zhōng.", fr: "Moyen.", ok: 1, why: "Compréhensible, mais un peu sec. 中杯，谢谢 est plus naturel." },
      ] },
      { npc: "要冰的还是热的？", py: "Yào bīng de háishi rè de?", fr: "Glacé ou chaud ?" },
      { choices: [
        { t: "热的，少放糖。", py: "Rè de, shǎo fàng táng.", fr: "Chaud, avec peu de sucre.", ok: 2, why: "Vous répondez et précisez le sucre (少放糖) : très naturel en Chine." },
        { t: "我很热。", py: "Wǒ hěn rè.", fr: "J'ai très chaud.", ok: 0, why: "« 我很热 » veut dire que VOUS avez chaud ! Pour la boisson : 热的." },
        { t: "热。", py: "Rè.", fr: "Chaud.", ok: 1, why: "On comprend, mais avec 的 c'est plus correct : 热的 (un chaud)." },
      ] },
      { npc: "好的，一共十八块。", py: "Hǎo de, yígòng shíbā kuài.", fr: "D'accord, ça fait dix-huit yuans en tout." },
      { choices: [
        { t: "可以用微信付吗？", py: "Kěyǐ yòng Wēixìn fù ma?", fr: "Je peux payer avec WeChat ?", ok: 2, why: "En Chine on paie presque tout par téléphone : question parfaite." },
        { t: "多少钱？", py: "Duōshao qián?", fr: "Combien ça coûte ?", ok: 1, why: "Correct, mais elle vient de vous dire le prix (十八块)." },
        { t: "十八岁。", py: "Shíbā suì.", fr: "Dix-huit ans.", ok: 0, why: "岁 sert pour l'âge ! Le prix c'était 十八块 (yuans)." },
      ] },
      { npc: "可以，请扫这里。", py: "Kěyǐ, qǐng sǎo zhèlǐ.", fr: "Oui, scannez ici s'il vous plaît." },
    ],
  },
  {
    id: "zh-d-fruits", after: "a1-acheter", level: "A1", emoji: "🍎", title: "买水果", titlePy: "mǎi shuǐguǒ",
    intro: "Au marché, vous voulez acheter des pommes chez un vendeur de fruits.",
    npc: "老板",
    turns: [
      { npc: "你要买什么？", py: "Nǐ yào mǎi shénme?", fr: "Qu'est-ce que vous voulez acheter ?" },
      { choices: [
        { t: "苹果多少钱一斤？", py: "Píngguǒ duōshao qián yì jīn?", fr: "Combien coûtent les pommes la livre ?", ok: 2, why: "En Chine les fruits se vendent au 斤 (500 g) : la question typique du marché." },
        { t: "苹果多少？", py: "Píngguǒ duōshao?", fr: "Pommes combien ?", ok: 1, why: "Compréhensible, mais précisez : 多少钱 (combien d'argent) et l'unité 一斤." },
        { t: "我是苹果。", py: "Wǒ shì píngguǒ.", fr: "Je suis une pomme.", ok: 0, why: "是 = être ! Pour demander le prix : 多少钱？" },
      ] },
      { npc: "五块一斤。", py: "Wǔ kuài yì jīn.", fr: "Cinq yuans la livre." },
      { choices: [
        { t: "太贵了！四块可以吗？", py: "Tài guì le! Sì kuài kěyǐ ma?", fr: "Trop cher ! Quatre yuans, c'est possible ?", ok: 2, why: "Au marché, on négocie ! 太…了 + une contre-proposition polie avec 可以吗." },
        { t: "很贵。", py: "Hěn guì.", fr: "C'est cher.", ok: 1, why: "Correct, mais sans proposition, le vendeur ne va pas baisser son prix." },
        { t: "五块很便宜，我要十块。", py: "Wǔ kuài hěn piányi, wǒ yào shí kuài.", fr: "Cinq yuans c'est pas cher, je veux payer dix.", ok: 0, why: "Vous proposez de payer plus cher que le prix ! Négocier, c'est proposer moins." },
      ] },
      { npc: "好吧，四块五。你要几斤？", py: "Hǎo ba, sì kuài wǔ. Nǐ yào jǐ jīn?", fr: "Bon d'accord, quatre cinquante. Vous en voulez combien de livres ?" },
      { choices: [
        { t: "我要两斤。", py: "Wǒ yào liǎng jīn.", fr: "J'en veux deux livres.", ok: 2, why: "Devant un classificateur, « deux » se dit 两, pas 二." },
        { t: "我要二斤。", py: "Wǒ yào èr jīn.", fr: "J'en veux deux livres.", ok: 1, why: "On vous comprend, mais devant un classificateur on dit 两 : 两斤." },
        { t: "我要两岁。", py: "Wǒ yào liǎng suì.", fr: "Je veux deux ans.", ok: 0, why: "岁 = an (d'âge). Pour les fruits : 斤." },
      ] },
      { npc: "两斤，九块。还要别的吗？", py: "Liǎng jīn, jiǔ kuài. Hái yào bié de ma?", fr: "Deux livres, neuf yuans. Autre chose ?" },
      { choices: [
        { t: "不要了，谢谢！", py: "Bú yào le, xièxie!", fr: "Non, ce sera tout, merci !", ok: 2, why: "不要了 = je n'en veux plus : la formule naturelle pour terminer." },
        { t: "没有。", py: "Méiyǒu.", fr: "Je n'ai pas.", ok: 1, why: "没有 veut dire « ne pas avoir » : on comprend, mais 不要了 est plus juste." },
        { t: "还要九块。", py: "Hái yào jiǔ kuài.", fr: "Je veux encore neuf yuans.", ok: 0, why: "Vous demandez de l'argent en plus ! Pour refuser : 不要了." },
      ] },
      { npc: "好，慢走！", py: "Hǎo, màn zǒu!", fr: "D'accord, au revoir (« marchez lentement ») !" },
    ],
  },
  {
    id: "zh-d-taxi", after: "a1-transport", level: "A1", emoji: "🚕", title: "坐出租车", titlePy: "zuò chūzūchē",
    intro: "Vous prenez un taxi à Pékin pour aller à la gare.",
    npc: "司机",
    turns: [
      { npc: "你好，去哪儿？", py: "Nǐ hǎo, qù nǎr?", fr: "Bonjour, où allez-vous ?" },
      { choices: [
        { t: "师傅，我去北京站。", py: "Shīfu, wǒ qù Běijīng Zhàn.", fr: "Monsieur, je vais à la gare de Pékin.", ok: 2, why: "师傅 est la façon polie d'interpeller un chauffeur, et 去 + lieu dit la destination." },
        { t: "北京站。", py: "Běijīng Zhàn.", fr: "Gare de Pékin.", ok: 2, why: "Très courant en taxi : juste la destination suffit." },
        { t: "我在北京站。", py: "Wǒ zài Běijīng Zhàn.", fr: "Je suis à la gare de Pékin.", ok: 0, why: "在 = être à un endroit. Pour y aller : 去北京站." },
      ] },
      { npc: "好的。你的火车几点开？", py: "Hǎo de. Nǐ de huǒchē jǐ diǎn kāi?", fr: "D'accord. Votre train part à quelle heure ?" },
      { choices: [
        { t: "三点半。我们能到吗？", py: "Sān diǎn bàn. Wǒmen néng dào ma?", fr: "Trois heures et demie. On peut y arriver à temps ?", ok: 2, why: "L'heure avec 点 et 半, et une question utile." },
        { t: "三个点半。", py: "Sān gè diǎn bàn.", fr: "Trois (classificateur) heures et demie.", ok: 0, why: "Pas de 个 avec l'heure : 三点半." },
        { t: "三点三十。", py: "Sān diǎn sānshí.", fr: "Trois heures trente.", ok: 1, why: "Compréhensible, mais on dit plutôt 三点半 (« et demie »)." },
      ] },
      { npc: "没问题，二十分钟就到。", py: "Méi wèntí, èrshí fēnzhōng jiù dào.", fr: "Pas de problème, on y est en vingt minutes." },
      { choices: [
        { t: "太好了，谢谢师傅！", py: "Tài hǎo le, xièxie shīfu!", fr: "Super, merci monsieur !", ok: 2, why: "太好了 pour exprimer le soulagement, et un merci poli." },
        { t: "二十分钟很长。", py: "Èrshí fēnzhōng hěn cháng.", fr: "Vingt minutes, c'est long.", ok: 1, why: "Grammaticalement correct, mais un peu impoli alors qu'il vous rassure." },
        { t: "我二十岁。", py: "Wǒ èrshí suì.", fr: "J'ai vingt ans.", ok: 0, why: "Hors sujet : il parlait de minutes, pas de votre âge." },
      ] },
      { npc: "到了。一共三十五块。", py: "Dào le. Yígòng sānshíwǔ kuài.", fr: "Nous y sommes. Ça fait trente-cinq yuans en tout." },
      { choices: [
        { t: "给你四十块，不用找了。", py: "Gěi nǐ sìshí kuài, bú yòng zhǎo le.", fr: "Voici quarante yuans, gardez la monnaie.", ok: 2, why: "给你 (voici) + 不用找了 (pas besoin de rendre la monnaie) : très naturel." },
        { t: "给你三十五块。", py: "Gěi nǐ sānshíwǔ kuài.", fr: "Voici trente-cinq yuans.", ok: 2, why: "Simple et parfait." },
        { t: "我没有三十五岁。", py: "Wǒ méiyǒu sānshíwǔ suì.", fr: "Je n'ai pas trente-cinq ans.", ok: 0, why: "块 (yuan) et 岁 (âge) se ressemblent à l'oreille, mais pas du tout le même sens !" },
      ] },
      { npc: "谢谢，一路顺风！", py: "Xièxie, yílù shùnfēng!", fr: "Merci, bon voyage !" },
    ],
  },
  {
    id: "zh-d-hotel", after: "a2-lvyou", level: "A2", emoji: "🏨", title: "在酒店", titlePy: "zài jiǔdiàn",
    intro: "Vous arrivez dans un hôtel à Xi'an où vous avez réservé une chambre.",
    npc: "前台",
    turns: [
      { npc: "您好，欢迎光临！请问有预订吗？", py: "Nín hǎo, huānyíng guānglín! Qǐngwèn yǒu yùdìng ma?", fr: "Bonjour, bienvenue ! Avez-vous une réservation ?" },
      { choices: [
        { t: "有，我在网上订了一个房间。", py: "Yǒu, wǒ zài wǎngshang dìng le yí gè fángjiān.", fr: "Oui, j'ai réservé une chambre sur internet.", ok: 2, why: "On répond 有 (reprise du verbe) puis on précise, avec 了 pour l'action accomplie." },
        { t: "是。", py: "Shì.", fr: "Oui (c'est ça).", ok: 1, why: "En chinois on répond souvent en reprenant le verbe de la question : 有." },
        { t: "没有房间。", py: "Méiyǒu fángjiān.", fr: "Il n'y a pas de chambre.", ok: 0, why: "Vous dites qu'il n'y a pas de chambre ! Répondez 有 et précisez." },
      ] },
      { npc: "请给我看一下您的护照。", py: "Qǐng gěi wǒ kàn yíxià nín de hùzhào.", fr: "Montrez-moi votre passeport, s'il vous plaît." },
      { choices: [
        { t: "好的，给您。", py: "Hǎo de, gěi nín.", fr: "D'accord, voici.", ok: 2, why: "给您 (« à vous », poli) en tendant le document." },
        { t: "我的护照很好看。", py: "Wǒ de hùzhào hěn hǎokàn.", fr: "Mon passeport est très joli.", ok: 0, why: "看一下 = jeter un œil, pas « beau ». Tendez-le simplement : 给您." },
        { t: "护照，这个。", py: "Hùzhào, zhège.", fr: "Passeport, celui-ci.", ok: 1, why: "Compréhensible mais maladroit. 好的，给您 est plus naturel." },
      ] },
      { npc: "您的房间在八楼，八零六。早饭从七点到九点。", py: "Nín de fángjiān zài bā lóu, bā líng liù. Zǎofàn cóng qī diǎn dào jiǔ diǎn.", fr: "Votre chambre est au 8e étage, la 806. Le petit-déjeuner est de 7 h à 9 h." },
      { choices: [
        { t: "请问，房间里有无线网吗？", py: "Qǐngwèn, fángjiān lǐ yǒu wúxiànwǎng ma?", fr: "Excusez-moi, il y a du wifi dans la chambre ?", ok: 2, why: "请问 pour introduire poliment une question, et 有…吗 pour demander s'il y a quelque chose." },
        { t: "早饭几点？", py: "Zǎofàn jǐ diǎn?", fr: "Le petit-déjeuner, à quelle heure ?", ok: 1, why: "Correct, mais elle vient de vous le dire (7 h – 9 h) !" },
        { t: "我住在八百零六楼。", py: "Wǒ zhù zài bābǎi líng liù lóu.", fr: "J'habite au 806e étage.", ok: 0, why: "806 est le numéro de chambre ; l'étage, c'est le 8 (八楼)." },
      ] },
      { npc: "有，密码在房卡上。祝您住得愉快！", py: "Yǒu, mìmǎ zài fángkǎ shang. Zhù nín zhù de yúkuài!", fr: "Oui, le mot de passe est sur la carte de la chambre. Bon séjour !" },
    ],
  },
  {
    id: "zh-d-yisheng", after: "b1-shenti", level: "B1", emoji: "🩺", title: "看医生", titlePy: "kàn yīshēng",
    intro: "Vous êtes malade depuis deux jours et vous allez à l'hôpital voir un médecin.",
    npc: "医生",
    turns: [
      { npc: "你哪儿不舒服？", py: "Nǐ nǎr bù shūfu?", fr: "Où avez-vous mal ? (Qu'est-ce qui ne va pas ?)" },
      { choices: [
        { t: "我头疼，嗓子也疼，还有点儿发烧。", py: "Wǒ tóu téng, sǎngzi yě téng, hái yǒudiǎnr fāshāo.", fr: "J'ai mal à la tête, à la gorge aussi, et un peu de fièvre.", ok: 2, why: "Partie du corps + 疼, puis 有点儿 pour « un peu » : description claire." },
        { t: "我很疼头。", py: "Wǒ hěn téng tóu.", fr: "Je fais très mal la tête.", ok: 0, why: "L'ordre est : partie du corps + 疼 : 我头疼." },
        { t: "我病了。", py: "Wǒ bìng le.", fr: "Je suis malade.", ok: 1, why: "Correct, mais le médecin a besoin de savoir OÙ vous avez mal." },
      ] },
      { npc: "疼了多长时间了？", py: "Téng le duō cháng shíjiān le?", fr: "Ça fait combien de temps que ça vous fait mal ?" },
      { choices: [
        { t: "已经两天了。", py: "Yǐjīng liǎng tiān le.", fr: "Ça fait déjà deux jours.", ok: 2, why: "已经…了 pour une durée qui continue : exactement la bonne structure." },
        { t: "两天以前。", py: "Liǎng tiān yǐqián.", fr: "Il y a deux jours.", ok: 1, why: "On comprend quand ça a commencé, mais la question porte sur la durée : 已经两天了." },
        { t: "两点。", py: "Liǎng diǎn.", fr: "Deux heures (de l'après-midi).", ok: 0, why: "点 donne une heure de la journée, pas une durée. Pour la durée : 两天 / 两个小时." },
      ] },
      { npc: "你对什么药过敏吗？", py: "Nǐ duì shénme yào guòmǐn ma?", fr: "Êtes-vous allergique à un médicament ?" },
      { choices: [
        { t: "我对青霉素过敏。", py: "Wǒ duì qīngméisù guòmǐn.", fr: "Je suis allergique à la pénicilline.", ok: 2, why: "对 + chose + 过敏 : la structure exacte. Information importante !" },
        { t: "我过敏青霉素。", py: "Wǒ guòmǐn qīngméisù.", fr: "J'allergique pénicilline.", ok: 1, why: "Compréhensible, mais il faut 对 devant la cause : 我对青霉素过敏." },
        { t: "我很喜欢药。", py: "Wǒ hěn xǐhuan yào.", fr: "J'aime beaucoup les médicaments.", ok: 0, why: "Hors sujet (et inquiétant) ! Répondez 没有 ou 我对…过敏." },
      ] },
      { npc: "你感冒了。这个药一天吃三次，每次两片。多喝水，多休息。", py: "Nǐ gǎnmào le. Zhège yào yì tiān chī sān cì, měi cì liǎng piàn. Duō hē shuǐ, duō xiūxi.", fr: "Vous avez un rhume. Ce médicament, trois fois par jour, deux comprimés à chaque fois. Buvez beaucoup d'eau et reposez-vous." },
      { choices: [
        { t: "好的。饭前吃还是饭后吃？", py: "Hǎo de. Fàn qián chī háishi fàn hòu chī?", fr: "D'accord. Avant ou après les repas ?", ok: 2, why: "Question précise avec 还是 (ou bien) : parfait." },
        { t: "好的，我一天吃六次。", py: "Hǎo de, wǒ yì tiān chī liù cì.", fr: "D'accord, je le prends six fois par jour.", ok: 0, why: "Contresens : trois fois par jour, deux comprimés à chaque fois (= six comprimés, pas six prises)." },
        { t: "明天我可以去跑步吗？", py: "Míngtiān wǒ kěyǐ qù pǎobù ma?", fr: "Je peux aller courir demain ?", ok: 1, why: "La phrase est correcte, mais il vient de vous dire de vous reposer…" },
      ] },
      { npc: "饭后吃。三天以后还不舒服的话，再来看看。", py: "Fàn hòu chī. Sān tiān yǐhòu hái bù shūfu de huà, zài lái kànkan.", fr: "Après les repas. Si ça ne va toujours pas dans trois jours, revenez." },
    ],
  },
  {
    id: "zh-d-jiudian", after: "b2-lvxing", level: "B2", emoji: "🏨", title: "酒店投诉", titlePy: "jiǔdiàn tóusù",
    intro: "À votre hôtel de Xi'an, la chambre réservée n'est pas celle qu'on vous donne. Vous expliquez le problème à la réception, poliment mais fermement.",
    npc: "服务员",
    turns: [
      { npc: "您好，请问有什么可以帮您的？", py: "Nín hǎo, qǐngwèn yǒu shénme kěyǐ bāng nín de?", fr: "Bonjour, en quoi puis-je vous aider ?" },
      { choices: [
        { t: "你好，我在网上订的是大床房，可是你们给我的是双床房。", py: "Nǐ hǎo, wǒ zài wǎngshàng dìng de shì dàchuángfáng, kěshì nǐmen gěi wǒ de shì shuāngchuángfáng.", fr: "Bonjour, j'ai réservé en ligne une chambre avec un grand lit, mais vous m'avez donné une chambre à deux lits.", ok: 2, why: "Le problème est exposé clairement avec la structure 我订的是… 可是…" },
        { t: "房间不对。", py: "Fángjiān bú duì.", fr: "La chambre ne va pas.", ok: 1, why: "Compréhensible, mais trop vague : précisez ce que vous aviez réservé." },
        { t: "我订了大床房的是。", py: "Wǒ dìng le dàchuángfáng de shì.", fr: "(phrase incorrecte)", ok: 0, why: "Ordre incorrect : 我订的是大床房." },
      ] },
      { npc: "真不好意思。今天大床房已经满了，恐怕换不了。", py: "Zhēn bù hǎoyìsi. Jīntiān dàchuángfáng yǐjīng mǎn le, kǒngpà huàn bu liǎo.", fr: "Vraiment désolé. Aujourd'hui, les chambres à grand lit sont complètes, j'ai peur qu'on ne puisse pas changer." },
      { choices: [
        { t: "既然今天换不了，那明天能不能帮我换一下？", py: "Jìrán jīntiān huàn bu liǎo, nà míngtiān néng bu néng bāng wǒ huàn yíxià?", fr: "Puisqu'on ne peut pas changer aujourd'hui, est-ce que vous pourriez me changer demain ?", ok: 2, why: "既然…那… : vous acceptez la contrainte et proposez une solution. Très naturel." },
        { t: "无论怎么样，我都要现在换！", py: "Wúlùn zěnmeyàng, wǒ dōu yào xiànzài huàn!", fr: "Quoi qu'il arrive, je veux changer maintenant !", ok: 1, why: "Grammaticalement juste, mais exiger l'impossible ne mène à rien." },
        { t: "即使满了，所以我换。", py: "Jíshǐ mǎn le, suǒyǐ wǒ huàn.", fr: "(connecteurs mal associés)", ok: 0, why: "即使 s'emploie avec 也 (même si… quand même), jamais avec 所以." },
      ] },
      { npc: "可以，明天中午以后给您换。另外，今天的早餐我们免费送给您。", py: "Kěyǐ, míngtiān zhōngwǔ yǐhòu gěi nín huàn. Lìngwài, jīntiān de zǎocān wǒmen miǎnfèi sòng gěi nín.", fr: "D'accord, nous vous changerons demain après midi. Par ailleurs, nous vous offrons le petit-déjeuner d'aujourd'hui." },
      { choices: [
        { t: "那太好了，谢谢你们这么快就解决了问题。", py: "Nà tài hǎo le, xièxie nǐmen zhème kuài jiù jiějué le wèntí.", fr: "C'est parfait, merci d'avoir réglé le problème aussi vite.", ok: 2, why: "Remerciement précis avec 这么快就… : poli et chaleureux." },
        { t: "早餐我不吃。", py: "Zǎocān wǒ bù chī.", fr: "Le petit-déjeuner, je ne le mange pas.", ok: 1, why: "Correct, mais un peu sec face à un geste commercial." },
        { t: "谢谢你们解决得问题。", py: "Xièxie nǐmen jiějué de wèntí.", fr: "(phrase incorrecte)", ok: 0, why: "得 introduit un complément de degré ; ici il faut 解决了问题." },
      ] },
      { npc: "不客气。祝您在西安玩儿得开心！", py: "Bú kèqi. Zhù nín zài Xī'ān wánr de kāixīn!", fr: "Je vous en prie. Passez un bon séjour à Xi'an !" },
    ],
  },
  {
    id: "zh-d-zufang", after: "b2-shehui", level: "B2", emoji: "🔑", title: "租房子", titlePy: "zū fángzi",
    intro: "Vous cherchez un appartement à Shanghai. Vous visitez un logement avec un agent immobilier et posez les bonnes questions.",
    npc: "中介",
    turns: [
      { npc: "这套房子离地铁站只有五分钟，周围很方便。您觉得怎么样？", py: "Zhè tào fángzi lí dìtiězhàn zhǐyǒu wǔ fēnzhōng, zhōuwéi hěn fāngbiàn. Nín juéde zěnmeyàng?", fr: "Cet appartement n'est qu'à cinq minutes du métro, le quartier est très pratique. Qu'en pensez-vous ?" },
      { choices: [
        { t: "位置不错，不过房间稍微小了一点儿。房租是多少？", py: "Wèizhì búcuò, búguò fángjiān shāowēi xiǎo le yìdiǎnr. Fángzū shì duōshao?", fr: "L'emplacement est bien, mais les pièces sont un peu petites. Quel est le loyer ?", ok: 2, why: "Avis nuancé avec 稍微…一点儿, puis la question essentielle." },
        { t: "很好很好，我要了！", py: "Hěn hǎo hěn hǎo, wǒ yào le!", fr: "Très bien, je le prends !", ok: 1, why: "Correct, mais vous ne connaissez même pas le prix…" },
        { t: "房间稍微很小。", py: "Fángjiān shāowēi hěn xiǎo.", fr: "(phrase incorrecte)", ok: 0, why: "稍微 ne s'emploie pas avec 很 : 稍微小一点儿." },
      ] },
      { npc: "每个月四千五，押一付三。", py: "Měi ge yuè sìqiān wǔ, yā yī fù sān.", fr: "4 500 yuans par mois, un mois de caution et trois mois payés d'avance." },
      { choices: [
        { t: "价格有点儿贵。如果我签一年的合同，能不能便宜一点儿？", py: "Jiàgé yǒudiǎnr guì. Rúguǒ wǒ qiān yì nián de hétong, néng bu néng piányi yìdiǎnr?", fr: "C'est un peu cher. Si je signe un contrat d'un an, pourriez-vous baisser un peu ?", ok: 2, why: "有点儿 pour une critique polie, 如果… pour proposer une contrepartie : vraie négociation." },
        { t: "太贵了，算了。", py: "Tài guì le, suàn le.", fr: "Trop cher, laissez tomber.", ok: 1, why: "Possible, mais vous perdez l'occasion de négocier." },
        { t: "价格贵有点儿。", py: "Jiàgé guì yǒudiǎnr.", fr: "(phrase incorrecte)", ok: 0, why: "有点儿 se place AVANT l'adjectif : 有点儿贵." },
      ] },
      { npc: "我可以问问房东。签一年的话，估计能便宜两百块。", py: "Wǒ kěyǐ wènwen fángdōng. Qiān yì nián de huà, gūjì néng piányi liǎngbǎi kuài.", fr: "Je peux demander au propriétaire. Pour un an, il pourra sans doute baisser de deux cents yuans." },
      { choices: [
        { t: "好的。另外，水电费是不是包括在房租里？", py: "Hǎo de. Lìngwài, shuǐdiànfèi shì bu shì bāokuò zài fángzū li?", fr: "D'accord. Par ailleurs, l'eau et l'électricité sont-elles comprises dans le loyer ?", ok: 2, why: "另外 pour ajouter une question pertinente : on pense à tout." },
        { t: "那我明天就搬进来。", py: "Nà wǒ míngtiān jiù bān jìnlai.", fr: "Alors j'emménage dès demain.", ok: 1, why: "Correct, mais le propriétaire n'a pas encore accepté !" },
        { t: "另外水电费包括吗房租？", py: "Lìngwài shuǐdiànfèi bāokuò ma fángzū?", fr: "(phrase incorrecte)", ok: 0, why: "吗 se met en fin de phrase : 水电费包括在房租里吗？" },
      ] },
      { npc: "水电费不包括，按用的算。我今天晚上给您回电话。", py: "Shuǐdiànfèi bù bāokuò, àn yòng de suàn. Wǒ jīntiān wǎnshang gěi nín huí diànhuà.", fr: "L'eau et l'électricité ne sont pas comprises, on paie selon la consommation. Je vous rappelle ce soir." },
    ],
  },
];
