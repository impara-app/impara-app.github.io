/* =====================================================================
   Italien — compléments du palier A1 (CECRL)
   ---------------------------------------------------------------------
   Contenu calé sur le niveau A1 réel : se présenter, famille, pluriel et
   accord, présent régulier et irrégulier, nombres, heure et dates,
   nourriture, ville, routine, goûts, questions et directions.
   Ces leçons s'ajoutent APRÈS les 5 leçons d'origine (identifiants
   inchangés : la progression déjà faite est conservée).
   ===================================================================== */

const mcq = (q, options, answer, explain = "") => ({ type: "mcq", q, options, answer, explain });
const fill = (q, answer, explain = "") => ({ type: "fill", q, answer, explain });
const match = (q, pairs, explain = "") => ({ type: "match", q, pairs, explain });
const tr = (q, answer, explain = "") => ({ type: "translate", q, answer, explain });

export const A1_PLUS = [
  /* ------------------------------------------------------------ 6 */
  {
    id: "a1-presentarsi", module: "expr", title: "Se présenter : nom, origine, ville", emoji: "🙋",
    intro: "Dire qui on est, d'où l'on vient et où l'on habite : les toutes premières phrases d'une conversation.",
    sections: [
      {
        title: "Mi chiamo… / Sono di… / Abito a…",
        text: "<b>Mi chiamo</b> = je m'appelle (littéralement « je me nomme »). <b>Sono di</b> + ville = je suis de… <b>Abito a</b> + ville, <b>in</b> + pays = j'habite à / en.",
        examples: [["Mi chiamo Luca.", "Je m'appelle Luca."], ["Come ti chiami?", "Comment tu t'appelles ?"], ["Sono di Milano.", "Je suis de Milan."], ["Abito a Parigi, in Francia.", "J'habite à Paris, en France."]],
      },
      {
        title: "Nationalités : -o/-a ou -e",
        text: "Les adjectifs en <b>-o</b> ont un féminin en <b>-a</b> (italiano → italiana). Ceux en <b>-e</b> sont identiques au masculin et au féminin (francese, inglese). Pas de majuscule en italien !",
        table: { cols: ["Masculin", "Féminin", "Sens"], rows: [["italiano", "italiana", "italien(ne)"], ["spagnolo", "spagnola", "espagnol(e)"], ["tedesco", "tedesca", "allemand(e)"], ["francese", "francese", "français(e)"], ["inglese", "inglese", "anglais(e)"], ["cinese", "cinese", "chinois(e)"]] },
      },
      {
        title: "Tu ou Lei ?",
        text: "<b>tu</b> avec les amis, la famille, les jeunes. <b>Lei</b> (3e personne, souvent avec majuscule) pour vouvoyer : <i>Come si chiama?</i> = Comment vous appelez-vous ?",
        examples: [["Di dove sei?", "D'où es-tu ?"], ["Di dov'è Lei?", "D'où êtes-vous ?"], ["Piacere, sono Anna.", "Enchantée, je suis Anna."]],
      },
    ],
    mnemo: "Les nationalités en -ese ne changent pas : franc-ESE, ingl-ESE, cin-ESE… « ese » comme « c'est aisé » !",
    vocab: [["mi chiamo", "je m'appelle"], ["come ti chiami?", "comment t'appelles-tu ?"], ["di dove sei?", "d'où es-tu ?"], ["abitare", "habiter"], ["la città", "la ville"], ["il paese", "le pays"], ["l'Italia", "l'Italie"], ["la Francia", "la France"], ["italiano", "italien"], ["francese", "français"], ["inglese", "anglais"], ["spagnolo", "espagnol"], ["tedesco", "allemand"], ["la lingua", "la langue"], ["parlare", "parler"]],
    quiz: [
      mcq("« Comment tu t'appelles ? » se dit :", ["Come stai?", "Come ti chiami?", "Chi sei?", "Dove abiti?"], 1, "Chiamarsi = s'appeler : come ti chiami?"),
      fill("Mi ___ Giulia. (je m'appelle)", ["chiamo"], "Mi chiamo + prénom."),
      mcq("Féminin de « italiano » :", ["italiane", "italiana", "italiano", "italiani"], 1, "-o → -a au féminin."),
      mcq("Marie est française. En italien :", ["Marie è francesa.", "Marie è francese.", "Marie è Francese.", "Marie sono francese."], 1, "francese est invariable en genre et s'écrit sans majuscule."),
      fill("Abito ___ Roma. (à)", ["a"], "a + ville, in + pays."),
      fill("Abito ___ Francia. (en)", ["in"], "in + pays."),
      match("Associez", [["tedesco", "allemand"], ["spagnolo", "espagnol"], ["inglese", "anglais"], ["la lingua", "la langue"]]),
      tr("Traduisez : Je suis de Lyon.", ["sono di lione", "io sono di lione", "sono di lyon", "io sono di lyon"], "Sono di + ville (Lione en italien)."),
    ],
  },

  /* ------------------------------------------------------------ 7 */
  {
    id: "a1-famiglia", module: "vocab", title: "La famille et les possessifs", emoji: "👨‍👩‍👧",
    intro: "Présenter sa famille et dire « mon, ton, son » : en italien, le possessif s'accompagne en général de l'article.",
    sections: [
      {
        title: "Les membres de la famille",
        examples: [["il padre / la madre", "le père / la mère"], ["il fratello / la sorella", "le frère / la sœur"], ["il figlio / la figlia", "le fils / la fille"], ["il marito / la moglie", "le mari / la femme"], ["il nonno / la nonna", "le grand-père / la grand-mère"], ["i genitori", "les parents"]],
      },
      {
        title: "Possessifs : article + possessif",
        text: "On dit <b>il mio libro</b> (le mon livre). Le possessif s'accorde avec l'objet possédé, pas avec le possesseur. <b>Exception</b> : pas d'article avec un membre de la famille au singulier : <b>mia madre</b>, <b>tuo fratello</b>.",
        table: { cols: ["", "Masc.", "Fém.", "Masc. pl.", "Fém. pl."], rows: [["mon", "il mio", "la mia", "i miei", "le mie"], ["ton", "il tuo", "la tua", "i tuoi", "le tue"], ["son", "il suo", "la sua", "i suoi", "le sue"]] },
      },
      {
        title: "Exemples",
        examples: [["Mia sorella si chiama Sara.", "Ma sœur s'appelle Sara."], ["I miei genitori abitano a Napoli.", "Mes parents habitent à Naples."], ["Hai fratelli?", "As-tu des frères et sœurs ?"], ["Ho un fratello e due sorelle.", "J'ai un frère et deux sœurs."]],
      },
    ],
    mnemo: "Famille au singulier = pas d'article : mia madre, mio padre. Mais au pluriel il revient : i miei fratelli.",
    vocab: [["la famiglia", "la famille"], ["il padre", "le père"], ["la madre", "la mère"], ["i genitori", "les parents"], ["il fratello", "le frère"], ["la sorella", "la sœur"], ["il figlio", "le fils"], ["la figlia", "la fille"], ["il marito", "le mari"], ["la moglie", "l'épouse"], ["il nonno", "le grand-père"], ["la nonna", "la grand-mère"], ["lo zio", "l'oncle"], ["la zia", "la tante"], ["il cugino", "le cousin"], ["il bambino", "l'enfant (garçon)"]],
    quiz: [
      mcq("« Ma mère » se dit :", ["la mia madre", "mia madre", "il mio madre", "mio madre"], 1, "Membre de la famille au singulier : pas d'article."),
      mcq("« Mes parents » se dit :", ["miei genitori", "i miei genitori", "le mie genitori", "il mio genitori"], 1, "Au pluriel, l'article revient : i miei genitori."),
      fill("___ fratello si chiama Marco. (ton)", ["tuo"], "Tuo fratello, sans article."),
      fill("Ho due ___. (sœurs)", ["sorelle"], "sorella → sorelle au pluriel."),
      match("Associez", [["la moglie", "l'épouse"], ["il nonno", "le grand-père"], ["lo zio", "l'oncle"], ["la figlia", "la fille"]]),
      mcq("« Il suo libro » peut signifier :", ["son livre ou son livre à elle", "leur livre uniquement", "ton livre", "mes livres"], 0, "suo s'accorde avec l'objet (libro, masculin), pas avec le possesseur."),
      tr("Traduisez : J'ai un frère.", ["ho un fratello", "io ho un fratello"], "Ho un fratello."),
      fill("La ___ di Luca è grande. (famille)", ["famiglia"], "la famiglia."),
    ],
  },

  /* ------------------------------------------------------------ 8 */
  {
    id: "a1-plurale", module: "gram", title: "Pluriel, accords et couleurs", emoji: "🎨",
    intro: "Au pluriel, ce n'est pas un -s qu'on ajoute : c'est la dernière voyelle qui change.",
    sections: [
      {
        title: "Les terminaisons du pluriel",
        table: { cols: ["Singulier", "Pluriel", "Exemple"], rows: [["-o (masc.)", "-i", "il libro → i libri"], ["-a (fém.)", "-e", "la casa → le case"], ["-e (m. ou f.)", "-i", "il fiore → i fiori · la chiave → le chiavi"], ["mot accentué / étranger", "invariable", "la città → le città · il bar → i bar"]] },
      },
      {
        title: "Articles pluriels",
        text: "<b>il → i</b>, <b>lo / l' (masc.) → gli</b>, <b>la / l' (fém.) → le</b>.",
        examples: [["i ragazzi", "les garçons"], ["gli amici", "les amis"], ["gli studenti", "les étudiants"], ["le ragazze", "les filles"]],
      },
      {
        title: "L'adjectif s'accorde (et se place souvent après)",
        text: "Les couleurs en -o s'accordent (rosso, rossa, rossi, rosse). Celles en -e ont deux formes (verde, verdi). <b>blu, rosa, viola</b> sont invariables.",
        examples: [["una macchina rossa", "une voiture rouge"], ["due case bianche", "deux maisons blanches"], ["gli occhi verdi", "les yeux verts"], ["le scarpe blu", "les chaussures bleues"]],
      },
    ],
    mnemo: "Pluriel italien = changement de voyelle : -o→-i, -a→-e, -e→-i. Les mots qui finissent par une voyelle accentuée (città, caffè) ne bougent pas.",
    vocab: [["il libro", "le livre"], ["la casa", "la maison"], ["il ragazzo", "le garçon"], ["la ragazza", "la fille"], ["l'amico", "l'ami"], ["grande", "grand"], ["piccolo", "petit"], ["bello", "beau"], ["nuovo", "nouveau"], ["vecchio", "vieux"], ["rosso", "rouge"], ["bianco", "blanc"], ["nero", "noir"], ["verde", "vert"], ["giallo", "jaune"], ["blu", "bleu"]],
    quiz: [
      fill("il libro → i ___", ["libri"], "-o → -i."),
      fill("la casa → le ___", ["case"], "-a → -e."),
      mcq("Pluriel de « la città » :", ["le citte", "le città", "le cittadi", "i città"], 1, "Mot accentué en finale : invariable."),
      mcq("Article de « amici » :", ["i", "gli", "le", "lo"], 1, "Masculin pluriel devant voyelle : gli amici."),
      mcq("« Les fleurs rouges » :", ["i fiori rossi", "le fiori rosse", "i fiori rosso", "gli fiori rossi"], 0, "fiore est masculin : i fiori rossi."),
      fill("Ho due macchine ___. (blanches)", ["bianche"], "bianca → bianche (le h garde le son « k »)."),
      match("Associez", [["giallo", "jaune"], ["nero", "noir"], ["verde", "vert"], ["vecchio", "vieux"]]),
      tr("Traduisez : une petite maison", ["una piccola casa", "una casa piccola"], "piccola casa ou casa piccola : les deux existent."),
    ],
  },

  /* ------------------------------------------------------------ 9 */
  {
    id: "a1-presente-are", module: "conj", title: "Le présent des verbes en -are", emoji: "🗣️",
    intro: "La grande majorité des verbes italiens se terminent en -are. Une seule conjugaison à retenir pour des centaines de verbes.",
    sections: [
      {
        title: "Parlare (parler)",
        table: { cols: ["Pronom", "Terminaison", "Parlare"], rows: [["io", "-o", "parlo"], ["tu", "-i", "parli"], ["lui / lei", "-a", "parla"], ["noi", "-iamo", "parliamo"], ["voi", "-ate", "parlate"], ["loro", "-ano", "parlano"]] },
      },
      {
        title: "Attention à l'orthographe",
        text: "Verbes en <b>-care / -gare</b> : on ajoute un h devant i pour garder le son dur (cerco → <b>cerchi</b>, paghi). Verbes en <b>-iare</b> : un seul i (mangio → <b>mangi</b>, studi). L'accent de <i>parlano</i> tombe sur <b>par</b>.",
        examples: [["Cerchi le chiavi?", "Tu cherches les clés ?"], ["Mangiamo alle otto.", "Nous mangeons à huit heures."], ["Studi l'italiano?", "Tu étudies l'italien ?"]],
      },
      {
        title: "La négation : non + verbe",
        examples: [["Non parlo tedesco.", "Je ne parle pas allemand."], ["Lavorano a Torino.", "Ils travaillent à Turin."], ["Ascoltate la musica?", "Vous écoutez de la musique ?"]],
      },
    ],
    mnemo: "-o, -i, -a, -iamo, -ate, -ano : « O, I, A… IAMO, ATE, ANO ». Et la négation, c'est juste « non » devant le verbe.",
    vocab: [["parlare", "parler"], ["lavorare", "travailler"], ["studiare", "étudier"], ["mangiare", "manger"], ["cercare", "chercher"], ["pagare", "payer"], ["ascoltare", "écouter"], ["guardare", "regarder"], ["comprare", "acheter"], ["aspettare", "attendre"], ["arrivare", "arriver"], ["cucinare", "cuisiner"], ["giocare", "jouer"], ["imparare", "apprendre"]],
    quiz: [
      fill("Io ___ italiano. (parlare)", ["parlo"], "io → -o."),
      fill("Noi ___ a Milano. (lavorare)", ["lavoriamo"], "noi → -iamo."),
      mcq("Tu (mangiare) :", ["mangii", "mangi", "mangia", "mangiate"], 1, "Un seul i : mangi."),
      mcq("Tu (cercare) :", ["cerci", "cerchi", "cerca", "cercate"], 1, "On ajoute un h : cerchi."),
      fill("Loro ___ la TV. (guardare)", ["guardano"], "loro → -ano."),
      mcq("« Je ne travaille pas » :", ["Non lavoro.", "Lavoro non.", "No lavoro.", "Non lavora."], 0, "non devant le verbe."),
      match("Associez", [["comprare", "acheter"], ["aspettare", "attendre"], ["imparare", "apprendre"], ["pagare", "payer"]]),
      tr("Traduisez : Vous étudiez l'italien ? (voi)", ["studiate l'italiano", "voi studiate l'italiano", "studiate italiano"], "Studiate l'italiano?"),
    ],
  },

  /* ------------------------------------------------------------ 10 */
  {
    id: "a1-presente-ere-ire", module: "conj", title: "Le présent des verbes en -ere et -ire", emoji: "📖",
    intro: "Deuxième et troisième groupes : presque les mêmes terminaisons que -are, avec une particularité pour certains verbes en -ire.",
    sections: [
      {
        title: "Leggere (lire) et dormire (dormir)",
        table: { cols: ["Pronom", "Leggere", "Dormire"], rows: [["io", "leggo", "dormo"], ["tu", "leggi", "dormi"], ["lui / lei", "legge", "dorme"], ["noi", "leggiamo", "dormiamo"], ["voi", "leggete", "dormite"], ["loro", "leggono", "dormono"]] },
      },
      {
        title: "Les verbes en -isc- (capire, finire, preferire)",
        text: "Beaucoup de verbes en -ire ajoutent <b>-isc-</b> à io, tu, lui et loro : <b>capisco, capisci, capisce</b>, capiamo, capite, <b>capiscono</b>.",
        examples: [["Non capisco.", "Je ne comprends pas."], ["Finisci alle sei?", "Tu finis à six heures ?"], ["Preferisco il tè.", "Je préfère le thé."]],
      },
      {
        title: "Autres verbes fréquents",
        examples: [["Scrivo una lettera.", "J'écris une lettre."], ["Prendi un caffè?", "Tu prends un café ?"], ["Vedo il mare.", "Je vois la mer."], ["Partiamo domani.", "Nous partons demain."]],
      },
    ],
    mnemo: "-ere et -ire, c'est -are avec un e : parla → legge, parlate → leggete. Et « capISCo » : pense à « je comprends ISC… presque ».",
    vocab: [["leggere", "lire"], ["scrivere", "écrire"], ["prendere", "prendre"], ["vedere", "voir"], ["vivere", "vivre"], ["mettere", "mettre"], ["dormire", "dormir"], ["partire", "partir"], ["aprire", "ouvrir"], ["sentire", "entendre, sentir"], ["capire", "comprendre"], ["finire", "finir"], ["preferire", "préférer"], ["la lettera", "la lettre"]],
    quiz: [
      fill("Io ___ un libro. (leggere)", ["leggo"], "leggo."),
      fill("Lei ___ molto. (dormire)", ["dorme"], "lui/lei → -e."),
      mcq("« Je ne comprends pas » :", ["Non capo.", "Non capisco.", "Non capiscio.", "Non capiamo."], 1, "capire → capisco."),
      mcq("Loro (finire) :", ["finono", "finiscono", "finiscano", "finisceno"], 1, "-isc- à loro : finiscono."),
      fill("Voi ___ un caffè? (prendere)", ["prendete"], "voi → -ete."),
      mcq("Noi (partire) :", ["partiamo", "partimo", "partiscono", "partite"], 0, "noi → -iamo pour tous les groupes."),
      match("Associez", [["aprire", "ouvrir"], ["vedere", "voir"], ["mettere", "mettre"], ["scrivere", "écrire"]]),
      tr("Traduisez : Je préfère le thé.", ["preferisco il tè", "io preferisco il tè", "preferisco il te"], "Preferisco il tè."),
    ],
  },

  /* ------------------------------------------------------------ 11 */
  {
    id: "a1-numeri-grandi", module: "nombres", title: "Les nombres jusqu'à 1000 et les prix", emoji: "💶",
    intro: "Compter au-delà de 20, donner un âge, un prix ou un numéro de téléphone.",
    sections: [
      {
        title: "Les dizaines",
        table: { cols: ["", "", "", ""], rows: [["20 venti", "30 trenta", "40 quaranta", "50 cinquanta"], ["60 sessanta", "70 settanta", "80 ottanta", "90 novanta"], ["100 cento", "200 duecento", "500 cinquecento", "1000 mille"]] },
      },
      {
        title: "Former les nombres",
        text: "Les dizaines perdent leur voyelle finale devant <b>uno</b> et <b>otto</b> : <b>ventuno</b>, <b>ventotto</b>, trentuno. Avec <b>tre</b>, accent : <b>ventitré</b>. On écrit tout attaché : centoventi. Pluriel de mille : <b>duemila</b>.",
        examples: [["ventuno", "21"], ["trentotto", "38"], ["quarantatré", "43"], ["centocinquanta", "150"], ["duemila", "2000"]],
      },
      {
        title: "Prix et âge",
        examples: [["Quanto costa?", "Combien ça coûte ?"], ["Costa dodici euro.", "Ça coûte douze euros."], ["Quanto costano le mele?", "Combien coûtent les pommes ?"], ["Mio nonno ha ottantadue anni.", "Mon grand-père a quatre-vingt-deux ans."]],
      },
    ],
    mnemo: "Pas de « soixante-dix » ni « quatre-vingts » : settanta (7×10), ottanta (8×10), novanta (9×10). Plus simple que le français !",
    vocab: [["trenta", "trente"], ["quaranta", "quarante"], ["cinquanta", "cinquante"], ["sessanta", "soixante"], ["settanta", "soixante-dix"], ["ottanta", "quatre-vingts"], ["novanta", "quatre-vingt-dix"], ["cento", "cent"], ["mille", "mille"], ["duemila", "deux mille"], ["quanto costa?", "combien ça coûte ?"], ["l'euro", "l'euro"], ["il prezzo", "le prix"], ["caro", "cher"], ["economico", "bon marché"]],
    quiz: [
      mcq("70 se dit :", ["settanta", "sessanta", "settenta", "sedicidieci"], 0, "settanta."),
      mcq("21 se dit :", ["ventiuno", "ventuno", "venti e uno", "vintuno"], 1, "La dizaine perd son i devant uno."),
      fill("38 = trent___", ["otto"], "trentotto."),
      mcq("2000 se dit :", ["duemille", "duemila", "due mille", "duomila"], 1, "Pluriel de mille : mila."),
      fill("Quanto ___ le mele? (coûtent)", ["costano"], "costare → costano au pluriel."),
      match("Associez", [["cinquanta", "50"], ["novanta", "90"], ["quaranta", "40"], ["cento", "100"]]),
      mcq("« C'est cher » :", ["È caro.", "È economico.", "È carino.", "Costa poco."], 0, "caro = cher."),
      tr("Écrivez en lettres : 43", ["quarantatré", "quarantatre"], "quarantatré (accent sur le é)."),
    ],
  },

  /* ------------------------------------------------------------ 12 */
  {
    id: "a1-tempo", module: "nombres", title: "L'heure, les jours et les mois", emoji: "🕒",
    intro: "Demander l'heure, parler de la semaine et des dates : indispensable pour les rendez-vous.",
    sections: [
      {
        title: "Che ore sono?",
        text: "On dit <b>sono le</b> + heure (pluriel) mais <b>è l'una</b> (une heure), <b>è mezzogiorno</b>, <b>è mezzanotte</b>. <b>e un quarto</b> = et quart, <b>e mezza</b> = et demie, <b>meno un quarto</b> = moins le quart.",
        examples: [["Sono le tre.", "Il est trois heures."], ["È l'una e mezza.", "Il est une heure et demie."], ["Sono le otto meno un quarto.", "Il est huit heures moins le quart."], ["A che ora?", "À quelle heure ?"], ["Alle nove.", "À neuf heures."]],
      },
      {
        title: "Les jours de la semaine (sans majuscule)",
        table: { cols: ["", "", "", ""], rows: [["lunedì", "martedì", "mercoledì", "giovedì"], ["venerdì", "sabato", "domenica", ""]] },
        text: "<b>il lunedì</b> (avec article) = le lundi, tous les lundis.",
      },
      {
        title: "Les mois et la date",
        text: "gennaio, febbraio, marzo, aprile, maggio, giugno, luglio, agosto, settembre, ottobre, novembre, dicembre. La date : <b>il 5 maggio</b>, mais <b>il primo</b> pour le 1er.",
        examples: [["Oggi è martedì.", "Aujourd'hui, c'est mardi."], ["Il mio compleanno è il 3 luglio.", "Mon anniversaire est le 3 juillet."], ["Domani è il primo marzo.", "Demain, c'est le 1er mars."]],
      },
    ],
    mnemo: "Les jours finissent presque tous en -dì (« jour » ancien) : lunedì = jour de la Lune, martedì = de Mars… sauf sabato et domenica.",
    vocab: [["l'ora", "l'heure"], ["che ore sono?", "quelle heure est-il ?"], ["mezzogiorno", "midi"], ["mezzanotte", "minuit"], ["il quarto", "le quart"], ["mezza", "et demie"], ["oggi", "aujourd'hui"], ["domani", "demain"], ["ieri", "hier"], ["lunedì", "lundi"], ["martedì", "mardi"], ["mercoledì", "mercredi"], ["giovedì", "jeudi"], ["venerdì", "vendredi"], ["sabato", "samedi"], ["domenica", "dimanche"], ["la settimana", "la semaine"], ["il mese", "le mois"], ["gennaio", "janvier"], ["luglio", "juillet"], ["il compleanno", "l'anniversaire"], ["febbraio", "février"], ["marzo", "mars"], ["aprile", "avril"], ["maggio", "mai"], ["giugno", "juin"], ["agosto", "août"], ["settembre", "septembre"], ["ottobre", "octobre"], ["novembre", "novembre"], ["dicembre", "décembre"]],
    quiz: [
      mcq("« Il est une heure » :", ["Sono l'una.", "È l'una.", "È la una.", "Sono le una."], 1, "Exception : è l'una."),
      fill("___ le quattro. (il est)", ["sono"], "Sono le + heure à partir de 2 h."),
      mcq("« Et demie » :", ["e mezza", "e quarto", "meno mezza", "e metà"], 0, "e mezza."),
      mcq("Le jour après venerdì :", ["giovedì", "domenica", "sabato", "lunedì"], 2, "venerdì → sabato."),
      fill("Oggi è lunedì, domani è ___.", ["martedì", "martedi"], "lunedì → martedì."),
      match("Associez", [["ieri", "hier"], ["oggi", "aujourd'hui"], ["domani", "demain"], ["la settimana", "la semaine"]]),
      mcq("« Le 1er mai » :", ["il uno maggio", "il primo maggio", "l'uno maggio", "il prima maggio"], 1, "il primo pour le premier du mois."),
      tr("Traduisez : À huit heures.", ["alle otto"], "alle (a + le) otto."),
    ],
  },

  /* ------------------------------------------------------------ 13 */
  {
    id: "a1-cibo", module: "expr", title: "Au bar et au restaurant", emoji: "🍝",
    intro: "Commander poliment, demander l'addition et parler de ce qu'on mange : l'Italie se découvre aussi à table.",
    sections: [
      {
        title: "Commander : vorrei…",
        text: "<b>Vorrei</b> (je voudrais) est la formule polie pour commander. <b>Per me…</b> = pour moi… À la fin : <b>il conto, per favore</b>.",
        examples: [["Vorrei un caffè, per favore.", "Je voudrais un café, s'il vous plaît."], ["Per me una pizza margherita.", "Pour moi une pizza margherita."], ["Il conto, per favore.", "L'addition, s'il vous plaît."], ["Un tavolo per due?", "Une table pour deux ?"]],
      },
      {
        title: "Du, de la, des : il partitivo",
        text: "Pour une quantité indéfinie, on utilise <b>di + article</b> : <b>del pane</b> (du pain), <b>della carne</b>, <b>dell'acqua</b>, <b>dei pomodori</b>. Dans les questions, on l'omet souvent : <i>Vuoi acqua?</i>",
        examples: [["Compro del pane.", "J'achète du pain."], ["Vorrei dell'acqua naturale.", "Je voudrais de l'eau plate."], ["Mangio dei biscotti.", "Je mange des biscuits."]],
      },
      {
        title: "Le repas à l'italienne",
        text: "<b>colazione</b> (petit-déjeuner), <b>pranzo</b> (déjeuner), <b>cena</b> (dîner). Au restaurant : <b>antipasto</b>, <b>primo</b> (pâtes, risotto), <b>secondo</b> (viande, poisson), <b>contorno</b>, <b>dolce</b>.",
      },
    ],
    mnemo: "Vorrei = « je voudrais » : avec ce seul mot + per favore, vous commandez n'importe quoi en Italie.",
    vocab: [["vorrei", "je voudrais"], ["il conto", "l'addition"], ["il caffè", "le café"], ["l'acqua", "l'eau"], ["il vino", "le vin"], ["la birra", "la bière"], ["il pane", "le pain"], ["la pasta", "les pâtes"], ["la carne", "la viande"], ["il pesce", "le poisson"], ["la verdura", "les légumes"], ["la frutta", "les fruits"], ["la mela", "la pomme"], ["il formaggio", "le fromage"], ["il latte", "le lait"], ["la colazione", "le petit-déjeuner"], ["il pranzo", "le déjeuner"], ["la cena", "le dîner"], ["buono", "bon"]],
    quiz: [
      mcq("Pour commander poliment :", ["Voglio un caffè!", "Vorrei un caffè, per favore.", "Dammi un caffè.", "Ho un caffè."], 1, "Vorrei = je voudrais."),
      fill("Il ___, per favore. (l'addition)", ["conto"], "il conto."),
      mcq("« Du pain » :", ["di pane", "del pane", "dal pane", "il pane del"], 1, "di + il = del."),
      fill("Vorrei ___ acqua. (de l')", ["dell'", "dell"], "di + l' = dell'."),
      mcq("Le « primo » au restaurant, c'est :", ["le dessert", "les pâtes ou le risotto", "la viande", "l'apéritif"], 1, "primo = premier plat (pâtes, riz, soupe)."),
      match("Associez", [["il pesce", "le poisson"], ["la carne", "la viande"], ["il formaggio", "le fromage"], ["la cena", "le dîner"]]),
      mcq("« Le déjeuner » :", ["la colazione", "il pranzo", "la cena", "la merenda"], 1, "il pranzo, vers 13 h."),
      tr("Traduisez : Une bière, s'il vous plaît.", ["una birra per favore", "una birra, per favore"], "Una birra, per favore."),
    ],
  },

  /* ------------------------------------------------------------ 14 */
  {
    id: "a1-citta", module: "gram", title: "En ville : c'è, ci sono et les prépositions", emoji: "🏙️",
    intro: "Décrire un lieu, dire ce qu'il y a et où se trouvent les choses.",
    sections: [
      {
        title: "C'è / ci sono (il y a)",
        text: "<b>c'è</b> + singulier, <b>ci sono</b> + pluriel. Question : <i>C'è una farmacia qui vicino?</i>",
        examples: [["C'è un bar in piazza.", "Il y a un bar sur la place."], ["Ci sono tre musei.", "Il y a trois musées."], ["Non c'è il treno oggi.", "Il n'y a pas de train aujourd'hui."]],
      },
      {
        title: "Prépositions + article (preposizioni articolate)",
        text: "<b>a, di, da, in, su</b> se soudent à l'article : a + il = <b>al</b>, in + la = <b>nella</b>, di + il = <b>del</b>, da + il = <b>dal</b>, su + il = <b>sul</b>.",
        table: { cols: ["", "il", "la", "l'", "i", "le"], rows: [["a", "al", "alla", "all'", "ai", "alle"], ["in", "nel", "nella", "nell'", "nei", "nelle"], ["di", "del", "della", "dell'", "dei", "delle"], ["da", "dal", "dalla", "dall'", "dai", "dalle"]] },
      },
      {
        title: "Aller à / en",
        text: "<b>vado a</b> + ville, <b>vado in</b> + pays ou lieu en -eria / -teca (in banca, in farmacia, in biblioteca), <b>vado al</b> cinema, <b>al</b> mare, <b>da</b> + personne (dal medico).",
        examples: [["Vado al supermercato.", "Je vais au supermarché."], ["Lavoro in banca.", "Je travaille à la banque."], ["Vado dal dottore.", "Je vais chez le médecin."]],
      },
    ],
    mnemo: "c'è = « ça est là » au singulier, ci sono = « ils sont là » au pluriel.",
    vocab: [["c'è", "il y a (sing.)"], ["ci sono", "il y a (plur.)"], ["la piazza", "la place"], ["la strada", "la rue"], ["la stazione", "la gare"], ["il treno", "le train"], ["l'autobus", "le bus"], ["la banca", "la banque"], ["la farmacia", "la pharmacie"], ["il museo", "le musée"], ["la chiesa", "l'église"], ["il supermercato", "le supermarché"], ["l'ospedale", "l'hôpital"], ["l'albergo", "l'hôtel"], ["vicino", "près"], ["lontano", "loin"]],
    quiz: [
      mcq("« Il y a deux églises » :", ["C'è due chiese.", "Ci sono due chiese.", "Ci è due chiese.", "Sono due chiese."], 1, "Pluriel : ci sono."),
      fill("___ una farmacia qui vicino? (il y a)", ["c'è", "ce", "c'e"], "Singulier : c'è."),
      fill("Vado ___ cinema. (au)", ["al"], "a + il = al."),
      fill("Il libro è ___ borsa. (dans la)", ["nella"], "in + la = nella."),
      mcq("« Je vais chez le médecin » :", ["Vado al medico.", "Vado dal medico.", "Vado nel medico.", "Vado di medico."], 1, "da + personne : dal medico."),
      match("Associez", [["la stazione", "la gare"], ["l'albergo", "l'hôtel"], ["la strada", "la rue"], ["lontano", "loin"]]),
      mcq("di + i = ?", ["dei", "degli", "dii", "del"], 0, "di + i = dei."),
      tr("Traduisez : Il y a un musée.", ["c'è un museo", "ce un museo"], "C'è un museo."),
    ],
  },

  /* ------------------------------------------------------------ 15 */
  {
    id: "a1-irregolari", module: "conj", title: "Verbes irréguliers : andare, fare, volere…", emoji: "🚶",
    intro: "Les verbes les plus utiles sont souvent irréguliers. Voici les incontournables du niveau A1.",
    sections: [
      {
        title: "Andare, venire, fare, stare",
        table: { cols: ["", "andare", "venire", "fare", "stare"], rows: [["io", "vado", "vengo", "faccio", "sto"], ["tu", "vai", "vieni", "fai", "stai"], ["lui/lei", "va", "viene", "fa", "sta"], ["noi", "andiamo", "veniamo", "facciamo", "stiamo"], ["voi", "andate", "venite", "fate", "state"], ["loro", "vanno", "vengono", "fanno", "stanno"]] },
      },
      {
        title: "Volere, potere, dovere (+ infinitif)",
        table: { cols: ["", "volere", "potere", "dovere"], rows: [["io", "voglio", "posso", "devo"], ["tu", "vuoi", "puoi", "devi"], ["lui/lei", "vuole", "può", "deve"], ["noi", "vogliamo", "possiamo", "dobbiamo"], ["voi", "volete", "potete", "dovete"], ["loro", "vogliono", "possono", "devono"]] },
      },
      {
        title: "En contexte",
        examples: [["Come stai? — Sto bene.", "Comment vas-tu ? — Je vais bien."], ["Che cosa fai stasera?", "Que fais-tu ce soir ?"], ["Posso entrare?", "Je peux entrer ?"], ["Devo lavorare domani.", "Je dois travailler demain."], ["Vieni con noi?", "Tu viens avec nous ?"]],
      },
    ],
    mnemo: "« Stare » sert à dire comment on va (sto bene) ; « essere » dit ce qu'on est. Fare = faire, et « fa caldo » = il fait chaud.",
    vocab: [["andare", "aller"], ["venire", "venir"], ["fare", "faire"], ["stare", "être, rester (état)"], ["volere", "vouloir"], ["potere", "pouvoir"], ["dovere", "devoir"], ["uscire", "sortir"], ["dare", "donner"], ["sapere", "savoir"], ["stasera", "ce soir"], ["insieme", "ensemble"]],
    quiz: [
      fill("Io ___ a Roma domani. (andare)", ["vado"], "vado."),
      fill("Che cosa ___ tu? (fare)", ["fai"], "fai."),
      mcq("Loro (andare) :", ["andano", "vanno", "vano", "vadono"], 1, "vanno."),
      mcq("« Je peux » :", ["poto", "posso", "puoi", "può"], 1, "posso."),
      fill("Noi ___ studiare. (dovere)", ["dobbiamo"], "dobbiamo."),
      mcq("« Comment allez-vous ? (tu) — Je vais bien. »", ["Come sei? — Sono bene.", "Come stai? — Sto bene.", "Come vai? — Vado bene.", "Come fai? — Faccio bene."], 1, "stare pour l'état."),
      match("Associez", [["voglio", "je veux"], ["vengo", "je viens"], ["faccio", "je fais"], ["devo", "je dois"]]),
      tr("Traduisez : Tu viens avec nous ?", ["vieni con noi", "tu vieni con noi"], "Vieni con noi?"),
    ],
  },

  /* ------------------------------------------------------------ 16 */
  {
    id: "a1-routine", module: "conj", title: "La journée : verbes pronominaux", emoji: "⏰",
    intro: "Se lever, se laver, s'habiller : raconter sa routine avec les verbes pronominaux et les adverbes de fréquence.",
    sections: [
      {
        title: "Alzarsi (se lever)",
        text: "Le pronom réfléchi se place avant le verbe : <b>mi, ti, si, ci, vi, si</b>.",
        table: { cols: ["Pronom", "Alzarsi"], rows: [["io", "mi alzo"], ["tu", "ti alzi"], ["lui / lei", "si alza"], ["noi", "ci alziamo"], ["voi", "vi alzate"], ["loro", "si alzano"]] },
      },
      {
        title: "Ma journée",
        examples: [["Mi sveglio alle sette.", "Je me réveille à sept heures."], ["Mi lavo e mi vesto.", "Je me lave et je m'habille."], ["Faccio colazione al bar.", "Je prends le petit-déjeuner au bar."], ["La sera mi riposo.", "Le soir, je me repose."], ["Vado a letto a mezzanotte.", "Je vais au lit à minuit."]],
      },
      {
        title: "La fréquence",
        text: "<b>sempre</b> (toujours), <b>di solito</b> (d'habitude), <b>spesso</b> (souvent), <b>qualche volta</b> (parfois), <b>non… mai</b> (ne… jamais).",
        examples: [["Non bevo mai il caffè.", "Je ne bois jamais de café."], ["Di solito cucino io.", "D'habitude, c'est moi qui cuisine."]],
      },
    ],
    mnemo: "« Non… mai » encadre le verbe comme « ne… jamais » : non bevo mai.",
    vocab: [["alzarsi", "se lever"], ["svegliarsi", "se réveiller"], ["lavarsi", "se laver"], ["vestirsi", "s'habiller"], ["riposarsi", "se reposer"], ["chiamarsi", "s'appeler"], ["la mattina", "le matin"], ["il pomeriggio", "l'après-midi"], ["la sera", "le soir"], ["la notte", "la nuit"], ["sempre", "toujours"], ["spesso", "souvent"], ["di solito", "d'habitude"], ["mai", "jamais"], ["il letto", "le lit"]],
    quiz: [
      fill("Io mi ___ alle sette. (alzarsi)", ["alzo"], "mi alzo."),
      fill("Loro ___ vestono. (pronom)", ["si"], "loro → si."),
      mcq("« Nous nous réveillons » :", ["ci svegliamo", "si svegliamo", "vi svegliate", "noi svegliamo"], 0, "noi → ci."),
      mcq("« Je ne bois jamais de vin » :", ["Bevo mai vino.", "Non bevo mai vino.", "Mai non bevo vino.", "Non mai bevo vino."], 1, "non + verbe + mai."),
      match("Associez", [["la mattina", "le matin"], ["il pomeriggio", "l'après-midi"], ["la sera", "le soir"], ["la notte", "la nuit"]]),
      mcq("« Souvent » :", ["sempre", "spesso", "mai", "presto"], 1, "spesso."),
      fill("Come ti ___? (s'appeler)", ["chiami"], "ti chiami."),
      tr("Traduisez : Je me repose le soir.", ["mi riposo la sera", "la sera mi riposo", "io mi riposo la sera"], "Mi riposo la sera."),
    ],
  },

  /* ------------------------------------------------------------ 17 */
  {
    id: "a1-piacere", module: "expr", title: "Goûts et loisirs : mi piace", emoji: "❤️",
    intro: "En italien, « j'aime » se construit à l'envers : c'est la chose qui « me plaît ».",
    sections: [
      {
        title: "Mi piace / mi piacciono",
        text: "<b>mi piace</b> + singulier ou infinitif, <b>mi piacciono</b> + pluriel. Négation : <b>non mi piace</b>. Pour demander : <i>Ti piace…?</i>",
        examples: [["Mi piace la musica.", "J'aime la musique."], ["Mi piacciono i film italiani.", "J'aime les films italiens."], ["Mi piace leggere.", "J'aime lire."], ["Non mi piace il caffè.", "Je n'aime pas le café."]],
      },
      {
        title: "Anche a me / Neanche a me",
        text: "Pour réagir : <b>Anche a me!</b> (moi aussi), <b>A me no.</b> (pas moi), <b>Neanche a me.</b> (moi non plus).",
        examples: [["Mi piace il calcio. — Anche a me!", "J'aime le foot. — Moi aussi !"], ["Non mi piace il freddo. — Neanche a me.", "Je n'aime pas le froid. — Moi non plus."]],
      },
      {
        title: "Les loisirs",
        examples: [["Gioco a calcio il sabato.", "Je joue au foot le samedi."], ["Nel tempo libero faccio sport.", "Pendant mon temps libre, je fais du sport."], ["Andiamo al cinema?", "On va au cinéma ?"]],
      },
    ],
    mnemo: "Piace = « plaît ». Mi piace la pizza = la pizza me plaît. Plusieurs choses ? Elles « plaisent » : mi piacciono.",
    vocab: [["mi piace", "j'aime (sing.)"], ["mi piacciono", "j'aime (plur.)"], ["anche a me", "moi aussi"], ["neanche a me", "moi non plus"], ["il tempo libero", "le temps libre"], ["la musica", "la musique"], ["il calcio", "le football"], ["lo sport", "le sport"], ["il cinema", "le cinéma"], ["il film", "le film"], ["viaggiare", "voyager"], ["ballare", "danser"], ["cantare", "chanter"], ["nuotare", "nager"], ["la canzone", "la chanson"]],
    quiz: [
      mcq("« J'aime les chats » :", ["Mi piace i gatti.", "Mi piacciono i gatti.", "Io piaccio i gatti.", "Mi piacciano i gatti."], 1, "Pluriel : piacciono."),
      fill("Mi ___ ballare. (aime)", ["piace"], "Infinitif : piace."),
      mcq("Réponse à « Mi piace il mare » pour dire « moi aussi » :", ["Anche io.", "Anche a me!", "Neanche a me.", "A me no."], 1, "Construction avec a : anche a me."),
      mcq("« Tu aimes le sport ? » :", ["Ti piace lo sport?", "Tu piaci lo sport?", "Ti piacciono lo sport?", "Mi piace lo sport?"], 0, "Ti piace…?"),
      match("Associez", [["nuotare", "nager"], ["cantare", "chanter"], ["viaggiare", "voyager"], ["il calcio", "le football"]]),
      fill("Non mi ___ i film horror. (aime)", ["piacciono"], "Pluriel : piacciono."),
      mcq("« Moi non plus » :", ["Anche a me.", "Neanche a me.", "A me sì.", "Neanche io piace."], 1, "neanche a me."),
      tr("Traduisez : J'aime voyager.", ["mi piace viaggiare", "a me piace viaggiare"], "Mi piace viaggiare."),
    ],
  },

  /* ------------------------------------------------------------ 18 */
  {
    id: "a1-domande", module: "expr", title: "Poser des questions et demander son chemin", emoji: "🧭",
    intro: "Qui, quoi, où, quand, comment, pourquoi… et comprendre la réponse quand on cherche une rue.",
    sections: [
      {
        title: "Les mots interrogatifs",
        table: { cols: ["Italien", "Français"], rows: [["chi?", "qui ?"], ["che cosa? / cosa?", "quoi ?"], ["dove?", "où ?"], ["quando?", "quand ?"], ["come?", "comment ?"], ["perché?", "pourquoi ? / parce que"], ["quanto? / quanti?", "combien ?"], ["quale?", "quel / lequel ?"]] },
      },
      {
        title: "Demander son chemin",
        text: "Toujours poli : <b>Scusi</b> (excusez-moi, vouvoiement). Réponses : <b>a destra</b> (à droite), <b>a sinistra</b> (à gauche), <b>dritto</b> (tout droit), <b>la prima / seconda strada</b>.",
        examples: [["Scusi, dov'è la stazione?", "Excusez-moi, où est la gare ?"], ["Vada dritto e poi giri a destra.", "Allez tout droit puis tournez à droite."], ["È la seconda strada a sinistra.", "C'est la deuxième rue à gauche."], ["È lontano? — No, è a cinque minuti.", "C'est loin ? — Non, c'est à cinq minutes."]],
      },
      {
        title: "Perché… perché",
        text: "<b>Perché</b> sert à la fois pour « pourquoi » et « parce que ».",
        examples: [["Perché studi l'italiano? — Perché amo l'Italia.", "Pourquoi étudies-tu l'italien ? — Parce que j'aime l'Italie."]],
      },
    ],
    mnemo: "Dove = où (« d'où » ? non !) ; da dove = d'où. Et perché répond à perché.",
    vocab: [["chi", "qui"], ["che cosa", "quoi"], ["dove", "où"], ["quando", "quand"], ["come", "comment"], ["perché", "pourquoi, parce que"], ["quanto", "combien"], ["quale", "quel, lequel"], ["scusi", "excusez-moi"], ["a destra", "à droite"], ["a sinistra", "à gauche"], ["dritto", "tout droit"], ["girare", "tourner"], ["il minuto", "la minute"], ["la mappa", "le plan"]],
    quiz: [
      mcq("« Où est la gare ? » :", ["Dove è la stazione?", "Dov'è la stazione?", "Quando è la stazione?", "Come è la stazione?"], 1, "dove + è = dov'è."),
      match("Associez", [["chi", "qui"], ["quando", "quand"], ["come", "comment"], ["perché", "pourquoi"]]),
      mcq("« À gauche » :", ["a destra", "a sinistra", "dritto", "dietro"], 1, "a sinistra."),
      fill("Vada ___ e poi giri a destra. (tout droit)", ["dritto", "diritto"], "dritto (ou diritto)."),
      mcq("Pour aborder poliment un inconnu :", ["Ciao!", "Scusi…", "Ehi!", "Senti!"], 1, "Scusi (vouvoiement)."),
      fill("___ anni hai? (combien)", ["quanti"], "quanti + nom masculin pluriel."),
      mcq("« Parce que » se dit :", ["perché", "porque", "per che", "poiché tu"], 0, "perché = pourquoi et parce que."),
      tr("Traduisez : C'est loin ?", ["è lontano", "e lontano"], "È lontano?"),
    ],
  },
];

/** Questions ajoutées à l'examen A1 (à la suite des 8 d'origine) */
export const A1_EXAM_PLUS = [
  mcq("« Ma sœur » :", ["la mia sorella", "mia sorella", "mio sorella", "la sorella mia"], 1, "Famille au singulier : pas d'article."),
  fill("Loro ___ (finire) alle cinque.", ["finiscono"], "Verbe en -isc- : finiscono."),
  mcq("Pluriel de « il ragazzo italiano » :", ["i ragazzi italiani", "gli ragazzi italiani", "i ragazzi italiano", "le ragazze italiane"], 0, "i ragazzi italiani."),
  mcq("« Il est trois heures et quart » :", ["È le tre e un quarto.", "Sono le tre e un quarto.", "Sono tre e quarto.", "È tre ore e quarto."], 1, "Sono le tre e un quarto."),
  fill("Vorrei ___ acqua. (de l')", ["dell'", "dell"], "Partitif : dell'acqua."),
  mcq("« Il y a des pommes » :", ["C'è delle mele.", "Ci sono delle mele.", "Ci è mele.", "Sono delle mele."], 1, "Pluriel : ci sono."),
  fill("Mi ___ i libri di storia. (aime)", ["piacciono"], "Pluriel : piacciono."),
  mcq("Noi (andare) :", ["vanno", "andiamo", "andamo", "vadiamo"], 1, "andiamo."),
  tr("Traduisez : Je dois travailler.", ["devo lavorare", "io devo lavorare"], "Devo lavorare."),
  mcq("75 se dit :", ["settantacinque", "sessantacinque", "settanta e cinque", "settecinque"], 0, "settantacinque."),
  fill("Scusi, ___ è il museo? (où)", ["dove", "dov'"], "Dov'è il museo?"),
  mcq("« Je me lève à sept heures » :", ["Alzo alle sette.", "Mi alzo alle sette.", "Mi alzo a sette.", "Si alzo alle sette."], 1, "Mi alzo alle sette."),
];
