/* =====================================================================
   Italien — compléments du palier A2 (CECRL)
   ---------------------------------------------------------------------
   Calé sur le niveau A2 réel (descripteurs CECRL et programmes de
   certification CELI 1 / CILS A2) : raconter au passé (passato
   prossimo avec essere, verbes pronominaux, marqueurs de temps),
   stare + gérondif, pronoms COD et COI, comparatifs, impératif,
   ci et ne, conditionnel de politesse, et les situations concrètes :
   logement, santé, voyage, magasins, météo, travail et études.
   Les leçons s'ajoutent APRÈS les 4 leçons d'origine (identifiants
   inchangés : la progression déjà faite est conservée).
   ===================================================================== */

const mcq = (q, options, answer, explain = "") => ({ type: "mcq", q, options, answer, explain });
const fill = (q, answer, explain = "") => ({ type: "fill", q, answer, explain });
const match = (q, pairs, explain = "") => ({ type: "match", q, pairs, explain });
const tr = (q, answer, explain = "") => ({ type: "translate", q, answer, explain });

export const A2_PLUS = [
  /* ------------------------------------------------------------ 5 */
  {
    id: "a2-passato-essere", module: "conj", title: "Raconter sa journée : passé composé avec essere", emoji: "🕰️",
    intro: "Au niveau A2, on raconte ce qu'on a fait : il faut choisir le bon auxiliaire, accorder le participe et placer les petits mots du temps.",
    sections: [
      {
        title: "Essere + participe accordé",
        text: "Avec <b>essere</b>, le participe s'accorde avec le sujet comme un adjectif : <b>-o, -a, -i, -e</b>. Verbes concernés : mouvement (andare, venire, partire, arrivare, uscire, tornare, entrare), état ou changement (stare, restare, nascere, morire, diventare) et <b>tous les verbes pronominaux</b>.",
        examples: [["Marco è andato al mare.", "Marco est allé à la mer."], ["Giulia è partita ieri.", "Giulia est partie hier."], ["Siamo tornati tardi.", "Nous sommes rentrés tard."], ["Le ragazze sono uscite.", "Les filles sont sorties."]],
      },
      {
        title: "Les verbes pronominaux au passé",
        text: "Pronom + <b>essere</b> + participe accordé : <i>mi sono alzato/a</i>, <i>ti sei svegliato/a</i>, <i>si è vestito/a</i>, <i>ci siamo divertiti</i>.",
        table: { cols: ["", "alzarsi (se lever)"], rows: [["io", "mi sono alzato / alzata"], ["tu", "ti sei alzato / alzata"], ["lui / lei", "si è alzato / alzata"], ["noi", "ci siamo alzati / alzate"], ["voi", "vi siete alzati / alzate"], ["loro", "si sono alzati / alzate"]] },
      },
      {
        title: "Les marqueurs de temps",
        text: "<b>fa</b> se place APRÈS la durée (<i>due giorni fa</i> = il y a deux jours). <b>scorso</b> s'accorde (<i>la settimana scorsa, l'anno scorso</i>). <b>già</b> = déjà, <b>non… ancora</b> = pas encore, <b>appena</b> = venir de.",
        examples: [["Sono arrivata tre giorni fa.", "Je suis arrivée il y a trois jours."], ["L'estate scorsa siamo stati in Sicilia.", "L'été dernier, nous avons été en Sicile."], ["Hai già mangiato? — No, non ho ancora mangiato.", "Tu as déjà mangé ? — Non, pas encore."], ["Il treno è appena partito.", "Le train vient de partir."]],
      },
    ],
    mnemo: "Essere = « la maison DR. MRS VANDERTRAMP » des Français : les verbes de mouvement et de changement d'état. En plus, TOUS les verbes en -si prennent essere.",
    vocab: [["tornare", "rentrer, revenir"], ["uscire", "sortir"], ["nascere", "naître"], ["restare", "rester"], ["diventare", "devenir"], ["divertirsi", "s'amuser"], ["fa", "il y a (durée)"], ["scorso", "dernier (passé)"], ["già", "déjà"], ["non… ancora", "pas encore"], ["appena", "venir de, à peine"], ["tardi", "tard"], ["presto", "tôt, bientôt"], ["il fine settimana", "le week-end"]],
    quiz: [
      mcq("Giulia (partire) hier : ", ["Giulia ha partito ieri.", "Giulia è partito ieri.", "Giulia è partita ieri.", "Giulia ha partita ieri."], 2, "Partire → essere, et accord au féminin : è partita."),
      fill("Stamattina mi ___ alzata alle sette. (suis)", ["sono"], "Verbe pronominal → essere : mi sono alzata."),
      mcq("« Il y a deux ans » :", ["fa due anni", "due anni fa", "ci sono due anni", "da due anni"], 1, "fa se place après la durée : due anni fa."),
      fill("Noi ci siamo ___ molto alla festa. (divertirsi, sujet masculin pluriel)", ["divertiti"], "ci siamo divertiti (accord au pluriel)."),
      mcq("« Tu as déjà mangé ? » :", ["Hai ancora mangiato?", "Hai già mangiato?", "Sei già mangiato?", "Hai mangiato fa?"], 1, "Mangiare → avere ; già = déjà."),
      mcq("Quelle phrase est correcte ?", ["Ho andato a Roma.", "Sono andata a Roma.", "Sono andato a Roma ieri le ragazze.", "Ha andata a Roma."], 1, "Andare → essere : sono andata (une femme parle)."),
      match("Associez", [["già", "déjà"], ["appena", "venir de"], ["scorso", "dernier"], ["tardi", "tard"]]),
      tr("Traduisez : Nous sommes rentrés tard.", ["siamo tornati tardi", "noi siamo tornati tardi", "siamo rientrati tardi", "siamo tornate tardi"], "Tornare → essere : siamo tornati."),
    ],
  },

  /* ------------------------------------------------------------ 6 */
  {
    id: "a2-gerundio", module: "conj", title: "En train de… : stare + gérondif", emoji: "⏳",
    intro: "Pour une action en cours au moment où l'on parle, l'italien utilise stare + gérondif, très fréquent à l'oral (« Cosa stai facendo? »).",
    sections: [
      {
        title: "Former le gérondif",
        text: "-are → <b>-ando</b> (parlare → parlando) · -ere / -ire → <b>-endo</b> (leggere → leggendo, dormire → dormendo). Irréguliers : fare → <b>facendo</b>, dire → <b>dicendo</b>, bere → <b>bevendo</b>.",
        table: { cols: ["", "stare + gérondif"], rows: [["io", "sto mangiando"], ["tu", "stai leggendo"], ["lui / lei", "sta dormendo"], ["noi", "stiamo lavorando"], ["voi", "state facendo"], ["loro", "stanno uscendo"]] },
      },
      {
        title: "Dans la conversation",
        examples: [["Cosa stai facendo?", "Qu'est-ce que tu es en train de faire ?"], ["Sto cucinando, ti richiamo dopo.", "Je suis en train de cuisiner, je te rappelle après."], ["I bambini stanno dormendo.", "Les enfants sont en train de dormir."], ["Sta piovendo.", "Il est en train de pleuvoir."]],
      },
      {
        title: "Stare per + infinitif : être sur le point de",
        text: "<b>stare per</b> + infinitif = action imminente.",
        examples: [["Il film sta per cominciare.", "Le film est sur le point de commencer."], ["Sto per uscire.", "Je suis sur le point de sortir."]],
      },
    ],
    mnemo: "-ANDO pour -ARE (deux A), -ENDO pour les autres. Et « stare » au présent : sto, stai, sta, stiamo, state, stanno.",
    vocab: [["stare", "être (en train de), rester"], ["facendo", "en faisant"], ["piovere", "pleuvoir"], ["cominciare", "commencer"], ["richiamare", "rappeler"], ["dopo", "après"], ["adesso", "maintenant"], ["in questo momento", "en ce moment"], ["stare per", "être sur le point de"], ["bere", "boire"]],
    quiz: [
      fill("Cosa stai ___? (fare)", ["facendo"], "fare → facendo (irrégulier)."),
      mcq("« Les enfants sont en train de dormir » :", ["I bambini stanno dormendo.", "I bambini sono dormendo.", "I bambini stano dormiendo.", "I bambini stanno dormando."], 0, "stare + dormendo."),
      fill("Sto ___ un libro. (leggere)", ["leggendo"], "-ere → -endo."),
      mcq("Gérondif de « parlare » :", ["parlendo", "parlando", "parlato", "parlante"], 1, "-are → -ando."),
      mcq("« Le train est sur le point de partir » :", ["Il treno sta partendo per.", "Il treno sta per partire.", "Il treno è per partire.", "Il treno sta di partire."], 1, "stare per + infinitif."),
      fill("Noi ___ lavorando. (stare)", ["stiamo"], "noi stiamo."),
      match("Associez", [["bere", "bevendo"], ["dire", "dicendo"], ["fare", "facendo"], ["dormire", "dormendo"]]),
      tr("Traduisez : Il pleut.", ["sta piovendo", "piove"], "Piove ou sta piovendo (en ce moment)."),
    ],
  },

  /* ------------------------------------------------------------ 7 */
  {
    id: "a2-pronomi-cod", module: "gram", title: "Les pronoms : lo, la, li, le — gli, le", emoji: "👉",
    intro: "Pour ne pas répéter les mots : « je le prends », « je lui téléphone ». Indispensable dans les magasins et au téléphone.",
    sections: [
      {
        title: "Pronoms COD (le, la, les)",
        text: "<b>lo</b> (masc.), <b>la</b> (fém.), <b>li</b> (masc. pl.), <b>le</b> (fém. pl.). Ils se placent <b>avant</b> le verbe conjugué. Devant voyelle : <b>l'</b>.",
        examples: [["Il caffè? Lo prendo senza zucchero.", "Le café ? Je le prends sans sucre."], ["Conosci Anna? — Sì, la conosco.", "Tu connais Anna ? — Oui, je la connais."], ["Le scarpe? Le compro domani.", "Les chaussures ? Je les achète demain."], ["Questo film? L'ho già visto.", "Ce film ? Je l'ai déjà vu."]],
      },
      {
        title: "Pronoms COI (lui, leur)",
        text: "<b>gli</b> = à lui (et souvent à eux à l'oral), <b>le</b> = à elle, <b>Le</b> = à vous (politesse). Avec <b>telefonare, scrivere, dire, regalare, dare</b>…",
        examples: [["Telefono a Marco → Gli telefono.", "Je téléphone à Marco → Je lui téléphone."], ["Scrivo a Sara → Le scrivo.", "J'écris à Sara → Je lui écris."], ["Cosa Le porto?", "Qu'est-ce que je vous apporte ?"]],
      },
      {
        title: "Avec un infinitif",
        text: "Avec devo, posso, voglio + infinitif, le pronom va avant le verbe conjugué <b>ou</b> s'attache à l'infinitif : <i>Lo devo comprare</i> = <i>Devo comprarlo</i>.",
      },
    ],
    mnemo: "LI pour les garçons, LE pour les filles… mais attention : le tout seul peut aussi vouloir dire « à elle » (COI) !",
    vocab: [["lo", "le (COD)"], ["la", "la (COD)"], ["li", "les (masc.)"], ["le", "les (fém.) / à elle"], ["gli", "à lui"], ["conoscere", "connaître"], ["telefonare", "téléphoner"], ["regalare", "offrir (un cadeau)"], ["portare", "apporter, porter"], ["lo zucchero", "le sucre"], ["le scarpe", "les chaussures"], ["il regalo", "le cadeau"]],
    quiz: [
      mcq("Il giornale? ___ leggo ogni mattina.", ["La", "Lo", "Li", "Gli"], 1, "giornale est masculin : lo."),
      mcq("Le mele? ___ compro al mercato.", ["Li", "Lo", "Le", "Gli"], 2, "mele, féminin pluriel : le."),
      fill("Telefono a mio padre → ___ telefono.", ["gli"], "à lui : gli."),
      fill("Scrivo a mia sorella → ___ scrivo.", ["le"], "à elle : le."),
      mcq("« Je dois l'acheter » (le livre) :", ["Devo comprarlo.", "Devo lo comprare.", "Lo devo comprarlo.", "Devo comprargli."], 0, "Devo comprarlo (ou Lo devo comprare)."),
      mcq("Cameriere au client : « Que vous apporte-je ? »", ["Cosa ti porto?", "Cosa gli porto?", "Cosa Le porto?", "Cosa lo porto?"], 2, "Le = à vous (vouvoiement)."),
      match("Associez", [["regalare", "offrir"], ["conoscere", "connaître"], ["il regalo", "le cadeau"], ["lo zucchero", "le sucre"]]),
      tr("Traduisez : Je la connais.", ["la conosco", "io la conosco"], "La conosco."),
    ],
  },

  /* ------------------------------------------------------------ 8 */
  {
    id: "a2-comparativi", module: "gram", title: "Comparer : più… di, meno… di, come", emoji: "⚖️",
    intro: "Plus grand, moins cher, aussi beau, le meilleur : comparer des villes, des prix, des personnes.",
    sections: [
      {
        title: "Plus / moins / aussi",
        text: "<b>più</b> + adjectif + <b>di</b> (= plus… que) · <b>meno</b> + adjectif + <b>di</b> · <b>(così)</b> + adjectif + <b>come</b> ou <b>tanto… quanto</b> (= aussi… que). <b>di</b> se contracte avec l'article : <i>del, della…</i>",
        examples: [["Roma è più grande di Firenze.", "Rome est plus grande que Florence."], ["Il treno è meno caro dell'aereo.", "Le train est moins cher que l'avion."], ["Luca è alto come suo padre.", "Luca est aussi grand que son père."]],
      },
      {
        title: "Più… che",
        text: "On utilise <b>che</b> (et non di) quand on compare deux adjectifs, deux verbes, ou devant une préposition.",
        examples: [["È più bello che utile.", "C'est plus beau qu'utile."], ["Mi piace più leggere che guardare la TV.", "J'aime plus lire que regarder la télé."], ["Fa più caldo a Napoli che a Milano.", "Il fait plus chaud à Naples qu'à Milan."]],
      },
      {
        title: "Le superlatif et les irréguliers",
        text: "<b>il / la più</b> + adjectif (+ <b>di</b>) = le plus… de. Irréguliers fréquents : buono → <b>migliore</b> (meilleur), cattivo → <b>peggiore</b> (pire). Superlatif absolu : <b>-issimo</b> (bellissimo = très beau).",
        examples: [["È il ristorante più famoso della città.", "C'est le restaurant le plus célèbre de la ville."], ["La pizza napoletana è la migliore!", "La pizza napolitaine est la meilleure !"], ["Il tiramisù è buonissimo.", "Le tiramisu est très très bon."]],
      },
    ],
    mnemo: "Più DI devant un nom ou un pronom (più alto DI te), più CHE devant tout le reste (adjectif, verbe, préposition).",
    vocab: [["più", "plus"], ["meno", "moins"], ["come", "comme, aussi… que"], ["migliore", "meilleur"], ["peggiore", "pire"], ["alto", "grand (taille)"], ["basso", "petit (taille)"], ["caro", "cher"], ["famoso", "célèbre"], ["utile", "utile"], ["bellissimo", "magnifique"], ["l'aereo", "l'avion"]],
    quiz: [
      fill("Milano è più grande ___ Bologna.", ["di"], "più + adjectif + di + nom."),
      mcq("« Le train est moins cher que l'avion » :", ["Il treno è meno caro che l'aereo.", "Il treno è meno caro dell'aereo.", "Il treno è più caro dell'aereo.", "Il treno è meno caro di aereo."], 1, "di + l' = dell'."),
      mcq("Mi piace più nuotare ___ correre.", ["di", "che", "come", "del"], 1, "Deux verbes : più… che."),
      fill("Questo vino è buono, ma quello è ___. (meilleur)", ["migliore"], "buono → migliore."),
      mcq("« Très beau » (une seule forme) :", ["molto bellissimo", "bellissimo", "più bello", "il più bello"], 1, "-issimo = très."),
      mcq("« Luca est aussi grand que son père » :", ["Luca è alto come suo padre.", "Luca è alto che suo padre.", "Luca è più alto come suo padre.", "Luca è tanto alto di suo padre."], 0, "(così) alto come."),
      match("Associez", [["migliore", "meilleur"], ["peggiore", "pire"], ["meno", "moins"], ["famoso", "célèbre"]]),
      tr("Traduisez : C'est le plus beau jour de l'année.", ["è il giorno più bello dell'anno", "e il giorno piu bello dell'anno"], "il + nom + più + adjectif + di."),
    ],
  },

  /* ------------------------------------------------------------ 9 */
  {
    id: "a2-imperativo", module: "conj", title: "Donner des conseils et des instructions : l'impératif", emoji: "👨‍🍳",
    intro: "Recettes, directions, conseils entre amis : l'impératif avec tu, noi et voi, et sa négation un peu particulière.",
    sections: [
      {
        title: "Impératif avec tu, noi, voi",
        text: "Verbes en <b>-are</b> : tu → <b>-a</b> (parla!), voi → <b>-ate</b>. Verbes en <b>-ere / -ire</b> : tu → <b>-i</b> (prendi! senti!). Noi et voi = comme le présent (andiamo! venite!).",
        table: { cols: ["", "tu", "noi", "voi"], rows: [["guardare", "guarda!", "guardiamo!", "guardate!"], ["prendere", "prendi!", "prendiamo!", "prendete!"], ["aprire", "apri!", "apriamo!", "aprite!"], ["finire", "finisci!", "finiamo!", "finite!"]] },
      },
      {
        title: "Les irréguliers à connaître",
        text: "andare → <b>va'</b> · fare → <b>fa'</b> · dare → <b>da'</b> · stare → <b>sta'</b> · dire → <b>di'</b> · essere → <b>sii</b> · avere → <b>abbi</b>. Avec un pronom, la consonne double : <i>fammi vedere</i>, <i>dimmi</i>.",
        examples: [["Dimmi la verità!", "Dis-moi la vérité !"], ["Fammi vedere!", "Fais-moi voir !"], ["Va' dritto e gira a sinistra.", "Va tout droit et tourne à gauche."]],
      },
      {
        title: "La négation avec tu : non + infinitif",
        text: "À la 2e personne du singulier, l'impératif négatif = <b>non + infinitif</b>. Pour noi et voi, on met simplement non devant.",
        examples: [["Non toccare!", "Ne touche pas !"], ["Non preoccuparti!", "Ne t'inquiète pas !"], ["Non dimenticate i passaporti!", "N'oubliez pas les passeports !"], ["Aggiungi il sale e mescola bene.", "Ajoute le sel et mélange bien."]],
      },
    ],
    mnemo: "Impératif tu des verbes en -are : inversion de la voyelle ! Au présent « tu parli », à l'impératif « parla! ». Et en négatif, on repasse à l'infinitif : non parlare!",
    vocab: [["guardare", "regarder"], ["aggiungere", "ajouter"], ["mescolare", "mélanger"], ["il sale", "le sel"], ["toccare", "toucher"], ["dimenticare", "oublier"], ["preoccuparsi", "s'inquiéter"], ["la verità", "la vérité"], ["il passaporto", "le passeport"], ["attento", "attentif (attento! = attention !)"], ["sbrigarsi", "se dépêcher"], ["la ricetta", "la recette"]],
    quiz: [
      mcq("Impératif de « mangiare » (tu) :", ["mangi!", "mangia!", "mangiare!", "mangiate!"], 1, "-are → -a avec tu."),
      mcq("« Ne touche pas ! » :", ["Non tocca!", "Non toccare!", "Non tocchi!", "Tocca non!"], 1, "Négation avec tu : non + infinitif."),
      fill("___ la finestra, per favore! (aprire, tu)", ["apri"], "-ire → -i : apri!"),
      mcq("« Dis-moi ! » :", ["Dici mi!", "Dimmi!", "Dì me!", "Dica mi!"], 1, "di' + mi → dimmi (consonne doublée)."),
      fill("Ragazzi, ___ attenzione! (fare, voi)", ["fate"], "voi : fate."),
      mcq("« Ne t'inquiète pas ! » :", ["Non ti preoccupa!", "Non preoccuparti!", "Non preoccupati!", "Preoccupati non!"], 1, "non + infinitif + pronom attaché : non preoccuparti."),
      match("Associez", [["aggiungere", "ajouter"], ["mescolare", "mélanger"], ["dimenticare", "oublier"], ["sbrigarsi", "se dépêcher"]]),
      tr("Traduisez : Allons-y !", ["andiamo", "andiamo!"], "noi : andiamo!"),
    ],
  },

  /* ------------------------------------------------------------ 10 */
  {
    id: "a2-ci-ne", module: "gram", title: "Ci et ne : « y » et « en »", emoji: "🔁",
    intro: "Deux petits mots très fréquents à l'oral : « ci vado » (j'y vais), « ne voglio due » (j'en veux deux).",
    sections: [
      {
        title: "Ci = y (lieu)",
        text: "<b>ci</b> remplace un lieu déjà mentionné. Expressions fixes : <b>ci vuole / ci vogliono</b> = il faut (du temps, des choses).",
        examples: [["Vai a Roma? — Sì, ci vado domani.", "Tu vas à Rome ? — Oui, j'y vais demain."], ["Sei mai stato in Sicilia? — No, non ci sono mai stato.", "Tu es déjà allé en Sicile ? — Non, je n'y suis jamais allé."], ["Ci vogliono due ore in treno.", "Il faut deux heures en train."]],
      },
      {
        title: "Ne = en (quantité)",
        text: "<b>ne</b> remplace une quantité ou « de cela ». On garde le nombre ou la quantité dans la phrase. Au passé composé, le participe s'accorde avec ce que remplace ne.",
        examples: [["Quante mele vuoi? — Ne voglio tre.", "Combien de pommes veux-tu ? — J'en veux trois."], ["Hai fratelli? — Sì, ne ho due.", "Tu as des frères ? — Oui, j'en ai deux."], ["Che ne pensi?", "Qu'en penses-tu ?"], ["Quante pizze hai mangiato? — Ne ho mangiate due.", "Combien de pizzas as-tu mangé ? — J'en ai mangé deux."]],
      },
      {
        title: "Au marché",
        examples: [["Vorrei dei pomodori. — Quanti ne vuole?", "Je voudrais des tomates. — Combien en voulez-vous ?"], ["Ne prendo un chilo.", "J'en prends un kilo."], ["Un etto di prosciutto, per favore.", "Cent grammes de jambon, s'il vous plaît."]],
      },
    ],
    mnemo: "CI comme « ici » (un lieu), NE comme « nombre » (une quantité).",
    vocab: [["ci", "y (lieu)"], ["ne", "en (quantité)"], ["ci vuole", "il faut (sing.)"], ["ci vogliono", "il faut (plur.)"], ["mai", "jamais"], ["pensare", "penser"], ["il pomodoro", "la tomate"], ["il chilo", "le kilo"], ["l'etto", "cent grammes"], ["il prosciutto", "le jambon"], ["il mercato", "le marché"], ["quanti", "combien (plur.)"]],
    quiz: [
      mcq("Vai al cinema stasera? — Sì, ___ vado con Luca.", ["ne", "ci", "lo", "gli"], 1, "ci = y (lieu)."),
      mcq("Quanti caffè bevi al giorno? — ___ bevo tre.", ["Ci", "Ne", "Li", "Lo"], 1, "ne = en (quantité)."),
      fill("Che ___ pensi? (en)", ["ne"], "Che ne pensi? = Qu'en penses-tu ?"),
      mcq("« Il faut trois heures » :", ["Ci vuole tre ore.", "Ci vogliono tre ore.", "Ne vogliono tre ore.", "Bisogna tre ore."], 1, "Pluriel : ci vogliono."),
      mcq("« Un etto » correspond à :", ["un kilo", "cent grammes", "un litre", "dix grammes"], 1, "un etto = 100 g, très utilisé au marché."),
      fill("Hai sorelle? — Sì, ___ ho una.", ["ne"], "ne ho una = j'en ai une."),
      match("Associez", [["il pomodoro", "la tomate"], ["il prosciutto", "le jambon"], ["il mercato", "le marché"], ["mai", "jamais"]]),
      tr("Traduisez : J'y vais demain.", ["ci vado domani", "domani ci vado", "io ci vado domani"], "Ci vado domani."),
    ],
  },

  /* ------------------------------------------------------------ 11 */
  {
    id: "a2-condizionale", module: "expr", title: "Demander poliment : vorrei, potrei, mi piacerebbe", emoji: "🎩",
    intro: "Le conditionnel de politesse sert partout au quotidien : commander, demander un service, exprimer un souhait, donner un conseil.",
    sections: [
      {
        title: "Les formes les plus utiles",
        text: "On les apprend comme des expressions : <b>vorrei</b> (je voudrais), <b>potrei</b> (pourrais-je), <b>potrebbe</b> (pourriez-vous), <b>mi piacerebbe</b> (j'aimerais), <b>dovresti</b> (tu devrais), <b>sarebbe</b> (ce serait).",
        examples: [["Vorrei un cappuccino, per favore.", "Je voudrais un cappuccino, s'il vous plaît."], ["Potrebbe ripetere, per favore?", "Pourriez-vous répéter, s'il vous plaît ?"], ["Potrei avere il conto?", "Pourrais-je avoir l'addition ?"]],
      },
      {
        title: "Souhaits et conseils",
        examples: [["Mi piacerebbe visitare Venezia.", "J'aimerais visiter Venise."], ["Dovresti dormire di più.", "Tu devrais dormir plus."], ["Sarebbe bello andare al mare.", "Ce serait bien d'aller à la mer."], ["Ti andrebbe di uscire stasera?", "Ça te dirait de sortir ce soir ?"]],
      },
      {
        title: "Conjugaison (verbes réguliers)",
        text: "Infinitif sans -e (et -are → -er) + <b>-ei, -esti, -ebbe, -emmo, -este, -ebbero</b> : parlerei, prenderei, dormirei. Radicaux irréguliers : volere → <b>vorr-</b>, potere → <b>potr-</b>, dovere → <b>dovr-</b>, andare → <b>andr-</b>, essere → <b>sar-</b>, avere → <b>avr-</b>.",
      },
    ],
    mnemo: "« Vorrei » commence comme « vouloir » et finit en -ei comme « je » : c'est LE mot magique du voyageur.",
    vocab: [["vorrei", "je voudrais"], ["potrei", "je pourrais"], ["potrebbe", "pourriez-vous"], ["mi piacerebbe", "j'aimerais"], ["dovresti", "tu devrais"], ["sarebbe", "ce serait"], ["ripetere", "répéter"], ["visitare", "visiter"], ["il favore", "le service, la faveur"], ["volentieri", "volontiers"], ["magari", "peut-être, si seulement"], ["ti andrebbe di…?", "ça te dirait de… ?"]],
    quiz: [
      mcq("Pour commander poliment :", ["Vorrei un caffè, per favore.", "Voglio un caffè, adesso.", "Dammi un caffè, subito.", "Ho un caffè, per favore."], 0, "vorrei = je voudrais."),
      fill("___ ripetere, per favore? (pourriez-vous)", ["potrebbe"], "Potrebbe (vouvoiement)."),
      mcq("« J'aimerais voyager » :", ["Mi piace viaggiare.", "Mi piacerebbe viaggiare.", "Mi piacerei viaggiare.", "Piacerei viaggiare."], 1, "mi piacerebbe + infinitif."),
      fill("Sei stanco: ___ riposarti. (tu devrais)", ["dovresti"], "dovresti = tu devrais."),
      mcq("Ti andrebbe di andare al cinema? Réponse positive :", ["Volentieri!", "Magari no.", "Non vorrei.", "Prego."], 0, "Volentieri = volontiers."),
      mcq("Conditionnel de « parlare » (io) :", ["parlarei", "parlerei", "parlerò", "parlassi"], 1, "-are → -er- : parlerei."),
      match("Associez", [["sarebbe", "ce serait"], ["volentieri", "volontiers"], ["magari", "si seulement"], ["potrei", "je pourrais"]]),
      tr("Traduisez : Je voudrais l'addition.", ["vorrei il conto", "vorrei il conto per favore"], "Vorrei il conto."),
    ],
  },

  /* ------------------------------------------------------------ 12 */
  {
    id: "a2-casa", module: "vocab", title: "La maison et chercher un logement", emoji: "🏠",
    intro: "Décrire son appartement, lire une annonce, parler du loyer : la situation typique d'un séjour en Italie.",
    sections: [
      {
        title: "Les pièces et les meubles",
        examples: [["la cucina / il soggiorno", "la cuisine / le séjour"], ["la camera da letto / il bagno", "la chambre / la salle de bain"], ["il divano / l'armadio", "le canapé / l'armoire"], ["il tavolo / la sedia", "la table / la chaise"], ["il frigorifero / la lavatrice", "le frigo / la machine à laver"]],
      },
      {
        title: "Lire une annonce",
        text: "<b>affittasi</b> = à louer · <b>bilocale</b> = deux pièces · <b>arredato</b> = meublé · <b>spese incluse</b> = charges comprises · <b>piano</b> = étage (<i>al terzo piano</i>) · <b>l'affitto</b> = le loyer.",
        examples: [["Affittasi bilocale arredato in centro, 650 euro al mese.", "À louer : deux-pièces meublé au centre, 650 euros par mois."], ["Le spese sono incluse?", "Les charges sont comprises ?"], ["L'appartamento è al secondo piano, senza ascensore.", "L'appartement est au deuxième étage, sans ascenseur."]],
      },
      {
        title: "Décrire",
        examples: [["La mia camera è piccola ma luminosa.", "Ma chambre est petite mais lumineuse."], ["Abito con due coinquilini.", "J'habite avec deux colocataires."], ["Il bagno è in fondo al corridoio.", "La salle de bain est au bout du couloir."]],
      },
    ],
    mnemo: "BI-locale = 2 pièces, TRI-locale = 3 pièces, MONO-locale = studio. Les Italiens comptent les pièces sans la cuisine ni la salle de bain… parfois !",
    vocab: [["l'appartamento", "l'appartement"], ["la cucina", "la cuisine"], ["il soggiorno", "le séjour"], ["la camera da letto", "la chambre"], ["il bagno", "la salle de bain"], ["il divano", "le canapé"], ["l'armadio", "l'armoire"], ["la sedia", "la chaise"], ["l'affitto", "le loyer"], ["arredato", "meublé"], ["il piano", "l'étage"], ["l'ascensore", "l'ascenseur"], ["il coinquilino", "le colocataire"], ["luminoso", "lumineux"]],
    quiz: [
      mcq("« Bilocale » signifie :", ["deux étages", "deux-pièces", "deux salles de bain", "maison mitoyenne"], 1, "bilocale = deux pièces."),
      mcq("Dans une annonce, « arredato » =", ["rénové", "meublé", "loué", "vendu"], 1, "arredato = meublé."),
      fill("Pago 500 euro di ___ al mese. (loyer)", ["affitto"], "l'affitto = le loyer."),
      mcq("« Au troisième étage » :", ["al terzo piano", "nel terzo piano", "al tre piano", "a terza piana"], 0, "al terzo piano."),
      match("Associez", [["il divano", "le canapé"], ["l'armadio", "l'armoire"], ["la sedia", "la chaise"], ["il bagno", "la salle de bain"]]),
      mcq("« Les charges sont comprises » :", ["Le spese sono incluse.", "Le spese sono pagate.", "Le spese sono escluse.", "Le spese sono care."], 0, "spese incluse."),
      fill("Abito con due ___. (colocataires)", ["coinquilini", "coinquiline"], "coinquilino/a."),
      tr("Traduisez : La cuisine est petite.", ["la cucina è piccola", "la cucina e piccola"], "La cucina è piccola."),
    ],
  },

  /* ------------------------------------------------------------ 13 */
  {
    id: "a2-salute", module: "vocab", title: "Le corps et la santé : chez le médecin", emoji: "🩺",
    intro: "Dire où l'on a mal, décrire des symptômes simples, aller à la pharmacie : des phrases qu'on espère ne pas utiliser… mais qu'il faut connaître.",
    sections: [
      {
        title: "Mi fa male… / Mi fanno male…",
        text: "« J'ai mal à » = <b>mi fa male</b> + nom singulier, <b>mi fanno male</b> + nom pluriel. Ou <b>ho mal di</b> + partie du corps (ho mal di testa, di gola, di pancia).",
        examples: [["Mi fa male la schiena.", "J'ai mal au dos."], ["Mi fanno male i piedi.", "J'ai mal aux pieds."], ["Ho mal di testa.", "J'ai mal à la tête."], ["Ho mal di gola e ho la febbre.", "J'ai mal à la gorge et j'ai de la fièvre."]],
      },
      {
        title: "Le corps : pluriels irréguliers",
        text: "Attention : <b>il braccio → le braccia</b>, <b>il ginocchio → le ginocchia</b>, <b>la mano → le mani</b>, <b>l'orecchio → le orecchie</b>, <b>l'occhio → gli occhi</b>.",
        examples: [["la testa / la gola", "la tête / la gorge"], ["la pancia / la schiena", "le ventre / le dos"], ["il braccio → le braccia", "le bras → les bras"], ["la mano → le mani", "la main → les mains"]],
      },
      {
        title: "Chez le médecin et à la pharmacie",
        examples: [["Cosa si sente?", "Qu'est-ce que vous ressentez ?"], ["Ho il raffreddore e la tosse.", "J'ai un rhume et de la toux."], ["Prenda queste compresse due volte al giorno.", "Prenez ces comprimés deux fois par jour."], ["Mi serve qualcosa per il mal di testa.", "J'ai besoin de quelque chose pour le mal de tête."], ["Chiamate un'ambulanza! Il numero è 112.", "Appelez une ambulance ! Le numéro est le 112."]],
      },
    ],
    mnemo: "« Mi fa male » fonctionne comme « mi piace » : le verbe s'accorde avec la partie du corps (mi fanno male le gambe).",
    vocab: [["la testa", "la tête"], ["la gola", "la gorge"], ["la pancia", "le ventre"], ["la schiena", "le dos"], ["il braccio", "le bras"], ["la mano", "la main"], ["la gamba", "la jambe"], ["il piede", "le pied"], ["l'occhio", "l'œil"], ["la febbre", "la fièvre"], ["il raffreddore", "le rhume"], ["la tosse", "la toux"], ["la compressa", "le comprimé"], ["il medico", "le médecin"], ["la ricetta", "l'ordonnance, la recette"]],
    quiz: [
      mcq("« J'ai mal aux pieds » :", ["Mi fa male i piedi.", "Mi fanno male i piedi.", "Ho male ai piedi.", "Mi fanno male le piedi."], 1, "Pluriel : mi fanno male i piedi."),
      fill("Ho mal di ___. (tête)", ["testa"], "ho mal di testa."),
      mcq("Pluriel de « il braccio » :", ["i bracci", "le braccia", "le braccie", "gli bracci"], 1, "Pluriel irrégulier : le braccia."),
      mcq("« Ho il raffreddore » signifie :", ["J'ai froid", "J'ai un rhume", "J'ai de la fièvre", "J'ai faim"], 1, "il raffreddore = le rhume."),
      fill("Mi fa male la ___. (dos)", ["schiena"], "la schiena = le dos."),
      match("Associez", [["la gola", "la gorge"], ["la pancia", "le ventre"], ["la tosse", "la toux"], ["la febbre", "la fièvre"]]),
      mcq("Pluriel de « la mano » :", ["le mane", "le mani", "i mani", "le manos"], 1, "la mano → le mani (féminin)."),
      tr("Traduisez : J'ai de la fièvre.", ["ho la febbre", "io ho la febbre"], "Ho la febbre."),
    ],
  },

  /* ------------------------------------------------------------ 14 */
  {
    id: "a2-viaggi", module: "expr", title: "En voyage : train, hôtel et réservations", emoji: "🧳",
    intro: "Acheter un billet, réserver une chambre, comprendre une annonce en gare : tout ce qu'il faut pour voyager seul en Italie.",
    sections: [
      {
        title: "À la gare",
        text: "<b>il binario</b> = le quai, la voie · <b>andata e ritorno</b> = aller-retour · <b>la coincidenza</b> = la correspondance · <b>in ritardo</b> = en retard · <b>convalidare / obliterare</b> = composter (obligatoire pour les billets régionaux papier !).",
        examples: [["Un biglietto per Firenze, andata e ritorno.", "Un billet pour Florence, aller-retour."], ["Da quale binario parte il treno per Bologna?", "De quel quai part le train pour Bologne ?"], ["Il treno è in ritardo di venti minuti.", "Le train a vingt minutes de retard."]],
      },
      {
        title: "À l'hôtel",
        examples: [["Ho prenotato una camera doppia a nome Martin.", "J'ai réservé une chambre double au nom de Martin."], ["La colazione è inclusa?", "Le petit-déjeuner est inclus ?"], ["A che ora bisogna lasciare la camera?", "À quelle heure faut-il libérer la chambre ?"], ["Avete una camera singola per due notti?", "Vous avez une chambre simple pour deux nuits ?"]],
      },
      {
        title: "Les mots du voyage",
        text: "<b>prenotare</b> = réserver · <b>la valigia</b> = la valise · <b>il volo</b> = le vol · <b>l'aeroporto</b> = l'aéroport · <b>la carta d'identità</b> = la carte d'identité.",
      },
    ],
    mnemo: "BINARIO : deux (bi) rails. Si votre train est « soppresso », il est supprimé… préparez un plan B !",
    vocab: [["il biglietto", "le billet"], ["il binario", "le quai, la voie"], ["andata e ritorno", "aller-retour"], ["in ritardo", "en retard"], ["in orario", "à l'heure"], ["prenotare", "réserver"], ["la camera doppia", "la chambre double"], ["la camera singola", "la chambre simple"], ["la valigia", "la valise"], ["il volo", "le vol"], ["l'aeroporto", "l'aéroport"], ["la coincidenza", "la correspondance"], ["la partenza", "le départ"], ["l'arrivo", "l'arrivée"]],
    quiz: [
      mcq("« Il binario 5 » désigne :", ["le guichet 5", "le quai 5", "le wagon 5", "la sortie 5"], 1, "il binario = la voie / le quai."),
      fill("Un biglietto di andata e ___, per favore. (retour)", ["ritorno"], "andata e ritorno."),
      mcq("« Le train est en retard » :", ["Il treno è in orario.", "Il treno è in ritardo.", "Il treno è tardi.", "Il treno è lento."], 1, "in ritardo."),
      fill("Ho ___ una camera per due notti. (réservé)", ["prenotato"], "prenotare → ho prenotato."),
      mcq("Une chambre pour une personne :", ["camera doppia", "camera singola", "camera matrimoniale", "camera da letto"], 1, "singola = simple."),
      match("Associez", [["la valigia", "la valise"], ["il volo", "le vol"], ["la partenza", "le départ"], ["la coincidenza", "la correspondance"]]),
      mcq("« La colazione è inclusa? » demande si…", ["le dîner est servi", "le petit-déjeuner est compris", "la chambre est libre", "le parking est gratuit"], 1, "la colazione = le petit-déjeuner."),
      tr("Traduisez : Le train part à huit heures.", ["il treno parte alle otto"], "Il treno parte alle otto."),
    ],
  },

  /* ------------------------------------------------------------ 15 */
  {
    id: "a2-negozi", module: "vocab", title: "Dans les magasins : vêtements, tailles, prix", emoji: "👗",
    intro: "Demander une taille, essayer, comparer les prix et payer : la conversation type dans une boutique italienne.",
    sections: [
      {
        title: "Les vêtements",
        examples: [["la maglietta / la camicia", "le t-shirt / la chemise"], ["i pantaloni / la gonna", "le pantalon / la jupe"], ["il vestito / la giacca", "la robe ou le costume / la veste"], ["il maglione / il cappotto", "le pull / le manteau"], ["le scarpe / gli stivali", "les chaussures / les bottes"]],
      },
      {
        title: "La conversation en boutique",
        examples: [["Posso provare questa giacca?", "Je peux essayer cette veste ?"], ["Che taglia porta? — La 42.", "Quelle taille faites-vous ? — Du 42."], ["Che numero porta? — Il 39.", "Vous chaussez du combien ? — Du 39."], ["Mi sta un po' stretta. Ce l'ha più grande?", "Elle me serre un peu. Vous l'avez plus grande ?"], ["Quanto costa? — È in saldo: 30 euro.", "Combien ça coûte ? — C'est en solde : 30 euros."], ["Posso pagare con la carta?", "Je peux payer par carte ?"]],
      },
      {
        title: "Questo / quello",
        text: "<b>questo</b> (ce…-ci, proche) et <b>quello</b> (ce…-là, loin). <i>Quello</i> change de forme comme l'article : quel vestito, quello zaino, quell'abito, quei pantaloni, quegli stivali, quella gonna.",
      },
    ],
    mnemo: "TAGLIA pour les vêtements (on « taille » le tissu), NUMERO pour les chaussures.",
    vocab: [["la maglietta", "le t-shirt"], ["la camicia", "la chemise"], ["i pantaloni", "le pantalon"], ["la gonna", "la jupe"], ["la giacca", "la veste"], ["il maglione", "le pull"], ["il cappotto", "le manteau"], ["la taglia", "la taille (vêtement)"], ["il numero", "la pointure, le numéro"], ["provare", "essayer"], ["stretto", "serré, étroit"], ["largo", "large"], ["i saldi", "les soldes"], ["lo sconto", "la réduction"], ["la carta", "la carte (bancaire)"]],
    quiz: [
      mcq("Pour les chaussures, on demande :", ["Che taglia porta?", "Che numero porta?", "Che misura è?", "Quanto porta?"], 1, "numero pour les chaussures."),
      fill("Posso ___ questi pantaloni? (essayer)", ["provare"], "provare = essayer."),
      mcq("« Mi sta stretta » signifie :", ["Elle me va bien", "Elle me serre", "Elle est trop longue", "Elle est trop chère"], 1, "stretto = serré."),
      mcq("« Quei pantaloni » : pourquoi « quei » ?", ["masculin pluriel devant une consonne", "masculin pluriel devant une voyelle", "féminin pluriel devant une consonne", "masculin singulier devant « s » + consonne"], 0, "quello suit l'article : i pantaloni → quei pantaloni."),
      match("Associez", [["la gonna", "la jupe"], ["il maglione", "le pull"], ["il cappotto", "le manteau"], ["la camicia", "la chemise"]]),
      fill("Questa giacca è in ___: costa solo 40 euro. (soldes)", ["saldo"], "in saldo = en solde."),
      mcq("« Je peux payer par carte ? » :", ["Posso pagare con la carta?", "Posso pagare per carta?", "Posso pagare di carta?", "Posso pago con carta?"], 0, "pagare con la carta."),
      tr("Traduisez : Combien coûtent ces chaussures ?", ["quanto costano queste scarpe", "quanto costano quelle scarpe"], "Quanto costano queste scarpe?"),
    ],
  },

  /* ------------------------------------------------------------ 16 */
  {
    id: "a2-meteo", module: "vocab", title: "Le temps qu'il fait et les saisons", emoji: "🌦️",
    intro: "Parler de la météo, le grand classique des conversations : fa caldo, piove, c'è il sole.",
    sections: [
      {
        title: "Fa, c'è, è",
        text: "<b>Fa</b> caldo / freddo / bel tempo / brutto tempo. <b>C'è</b> il sole / vento / nebbia. <b>È</b> nuvoloso / sereno. Verbes : <b>piove</b> (il pleut), <b>nevica</b> (il neige).",
        examples: [["Che tempo fa oggi?", "Quel temps fait-il aujourd'hui ?"], ["Fa molto caldo, ci sono 35 gradi.", "Il fait très chaud, il fait 35 degrés."], ["C'è vento e il cielo è nuvoloso.", "Il y a du vent et le ciel est nuageux."], ["Domani piove al nord e c'è il sole al sud.", "Demain il pleut au nord et il y a du soleil au sud."]],
      },
      {
        title: "Les saisons",
        text: "<b>la primavera, l'estate, l'autunno, l'inverno</b>. « En été » = <b>in estate</b> ou <b>d'estate</b>.",
        examples: [["In inverno nevica in montagna.", "En hiver il neige à la montagne."], ["D'estate andiamo sempre al mare.", "L'été, nous allons toujours à la mer."], ["Preferisco la primavera.", "Je préfère le printemps."]],
      },
      {
        title: "Avoir chaud / froid",
        text: "Pour une personne : <b>avere caldo / freddo</b> (ho freddo = j'ai froid). Pour le temps : <b>fa caldo / freddo</b>.",
      },
    ],
    mnemo: "Le TEMPS « fait » (fa freddo), la PERSONNE « a » (ho freddo) : comme en français !",
    vocab: [["il tempo", "le temps (météo)"], ["fa caldo", "il fait chaud"], ["fa freddo", "il fait froid"], ["il sole", "le soleil"], ["piove", "il pleut"], ["nevica", "il neige"], ["il vento", "le vent"], ["nuvoloso", "nuageux"], ["la nebbia", "le brouillard"], ["il grado", "le degré"], ["la primavera", "le printemps"], ["l'estate", "l'été"], ["l'autunno", "l'automne"], ["l'inverno", "l'hiver"]],
    quiz: [
      mcq("« Quel temps fait-il ? » :", ["Che tempo è?", "Che tempo fa?", "Come è il tempo?", "Che ora fa?"], 1, "Che tempo fa?"),
      fill("Oggi ___ freddo. (il fait)", ["fa"], "fa freddo."),
      mcq("« J'ai froid » :", ["Fa freddo.", "Sono freddo.", "Ho freddo.", "Mi fa freddo."], 2, "Pour une personne : avere freddo."),
      fill("In inverno ___ in montagna. (il neige)", ["nevica"], "nevicare → nevica."),
      match("Associez", [["la primavera", "le printemps"], ["l'autunno", "l'automne"], ["l'estate", "l'été"], ["l'inverno", "l'hiver"]]),
      mcq("« Il y a du soleil » :", ["Fa sole.", "C'è il sole.", "È sole.", "Ha sole."], 1, "C'è il sole."),
      mcq("« Nuvoloso » :", ["pluvieux", "nuageux", "venteux", "ensoleillé"], 1, "nuvola = nuage."),
      tr("Traduisez : Il pleut.", ["piove", "sta piovendo"], "Piove."),
    ],
  },

  /* ------------------------------------------------------------ 17 */
  {
    id: "a2-lavoro-studio", module: "expr", title: "Travail, études et projets", emoji: "💼",
    intro: "Dire ce qu'on fait dans la vie, parler de ses études et de ses projets : la conversation des premières rencontres en version A2.",
    sections: [
      {
        title: "Che lavoro fai?",
        text: "Deux façons de le dire : <b>fare</b> + article + profession (<i>faccio l'insegnante</i>) ou <b>essere</b> + profession sans article (<i>sono insegnante</i>).",
        examples: [["Che lavoro fai? — Faccio il cameriere.", "Quel est ton métier ? — Je suis serveur."], ["Sono ingegnere e lavoro in un'azienda.", "Je suis ingénieur et je travaille dans une entreprise."], ["Lavoro a tempo pieno / part-time.", "Je travaille à temps plein / à temps partiel."]],
      },
      {
        title: "Les études",
        examples: [["Studio economia all'università.", "J'étudie l'économie à l'université."], ["Sono al terzo anno.", "Je suis en troisième année."], ["Ho un esame la settimana prossima.", "J'ai un examen la semaine prochaine."], ["Sto facendo uno stage in un'azienda italiana.", "Je fais un stage dans une entreprise italienne."]],
      },
      {
        title: "Les projets : pensare di, avere intenzione di",
        text: "<b>pensare di</b> + infinitif = penser (à) faire · <b>avere intenzione di</b> = avoir l'intention de · <b>sperare di</b> = espérer.",
        examples: [["Penso di cercare lavoro in Italia.", "Je pense chercher du travail en Italie."], ["Spero di trovare uno stage a Milano.", "J'espère trouver un stage à Milan."], ["L'anno prossimo ho intenzione di imparare il cinese.", "L'année prochaine, j'ai l'intention d'apprendre le chinois."]],
      },
    ],
    mnemo: "Fare + article (faccio IL medico), essere sans article (sono medico). Les deux sont corrects !",
    vocab: [["il lavoro", "le travail"], ["l'azienda", "l'entreprise"], ["l'ufficio", "le bureau"], ["il collega", "le collègue"], ["lo stipendio", "le salaire"], ["l'università", "l'université"], ["l'esame", "l'examen"], ["lo stage", "le stage"], ["la laurea", "le diplôme universitaire"], ["cercare lavoro", "chercher du travail"], ["sperare", "espérer"], ["prossimo", "prochain"], ["l'insegnante", "l'enseignant(e)"], ["il cameriere", "le serveur"]],
    quiz: [
      mcq("« Quel est ton métier ? » :", ["Che lavoro fai?", "Cosa lavori?", "Quale lavoro sei?", "Come lavori?"], 0, "Che lavoro fai?"),
      mcq("Forme correcte :", ["Faccio medico.", "Faccio il medico.", "Sono il medico.", "Ho il medico."], 1, "fare + article : faccio il medico."),
      fill("Spero ___ trovare un lavoro. (de)", ["di"], "sperare di + infinitif."),
      fill("Ho un ___ domani all'università. (examen)", ["esame"], "l'esame."),
      match("Associez", [["lo stipendio", "le salaire"], ["l'azienda", "l'entreprise"], ["il collega", "le collègue"], ["la laurea", "le diplôme"]]),
      mcq("« La semaine prochaine » :", ["la settimana scorsa", "la settimana prossima", "la prossima volta", "fra settimana"], 1, "prossimo = prochain."),
      mcq("« Avere intenzione di » =", ["avoir besoin de", "avoir l'intention de", "avoir envie de", "faire attention à"], 1, "avoir l'intention de."),
      tr("Traduisez : Je fais un stage.", ["faccio uno stage", "sto facendo uno stage", "io faccio uno stage"], "Faccio uno stage."),
    ],
  },
];

/** Questions ajoutées à l'examen A2 (à la suite des 8 d'origine) */
export const A2_EXAM_PLUS = [
  mcq("Le ragazze (uscire) ieri sera :", ["hanno uscito", "sono uscite", "sono usciti", "hanno uscite"], 1, "uscire → essere, accord féminin pluriel."),
  fill("Mi sono ___ alle otto. (svegliarsi, je suis un homme)", ["svegliato"], "Verbe pronominal → essere + accord."),
  mcq("« Je suis en train de travailler » :", ["Sono lavorando.", "Sto lavorando.", "Sto lavorare.", "Faccio lavorando."], 1, "stare + gérondif."),
  mcq("La pizza? ___ mangio stasera.", ["Lo", "La", "Le", "Gli"], 1, "pizza, féminin : la."),
  fill("Telefono a Marco → ___ telefono.", ["gli"], "à lui : gli."),
  mcq("Questo libro è ___ interessante di quello.", ["più", "che", "come", "molto"], 0, "più… di."),
  mcq("« Ne parle pas ! » (tu) :", ["Non parla!", "Non parlare!", "Non parli!", "Parla non!"], 1, "non + infinitif."),
  fill("Quanti anni hai? — ___ ho venti.", ["ne"], "ne = en (quantité)."),
  mcq("Pour demander poliment :", ["Voglio un'informazione.", "Vorrei un'informazione.", "Volevo un'informazione no.", "Voleva un'informazione."], 1, "vorrei."),
  mcq("« J'ai mal au dos » :", ["Ho male la schiena.", "Mi fa male la schiena.", "Mi fanno male la schiena.", "Sono male alla schiena."], 1, "mi fa male + nom singulier."),
  mcq("Au guichet : « andata e ritorno » =", ["aller simple", "aller-retour", "première classe", "billet de retour"], 1, "aller-retour."),
  tr("Traduisez : Il fait chaud aujourd'hui.", ["oggi fa caldo", "fa caldo oggi"], "Fa caldo."),
];
