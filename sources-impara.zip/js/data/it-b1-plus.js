/* =====================================================================
   Italien — compléments du palier B1 (CECRL, « Seuil »)
   ---------------------------------------------------------------------
   Calé sur le niveau B1 réel (descripteurs CECRL, Profilo della lingua
   italiana, certifications CELI 2 / CILS UNO-B1) : raconter une histoire
   au passé (trapassato prossimo), pronoms combinés et accord du participe,
   premiers emplois du subjonctif présent pour donner son avis, pronoms
   relatifs, hypothèse réelle et conseils au conditionnel, « si »
   impersonnel, connecteurs pour argumenter, discours rapporté au présent
   et au passé, et les situations de la vie autonome : travail et
   candidature, médias et numérique, émotions, ville et environnement,
   démarches administratives.
   Les leçons s'ajoutent APRÈS les 4 leçons d'origine du palier.
   ===================================================================== */

const mcq = (q, options, answer, explain = "") => ({ type: "mcq", q, options, answer, explain });
const fill = (q, answer, explain = "") => ({ type: "fill", q, answer, explain });
const match = (q, pairs, explain = "") => ({ type: "match", q, pairs, explain });
const tr = (q, answer, explain = "") => ({ type: "translate", q, answer, explain });

export const B1_PLUS = [
  /* ------------------------------------------------------------ 5 */
  {
    id: "b1-trapassato", module: "conj", title: "Raconter une histoire : le plus-que-parfait", emoji: "📖",
    intro: "Au niveau B1, on raconte un événement passé de façon structurée : le décor (imparfait), les actions (passé composé) et ce qui s'était passé AVANT (trapassato prossimo).",
    sections: [
      {
        title: "Trapassato prossimo = imparfait de avere / essere + participe",
        text: "Il exprime une action <b>antérieure</b> à une autre action passée : <i>quand je suis arrivé, le film <b>avait</b> déjà <b>commencé</b></i>. Mêmes règles d'auxiliaire et d'accord que le passé composé.",
        table: { cols: ["", "mangiare", "partire"], rows: [["io", "avevo mangiato", "ero partito/a"], ["tu", "avevi mangiato", "eri partito/a"], ["lui / lei", "aveva mangiato", "era partito/a"], ["noi", "avevamo mangiato", "eravamo partiti/e"], ["voi", "avevate mangiato", "eravate partiti/e"], ["loro", "avevano mangiato", "erano partiti/e"]] },
      },
      {
        title: "Dans un récit",
        examples: [["Quando sono arrivato al cinema, il film era già cominciato.", "Quand je suis arrivé au cinéma, le film avait déjà commencé."], ["Non avevo mai visto Venezia prima di quel viaggio.", "Je n'avais jamais vu Venise avant ce voyage."], ["Ero stanca perché avevo lavorato tutto il giorno.", "J'étais fatiguée parce que j'avais travaillé toute la journée."], ["Mi ha detto che aveva perso le chiavi.", "Il m'a dit qu'il avait perdu les clés."]],
      },
      {
        title: "Les mots pour organiser le récit",
        text: "<b>prima</b> (d'abord), <b>poi / dopo</b> (ensuite), <b>a un certo punto</b> (à un moment donné), <b>all'improvviso</b> (soudain), <b>alla fine</b> (à la fin), <b>prima di</b> + infinitif (avant de), <b>dopo aver</b> + participe (après avoir).",
        examples: [["Prima di uscire, ho chiuso la finestra.", "Avant de sortir, j'ai fermé la fenêtre."], ["Dopo aver cenato, siamo andati a fare una passeggiata.", "Après avoir dîné, nous sommes allés nous promener."], ["A un certo punto è andata via la luce.", "À un moment donné, il y a eu une coupure de courant."]],
      },
    ],
    mnemo: "Trapassato = « trois couches de passé » : le décor (era), l'action (è successo) et l'avant (era già successo).",
    vocab: [["prima di", "avant de"], ["dopo aver", "après avoir"], ["a un certo punto", "à un moment donné"], ["alla fine", "à la fin"], ["già", "déjà"], ["mai", "jamais"], ["succedere", "arriver, se passer"], ["accorgersi", "se rendre compte"], ["perdere", "perdre"], ["la storia", "l'histoire"], ["raccontare", "raconter"], ["ricordare", "se souvenir"]],
    quiz: [
      mcq("Quando sono arrivata, Marco ___ già ___.", ["è / uscito", "era / uscito", "ha / uscito", "aveva / uscito"], 1, "Action antérieure : trapassato ; uscire → essere."),
      fill("Non ___ mai visto il mare prima. (io, avere)", ["avevo"], "Imparfait de avere : avevo."),
      mcq("« Après avoir mangé » :", ["dopo mangiato", "dopo aver mangiato", "dopo di mangiare", "dopo avere mangiare"], 1, "dopo aver + participe passé."),
      fill("___ di partire, ho salutato tutti. (avant)", ["Prima", "prima"], "prima di + infinitif."),
      mcq("Quelle phrase utilise correctement le trapassato ?", ["Ieri avevo andato al mare.", "Ero contento perché avevo superato l'esame.", "Domani avevo partito.", "Avevo mangio la pizza."], 1, "Superare l'esame a eu lieu AVANT d'être content."),
      match("Associez", [["all'improvviso", "soudain"], ["alla fine", "à la fin"], ["accorgersi", "se rendre compte"], ["succedere", "se passer"]]),
      mcq("Le ragazze ___ già ___ quando abbiamo telefonato.", ["avevano / partite", "erano / partite", "erano / partito", "hanno / partito"], 1, "partire → essere, accord féminin pluriel."),
      tr("Traduisez : Il m'a dit qu'il avait perdu les clés.", ["mi ha detto che aveva perso le chiavi"], "aveva perso = trapassato."),
    ],
  },

  /* ------------------------------------------------------------ 6 */
  {
    id: "b1-pronomi-combinati", module: "gram", title: "Me lo, glielo, ce ne : les pronoms combinés", emoji: "🔗",
    intro: "« Je te le donne », « je le lui ai dit », « il y en a » : en italien, deux pronoms se combinent en un seul bloc. Et au passé, le participe s'accorde avec lo, la, li, le.",
    sections: [
      {
        title: "COI + COD : mi → me, ti → te, ci → ce, vi → ve",
        text: "Le pronom indirect passe devant et change de voyelle : <b>me lo, te la, ce li, ve le</b>. À la 3e personne, <b>gli / le</b> deviennent <b>glie-</b> et s'écrivent en un mot : <b>glielo, gliela, glieli, gliele, gliene</b> (à lui, à elle et à vous de politesse).",
        examples: [["Mi presti la penna? — Sì, te la presto.", "Tu me prêtes le stylo ? — Oui, je te le prête."], ["Hai dato il libro a Luca? — Sì, gliel'ho dato.", "Tu as donné le livre à Luca ? — Oui, je le lui ai donné."], ["Ci porti le foto? — Sì, ve le porto domani.", "Tu nous apportes les photos ? — Oui, je vous les apporte demain."]],
      },
      {
        title: "Avec ne : me ne, gliene, ce n'è",
        examples: [["Quanti caffè hai bevuto? — Ne ho bevuti tre.", "Combien de cafés as-tu bu ? — J'en ai bu trois."], ["C'è del pane? — Sì, ce n'è ancora.", "Il y a du pain ? — Oui, il en reste."], ["Me ne vado.", "Je m'en vais."]],
      },
      {
        title: "Au passé : le participe s'accorde avec lo, la, li, le et ne",
        text: "<i>La pizza? L'ho mangiat<b>a</b>.</i> — <i>I biglietti? Li ho comprat<b>i</b>.</i> — <i>Le chiavi? Le ho pres<b>e</b>.</i> L'élision <b>l'</b> se fait seulement au singulier.",
        examples: [["Hai visto Giulia? — Sì, l'ho vista ieri.", "Tu as vu Giulia ? — Oui, je l'ai vue hier."], ["Le lettere? Gliele ho spedite stamattina.", "Les lettres ? Je les lui ai envoyées ce matin."]],
      },
    ],
    mnemo: "Glie- est le « super-pronom » : à lui, à elle, à vous… on ne se trompe jamais, c'est toujours glielo, gliela, glieli, gliele.",
    vocab: [["prestare", "prêter"], ["portare", "apporter"], ["spedire", "envoyer (courrier)"], ["regalare", "offrir"], ["restituire", "rendre"], ["mostrare", "montrer"], ["spiegare", "expliquer"], ["andarsene", "s'en aller"], ["volerci", "falloir (temps, quantité)"], ["metterci", "mettre (du temps)"], ["il regalo", "le cadeau"], ["la chiave", "la clé"]],
    quiz: [
      mcq("Mi dai il numero? — Sì, ___ do.", ["me lo", "te lo", "mi lo", "lo ti"], 1, "à toi + le : te lo."),
      mcq("Hai detto la verità a Marco? — Sì, ___ ho detta.", ["gli la", "glie la", "gliel'", "la gli"], 2, "gli + la → gliela → gliel' devant ho."),
      fill("Le chiavi? Le ho ___. (prendere)", ["prese"], "Accord avec le : prese."),
      mcq("Quante foto hai fatto? — ___ ho fatte cinquanta.", ["Le", "Ne", "Ci", "Lo"], 1, "Quantité : ne (+ accord : fatte)."),
      fill("Ci mandi la mail? — Sì, ___ la mando subito.", ["ve"], "à vous : ve la."),
      match("Associez", [["prestare", "prêter"], ["restituire", "rendre"], ["spedire", "envoyer"], ["andarsene", "s'en aller"]]),
      mcq("« Il faut deux heures » :", ["Ci vogliono due ore.", "Ci mettono due ore.", "Ne vuole due ore.", "Si vuole due ore."], 0, "volerci : ci vuole / ci vogliono."),
      tr("Traduisez : Je le lui ai donné (le livre, à lui).", ["gliel'ho dato", "glielo ho dato"], "gli + lo = glielo → gliel'ho."),
    ],
  },

  /* ------------------------------------------------------------ 7 */
  {
    id: "b1-congiuntivo-intro", module: "conj", title: "Donner son avis : penso che + subjonctif", emoji: "💭",
    intro: "Dès le B1, les Italiens attendent le congiuntivo après les verbes d'opinion, d'espoir et de volonté. On commence par les formes les plus fréquentes ; le palier B2 complétera tous les temps.",
    sections: [
      {
        title: "Quand ? Opinion, doute, souhait, volonté",
        text: "<b>Penso / credo che</b>, <b>spero che</b>, <b>voglio che</b>, <b>ho paura che</b>, <b>mi sembra che</b>, <b>bisogna che</b>, <b>è meglio che</b>… + congiuntivo. Mais avec un fait certain (<i>so che, è vero che</i>) → indicatif.",
        examples: [["Penso che sia una buona idea.", "Je pense que c'est une bonne idée."], ["Spero che tu stia meglio.", "J'espère que tu vas mieux."], ["Credo che abbiano ragione.", "Je crois qu'ils ont raison."], ["So che è una buona idea.", "Je sais que c'est une bonne idée (certitude → indicatif)."]],
      },
      {
        title: "Les formes à connaître d'abord",
        table: { cols: ["", "essere", "avere", "parlare", "prendere"], rows: [["io / tu / lui", "sia", "abbia", "parli", "prenda"], ["noi", "siamo", "abbiamo", "parliamo", "prendiamo"], ["voi", "siate", "abbiate", "parliate", "prendiate"], ["loro", "siano", "abbiano", "parlino", "prendano"]] },
      },
      {
        title: "Même sujet ? Alors di + infinitif",
        text: "Si le sujet est le même, on n'emploie pas <i>che</i> : <i>Penso <b>di</b> partire</i> (je pense partir), <i>Spero <b>di</b> vederti</i> (j'espère te voir).",
        examples: [["Spero di vederti presto.", "J'espère te voir bientôt."], ["Spero che tu venga alla festa.", "J'espère que tu viendras à la fête."]],
      },
    ],
    mnemo: "Au singulier, les trois personnes sont identiques (che io sia, che tu sia, che lui sia) : ajoutez le sujet si besoin pour être clair.",
    vocab: [["pensare che", "penser que"], ["credere che", "croire que"], ["sperare che", "espérer que"], ["mi sembra che", "il me semble que"], ["bisogna che", "il faut que"], ["è meglio che", "il vaut mieux que"], ["avere paura che", "avoir peur que"], ["avere ragione", "avoir raison"], ["avere torto", "avoir tort"], ["l'opinione", "l'opinion"], ["secondo me", "selon moi"], ["essere sicuro", "être sûr"]],
    quiz: [
      mcq("Penso che Marco ___ stanco.", ["è", "sia", "sarà", "essere"], 1, "Opinion → congiuntivo : sia."),
      mcq("So che Marco ___ stanco.", ["è", "sia", "siano", "fosse"], 0, "Certitude (so che) → indicatif."),
      fill("Spero che tu ___ bene. (stare)", ["stia"], "stare → che tu stia."),
      mcq("« J'espère te voir bientôt » :", ["Spero che ti veda presto.", "Spero di vederti presto.", "Spero vederti presto.", "Spero che vederti presto."], 1, "Même sujet : sperare di + infinitif."),
      fill("Credo che loro ___ ragione. (avere)", ["abbiano"], "avere → abbiano."),
      match("Associez", [["avere torto", "avoir tort"], ["bisogna che", "il faut que"], ["mi sembra che", "il me semble que"], ["secondo me", "selon moi"]]),
      mcq("È meglio che voi ___ il treno.", ["prendete", "prendiate", "prendano", "prendere"], 1, "voi : prendiate."),
      tr("Traduisez : Je pense que c'est une bonne idée.", ["penso che sia una buona idea", "credo che sia una buona idea"], "penso che + sia."),
    ],
  },

  /* ------------------------------------------------------------ 8 */
  {
    id: "b1-relativi", module: "gram", title: "Che, cui, chi : relier ses phrases", emoji: "🪢",
    intro: "Pour faire des phrases plus riches : « la personne dont je parle », « la ville où j'habite », « celui qui… ».",
    sections: [
      {
        title: "Che = qui / que",
        text: "<b>che</b> remplace un sujet ou un complément direct, jamais après une préposition.",
        examples: [["Il ragazzo che parla è mio fratello.", "Le garçon qui parle est mon frère."], ["Il libro che leggo è bellissimo.", "Le livre que je lis est magnifique."]],
      },
      {
        title: "Préposition + cui",
        text: "Après une préposition : <b>di cui</b> (dont), <b>a cui</b> (à qui), <b>in cui</b> (où), <b>con cui</b> (avec qui), <b>per cui</b> (pour lequel / c'est pourquoi). <b>il cui</b> = dont le.",
        examples: [["La persona di cui ti ho parlato.", "La personne dont je t'ai parlé."], ["La città in cui abito è piccola.", "La ville où j'habite est petite."], ["L'amica con cui sono partita.", "L'amie avec qui je suis partie."], ["Lo scrittore il cui libro ha vinto.", "L'écrivain dont le livre a gagné."]],
      },
      {
        title: "Chi, quello che, tutto quello che",
        text: "<b>chi</b> = celui qui / ceux qui (sens général, verbe au singulier). <b>quello che / ciò che</b> = ce que. <b>tutto quello che</b> = tout ce que.",
        examples: [["Chi dorme non piglia pesci.", "Qui dort ne prend pas de poisson (proverbe)."], ["Fai quello che vuoi.", "Fais ce que tu veux."], ["Grazie per tutto quello che hai fatto.", "Merci pour tout ce que tu as fait."]],
      },
    ],
    mnemo: "Une préposition devant ? → cui. Pas de préposition ? → che. C'est (presque) tout !",
    vocab: [["che", "qui, que"], ["di cui", "dont"], ["in cui", "où"], ["con cui", "avec qui"], ["a cui", "à qui"], ["il quale / la quale", "lequel / laquelle"], ["chi", "celui qui"], ["quello che", "ce que"], ["tutto quello che", "tout ce que"], ["lo scrittore", "l'écrivain"], ["il motivo", "la raison"], ["parlare di", "parler de"]],
    quiz: [
      mcq("La ragazza ___ ho conosciuto ieri si chiama Sara.", ["che", "cui", "chi", "di cui"], 0, "COD → che."),
      mcq("È il film ___ ti ho parlato.", ["che", "di cui", "in cui", "a cui"], 1, "parlare DI → di cui."),
      fill("La casa in ___ abito è vecchia.", ["cui"], "in cui = où."),
      mcq("« Fais ce que tu veux » :", ["Fai che vuoi.", "Fai quello che vuoi.", "Fai cui vuoi.", "Fai chi vuoi."], 1, "quello che = ce que."),
      mcq("___ cerca, trova.", ["Che", "Chi", "Cui", "Quale"], 1, "chi = celui qui (proverbe)."),
      match("Associez", [["di cui", "dont"], ["in cui", "où"], ["con cui", "avec qui"], ["chi", "celui qui"]]),
      fill("Il motivo per ___ sono qui è semplice.", ["cui"], "per cui = pour laquelle."),
      tr("Traduisez : La personne dont je t'ai parlé.", ["la persona di cui ti ho parlato"], "di cui = dont."),
    ],
  },

  /* ------------------------------------------------------------ 9 */
  {
    id: "b1-se-consigli", module: "gram", title: "Si… et conseils : hypothèse réelle et dovresti", emoji: "🔀",
    intro: "Faire des projets sous condition (« s'il fait beau, on ira à la mer ») et donner des conseils avec le conditionnel (« tu devrais te reposer »).",
    sections: [
      {
        title: "Se + présent → présent / futur / impératif",
        text: "Pour une condition réelle ou probable. Attention : après <b>se</b> au futur, l'italien met souvent le futur aussi (<i>se avrò tempo, verrò</i>), contrairement au français.",
        examples: [["Se piove, restiamo a casa.", "S'il pleut, on reste à la maison."], ["Se avrò tempo, ti chiamerò.", "Si j'ai le temps, je t'appellerai."], ["Se hai fame, mangia qualcosa!", "Si tu as faim, mange quelque chose !"]],
      },
      {
        title: "Conseiller : dovresti, potresti, al tuo posto",
        text: "<b>dovere</b> et <b>potere</b> au conditionnel adoucissent un conseil : <i>dovresti</i> (tu devrais), <i>potresti</i> (tu pourrais), <i>sarebbe meglio</i> (ce serait mieux). <b>Al posto tuo / Se fossi in te</b> = à ta place.",
        examples: [["Dovresti dormire di più.", "Tu devrais dormir davantage."], ["Potresti chiedere aiuto a tua sorella.", "Tu pourrais demander de l'aide à ta sœur."], ["Al posto tuo, accetterei.", "À ta place, j'accepterais."], ["Sarebbe meglio partire presto.", "Il vaudrait mieux partir tôt."]],
      },
      {
        title: "Souhaits et regrets polis",
        examples: [["Mi piacerebbe vivere a Roma.", "J'aimerais vivre à Rome."], ["Avrei voluto venire, ma ero malato.", "J'aurais voulu venir, mais j'étais malade."]],
      },
    ],
    mnemo: "Dovresti / potresti = l'italien « avec des gants » : on conseille sans donner d'ordre.",
    vocab: [["se", "si"], ["dovresti", "tu devrais"], ["potresti", "tu pourrais"], ["sarebbe meglio", "il vaudrait mieux"], ["al posto tuo", "à ta place"], ["il consiglio", "le conseil"], ["consigliare", "conseiller"], ["chiedere aiuto", "demander de l'aide"], ["riposarsi", "se reposer"], ["accettare", "accepter"], ["rinunciare", "renoncer"], ["decidere", "décider"]],
    quiz: [
      mcq("Se ___ bel tempo, andiamo al mare.", ["fa", "farebbe", "faccia", "fare"], 0, "Condition réelle : se + présent."),
      fill("Sei stanco: ___ riposarti. (tu devrais)", ["dovresti"], "dovere au conditionnel : dovresti."),
      mcq("« À ta place, j'accepterais » :", ["Al posto tuo, accetto.", "Al posto tuo, accetterei.", "Al tuo posto, accettavo.", "Se tuo posto, accetterei."], 1, "Conditionnel : accetterei."),
      fill("Se avrò tempo, ti ___. (chiamare, futur)", ["chiamerò", "chiamero"], "Futur dans la principale."),
      mcq("Pour un conseil poli :", ["Devi venire!", "Potresti venire?", "Vieni!", "Vengo."], 1, "potresti = tu pourrais."),
      match("Associez", [["consigliare", "conseiller"], ["rinunciare", "renoncer"], ["riposarsi", "se reposer"], ["sarebbe meglio", "il vaudrait mieux"]]),
      mcq("« J'aurais voulu venir » :", ["Avrei voluto venire.", "Vorrei venuto.", "Ho voluto venire.", "Avevo voluto venire."], 0, "Conditionnel passé : avrei voluto."),
      tr("Traduisez : Tu devrais dormir davantage.", ["dovresti dormire di più"], "dovresti + infinitif."),
    ],
  },

  /* ------------------------------------------------------------ 10 */
  {
    id: "b1-si-impersonale", module: "gram", title: "In Italia si mangia bene : le « si » impersonnel", emoji: "🍽️",
    intro: "« On mange bien », « ici on parle italien », « ça ne se fait pas » : le si impersonnel est partout, dans les règles, les recettes, les panneaux et les généralités.",
    sections: [
      {
        title: "Si + verbe à la 3e personne",
        text: "Sans complément ou avec un complément singulier : verbe au <b>singulier</b>. Avec un nom pluriel : verbe au <b>pluriel</b> (si passivant).",
        examples: [["In Italia si mangia bene.", "En Italie, on mange bien."], ["Qui si parla inglese.", "Ici, on parle anglais."], ["In estate si vendono molti gelati.", "En été, on vend beaucoup de glaces."], ["Come si dice « merci » in italiano?", "Comment dit-on « merci » en italien ?"]],
      },
      {
        title: "Règles et usages",
        examples: [["Non si fuma.", "Défense de fumer."], ["Non si fa così!", "Ça ne se fait pas !"], ["Si prega di non toccare.", "Prière de ne pas toucher."], ["Si apre la scatola e si aggiunge l'acqua.", "On ouvre la boîte et on ajoute l'eau."]],
      },
      {
        title: "Avec un verbe pronominal : ci si",
        text: "Pour un verbe déjà pronominal, on dit <b>ci si</b> : <i>ci si alza presto</i> (on se lève tôt). Avec essere, l'adjectif est au pluriel : <i>si è contenti</i>.",
        examples: [["La domenica ci si alza tardi.", "Le dimanche, on se lève tard."], ["Quando si è giovani, si ha tanta energia.", "Quand on est jeune, on a beaucoup d'énergie."]],
      },
    ],
    mnemo: "Si + singulier pour « on » en général ; si + pluriel quand l'objet est pluriel : si vende una casa, si vendono case.",
    vocab: [["si dice", "on dit"], ["si può", "on peut"], ["si deve", "on doit"], ["non si fuma", "défense de fumer"], ["si prega di", "prière de"], ["vietato", "interdit"], ["l'usanza", "la coutume"], ["la regola", "la règle"], ["di solito", "d'habitude"], ["aggiungere", "ajouter"], ["vendere", "vendre"], ["affittare", "louer"]],
    quiz: [
      mcq("In Italia ___ molta pasta.", ["si mangia", "si mangiano", "ci mangia", "mangia si"], 0, "Nom singulier (pasta) → singulier."),
      mcq("Qui ___ appartamenti.", ["si affitta", "si affittano", "affitta si", "ci si affitta"], 1, "Nom pluriel → si affittano."),
      fill("Come ___ dice « bonjour » in italiano?", ["si"], "Come si dice…?"),
      mcq("La domenica ___ alza tardi.", ["si si", "ci si", "si ci", "ne si"], 1, "Verbe pronominal : ci si alza."),
      mcq("Un panneau « Non si fuma » signifie :", ["On ne fume plus", "Défense de fumer", "Fumer tue", "Zone fumeurs"], 1, "Interdiction."),
      match("Associez", [["vietato", "interdit"], ["si prega di", "prière de"], ["l'usanza", "la coutume"], ["affittare", "louer"]]),
      fill("Quando ___ è stanchi, si dorme bene.", ["si"], "si è + adjectif pluriel."),
      tr("Traduisez : En Italie, on mange bien.", ["in italia si mangia bene"], "si impersonnel."),
    ],
  },

  /* ------------------------------------------------------------ 11 */
  {
    id: "b1-connettivi", module: "expr", title: "Argumenter : secondo me, però, quindi, anche se", emoji: "🗣️",
    intro: "Le B1 demande de défendre un point de vue simple : donner son avis, justifier, opposer, conclure. Les connecteurs font toute la différence.",
    sections: [
      {
        title: "Donner son avis, être d'accord ou pas",
        examples: [["Secondo me, è troppo caro.", "Selon moi, c'est trop cher."], ["Per me va bene.", "Pour moi, ça va."], ["Sono d'accordo con te.", "Je suis d'accord avec toi."], ["Non sono per niente d'accordo.", "Je ne suis pas du tout d'accord."], ["Dipende.", "Ça dépend."]],
      },
      {
        title: "Cause, conséquence, opposition",
        text: "<b>perché</b> (parce que) — <b>siccome</b> (comme, en début de phrase) — <b>quindi / perciò</b> (donc) — <b>però / ma</b> (mais) — <b>invece</b> (au contraire, alors que) — <b>anche se</b> (même si) — <b>comunque</b> (de toute façon, cependant).",
        examples: [["Siccome pioveva, siamo rimasti a casa.", "Comme il pleuvait, nous sommes restés à la maison."], ["È tardi, quindi vado a dormire.", "Il est tard, donc je vais dormir."], ["Io bevo il caffè, lei invece beve il tè.", "Moi je bois du café, elle, en revanche, boit du thé."], ["Anche se è difficile, ci provo.", "Même si c'est difficile, j'essaie."]],
      },
      {
        title: "Structurer et conclure",
        text: "<b>prima di tutto</b> (tout d'abord), <b>inoltre</b> (en plus), <b>da una parte… dall'altra</b> (d'un côté… de l'autre), <b>cioè</b> (c'est-à-dire), <b>insomma</b> (bref), <b>in conclusione</b> (en conclusion).",
        examples: [["Da una parte la città è bella, dall'altra è troppo cara.", "D'un côté la ville est belle, de l'autre elle est trop chère."], ["Insomma, è stata una bella giornata.", "Bref, ça a été une belle journée."]],
      },
    ],
    mnemo: "Siccome ouvre la phrase (comme…), perché vient après (… parce que). « Siccome piove, resto » / « Resto perché piove ».",
    vocab: [["secondo me", "selon moi"], ["essere d'accordo", "être d'accord"], ["dipende", "ça dépend"], ["siccome", "comme (cause)"], ["quindi", "donc"], ["però", "mais, pourtant"], ["invece", "au contraire"], ["anche se", "même si"], ["comunque", "de toute façon"], ["inoltre", "de plus"], ["cioè", "c'est-à-dire"], ["insomma", "bref"]],
    quiz: [
      mcq("___ era tardi, abbiamo preso un taxi.", ["Perché", "Siccome", "Quindi", "Invece"], 1, "Cause en début de phrase : siccome."),
      fill("Sono stanco, ___ vado a letto. (donc)", ["quindi", "perciò"], "quindi / perciò = donc."),
      mcq("« Même si » :", ["anche se", "se anche", "ancora se", "comunque"], 0, "anche se."),
      mcq("Io amo il mare, mio fratello ___ preferisce la montagna.", ["quindi", "invece", "siccome", "cioè"], 1, "Opposition : invece."),
      match("Associez", [["insomma", "bref"], ["inoltre", "de plus"], ["cioè", "c'est-à-dire"], ["dipende", "ça dépend"]]),
      fill("Sono d'___ con te.", ["accordo"], "essere d'accordo."),
      mcq("Pour conclure un petit discours :", ["Prima di tutto", "In conclusione", "Da una parte", "Siccome"], 1, "in conclusione."),
      tr("Traduisez : Selon moi, c'est trop cher.", ["secondo me è troppo caro", "secondo me, è troppo caro"], "secondo me."),
    ],
  },

  /* ------------------------------------------------------------ 12 */
  {
    id: "b1-discorso-indiretto", module: "gram", title: "Il a dit que… : rapporter les paroles", emoji: "📣",
    intro: "Raconter ce que quelqu'un a dit, demandé ou conseillé : un réflexe essentiel à l'oral comme à l'écrit.",
    sections: [
      {
        title: "Au présent : rien ne change (ou presque)",
        examples: [["Marco: « Sono stanco. » → Marco dice che è stanco.", "Marco dit qu'il est fatigué."], ["Anna: « Vengo domani. » → Anna dice che viene domani.", "Anna dit qu'elle vient demain."]],
      },
      {
        title: "Au passé : présent → imparfait, passé composé → trapassato",
        text: "Avec <b>ha detto che / ha raccontato che</b> : le présent devient <b>imparfait</b>, le passé composé devient <b>trapassato</b>, le futur devient <b>conditionnel passé</b>. Les mots changent aussi : <i>oggi → quel giorno, domani → il giorno dopo, qui → lì</i>.",
        examples: [["Marco ha detto che era stanco.", "Marco a dit qu'il était fatigué."], ["Ha detto che aveva già mangiato.", "Il a dit qu'il avait déjà mangé."], ["Mi ha scritto che sarebbe arrivata il giorno dopo.", "Elle m'a écrit qu'elle arriverait le lendemain."]],
      },
      {
        title: "Questions et ordres rapportés",
        text: "Question : <b>mi ha chiesto se…</b> (si) ou avec le mot interrogatif (<i>dove, quando, perché</i>). Ordre : <b>mi ha detto di</b> + infinitif.",
        examples: [["Mi ha chiesto se volevo un caffè.", "Il m'a demandé si je voulais un café."], ["Le ho chiesto dove abitava.", "Je lui ai demandé où elle habitait."], ["Il medico mi ha detto di riposare.", "Le médecin m'a dit de me reposer."]],
      },
    ],
    mnemo: "Au passé, tout recule d'une case : è → era, è andato → era andato, andrà → sarebbe andato.",
    vocab: [["dire che", "dire que"], ["chiedere se", "demander si"], ["raccontare", "raconter"], ["rispondere", "répondre"], ["spiegare", "expliquer"], ["promettere", "promettre"], ["il giorno dopo", "le lendemain"], ["il giorno prima", "la veille"], ["quel giorno", "ce jour-là"], ["lì", "là"], ["il messaggio", "le message"], ["la notizia", "la nouvelle"]],
    quiz: [
      mcq("Luca: « Ho fame. » → Luca ha detto che ___ fame.", ["ha", "aveva", "avrà", "ebbe"], 1, "Présent → imparfait."),
      mcq("Sara: « Sono partita. » → Sara ha detto che ___ partita.", ["è", "era", "sarà", "sia"], 1, "Passé composé → trapassato : era partita."),
      fill("Mi ha chiesto ___ volevo venire. (si)", ["se"], "chiedere se = demander si."),
      mcq("Le médecin : « Riposa ! » → Il medico mi ha detto ___ riposare.", ["che", "di", "a", "se"], 1, "Ordre rapporté : dire di + infinitif."),
      mcq("« demain » devient dans un récit au passé :", ["ieri", "il giorno dopo", "il giorno prima", "oggi"], 1, "domani → il giorno dopo."),
      match("Associez", [["promettere", "promettre"], ["rispondere", "répondre"], ["il giorno prima", "la veille"], ["la notizia", "la nouvelle"]]),
      fill("Ha detto che ___ arrivata il giorno dopo. (conditionnel passé de essere)", ["sarebbe"], "futur → conditionnel passé."),
      tr("Traduisez : Il m'a demandé si je voulais un café.", ["mi ha chiesto se volevo un caffè", "mi ha chiesto se volevo un caffe"], "chiedere se + imparfait."),
    ],
  },

  /* ------------------------------------------------------------ 13 */
  {
    id: "b1-lavoro", module: "vocab", title: "Chercher un emploi : CV et entretien", emoji: "🧑‍💼",
    intro: "Lire une annonce, préparer son curriculum, se présenter à un entretien : le vocabulaire et les phrases types du monde du travail.",
    sections: [
      {
        title: "L'annonce et la candidature",
        examples: [["Cercasi cameriere con esperienza.", "Recherche serveur avec expérience."], ["Inviare il curriculum all'indirizzo email indicato.", "Envoyer le CV à l'adresse e-mail indiquée."], ["Vorrei candidarmi per il posto di receptionist.", "Je voudrais postuler au poste de réceptionniste."], ["Contratto a tempo determinato, part-time.", "Contrat à durée déterminée, à temps partiel."]],
      },
      {
        title: "Au colloquio (entretien)",
        examples: [["Mi parli un po' di Lei.", "Parlez-moi un peu de vous."], ["Ho lavorato due anni in un'agenzia di viaggi.", "J'ai travaillé deux ans dans une agence de voyages."], ["Il mio punto di forza è la precisione.", "Mon point fort, c'est la précision."], ["Sono disponibile da subito.", "Je suis disponible immédiatement."], ["Quando posso sapere la vostra risposta?", "Quand puis-je connaître votre réponse ?"]],
      },
      {
        title: "Registre formel : Lei",
        text: "À l'entretien, on vouvoie avec <b>Lei</b> (3e personne du singulier) : <i>Lei parla inglese? Mi dica. Si accomodi.</i> (asseyez-vous).",
        examples: [["Si accomodi, prego.", "Asseyez-vous, je vous en prie."], ["Ha domande per noi?", "Avez-vous des questions pour nous ?"]],
      },
    ],
    mnemo: "Le curriculum se dit aussi « il CV » (ci-vu). Et « cercasi » en tête d'annonce = « on cherche ».",
    vocab: [["il colloquio", "l'entretien"], ["il curriculum", "le CV"], ["candidarsi", "postuler"], ["l'annuncio", "l'annonce"], ["l'esperienza", "l'expérience"], ["il contratto", "le contrat"], ["a tempo determinato", "à durée déterminée"], ["a tempo pieno", "à temps plein"], ["lo stipendio", "le salaire"], ["le competenze", "les compétences"], ["il punto di forza", "le point fort"], ["disponibile", "disponible"], ["assumere", "embaucher"], ["licenziare", "licencier"]],
    quiz: [
      mcq("« L'entretien d'embauche » :", ["il colloquio", "il collegio", "la colazione", "il concorso"], 0, "il colloquio di lavoro."),
      fill("Vorrei ___ per questo posto. (postuler)", ["candidarmi"], "candidarsi → vorrei candidarmi."),
      mcq("« Contrat à durée indéterminée » :", ["a tempo determinato", "a tempo indeterminato", "a tempo pieno", "part-time"], 1, "indeterminato = indéterminé."),
      mcq("À un entretien, on dit plutôt :", ["Siediti!", "Si accomodi.", "Accomodati, bello.", "Siedi."], 1, "Registre formel : Lei."),
      match("Associez", [["assumere", "embaucher"], ["licenziare", "licencier"], ["lo stipendio", "le salaire"], ["disponibile", "disponible"]]),
      fill("Ho due anni di ___ nel turismo. (expérience)", ["esperienza"], "l'esperienza."),
      mcq("« Cercasi » dans une annonce signifie :", ["on cherche", "on vend", "on a trouvé", "on loue"], 0, "cercasi = on cherche."),
      tr("Traduisez : Je suis disponible immédiatement.", ["sono disponibile da subito", "sono disponibile subito"], "da subito."),
    ],
  },

  /* ------------------------------------------------------------ 14 */
  {
    id: "b1-media", module: "vocab", title: "Médias, internet et téléphone", emoji: "📱",
    intro: "Parler des nouvelles, des réseaux sociaux et des petits soucis numériques : un thème incontournable des certifications B1.",
    sections: [
      {
        title: "S'informer",
        examples: [["Hai sentito la notizia?", "Tu as entendu la nouvelle ?"], ["Leggo il giornale online ogni mattina.", "Je lis le journal en ligne chaque matin."], ["Al telegiornale hanno detto che domani c'è sciopero.", "Au journal télévisé, ils ont dit que demain il y a grève."]],
      },
      {
        title: "Les réseaux et les messages",
        examples: [["Ti mando il link su WhatsApp.", "Je t'envoie le lien sur WhatsApp."], ["Ha pubblicato una foto e ha ricevuto cento « mi piace ».", "Il a publié une photo et a reçu cent « j'aime »."], ["Seguo molti account di cucina.", "Je suis beaucoup de comptes de cuisine."]],
      },
      {
        title: "Les problèmes techniques",
        examples: [["Il telefono è scarico.", "Le téléphone est déchargé."], ["Non c'è campo.", "Il n'y a pas de réseau."], ["Ho dimenticato la password.", "J'ai oublié le mot de passe."], ["Devo scaricare l'app e registrarmi.", "Je dois télécharger l'appli et m'inscrire."], ["Si è bloccato il computer.", "L'ordinateur a planté."]],
      },
    ],
    mnemo: "« Non c'è campo » : en italien, le réseau téléphonique est un « champ » (campo). Et un téléphone vide est « scarico » (déchargé).",
    vocab: [["la notizia", "la nouvelle"], ["il telegiornale", "le journal télévisé"], ["il giornale", "le journal"], ["pubblicare", "publier"], ["condividere", "partager"], ["seguire", "suivre"], ["scaricare", "télécharger"], ["registrarsi", "s'inscrire"], ["la password", "le mot de passe"], ["scarico", "déchargé"], ["il campo", "le réseau"], ["il caricabatterie", "le chargeur"], ["lo schermo", "l'écran"], ["bloccarsi", "planter, se bloquer"]],
    quiz: [
      mcq("« Il n'y a pas de réseau » :", ["Non c'è rete di pesca.", "Non c'è campo.", "Non c'è linea di treno.", "Non c'è schermo."], 1, "Non c'è campo."),
      fill("Ho dimenticato la ___ del mio account.", ["password"], "la password."),
      mcq("« Partager une vidéo » :", ["scaricare un video", "condividere un video", "seguire un video", "bloccare un video"], 1, "condividere = partager."),
      mcq("Il telefono è ___ : mi presti il caricabatterie?", ["carico", "scarico", "bloccato", "pieno"], 1, "scarico = déchargé."),
      match("Associez", [["il telegiornale", "le journal télévisé"], ["registrarsi", "s'inscrire"], ["lo schermo", "l'écran"], ["pubblicare", "publier"]]),
      fill("Devo ___ l'app. (télécharger)", ["scaricare"], "scaricare."),
      mcq("« Hai sentito la notizia? » signifie :", ["Tu as entendu la nouvelle ?", "Tu as senti la note ?", "Tu as vu le journal ?", "Tu as écouté la musique ?"], 0, "la notizia = la nouvelle."),
      tr("Traduisez : Je t'envoie le lien.", ["ti mando il link", "ti invio il link"], "mandare / inviare."),
    ],
  },

  /* ------------------------------------------------------------ 15 */
  {
    id: "b1-emozioni", module: "expr", title: "Émotions et sentiments", emoji: "🎭",
    intro: "Dire ce qu'on ressent, réagir aux nouvelles des autres et parler de ses relations : la dimension personnelle du B1.",
    sections: [
      {
        title: "Comment je me sens",
        text: "<b>sentirsi</b> + adjectif : <i>mi sento solo, ti senti meglio?</i> Beaucoup d'émotions s'expriment avec <b>avere</b> : <i>avere paura, avere voglia, avere nostalgia</i>.",
        examples: [["Mi sento un po' giù oggi.", "Je me sens un peu déprimé aujourd'hui."], ["Sono preoccupata per l'esame.", "Je suis inquiète pour l'examen."], ["Ho paura dei cani.", "J'ai peur des chiens."], ["Sono emozionatissimo!", "Je suis super ému / excité !"]],
      },
      {
        title: "Réagir",
        examples: [["Che bello! Sono felice per te!", "Super ! Je suis heureux pour toi !"], ["Mi dispiace tanto.", "Je suis vraiment désolé."], ["Che peccato!", "Quel dommage !"], ["Dai, non ti preoccupare.", "Allez, ne t'inquiète pas."], ["Ma dai! Davvero?", "Non ! Vraiment ?"]],
      },
      {
        title: "Les relations",
        examples: [["Andiamo d'accordo.", "On s'entend bien."], ["Ci siamo litigati, ma poi abbiamo fatto pace.", "On s'est disputés, mais ensuite on s'est réconciliés."], ["Mi manchi.", "Tu me manques."]],
      },
    ],
    mnemo: "« Mi manchi » se construit à l'envers du français : TU es le sujet. Mi mancano i miei amici = mes amis me manquent.",
    vocab: [["sentirsi", "se sentir"], ["preoccupato", "inquiet"], ["deluso", "déçu"], ["arrabbiato", "en colère"], ["emozionato", "ému, excité"], ["giù", "déprimé, abattu"], ["avere paura", "avoir peur"], ["la nostalgia", "la nostalgie"], ["mancare", "manquer"], ["litigare", "se disputer"], ["fare pace", "se réconcilier"], ["andare d'accordo", "bien s'entendre"], ["mi dispiace", "je suis désolé"], ["che peccato", "quel dommage"]],
    quiz: [
      mcq("« Tu me manques » :", ["Ti manco.", "Mi manchi.", "Mi mancano.", "Manco te."], 1, "mancare : tu es le sujet → mi manchi."),
      fill("Mi ___ un po' giù. (sentirsi)", ["sento"], "mi sento."),
      mcq("Un ami a raté son examen. Vous dites :", ["Che bello!", "Mi dispiace.", "Ma dai, che fortuna!", "Mi manchi."], 1, "mi dispiace."),
      mcq("« Se réconcilier » :", ["fare pace", "fare la pace di", "litigare", "andare d'accordo"], 0, "fare pace."),
      match("Associez", [["deluso", "déçu"], ["arrabbiato", "en colère"], ["preoccupato", "inquiet"], ["emozionato", "ému"]]),
      fill("Mi ___ i miei genitori. (manquer, pluriel)", ["mancano"], "Les parents = sujet pluriel."),
      mcq("« Non ti preoccupare » signifie :", ["Ne t'inquiète pas", "Ne te fâche pas", "Ne pars pas", "Ne t'en va pas"], 0, "preoccuparsi = s'inquiéter."),
      tr("Traduisez : Nous nous entendons bien.", ["andiamo d'accordo", "noi andiamo d'accordo"], "andare d'accordo."),
    ],
  },

  /* ------------------------------------------------------------ 16 */
  {
    id: "b1-citta-ambiente", module: "vocab", title: "La ville et l'environnement", emoji: "♻️",
    intro: "Circulation, pollution, tri des déchets, transports : parler des problèmes de sa ville et proposer des solutions simples.",
    sections: [
      {
        title: "Les problèmes",
        examples: [["In centro c'è sempre traffico.", "Dans le centre, il y a toujours des embouteillages."], ["L'inquinamento è un problema serio.", "La pollution est un problème sérieux."], ["Gli affitti sono troppo cari.", "Les loyers sont trop chers."], ["Mancano i parcheggi.", "Il manque des places de parking."]],
      },
      {
        title: "Les gestes du quotidien",
        examples: [["Faccio la raccolta differenziata.", "Je fais le tri sélectif."], ["Bisogna risparmiare acqua ed energia.", "Il faut économiser l'eau et l'énergie."], ["Vado al lavoro in bici o con i mezzi pubblici.", "Je vais au travail à vélo ou en transports en commun."], ["Non buttare la plastica nell'indifferenziato!", "Ne jette pas le plastique dans les ordures ménagères !"]],
      },
      {
        title: "Proposer",
        examples: [["Secondo me il comune dovrebbe creare più piste ciclabili.", "Selon moi, la mairie devrait créer plus de pistes cyclables."], ["Sarebbe utile avere più zone pedonali.", "Ce serait utile d'avoir plus de zones piétonnes."]],
      },
    ],
    mnemo: "I mezzi (pubblici) = les transports en commun. Prendre i mezzi, c'est l'opposé de prendre la macchina.",
    vocab: [["il traffico", "la circulation"], ["l'inquinamento", "la pollution"], ["l'ambiente", "l'environnement"], ["la raccolta differenziata", "le tri sélectif"], ["i rifiuti", "les déchets"], ["buttare", "jeter"], ["riciclare", "recycler"], ["risparmiare", "économiser"], ["i mezzi pubblici", "les transports en commun"], ["la pista ciclabile", "la piste cyclable"], ["la zona pedonale", "la zone piétonne"], ["il comune", "la mairie, la commune"], ["il quartiere", "le quartier"], ["l'affitto", "le loyer"]],
    quiz: [
      mcq("« Le tri sélectif » :", ["la raccolta differenziata", "la differenza raccolta", "il riciclo diverso", "la spazzatura"], 0, "la raccolta differenziata."),
      fill("Bisogna ___ energia. (économiser)", ["risparmiare"], "risparmiare."),
      mcq("« Les transports en commun » :", ["le macchine", "i mezzi pubblici", "i trasporti comuni", "i viaggi"], 1, "i mezzi pubblici."),
      mcq("Il comune ___ creare più parchi. (devrait)", ["deve", "dovrebbe", "dovrà", "doveva"], 1, "Conseil / proposition : conditionnel."),
      match("Associez", [["l'inquinamento", "la pollution"], ["i rifiuti", "les déchets"], ["il quartiere", "le quartier"], ["l'affitto", "le loyer"]]),
      fill("Non ___ la carta per terra! (jeter, impératif tu)", ["buttare"], "Impératif négatif tu : non + infinitif."),
      mcq("« Zone piétonne » :", ["zona pedonale", "zona a piedi", "zona pedale", "zona ciclabile"], 0, "zona pedonale."),
      tr("Traduisez : Je vais au travail à vélo.", ["vado al lavoro in bici", "vado al lavoro in bicicletta"], "in bici."),
    ],
  },

  /* ------------------------------------------------------------ 17 */
  {
    id: "b1-burocrazia", module: "expr", title: "Banque, poste et démarches", emoji: "🏛️",
    intro: "Ouvrir un compte, envoyer un colis, prendre rendez-vous, remplir un formulaire : se débrouiller seul face à l'administration italienne.",
    sections: [
      {
        title: "À la banque et à la poste",
        examples: [["Vorrei aprire un conto corrente.", "Je voudrais ouvrir un compte courant."], ["Devo fare un bonifico.", "Je dois faire un virement."], ["Quanto costa spedire questo pacco in Francia?", "Combien coûte l'envoi de ce colis en France ?"], ["La carta non funziona: me l'hanno bloccata.", "La carte ne marche pas : on me l'a bloquée."]],
      },
      {
        title: "Les documents",
        examples: [["Serve un documento d'identità.", "Il faut une pièce d'identité."], ["Deve compilare questo modulo e firmare qui.", "Vous devez remplir ce formulaire et signer ici."], ["Mi serve il codice fiscale.", "J'ai besoin du code fiscal (numéro personnel)."], ["Il permesso di soggiorno è scaduto.", "Le titre de séjour a expiré."]],
      },
      {
        title: "Prendre rendez-vous, faire la queue",
        examples: [["Bisogna prendere un appuntamento online.", "Il faut prendre rendez-vous en ligne."], ["Prenda il numero e aspetti il Suo turno.", "Prenez un ticket et attendez votre tour."], ["L'ufficio è chiuso il pomeriggio.", "Le bureau est fermé l'après-midi."], ["Lo sportello apre alle nove.", "Le guichet ouvre à 9 h."]],
      },
    ],
    mnemo: "Servire = « être nécessaire » : mi serve un modulo (il me faut un formulaire), mi servono due foto (il me faut deux photos).",
    vocab: [["il conto corrente", "le compte courant"], ["il bonifico", "le virement"], ["la carta di credito", "la carte de crédit"], ["il pacco", "le colis"], ["spedire", "envoyer"], ["il modulo", "le formulaire"], ["compilare", "remplir (un formulaire)"], ["firmare", "signer"], ["il documento d'identità", "la pièce d'identité"], ["scadere", "expirer"], ["l'appuntamento", "le rendez-vous"], ["lo sportello", "le guichet"], ["il turno", "le tour"], ["servire", "être nécessaire"]],
    quiz: [
      mcq("« Remplir un formulaire » :", ["riempire un modulo", "compilare un modulo", "fare un modulo", "scrivere un formulario"], 1, "compilare un modulo."),
      fill("Mi ___ due fototessere. (il me faut, pluriel)", ["servono"], "servire au pluriel : servono."),
      mcq("« Un virement » :", ["un bonifico", "un benefico", "un bollettino", "un bancomat"], 0, "il bonifico."),
      mcq("Il passaporto è ___ : devo rinnovarlo.", ["scaduto", "scaricato", "spedito", "firmato"], 0, "scadere → scaduto."),
      match("Associez", [["lo sportello", "le guichet"], ["il pacco", "le colis"], ["firmare", "signer"], ["il turno", "le tour"]]),
      fill("Vorrei aprire un ___ corrente.", ["conto"], "il conto corrente."),
      mcq("« Prenda il numero e aspetti il Suo turno » est :", ["tutoiement", "vouvoiement (Lei)", "pluriel", "impersonnel"], 1, "Impératif de politesse avec Lei."),
      tr("Traduisez : Je dois faire un virement.", ["devo fare un bonifico"], "fare un bonifico."),
    ],
  },
];

/* Questions supplémentaires de l'examen B1 */
export const B1_EXAM_PLUS = [
  mcq("Quando siamo arrivati, il treno ___ già ___.", ["è / partito", "era / partito", "ha / partito", "aveva / partito"], 1, "Antériorité : trapassato, partire → essere."),
  mcq("Hai dato il regalo a Sara? — Sì, ___ ho dato.", ["gliel'", "le l'", "la gli", "glie lo"], 0, "gli/le + lo → glielo → gliel'ho."),
  fill("Penso che tu ___ ragione. (avere)", ["abbia"], "congiuntivo : abbia."),
  mcq("È la città ___ sono nato.", ["che", "in cui", "di cui", "chi"], 1, "in cui = où."),
  mcq("Se ___ tempo, verrò alla festa.", ["avrò", "avrei", "abbia", "avessi"], 0, "Hypothèse réelle au futur."),
  mcq("In questo negozio ___ scarpe italiane.", ["si vende", "si vendono", "ci si vende", "si vendano"], 1, "Nom pluriel → si vendono."),
  fill("___ pioveva, siamo rimasti a casa. (comme)", ["Siccome", "siccome"], "siccome en début de phrase."),
  mcq("Anna: « Sono stanca. » → Anna ha detto che ___ stanca.", ["è", "era", "sarà", "sia"], 1, "Présent → imparfait."),
  mcq("« Postuler à un emploi » :", ["candidarsi", "licenziarsi", "assumere", "dimettersi"], 0, "candidarsi."),
  match("Associez", [["scaricare", "télécharger"], ["mi manchi", "tu me manques"], ["i rifiuti", "les déchets"], ["compilare", "remplir"]]),
  mcq("Tu sei stanco: ___ riposarti.", ["devi di", "dovresti", "dovrai a", "doveva"], 1, "Conseil : dovresti."),
  tr("Traduisez : Il m'a dit de me reposer.", ["mi ha detto di riposare", "mi ha detto di riposarmi"], "dire di + infinitif."),
];
