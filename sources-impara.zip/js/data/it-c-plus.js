/* =====================================================================
   Italien — compléments des paliers C1 (« Autonome ») et C2 (« Maîtrise »)
   ---------------------------------------------------------------------
   C1 : hypothèse nuancée (come se, magari, qualora), verbes pronominaux
   idiomatiques (farcela, andarsene…), concessives (per quanto, chiunque),
   presse et nominalisation, réunions et négociation, administration.
   C2 : constructions implicites (participe absolu, infinitif passé),
   conditionnel « journalistique » et futur de probabilité, registres,
   italien régional, classiques de la littérature, orthographe fine
   (élision, troncamento, accents).
   Les leçons s'ajoutent APRÈS les leçons d'origine de chaque palier.
   ===================================================================== */

const mcq = (q, options, answer, explain = "") => ({ type: "mcq", q, options, answer, explain });
const fill = (q, answer, explain = "") => ({ type: "fill", q, answer, explain });
const match = (q, pairs, explain = "") => ({ type: "match", q, pairs, explain });
const tr = (q, answer, explain = "") => ({ type: "translate", q, answer, explain });

/* ================================ C1 ================================ */
export const C1_PLUS = [
  {
    id: "c1-come-se", module: "conj", title: "Come se, magari, qualora : l'hypothèse nuancée", emoji: "🎭",
    intro: "Au-delà du « se » classique, l'italien soutenu dispose de tournures pour comparer à une situation imaginaire, exprimer un souhait ou une éventualité.",
    sections: [
      {
        title: "Come se : comme si",
        text: "<b>Come se</b> est toujours suivi du <b>subjonctif imparfait</b> (fait simultané) ou <b>plus-que-parfait</b> (fait antérieur) — jamais de l'indicatif.",
        examples: [["Parla come se fosse il capo.", "Il parle comme s'il était le chef."], ["Mi guarda come se non mi avesse mai visto.", "Il me regarde comme s'il ne m'avait jamais vu."], ["Fai come se fossi a casa tua.", "Fais comme chez toi (comme si tu étais chez toi)."]],
      },
      {
        title: "Magari : si seulement !",
        text: "Seul en début de phrase, <b>magari</b> + subjonctif imparfait exprime un souhait : <i>Magari fosse vero !</i> Dans une réponse, <b>Magari !</b> = « J'aimerais bien ! ». Au milieu d'une phrase, avec l'indicatif, il signifie « peut-être ».",
        examples: [["Magari avessi più tempo!", "Si seulement j'avais plus de temps !"], ["— Vai in vacanza? — Magari!", "— Tu pars en vacances ? — J'aimerais bien !"], ["Magari domani piove.", "Peut-être qu'il pleuvra demain."]],
      },
      {
        title: "Qualora, nel caso in cui : au cas où",
        text: "Dans un registre soutenu (contrats, règlements, e-mails formels), <b>qualora</b> et <b>nel caso in cui</b> remplacent <i>se</i> et prennent le <b>subjonctif</b>.",
        examples: [["Qualora non fosse possibile, la preghiamo di avvisarci.", "Au cas où ce ne serait pas possible, nous vous prions de nous prévenir."], ["Nel caso in cui ci siano problemi, chiamami.", "Au cas où il y aurait des problèmes, appelle-moi."]],
      },
    ],
    mnemo: "Come se, magari (souhait), qualora : trois portes vers l'imaginaire, et derrière chacune… le subjonctif.",
    vocab: [["come se", "comme si"], ["magari", "si seulement ; peut-être"], ["qualora", "au cas où (soutenu)"], ["nel caso in cui", "au cas où"], ["avvisare", "prévenir, avertir"], ["il capo", "le chef"], ["fingere", "faire semblant"], ["immaginare", "imaginer"]],
    quiz: [
      mcq("Parla come se ___ tutto.", ["sa", "sapesse", "saprà", "sappia"], 1, "come se + subjonctif imparfait."),
      mcq("« Magari fosse vero! » signifie :", ["Si seulement c'était vrai !", "C'est peut-être vrai.", "Ce n'est pas vrai.", "C'est vrai, bien sûr."], 0, "magari + subjonctif = souhait."),
      fill("Qualora il pacco non ___ arrivato, ci contatti. (essere)", ["fosse"], "qualora + subjonctif (ici plus-que-parfait : fosse arrivato)."),
      mcq("Mi tratta come se ___ un bambino.", ["sono", "fossi", "sarei", "ero"], 1, "come se fossi."),
      mcq("Dans « Magari domani vengo », magari signifie :", ["peut-être", "si seulement", "au cas où", "comme si"], 0, "Magari + indicatif au milieu de la phrase = peut-être."),
      match("Associez", [["come se", "comme si"], ["qualora", "au cas où"], ["magari!", "j'aimerais bien !"], ["fingere", "faire semblant"]]),
      tr("Traduisez : Si seulement j'avais plus de temps !", ["magari avessi più tempo", "magari avessi piu tempo"], "magari + subjonctif imparfait."),
    ],
  },
  {
    id: "c1-pronominali", module: "expr", title: "Farcela, andarsene, cavarsela : verbes pronominaux idiomatiques", emoji: "🧗",
    intro: "Ces verbes, collés à une ou deux particules (ce, ne, la, se), ont un sens qu'on ne devine pas. Les Italiens les emploient sans arrêt.",
    sections: [
      {
        title: "Les plus courants",
        text: "<b>farcela</b> = y arriver ; <b>andarsene</b> = s'en aller ; <b>cavarsela</b> = s'en sortir ; <b>prendersela</b> = se vexer ; <b>avercela con qualcuno</b> = en vouloir à quelqu'un ; <b>metterci</b> = mettre (du temps) ; <b>volerci</b> = falloir (du temps, des choses).",
        examples: [["Non ce la faccio più!", "Je n'en peux plus !"], ["Me ne vado, è tardi.", "Je m'en vais, il est tard."], ["Te la sei cavata bene all'esame.", "Tu t'en es bien sorti à l'examen."], ["Non prendertela, scherzavo.", "Ne te vexe pas, je plaisantais."]],
      },
      {
        title: "Les conjuguer",
        text: "Les particules se placent avant le verbe conjugué, et <i>ci / si</i> deviennent <b>ce / se</b> devant <i>la / ne</i> : <i>io ce la faccio, tu te ne vai, lui se la prende</i>. Au passé composé : auxiliaire <b>essere</b> avec andarsene, cavarsela, prendersela (<i>me ne sono andato</i>), mais <b>avere</b> avec farcela (<i>ce l'ho fatta</i>).",
        examples: [["Ce l'abbiamo fatta!", "On a réussi !"], ["Se n'è andata senza salutare.", "Elle est partie sans dire au revoir."], ["Ce l'ha con me da una settimana.", "Il m'en veut depuis une semaine."]],
      },
      {
        title: "Metterci et volerci : le temps nécessaire",
        text: "<b>Metterci</b> a pour sujet la personne : <i>Ci metto un'ora</i> (je mets une heure). <b>Volerci</b> a pour sujet la chose nécessaire, et s'accorde avec elle : <i>Ci vuole un'ora / Ci vogliono due ore</i>.",
        examples: [["Quanto ci metti per arrivare?", "Combien de temps tu mets pour arriver ?"], ["Ci vogliono tre uova per questa torta.", "Il faut trois œufs pour ce gâteau."], ["Ci è voluto molto coraggio.", "Il a fallu beaucoup de courage."]],
      },
    ],
    mnemo: "Ce la faccio : je « la » fais, la difficulté. Me ne vado : je m'en vais d'« ici » (ne).",
    vocab: [["farcela", "y arriver"], ["andarsene", "s'en aller"], ["cavarsela", "s'en sortir"], ["prendersela", "se vexer"], ["avercela con", "en vouloir à"], ["metterci", "mettre (du temps)"], ["volerci", "falloir"], ["scherzare", "plaisanter"]],
    quiz: [
      mcq("« Non ce la faccio più » signifie :", ["Je n'en peux plus", "Je ne le fais plus", "Je ne m'en vais plus", "Je n'y vais plus"], 0, "farcela = y arriver."),
      mcq("Passé composé de « farcela » (noi) :", ["ce la siamo fatta", "ce l'abbiamo fatta", "ce ne siamo fatti", "l'abbiamo fatta ce"], 1, "farcela prend avere : ce l'abbiamo fatta."),
      fill("Per fare questa torta ___ tre ore. (volerci, présent)", ["ci vogliono"], "Sujet pluriel (tre ore) → ci vogliono."),
      mcq("Lei ___ senza dire niente. (andarsene, passé composé)", ["se n'è andata", "se l'è andata", "ne è andata", "se ne ha andata"], 0, "andarsene → essere : se n'è andata."),
      mcq("« Ce l'ha con me » signifie :", ["Il m'en veut", "Il l'a avec moi", "Il y arrive avec moi", "Il s'en va avec moi"], 0, "avercela con = en vouloir à."),
      match("Associez", [["cavarsela", "s'en sortir"], ["prendersela", "se vexer"], ["metterci", "mettre (du temps)"], ["andarsene", "s'en aller"]]),
      tr("Traduisez : On a réussi !", ["ce l'abbiamo fatta", "ce l abbiamo fatta"], "farcela au passé composé."),
    ],
  },
  {
    id: "c1-concessive", module: "gram", title: "Per quanto, chiunque, comunque : les concessives", emoji: "🌉",
    intro: "« Aussi… que », « qui que ce soit », « quoi qu'il arrive » : l'italien utilise des mots indéfinis suivis du subjonctif.",
    sections: [
      {
        title: "Per quanto : aussi… que, bien que",
        text: "<b>Per quanto</b> + subjonctif : <i>Per quanto sia difficile, ci provo.</i> (Aussi difficile que ce soit, j'essaie.) Variante : <b>per quanto</b> + adjectif + subjonctif.",
        examples: [["Per quanto mi sforzi, non capisco.", "J'ai beau faire des efforts, je ne comprends pas."], ["Per quanto bravo sia, ha bisogno di aiuto.", "Aussi doué qu'il soit, il a besoin d'aide."]],
      },
      {
        title: "Chiunque, qualunque, dovunque, comunque",
        text: "<b>Chiunque</b> (qui que), <b>qualunque / qualsiasi</b> (quel que), <b>dovunque</b> (où que), <b>comunque</b> (de quelque manière que) + subjonctif. Attention : <i>comunque</i> seul en début de phrase = « de toute façon ».",
        examples: [["Chiunque tu sia, benvenuto.", "Qui que tu sois, bienvenue."], ["Qualunque cosa succeda, ti chiamo.", "Quoi qu'il arrive, je t'appelle."], ["Dovunque vada, trova amici.", "Où qu'il aille, il trouve des amis."], ["Comunque vada, sarà un successo.", "Quoi qu'il en soit (quelle que soit l'issue), ce sera un succès."]],
      },
      {
        title: "Pur + gérondif : tout en…",
        text: "<b>Pur</b> + gérondif exprime une concession élégante : <i>Pur essendo stanco, è venuto</i> = bien qu'il soit fatigué, il est venu.",
        examples: [["Pur sapendo la verità, non ha detto niente.", "Tout en connaissant la vérité, il n'a rien dit."], ["Pur avendo studiato, non ha superato l'esame.", "Bien qu'il ait étudié, il n'a pas réussi l'examen."]],
      },
    ],
    mnemo: "Les mots en -unque (chiunque, qualunque, dovunque, comunque) ouvrent toujours la porte au subjonctif.",
    vocab: [["per quanto", "aussi… que, bien que"], ["chiunque", "qui que, n'importe qui"], ["qualunque / qualsiasi", "quel que, n'importe quel"], ["dovunque", "où que, partout"], ["comunque", "de toute façon ; quoi qu'il en soit"], ["sforzarsi", "faire des efforts"], ["succedere", "arriver, se produire"], ["superare", "réussir, dépasser"]],
    quiz: [
      mcq("Per quanto ___ stanco, finisco il lavoro.", ["sono", "sia", "sarò", "ero"], 1, "per quanto + subjonctif."),
      mcq("___ cosa tu dica, non cambio idea.", ["Qualunque", "Chiunque", "Dovunque", "Comunque"], 0, "qualunque cosa = quoi que."),
      fill("Chiunque ___, non aprire la porta. (essere)", ["sia"], "chiunque + subjonctif."),
      mcq("« Pur essendo ricco, vive semplicemente » :", ["Bien qu'il soit riche, il vit simplement.", "Parce qu'il est riche, il vit simplement.", "Il est riche et vit simplement.", "S'il était riche, il vivrait simplement."], 0, "pur + gérondif = concession."),
      mcq("En début de phrase, « Comunque, ci vediamo domani » :", ["De toute façon, on se voit demain", "Comment qu'on se voie demain", "Partout, on se voit demain", "Bien qu'on se voie demain"], 0, "comunque seul = de toute façon."),
      match("Associez", [["chiunque", "qui que"], ["dovunque", "où que"], ["qualunque", "quel que"], ["per quanto", "aussi… que"]]),
      tr("Traduisez : Quoi qu'il arrive, je t'appelle.", ["qualunque cosa succeda ti chiamo", "qualsiasi cosa succeda ti chiamo"], "qualunque / qualsiasi cosa + subjonctif."),
    ],
  },
  {
    id: "c1-giornale", module: "vocab", title: "Lire la presse : nominalisation et style journalistique", emoji: "📰",
    intro: "Les titres italiens suppriment les verbes, multiplient les noms et utilisent un vocabulaire codé. Voici les clés pour les lire sans effort.",
    sections: [
      {
        title: "Des titres sans verbe",
        text: "Le titre remplace le verbe par un nom (<b>nominalisation</b>) : <i>aumentare → l'aumento</i>, <i>approvare → l'approvazione</i>, <i>dimettersi → le dimissioni</i>. On supprime aussi les articles.",
        examples: [["Benzina, nuovo aumento dei prezzi.", "Essence : nouvelle hausse des prix."], ["Via libera del governo alla riforma.", "Feu vert du gouvernement à la réforme."], ["Maltempo al Nord, scuole chiuse.", "Intempéries dans le Nord, écoles fermées."]],
      },
      {
        title: "Le vocabulaire des médias",
        text: "<b>il governo</b> (le gouvernement), <b>il premier</b> (le Premier ministre), <b>il Quirinale</b> (la présidence de la République), <b>Palazzo Chigi</b> (le siège du gouvernement), <b>lo sciopero</b> (la grève), <b>la manovra</b> (le budget), <b>il sondaggio</b> (le sondage).",
        examples: [["Sciopero dei treni venerdì.", "Grève des trains vendredi."], ["Secondo un sondaggio, il 60% è favorevole.", "Selon un sondage, 60 % sont favorables."], ["Il Quirinale ha firmato la legge.", "La présidence a signé la loi."]],
      },
      {
        title: "Rapporter avec prudence",
        text: "Pour une information non confirmée, la presse utilise le <b>conditionnel</b> : <i>Il ministro si sarebbe dimesso</i> = le ministre aurait démissionné. Expressions utiles : <b>secondo fonti</b> (selon des sources), <b>a quanto pare</b> (apparemment).",
        examples: [["Il ministro si sarebbe dimesso ieri sera.", "Le ministre aurait démissionné hier soir."], ["A quanto pare, l'accordo è vicino.", "Apparemment, l'accord est proche."]],
      },
    ],
    mnemo: "Titre italien = nom + virgule + nom. Conditionnel = « ce n'est pas encore sûr ».",
    vocab: [["l'aumento", "la hausse"], ["lo sciopero", "la grève"], ["il sondaggio", "le sondage"], ["le dimissioni", "la démission"], ["la manovra", "le budget (loi de finances)"], ["la riforma", "la réforme"], ["il maltempo", "les intempéries"], ["a quanto pare", "apparemment"]],
    quiz: [
      mcq("« Sciopero dei treni » :", ["Grève des trains", "Retard des trains", "Achat de trains", "Arrivée des trains"], 0, "lo sciopero = la grève."),
      mcq("« Il ministro si sarebbe dimesso » :", ["Le ministre aurait démissionné (pas confirmé)", "Le ministre va démissionner", "Le ministre a démissionné (certain)", "Le ministre ne démissionnera pas"], 0, "Conditionnel de l'information non confirmée."),
      fill("Nom de « approvare » : l'___", ["approvazione"], "approvare → l'approvazione."),
      mcq("Le Quirinale désigne :", ["la présidence de la République", "le Parlement (Chambre des députés)", "le siège du gouvernement", "la Cour constitutionnelle"], 0, "Le palais du Quirinal, à Rome."),
      match("Associez", [["il sondaggio", "le sondage"], ["l'aumento", "la hausse"], ["le dimissioni", "la démission"], ["il maltempo", "les intempéries"]]),
      tr("Traduisez : apparemment", ["a quanto pare", "apparentemente"], "a quanto pare."),
    ],
  },
  {
    id: "c1-riunione", module: "expr", title: "Réunions et négociation", emoji: "🤝",
    intro: "Prendre la parole, proposer, nuancer un désaccord, conclure : l'italien des réunions de travail, poli mais efficace.",
    sections: [
      {
        title: "Prendre et donner la parole",
        text: "<b>Posso intervenire?</b> (Je peux intervenir ?), <b>Se posso permettermi…</b> (Si je peux me permettre…), <b>Lascio la parola a…</b> (Je laisse la parole à…), <b>Tornando al punto…</b> (Pour revenir au sujet…).",
        examples: [["Se posso permettermi, vorrei aggiungere una cosa.", "Si je peux me permettre, j'aimerais ajouter une chose."], ["Tornando al punto principale, il budget è insufficiente.", "Pour revenir au point principal, le budget est insuffisant."]],
      },
      {
        title: "Nuancer et négocier",
        text: "Le conditionnel adoucit tout : <b>Proporrei di…</b> (Je proposerais de…), <b>Sarebbe meglio…</b>, <b>Capisco il suo punto di vista, però…</b>. Pour négocier : <b>venirsi incontro</b> (faire un pas l'un vers l'autre), <b>trovare un compromesso</b>.",
        examples: [["Capisco il suo punto di vista, però i tempi sono stretti.", "Je comprends votre point de vue, mais les délais sont serrés."], ["Potremmo venirci incontro sul prezzo.", "Nous pourrions faire un pas l'un vers l'autre sur le prix."], ["Proporrei di rinviare la decisione.", "Je proposerais de reporter la décision."]],
      },
      {
        title: "Conclure",
        text: "<b>Ricapitolando…</b> (En résumé…), <b>Siamo d'accordo che…</b>, <b>Mettiamo tutto per iscritto</b> (Mettons tout par écrit), <b>Ci aggiorniamo a lunedì</b> (On fait le point lundi).",
        examples: [["Ricapitolando: consegna a marzo e sconto del 5%.", "En résumé : livraison en mars et remise de 5 %."], ["Ci aggiorniamo la settimana prossima.", "On refait le point la semaine prochaine."]],
      },
    ],
    mnemo: "En réunion, le conditionnel est votre meilleur allié : proporrei, sarebbe meglio, potremmo.",
    vocab: [["intervenire", "intervenir"], ["l'ordine del giorno", "l'ordre du jour"], ["rinviare", "reporter"], ["il compromesso", "le compromis"], ["venirsi incontro", "faire un pas l'un vers l'autre"], ["la scadenza", "l'échéance"], ["ricapitolando", "en résumé"], ["aggiornarsi", "refaire le point"]],
    quiz: [
      mcq("Pour proposer poliment de reporter :", ["Proporrei di rinviare.", "Rinviamo!", "Voglio rinviare.", "Devi rinviare."], 0, "Conditionnel = politesse."),
      mcq("« Ci aggiorniamo a lunedì » :", ["On refait le point lundi", "On se met à jour lundi soir", "On s'arrête lundi", "On commence lundi"], 0, "aggiornarsi = refaire le point."),
      fill("Possiamo trovare un ___ che vada bene a tutti. (compromis)", ["compromesso"], "il compromesso."),
      mcq("« Venirsi incontro » :", ["faire un pas l'un vers l'autre", "se rencontrer par hasard", "venir à une réunion", "s'opposer"], 0, "Expression de la négociation."),
      match("Associez", [["la scadenza", "l'échéance"], ["rinviare", "reporter"], ["ricapitolando", "en résumé"], ["l'ordine del giorno", "l'ordre du jour"]]),
      tr("Traduisez : Je peux intervenir ?", ["posso intervenire"], "Posso intervenire?"),
    ],
  },
  {
    id: "c1-burocrazia", module: "vocab", title: "L'administration : documents et démarches", emoji: "🏛️",
    intro: "Le « burocratese », la langue de l'administration italienne, est célèbre pour sa complexité. Voici de quoi survivre au comune, à la poste ou à la questura.",
    sections: [
      {
        title: "Les documents",
        text: "<b>la carta d'identità</b>, <b>il codice fiscale</b> (numéro fiscal, indispensable partout), <b>il permesso di soggiorno</b> (titre de séjour), <b>la residenza</b> (domicile officiel), <b>il modulo</b> (le formulaire), <b>la marca da bollo</b> (le timbre fiscal).",
        examples: [["Per aprire un conto serve il codice fiscale.", "Pour ouvrir un compte, il faut le code fiscal."], ["Bisogna compilare il modulo e allegare una marca da bollo.", "Il faut remplir le formulaire et joindre un timbre fiscal."]],
      },
      {
        title: "Les démarches",
        text: "<b>fare domanda</b> (faire une demande), <b>presentare</b> (déposer), <b>rilasciare</b> (délivrer), <b>autocertificare</b> (attester sur l'honneur), <b>lo sportello</b> (le guichet), <b>prendere il numero</b> (prendre un ticket).",
        examples: [["Il passaporto viene rilasciato dalla questura.", "Le passeport est délivré par la préfecture de police."], ["Allo sportello 3, prego.", "Au guichet 3, s'il vous plaît."]],
      },
      {
        title: "Le style bureaucratique",
        text: "Formules typiques : <b>Si prega di…</b> (Prière de…), <b>Ai sensi della legge…</b> (Aux termes de la loi…), <b>In allegato</b> (En pièce jointe), <b>il sottoscritto</b> (le soussigné), <b>entro e non oltre</b> (au plus tard le).",
        examples: [["Si prega di presentarsi entro e non oltre il 30 giugno.", "Prière de se présenter au plus tard le 30 juin."], ["Il sottoscritto dichiara di risiedere a Torino.", "Le soussigné déclare résider à Turin."]],
      },
    ],
    mnemo: "Burocratese : on ne « demande » pas, on « fa domanda » ; on ne « donne » pas, on « rilascia ».",
    vocab: [["il codice fiscale", "le numéro fiscal"], ["il modulo", "le formulaire"], ["lo sportello", "le guichet"], ["rilasciare", "délivrer (un document)"], ["la residenza", "le domicile officiel"], ["la marca da bollo", "le timbre fiscal"], ["il sottoscritto", "le soussigné"], ["entro e non oltre", "au plus tard"]],
    quiz: [
      mcq("« Entro e non oltre il 30 giugno » :", ["au plus tard le 30 juin", "à partir du 30 juin", "seulement le 30 juin", "après le 30 juin"], 0, "Formule bureaucratique."),
      mcq("« Il passaporto viene rilasciato » :", ["est délivré", "est relâché", "est refusé", "est perdu"], 0, "rilasciare un documento = délivrer."),
      fill("Per favore, compili questo ___. (formulaire)", ["modulo"], "il modulo."),
      mcq("Le codice fiscale sert :", ["presque partout (banque, médecin, contrat)", "seulement pour payer ses impôts", "seulement pour voter et voyager", "seulement pour les étrangers résidents"], 0, "Il est demandé pour presque toutes les démarches."),
      match("Associez", [["lo sportello", "le guichet"], ["il sottoscritto", "le soussigné"], ["in allegato", "en pièce jointe"], ["fare domanda", "faire une demande"]]),
      tr("Traduisez : le guichet", ["lo sportello", "sportello"], "lo sportello."),
    ],
  },
];

export const C1_EXAM_PLUS = [
  mcq("Si comporta come se ___ il padrone.", ["è", "fosse", "sarà", "era"], 1, "come se + subjonctif imparfait."),
  mcq("« Non ce la faccio » :", ["Je n'y arrive pas", "Je ne le fais pas", "Je ne la fais pas", "Je ne m'en vais pas"], 0, "farcela."),
  fill("Per quanto ___ difficile, ci provo. (essere)", ["sia"], "per quanto + subjonctif."),
  mcq("« Sciopero generale » :", ["grève générale", "réunion générale", "assemblée", "élection"], 0, "lo sciopero."),
  mcq("Pour adoucir une proposition en réunion :", ["Proporrei…", "Propongo e basta.", "Dovete…", "Voglio…"], 0, "Conditionnel."),
  fill("Quanto tempo ci ___ per arrivare? (mettere, tu)", ["metti"], "metterci : ci metti."),
  mcq("« Il sottoscritto » :", ["le soussigné", "le sous-sol", "le suivant", "le signataire absent"], 0, "Formule administrative."),
  mcq("Qualunque cosa ___, resta calmo.", ["succede", "succeda", "succederà", "successe"], 1, "qualunque + subjonctif."),
  mcq("« Il ministro si sarebbe dimesso » indique :", ["une information non confirmée", "une démission certaine et officielle", "une démission qui aura lieu demain", "un souhait du journaliste"], 0, "Conditionnel journalistique."),
  tr("Traduisez : Si seulement c'était vrai !", ["magari fosse vero"], "magari + subjonctif."),
];

/* ================================ C2 ================================ */
export const C2_PLUS = [
  {
    id: "c2-implicite", module: "gram", title: "Constructions implicites : participe absolu et infinitif passé", emoji: "🪶",
    intro: "À l'écrit soutenu, l'italien supprime volontiers le verbe conjugué : participe absolu, gérondif et infinitif passé rendent la phrase dense et élégante.",
    sections: [
      {
        title: "Le participe absolu",
        text: "Le participe passé seul, en tête de phrase, exprime une action terminée avant l'action principale : <i>Finita la cena, siamo usciti</i> (Le dîner terminé, nous sommes sortis). Il s'accorde avec le nom qui suit ; les pronoms se collent à la fin : <i>Vistolo, lo salutai</i>.",
        examples: [["Finita la lezione, gli studenti uscirono.", "Le cours terminé, les étudiants sortirent."], ["Arrivati a Roma, abbiamo cercato un albergo.", "Arrivés à Rome, nous avons cherché un hôtel."], ["Lettala, ha strappato la lettera.", "Après l'avoir lue, il a déchiré la lettre."]],
      },
      {
        title: "Dopo + infinitif passé",
        text: "<b>Dopo</b> + avere / essere + participe = après avoir / être… L'auxiliaire peut perdre son -e final : <i>dopo aver mangiato</i>, <i>dopo esser partiti</i>.",
        examples: [["Dopo aver letto il libro, ho visto il film.", "Après avoir lu le livre, j'ai vu le film."], ["Dopo essere arrivata, mi ha chiamato.", "Une fois arrivée, elle m'a appelé."]],
      },
      {
        title: "Le gérondif passé",
        text: "<b>Avendo / essendo</b> + participe exprime la cause ou l'antériorité : <i>Avendo perso il treno, sono arrivato tardi</i> (Ayant raté le train, je suis arrivé en retard).",
        examples: [["Avendo finito presto, sono andato al cinema.", "Ayant fini tôt, je suis allé au cinéma."], ["Essendo partiti all'alba, siamo arrivati prima.", "Étant partis à l'aube, nous sommes arrivés avant."]],
      },
    ],
    mnemo: "Finita la cena = « une fois le dîner fini » : le participe seul suffit, l'italien soutenu adore cette économie.",
    vocab: [["finito", "terminé"], ["all'alba", "à l'aube"], ["strappare", "déchirer"], ["l'albergo", "l'hôtel"], ["salutare", "saluer"], ["dopo aver…", "après avoir…"], ["avendo…", "ayant…"]],
    quiz: [
      mcq("« Finita la riunione, … » signifie :", ["Une fois la réunion terminée, …", "Pour finir la réunion, …", "Si la réunion finit, …", "La réunion qui finit, …"], 0, "Participe absolu."),
      fill("Dopo ___ mangiato, siamo usciti. (avere, forme courte)", ["aver", "avere"], "dopo aver mangiato."),
      mcq("___ perso le chiavi, ha chiamato un fabbro.", ["Avendo", "Essendo", "Avere", "Avuto"], 0, "perdere → avere : avendo perso."),
      mcq("Accord du participe absolu : « ___ le lettere, le spedì. »", ["Scritte", "Scritto", "Scritti", "Scrivendo"], 0, "le lettere (f. pl.) → scritte."),
      mcq("« Arrivati alla stazione » (sujet : nous) :", ["Arrivés à la gare", "Pour arriver à la gare", "En arrivant demain", "Si nous arrivons à la gare"], 0, "Participe absolu."),
      tr("Traduisez : Après avoir lu le livre, …", ["dopo aver letto il libro", "dopo avere letto il libro"], "dopo + infinitif passé."),
    ],
  },
  {
    id: "c2-modalita", module: "conj", title: "Futur de probabilité et conditionnel de prudence", emoji: "🔍",
    intro: "Le futur et le conditionnel ne parlent pas toujours d'avenir ou d'hypothèse : ils servent aussi à supposer, à prendre ses distances ou à rapporter une rumeur.",
    sections: [
      {
        title: "Le futur de probabilité",
        text: "Le <b>futur simple</b> exprime une supposition sur le présent : <i>Saranno le otto</i> = il doit être huit heures. Le <b>futur antérieur</b> fait la même chose pour le passé : <i>Avrà perso il treno</i> = il a dû rater le train.",
        examples: [["— Dov'è Marco? — Sarà a casa.", "— Où est Marco ? — Il doit être chez lui."], ["Non risponde: avrà spento il telefono.", "Il ne répond pas : il a dû éteindre son téléphone."], ["Avrà avuto quarant'anni.", "Il devait avoir quarante ans."]],
      },
      {
        title: "Le conditionnel de dissociation",
        text: "Le <b>conditionnel</b> (présent ou passé) signale qu'on rapporte une information sans s'en porter garant : <i>Secondo la polizia, il ladro sarebbe fuggito in moto</i> = selon la police, le voleur se serait enfui à moto.",
        examples: [["L'attore starebbe per sposarsi.", "L'acteur serait sur le point de se marier."], ["Secondo alcune fonti, l'azienda avrebbe chiuso due filiali.", "Selon certaines sources, l'entreprise aurait fermé deux filiales."]],
      },
      {
        title: "Atténuer son propos",
        text: "Pour adoucir une affirmation : <b>direi che…</b> (je dirais que), <b>non saprei</b> (je ne saurais dire), <b>si direbbe che…</b> (on dirait que), <b>pare / sembra che</b> + subjonctif.",
        examples: [["Direi che è la soluzione migliore.", "Je dirais que c'est la meilleure solution."], ["Non saprei, dovrei pensarci.", "Je ne saurais dire, il faudrait que j'y réfléchisse."], ["Pare che abbia vinto un premio.", "Il paraît qu'il a gagné un prix."]],
      },
    ],
    mnemo: "Futur = « je suppose », conditionnel = « on dit que, mais je ne garantis rien ».",
    vocab: [["la fonte", "la source"], ["fuggire", "s'enfuir"], ["la filiale", "la filiale, l'agence"], ["spegnere", "éteindre"], ["stare per", "être sur le point de"], ["non saprei", "je ne saurais dire"], ["pare che", "il paraît que"]],
    quiz: [
      mcq("« Saranno le dieci » signifie :", ["Il doit être dix heures", "Il sera dix heures", "Ce sont dix heures", "Il était dix heures"], 0, "Futur de probabilité."),
      mcq("Il ne répond pas… « ___ già a letto. »", ["Sarà andato", "È andando", "Andrebbe", "Andò"], 0, "Futur antérieur = supposition sur le passé."),
      mcq("« Il ladro sarebbe fuggito » :", ["Le voleur se serait enfui (selon certains)", "Le voleur va s'enfuir", "Le voleur s'enfuirait s'il pouvait", "Le voleur ne s'est pas enfui"], 0, "Conditionnel de dissociation."),
      fill("Pare che ___ un incidente. (esserci, subj. passé : ci sia…)", ["ci sia stato", "sia stato"], "pare che + subjonctif."),
      match("Associez", [["direi che", "je dirais que"], ["non saprei", "je ne saurais dire"], ["la fonte", "la source"], ["stare per", "être sur le point de"]]),
      tr("Traduisez : Il doit être chez lui.", ["sarà a casa", "sara a casa"], "Futur de probabilité."),
    ],
  },
  {
    id: "c2-registri", module: "expr", title: "Du familier au soutenu : jongler entre les registres", emoji: "🎚️",
    intro: "Savoir dire la même chose de cinq façons, selon qu'on parle à un ami, à un client ou qu'on écrit à un ministère : c'est la vraie maîtrise.",
    sections: [
      {
        title: "Une même idée, plusieurs registres",
        text: "<i>Je ne comprends pas</i> : <b>Boh!</b> (familier) → <b>Non ho capito</b> (courant) → <b>Non mi è chiaro</b> (poli) → <b>Le sarei grato se potesse chiarire</b> (soutenu).",
        examples: [["Boh, non lo so.", "Bof, je ne sais pas (familier)."], ["Mi scusi, non mi è chiaro il punto due.", "Excusez-moi, le point deux ne m'est pas clair (poli)."], ["Le sarei grato se volesse chiarire la questione.", "Je vous serais reconnaissant de bien vouloir clarifier la question (soutenu)."]],
      },
      {
        title: "Le familier",
        text: "Mots très courants entre amis : <b>figo</b> (cool), <b>un casino</b> (un bazar, un tas), <b>sbattersi</b> (se démener), <b>beccare</b> (attraper, surprendre), <b>sgamare</b> (griller quelqu'un), <b>che palle!</b> (quelle barbe ! — vulgaire léger).",
        examples: [["Che figo questo posto!", "Trop cool, cet endroit !"], ["C'era un casino di gente.", "Il y avait un monde fou."], ["Mi ha beccato mentre copiavo.", "Il m'a surpris en train de copier."]],
      },
      {
        title: "Le soutenu",
        text: "À l'écrit formel : <b>pertanto</b> (par conséquent), <b>altresì</b> (également), <b>nonché</b> (ainsi que), <b>suddetto</b> (susdit), <b>codesto</b> (ce… — dans les lettres administratives), <b>porgere distinti saluti</b> (présenter ses salutations distinguées).",
        examples: [["Si richiede altresì la copia del documento.", "Une copie du document est également demandée."], ["Il direttore, nonché fondatore dell'azienda, ha parlato.", "Le directeur, ainsi que fondateur de l'entreprise, a parlé."], ["Porgo distinti saluti.", "Veuillez agréer mes salutations distinguées."]],
      },
    ],
    mnemo: "Boh → non lo so → non saprei → mi riservo di verificare : du café au ministère.",
    vocab: [["boh", "bof, je ne sais pas (fam.)"], ["figo", "cool (fam.)"], ["un casino", "un bazar ; énormément (fam.)"], ["beccare", "attraper, surprendre (fam.)"], ["altresì", "également (soutenu)"], ["nonché", "ainsi que (soutenu)"], ["pertanto", "par conséquent (soutenu)"], ["suddetto", "susdit"]],
    quiz: [
      mcq("Registre de « Che figo! » :", ["familier", "soutenu", "administratif", "littéraire"], 0, "figo = cool."),
      mcq("Équivalent soutenu de « anche » :", ["altresì", "boh", "figo", "casino"], 0, "altresì = également."),
      mcq("« C'era un casino di gente » :", ["Il y avait un monde fou", "Il y avait un casino", "Il y avait peu de gens", "Les gens jouaient"], 0, "un casino di = énormément de (fam.)."),
      fill("Il direttore, ___ fondatore, ha parlato. (ainsi que)", ["nonché"], "nonché."),
      match("Associez", [["pertanto", "par conséquent"], ["beccare", "surprendre"], ["suddetto", "susdit"], ["boh", "bof"]]),
      tr("Traduisez (soutenu) : Veuillez agréer mes salutations distinguées.", ["porgo distinti saluti", "distinti saluti"], "Porgo distinti saluti."),
    ],
  },
  {
    id: "c2-regionale", module: "vocab", title: "L'italien régional et les dialectes", emoji: "🗺️",
    intro: "Du Piémont à la Sicile, l'italien change de mots, d'accent et parfois de grammaire. Reconnaître ces variantes, c'est comprendre l'Italie réelle.",
    sections: [
      {
        title: "Mêmes choses, mots différents",
        text: "La pastèque : <b>anguria</b> (Nord) / <b>cocomero</b> (Centre) / <b>mellone</b> (Sud). Le garçon : <b>ragazzo</b> (standard), <b>bocia</b> (Vénétie), <b>guaglione</b> (Naples), <b>picciotto</b> (Sicile), <b>regazzino</b> (Rome).",
        examples: [["A Milano dicono anguria, a Roma cocomero.", "À Milan on dit anguria, à Rome cocomero."], ["Uè, guagliò!", "Hé, petit ! (napolitain)"]],
      },
      {
        title: "Grammaire régionale",
        text: "Au <b>Nord</b>, on emploie surtout le passé composé, même pour un passé lointain, et on met l'article devant les prénoms féminins : <i>la Giulia</i>. Au <b>Sud</b> (surtout en Sicile), le passé simple reste vivant : <i>ieri andai al mare</i>. À Rome, <i>annamo</i> = andiamo.",
        examples: [["Ho visto la Giulia ieri. (Nord)", "J'ai vu Giulia hier (avec article, au Nord)."], ["Ieri andai al mare. (Sicile)", "Hier je suis allé à la mer (passé simple, au Sud)."], ["Annamo, è tardi! (Rome)", "On y va, il est tard ! (romain)"]],
      },
      {
        title: "Les dialectes",
        text: "Les dialectes (napolitain, sicilien, vénitien, frioulan…) sont des langues à part entière, issues du latin comme l'italien. Le toscan de Florence est à l'origine de l'italien standard, grâce à Dante, Pétrarque et Boccace.",
        examples: [["Il napoletano ha una ricca tradizione di canzoni.", "Le napolitain a une riche tradition de chansons."], ["L'italiano standard nasce dal fiorentino.", "L'italien standard est né du florentin."]],
      },
    ],
    mnemo: "Anguria au Nord, cocomero au Centre, mellone au Sud : la pastèque traverse l'Italie en changeant de nom.",
    vocab: [["l'anguria / il cocomero", "la pastèque"], ["il dialetto", "le dialecte"], ["la cadenza", "l'accent (régional)"], ["il fiorentino", "le florentin"], ["guaglione", "garçon (napolitain)"], ["settentrionale", "du Nord"], ["meridionale", "du Sud"]],
    quiz: [
      mcq("« Cocomero » se dit surtout :", ["au Centre (Rome, Toscane)", "au Nord", "en Sicile seulement", "nulle part"], 0, "anguria au Nord, cocomero au Centre."),
      mcq("L'italien standard vient du dialecte :", ["florentin (toscan)", "romain (romanesco)", "vénitien (de la République)", "milanais (lombard)"], 0, "Grâce à Dante, Pétrarque, Boccace."),
      mcq("« La Giulia » avec article est typique :", ["du Nord", "du Sud", "de Rome", "de l'écrit officiel"], 0, "Article devant les prénoms au Nord."),
      mcq("« Meridionale » signifie :", ["du Sud", "du Nord", "de midi", "de l'Est"], 0, "il Meridione = le Sud."),
      match("Associez", [["il dialetto", "le dialecte"], ["la cadenza", "l'accent"], ["settentrionale", "du Nord"], ["meridionale", "du Sud"]]),
      tr("Traduisez : le dialecte", ["il dialetto", "dialetto"], "il dialetto."),
    ],
  },
  {
    id: "c2-classici", module: "expr", title: "Les classiques : Dante, Manzoni, Leopardi", emoji: "📜",
    intro: "Certaines phrases de la littérature italienne font partie de la langue courante. Les reconnaître enrichit la compréhension… et la conversation.",
    sections: [
      {
        title: "Dante (1265-1321)",
        text: "La <i>Divine Comédie</i> s'ouvre sur « <b>Nel mezzo del cammin di nostra vita</b> » (au milieu du chemin de notre vie). On cite aussi « <b>Lasciate ogni speranza, voi ch'entrate</b> » (abandonnez tout espoir, vous qui entrez) — avec humour, devant une salle d'examen !",
        examples: [["Nel mezzo del cammin di nostra vita…", "Au milieu du chemin de notre vie…"], ["Entrando in ufficio il lunedì: «Lasciate ogni speranza…»", "En entrant au bureau le lundi : « Abandonnez tout espoir… »"]],
      },
      {
        title: "Manzoni (1785-1873)",
        text: "<i>I promessi sposi</i> (Les Fiancés) est le roman que tous les Italiens lisent au lycée. Manzoni a « rincé ses vêtements dans l'Arno » (<b>sciacquare i panni in Arno</b>) : il a réécrit son roman en florentin pour forger une langue commune. Don Abbondio, le curé lâche, est devenu un type : <i>un don Abbondio</i> = un peureux.",
        examples: [["È un vero don Abbondio, ha paura di tutto.", "C'est un vrai don Abbondio, il a peur de tout."], ["I promessi sposi si studiano al liceo.", "Les Fiancés s'étudient au lycée."]],
      },
      {
        title: "Leopardi (1798-1837)",
        text: "Le poète de l'infini et de la mélancolie. « <b>L'infinito</b> » se termine par « <b>e il naufragar m'è dolce in questo mare</b> » (et le naufrage m'est doux dans cette mer).",
        examples: [["E il naufragar m'è dolce in questo mare.", "Et le naufrage m'est doux dans cette mer."]],
      },
    ],
    mnemo: "Dante : le chemin et l'enfer ; Manzoni : les fiancés et l'Arno ; Leopardi : l'infini et la mer.",
    vocab: [["il poeta", "le poète"], ["il romanzo", "le roman"], ["la speranza", "l'espoir"], ["il cammino", "le chemin"], ["il naufragio", "le naufrage"], ["dolce", "doux"], ["i promessi sposi", "les fiancés"]],
    quiz: [
      mcq("« Nel mezzo del cammin di nostra vita » est de :", ["Dante", "Manzoni", "Leopardi", "Pétrarque"], 0, "Début de la Divine Comédie."),
      mcq("« I promessi sposi » est :", ["un roman de Manzoni", "un poème de Dante", "un opéra de Verdi", "un film de Fellini"], 0, "Le grand roman italien du XIXe siècle."),
      mcq("« Un don Abbondio » désigne :", ["une personne peureuse", "un prêtre courageux", "un riche marchand", "un poète"], 0, "Le curé lâche des Fiancés."),
      mcq("« L'infinito » est un poème de :", ["Leopardi", "Dante", "Manzoni", "D'Annunzio"], 0, "Giacomo Leopardi."),
      match("Associez", [["la speranza", "l'espoir"], ["il romanzo", "le roman"], ["il naufragio", "le naufrage"], ["il cammino", "le chemin"]]),
      tr("Traduisez : le roman", ["il romanzo", "romanzo"], "il romanzo."),
    ],
  },
  {
    id: "c2-ortografia", module: "bases", title: "Élision, troncamento et accents : écrire sans fautes", emoji: "✒️",
    intro: "Même les Italiens hésitent : un'amica ou un amica ? qual è ou qual'è ? perché ou perchè ? Les règles qui font la différence à l'écrit.",
    sections: [
      {
        title: "L'élision : l'apostrophe",
        text: "On élide devant une voyelle : <b>l'amico</b>, <b>un'amica</b> (féminin → apostrophe), mais <b>un amico</b> (masculin → pas d'apostrophe : c'est un troncamento). On élide aussi <i>lo, la, una, quello, bello, santo</i> et souvent <i>ci</i> devant e/i : <i>c'è</i>.",
        examples: [["Ho incontrato un'amica.", "J'ai rencontré une amie (apostrophe)."], ["Ho incontrato un amico.", "J'ai rencontré un ami (sans apostrophe)."], ["Quell'albero è altissimo.", "Cet arbre est très haut."]],
      },
      {
        title: "Le troncamento : sans apostrophe",
        text: "Le <b>troncamento</b> supprime la fin d'un mot sans apostrophe : <i>buon giorno</i>, <i>un</i>, <i>qual</i>. D'où <b>qual è</b> (jamais d'apostrophe !). Exceptions avec apostrophe : <b>po'</b> (poco), <b>di'</b> (dis), <b>fa'</b>, <b>va'</b>, <b>sta'</b>, <b>da'</b> (impératifs).",
        examples: [["Qual è il problema?", "Quel est le problème ? (qual è, sans apostrophe)"], ["Un po' di pane, per favore.", "Un peu de pain, s'il vous plaît."], ["Di' la verità!", "Dis la vérité !"]],
      },
      {
        title: "Les accents",
        text: "Sur les mots en -ché, l'accent est <b>aigu</b> : <b>perché, poiché, benché, affinché, né, sé</b>. Il est <b>grave</b> sur <b>è, cioè, caffè, tè</b>. On accentue les monosyllabes pour les distinguer : <b>dà</b> (il donne) / da (de), <b>là</b> / la, <b>sì</b> / si, <b>tè</b> / te. Mais jamais : <i>qui, qua, su, blu, me, re</i>.",
        examples: [["Perché non vieni?", "Pourquoi tu ne viens pas ? (accent aigu)"], ["Lui mi dà un libro.", "Il me donne un livre (dà, verbe)."], ["Sì, vengo da Roma.", "Oui, je viens de Rome."]],
      },
    ],
    mnemo: "Un'amica (elle) / un amico (lui) ; qual è sans apostrophe ; perché avec l'accent aigu.",
    vocab: [["l'apostrofo", "l'apostrophe"], ["l'accento", "l'accent"], ["l'elisione", "l'élision"], ["il troncamento", "la troncation"], ["un po'", "un peu"], ["qual è", "quel est"], ["perché", "pourquoi ; parce que"]],
    quiz: [
      mcq("Quelle forme est correcte ?", ["qual è", "qual'è", "quale'è", "qualè"], 0, "Troncamento : pas d'apostrophe."),
      mcq("Quelle forme est correcte ?", ["un'amica", "un amica", "una'amica", "un'amico"], 0, "Féminin élidé → apostrophe."),
      mcq("Accent correct :", ["perché", "perchè", "perche'", "perche"], 0, "Accent aigu sur -ché."),
      mcq("« Lui mi ___ un consiglio. » (il me donne)", ["dà", "da", "da'", "dá"], 0, "dà (verbe) prend l'accent."),
      fill("Vuoi un ___ di torta? (peu)", ["po'"], "po' avec apostrophe."),
      mcq("Quel mot ne prend JAMAIS d'accent ?", ["qui", "sì", "là", "è"], 0, "qui, qua, su, blu : jamais d'accent."),
      tr("Écrivez correctement : quel est le problème ?", ["qual è il problema"], "qual è, sans apostrophe."),
    ],
  },
];

export const C2_EXAM_PLUS = [
  mcq("« Finita la partita, tornammo a casa » :", ["Une fois le match terminé, nous rentrâmes", "Pour finir le match, nous rentrâmes", "Le match fini demain", "Si le match finit"], 0, "Participe absolu."),
  mcq("« Avrà dimenticato l'appuntamento » :", ["Il a dû oublier le rendez-vous", "Il oubliera le rendez-vous", "Il aurait oublié", "Il n'oublie pas"], 0, "Futur antérieur de probabilité."),
  mcq("Équivalent soutenu de « quindi » :", ["pertanto", "boh", "figo", "allora (fam.)"], 0, "pertanto."),
  mcq("« Mellone » pour la pastèque se dit surtout :", ["dans le Sud", "dans le Nord", "en Toscane", "à Milan"], 0, "anguria / cocomero / mellone."),
  mcq("Auteur des « Promessi sposi » :", ["Manzoni", "Dante", "Leopardi", "Boccace"], 0, "Alessandro Manzoni."),
  mcq("Forme correcte :", ["qual è", "qual'è", "qual é", "qualè"], 0, "Pas d'apostrophe."),
  fill("Dopo ___ arrivati, abbiamo cenato. (essere, forme courte)", ["esser", "essere"], "dopo esser arrivati."),
  mcq("« Secondo fonti, il presidente sarebbe malato » :", ["information non confirmée", "information officielle", "hypothèse pour le futur", "souhait du journaliste"], 0, "Conditionnel de dissociation."),
  mcq("Accent correct :", ["poiché", "poichè", "poiche", "poichê"], 0, "Accent aigu."),
  tr("Traduisez : Il doit être huit heures.", ["saranno le otto", "saranno le 8"], "Futur de probabilité."),
];
