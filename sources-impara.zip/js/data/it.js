/* =====================================================================
   IMPARA — Contenu pédagogique (A1 → C2)
   ---------------------------------------------------------------------
   Ce fichier ne contient QUE des données. Pour ajouter une leçon :
   1. ajoutez un objet dans le tableau `lessons` du palier voulu ;
   2. donnez-lui un `id` unique (lettres, chiffres, tirets) ;
   3. c'est tout : la carte, le carnet et la progression s'adaptent.

   Types de questions supportés par le moteur de quiz :
   - mcq       : QCM            { q, options[], answer:index, explain }
   - fill      : texte à trous  { q (avec ___), answer:[acceptées], explain }
   - match     : association    { q, pairs:[[it, fr], ...], explain }
   - translate : traduction     { q, answer:[acceptées], explain }
   ===================================================================== */

// Petits constructeurs pour garder les données lisibles
import { A1_PLUS, A1_EXAM_PLUS } from "./it-a1-plus.js";
import { A2_PLUS, A2_EXAM_PLUS } from "./it-a2-plus.js";
import { B1_PLUS, B1_EXAM_PLUS } from "./it-b1-plus.js";
import { B2_PLUS, B2_EXAM_PLUS } from "./it-b2-plus.js";
import { C1_PLUS, C1_EXAM_PLUS, C2_PLUS, C2_EXAM_PLUS } from "./it-c-plus.js";

const mcq = (q, options, answer, explain = "") => ({ type: "mcq", q, options, answer, explain });
const fill = (q, answer, explain = "") => ({ type: "fill", q, answer, explain });
const match = (q, pairs, explain = "") => ({ type: "match", q, pairs, explain });
const tr = (q, answer, explain = "") => ({ type: "translate", q, answer, explain });

/** Modules pédagogiques (étiquettes affichées sur les leçons) */
export const MODULES = {
  bases: { label: "Bases", icon: "🔤" },
  vocab: { label: "Vocabulaire", icon: "📚" },
  gram: { label: "Grammaire", icon: "🧩" },
  conj: { label: "Conjugaison", icon: "⏳" },
  nombres: { label: "Nombres", icon: "🔢" },
  expr: { label: "Expressions", icon: "💬" },
};

export const LEVELS = [
  /* ================================================================ A1 */
  {
    id: "A1", name: "Débutant", title: "Les premiers pas", emoji: "🌱", color: "#1e8e5a",
    desc: "Alphabet, salutations, chiffres et verbes essentiels.",
    lessons: [
      {
        id: "a1-alfabeto", module: "bases", title: "L'alphabet et la prononciation", emoji: "🔤",
        intro: "Bonne nouvelle : l'italien se lit presque toujours comme il s'écrit. Quelques règles suffisent pour tout prononcer correctement.",
        sections: [
          {
            title: "21 lettres seulement",
            text: "L'alphabet italien compte <b>21 lettres</b>. J, K, W, X et Y n'apparaissent que dans les mots étrangers (<i>jeans, kiwi, taxi</i>). Toutes les lettres se prononcent, y compris le <b>e</b> final.",
            examples: [["ciao", "salut — « tchao »"], ["pane", "pain — « pané »"], ["amore", "amour — « amoré »"]],
          },
          {
            title: "C et G : doux ou durs ?",
            text: "Devant <b>E</b> et <b>I</b>, C se prononce « tch » et G « dj ». Devant A, O, U, ils sont durs. Pour les durcir devant E/I, on glisse un <b>H</b> : CHE = « ké », GHI = « gui ».",
            examples: [["cena", "dîner — « tchéna »"], ["gelato", "glace — « djélato »"], ["chiesa", "église — « kiéza »"], ["spaghetti", "spaghettis — « spaguétti »"]],
          },
          {
            title: "Les sons spéciaux",
            text: "<b>GLI</b> ≈ « lli » mouillé · <b>GN</b> comme en français · <b>SCI/SCE</b> = « ch » · le <b>R</b> est roulé · les <b>doubles consonnes</b> s'appuient (pala ≠ palla).",
            examples: [["famiglia", "famille"], ["gnocchi", "gnocchis"], ["pesce", "poisson — « péché »"], ["nonno", "grand-père (n appuyé)"]],
          },
        ],
        mnemo: "Le H italien ne se prononce jamais : c'est un « bouclier » qui garde C et G durs. Pensez au vin « CHIanti » = « kianti ».",
        vocab: [["ciao", "salut / au revoir"], ["grazie", "merci"], ["prego", "je vous en prie"], ["sì", "oui"], ["no", "non"], ["per favore", "s'il vous plaît"], ["scusa", "pardon (tu)"]],
        quiz: [
          mcq("Comment se prononce « cena » ?", ["« kéna »", "« tchéna »", "« séna »", "« chéna »"], 1, "Devant E et I, le C se prononce « tch »."),
          mcq("Quelle orthographe donne le son « ké » ?", ["ce", "che", "cie", "qe"], 1, "Le H durcit le C devant E et I : CHE = « ké »."),
          match("Associez chaque mot à sa traduction", [["grazie", "merci"], ["prego", "je vous en prie"], ["sì", "oui"], ["per favore", "s'il vous plaît"]]),
          mcq("Combien de lettres compte l'alphabet italien ?", ["26", "21", "24", "19"], 1, "21 lettres : J, K, W, X, Y sont réservées aux mots étrangers."),
          tr("Traduisez : merci", ["grazie"], "« Merci » se dit grazie (« gra-tsié »)."),
        ],
      },
      {
        id: "a1-saluti", module: "expr", title: "Saluer et se présenter", emoji: "👋",
        intro: "Les premiers mots de toute conversation : dire bonjour au bon moment, se présenter, et choisir entre « tu » et « vous ».",
        sections: [
          {
            title: "Dire bonjour selon le moment",
            text: "<b>Buongiorno</b> le matin et l'après-midi, <b>buonasera</b> à partir de 17 h environ, <b>buonanotte</b> seulement en allant se coucher. <b>Ciao</b> est informel (bonjour ET au revoir), <b>salve</b> est neutre et poli.",
            examples: [["Buongiorno, signora!", "Bonjour, madame !"], ["Buonasera a tutti.", "Bonsoir à tous."], ["Arrivederci!", "Au revoir !"]],
          },
          {
            title: "Se présenter",
            text: "On utilise le verbe pronominal <b>chiamarsi</b> (s'appeler).",
            examples: [["Come ti chiami?", "Comment t'appelles-tu ?"], ["Mi chiamo Marco.", "Je m'appelle Marco."], ["Piacere!", "Enchanté(e) !"], ["Di dove sei? — Sono francese.", "D'où es-tu ? — Je suis français(e)."]],
          },
          {
            title: "Tu ou Lei ?",
            text: "Le vouvoiement italien utilise <b>Lei</b> (« elle ») + le verbe à la <b>3e personne</b>, même pour un homme.",
            examples: [["Come stai?", "Comment vas-tu ?"], ["Come sta?", "Comment allez-vous ?"], ["Bene, grazie. E Lei?", "Bien, merci. Et vous ?"]],
          },
        ],
        mnemo: "« Lei », c'est comme parler à Sa Majesté : on s'adresse à la personne à la 3e personne, par respect.",
        vocab: [["buongiorno", "bonjour"], ["buonasera", "bonsoir"], ["buonanotte", "bonne nuit"], ["arrivederci", "au revoir"], ["salve", "bonjour (neutre)"], ["piacere", "enchanté(e)"], ["come stai?", "comment vas-tu ?"], ["bene", "bien"]],
        quiz: [
          mcq("Il est 20 h, vous entrez dans un restaurant. Vous dites :", ["Buongiorno", "Buonanotte", "Buonasera", "Arrivederci"], 2, "Buonasera s'utilise à partir de la fin d'après-midi. Buonanotte se dit seulement en allant se coucher."),
          fill("Ciao! Mi ___ Marco.", ["chiamo"], "Mi chiamo = je m'appelle (verbe chiamarsi)."),
          mcq("Comment demander poliment « Comment allez-vous ? » à un inconnu ?", ["Come stai?", "Come sta?", "Come stanno?", "Come state?"], 1, "Avec le vouvoiement (Lei), on conjugue à la 3e personne du singulier : Come sta?"),
          match("Associez chaque mot à sa traduction", [["arrivederci", "au revoir"], ["piacere", "enchanté(e)"], ["buonanotte", "bonne nuit"], ["salve", "bonjour (neutre)"]]),
          tr("Traduisez : Je suis français.", ["sono francese", "io sono francese"], "Sono francese — le pronom « io » est généralement omis. Francese est identique au masculin et au féminin."),
        ],
      },
      {
        id: "a1-numeri", module: "nombres", title: "Les chiffres et les nombres", emoji: "🔢",
        intro: "Compter de 0 à 1000, payer, donner son âge ou son numéro : les nombres italiens sont très logiques.",
        sections: [
          {
            title: "De 0 à 10",
            text: "À apprendre par cœur : ce sont les briques de tous les autres nombres.",
            table: { cols: ["", "", "", ""], rows: [["0 zero", "1 uno", "2 due", "3 tre"], ["4 quattro", "5 cinque", "6 sei", "7 sette"], ["8 otto", "9 nove", "10 dieci", ""]] },
          },
          {
            title: "De 11 à 20",
            text: "De 11 à 16, l'unité vient <b>avant</b> (-dici). À partir de 17, elle vient <b>après</b> (dicia-).",
            table: { cols: ["", "", "", "", ""], rows: [["11 undici", "12 dodici", "13 tredici", "14 quattordici", "15 quindici"], ["16 sedici", "17 diciassette", "18 diciotto", "19 diciannove", "20 venti"]] },
          },
          {
            title: "Dizaines, centaines, milliers",
            text: "venti, trenta, quaranta, cinquanta, sessanta, settanta, ottanta, novanta, <b>cento</b>, <b>mille</b> (pluriel : <i>mila</i>). La dizaine perd sa voyelle devant <b>uno</b> et <b>otto</b>. Tre final prend un accent : <i>ventitré</i>.",
            examples: [["ventuno", "21"], ["ventotto", "28"], ["trentatré", "33"], ["centocinquanta", "150"], ["duemilaventisei", "2026"]],
          },
        ],
        mnemo: "17-19 : « dicia- » = « dix-et- » → diciassette, diciotto, diciannove suivent exactement l'ordre français dix-sept, dix-huit, dix-neuf.",
        vocab: [["uno", "un"], ["dieci", "dix"], ["venti", "vingt"], ["cento", "cent"], ["mille", "mille"], ["quanto costa?", "combien ça coûte ?"]],
        quiz: [
          mcq("Comment dit-on 15 ?", ["cinquedici", "quindici", "quindieci", "quinze"], 1, "15 = quindici (de 11 à 16, l'unité se place avant -dici)."),
          fill("20 + 1 = ___ (en lettres)", ["ventuno"], "Devant uno et otto, la dizaine perd sa voyelle : venti → ventuno."),
          mcq("Que signifie « diciotto » ?", ["16", "17", "18", "19"], 2, "Dicia- + otto = dix-huit."),
          match("Associez chaque nombre", [["trenta", "30"], ["cinquanta", "50"], ["settanta", "70"], ["novanta", "90"]]),
          tr("Écrivez en lettres : 28", ["ventotto"], "Venti + otto → ventotto (le i tombe devant otto)."),
        ],
      },
      {
        id: "a1-essere-avere", module: "conj", title: "Les verbes essere et avere", emoji: "⏳",
        intro: "Être et avoir : les deux verbes les plus utilisés, indispensables pour former tous les temps composés.",
        sections: [
          {
            title: "Essere (être)",
            text: "Les pronoms sujets sont souvent omis : la terminaison suffit. Attention : <b>è</b> (il est) ≠ <b>e</b> (et).",
            table: { cols: ["Pronom", "Essere"], rows: [["io", "sono"], ["tu", "sei"], ["lui / lei / Lei", "è"], ["noi", "siamo"], ["voi", "siete"], ["loro", "sono"]] },
          },
          {
            title: "Avere (avoir)",
            text: "Le <b>h</b> ne se prononce pas : il distingue <i>ho</i> (j'ai) de <i>o</i> (ou), <i>ha</i> de <i>a</i> (à), <i>hanno</i> de <i>anno</i> (année).",
            table: { cols: ["Pronom", "Avere"], rows: [["io", "ho"], ["tu", "hai"], ["lui / lei / Lei", "ha"], ["noi", "abbiamo"], ["voi", "avete"], ["loro", "hanno"]] },
          },
          {
            title: "Expressions avec avere",
            text: "Comme en français, on « a » faim, soif, froid… et son âge.",
            examples: [["Ho fame.", "J'ai faim."], ["Hai sete?", "Tu as soif ?"], ["Ho vent'anni.", "J'ai vingt ans."], ["Quanti anni hai?", "Quel âge as-tu ?"]],
          },
        ],
        mnemo: "Le h muet de ho, hai, ha, hanno sert uniquement à les distinguer de o (ou), ai (aux), a (à) et anno (année).",
        vocab: [["essere", "être"], ["avere", "avoir"], ["la fame", "la faim"], ["la sete", "la soif"], ["l'anno", "l'année"], ["stanco", "fatigué"], ["contento", "content"]],
        quiz: [
          fill("Noi ___ italiani. (essere)", ["siamo"], "Essere, 1re personne du pluriel : siamo."),
          fill("Loro ___ una macchina rossa. (avere)", ["hanno"], "Avere à la 3e personne du pluriel : hanno. Una macchina = une voiture."),
          mcq("Quelle phrase signifie « J'ai soif » ?", ["Sono sete", "Ho sete", "Ho la sete", "Ha sete"], 1, "Comme en français, on utilise avere : ho sete."),
          mcq("Lequel signifie « il est » ?", ["e", "è", "ha", "hai"], 1, "è avec accent = il/elle est ; e sans accent = et."),
          tr("Traduisez : Tu as vingt ans.", ["hai venti anni", "tu hai venti anni", "hai vent'anni", "tu hai vent'anni"], "Hai vent'anni (ou venti anni). L'élision « vent'anni » est très courante."),
        ],
      },
      {
        id: "a1-articoli", module: "gram", title: "Le genre et les articles", emoji: "🧩",
        intro: "En italien, chaque nom a un genre, et l'article change selon la première lettre du mot. Une seule règle à comprendre !",
        sections: [
          {
            title: "Masculin, féminin, pluriel",
            text: "Noms en <b>-o</b> → généralement masculins ; en <b>-a</b> → féminins ; en <b>-e</b> → les deux. Pluriel : -o → <b>-i</b>, -a → <b>-e</b>, -e → <b>-i</b>.",
            examples: [["il ragazzo → i ragazzi", "le garçon → les garçons"], ["la ragazza → le ragazze", "la fille → les filles"], ["il fiore → i fiori", "la fleur → les fleurs"]],
          },
          {
            title: "L'article défini",
            text: "Au masculin, l'article dépend du son qui suit.",
            table: { cols: ["Devant…", "Singulier", "Pluriel"], rows: [["consonne (m.)", "il treno", "i treni"], ["s+consonne, z, gn, ps (m.)", "lo studente", "gli studenti"], ["voyelle (m.)", "l'amico", "gli amici"], ["consonne (f.)", "la pizza", "le pizze"], ["voyelle (f.)", "l'amica", "le amiche"]] },
          },
          {
            title: "L'article indéfini",
            text: "<b>un</b> (masc.), <b>uno</b> (masc. devant s+consonne, z…), <b>una</b> (fém.), <b>un'</b> (fém. devant voyelle).",
            examples: [["un caffè", "un café"], ["uno zio", "un oncle"], ["una birra", "une bière"], ["un'amica", "une amie"]],
          },
        ],
        mnemo: "« Lo » et « uno » sont les articles des mots difficiles à prononcer : S+consonne, Z, GN, PS. Lo studente, lo zucchero, uno psicologo.",
        vocab: [["il libro", "le livre"], ["la casa", "la maison"], ["lo studente", "l'étudiant"], ["l'amico", "l'ami"], ["la ragazza", "la fille"], ["lo zaino", "le sac à dos"], ["il caffè", "le café"]],
        quiz: [
          mcq("___ zaino", ["il", "lo", "la", "l'"], 1, "Zaino commence par z → lo zaino."),
          mcq("Pluriel de « l'amico » :", ["i amici", "gli amici", "le amici", "li amici"], 1, "Le pluriel de lo et de l' (masculin) est gli."),
          fill("Vorrei ___ birra, per favore.", ["una"], "Birra est féminin et commence par une consonne → una."),
          match("Associez singulier et pluriel", [["il treno", "i treni"], ["la pizza", "le pizze"], ["lo studente", "gli studenti"], ["il fiore", "i fiori"]]),
          mcq("Quel article pour « amica » (une amie) ?", ["un", "uno", "una", "un'"], 3, "Féminin devant voyelle : un' avec apostrophe. Au masculin, pas d'apostrophe : un amico."),
        ],
      },
    ],
    exam: [
      mcq("Comment se prononce « gelato » ?", ["« guélato »", "« djélato »", "« jélato »", "« khélato »"], 1, "G devant E = « dj »."),
      fill("Tu ___ stanco? (essere)", ["sei"], "Essere, 2e personne : sei."),
      mcq("___ studenti", ["i", "gli", "le", "lo"], 1, "Studente commence par s+consonne → lo studente, gli studenti."),
      tr("Traduisez : Bonsoir", ["buonasera"], "Buonasera, à partir de la fin d'après-midi."),
      fill("30 + 3 = ___ (en lettres)", ["trentatré"], "Trentatré, avec un accent sur le e final."),
      mcq("Comment dit-on « J'ai faim » ?", ["Sono fame", "Ho fame", "Ho la fama", "Ha fame"], 1, "Avere fame : ho fame."),
      match("Associez", [["buongiorno", "bonjour"], ["arrivederci", "au revoir"], ["scusa", "pardon"], ["prego", "je vous en prie"]]),
      mcq("___ amica", ["un", "uno", "una", "un'"], 3, "Féminin devant voyelle : un'amica."),
    ],
  },

  /* ================================================================ A2 */
  {
    id: "A2", name: "Élémentaire", title: "La vie quotidienne", emoji: "🍝", color: "#2f7d8c",
    desc: "Présent, passé composé, l'heure et les prépositions.",
    lessons: [
      {
        id: "a2-presente", module: "conj", title: "Le présent des verbes", emoji: "⏳",
        intro: "Trois groupes de verbes, une logique commune : une fois le modèle compris, vous conjuguez des centaines de verbes.",
        sections: [
          {
            title: "Les trois groupes",
            text: "Verbes en <b>-are</b>, <b>-ere</b> et <b>-ire</b>. On retire la terminaison et on ajoute celle de la personne.",
            table: { cols: ["", "parlare", "prendere", "dormire"], rows: [["io", "parlo", "prendo", "dormo"], ["tu", "parli", "prendi", "dormi"], ["lui/lei", "parla", "prende", "dorme"], ["noi", "parliamo", "prendiamo", "dormiamo"], ["voi", "parlate", "prendete", "dormite"], ["loro", "parlano", "prendono", "dormono"]] },
          },
          {
            title: "Les verbes en -isc",
            text: "Certains verbes en -ire ajoutent <b>-isc-</b> sauf à noi et voi : <i>finire, capire, preferire, pulire</i>.",
            examples: [["finisco, finisci, finisce", "je finis, tu finis, il finit"], ["finiamo, finite, finiscono", "nous finissons, vous finissez, ils finissent"], ["Capisci?", "Tu comprends ?"]],
          },
          {
            title: "Les irréguliers fréquents",
            text: "<b>andare</b> : vado, vai, va, andiamo, andate, vanno · <b>fare</b> : faccio, fai, fa, facciamo, fate, fanno · <b>volere</b> : voglio · <b>potere</b> : posso.",
            examples: [["Vado al lavoro.", "Je vais au travail."], ["Che cosa fai?", "Que fais-tu ?"]],
          },
        ],
        mnemo: "La 1re personne finit toujours en -O (parlo, prendo, dormo, finisco) et la 2e en -I. Seule la 3e change selon le groupe.",
        vocab: [["parlare", "parler"], ["mangiare", "manger"], ["prendere", "prendre"], ["dormire", "dormir"], ["capire", "comprendre"], ["andare", "aller"], ["fare", "faire"]],
        quiz: [
          fill("Io ___ italiano e francese. (parlare)", ["parlo"], "Parlare → io parlo."),
          fill("Voi ___ la pizza? (prendere)", ["prendete"], "Prendere → voi prendete."),
          mcq("Loro ___ (capire) tutto.", ["capono", "capiscono", "capisciono", "capiano"], 1, "Capire est un verbe en -isc : capiscono."),
          mcq("Comment dit-on « je vais » ?", ["ando", "vo", "vado", "andio"], 2, "Andare est irrégulier : vado."),
          tr("Traduisez : Nous mangeons des pâtes.", ["mangiamo la pasta", "mangiamo pasta", "noi mangiamo la pasta", "noi mangiamo pasta", "mangiamo della pasta"], "Mangiare → mangiamo (on ne double pas le i)."),
        ],
      },
      {
        id: "a2-passato", module: "conj", title: "Le passé composé (passato prossimo)", emoji: "⏳",
        intro: "Pour raconter ce que vous avez fait hier, le week-end dernier ou pendant vos vacances.",
        sections: [
          {
            title: "Formation",
            text: "Auxiliaire <b>avere</b> ou <b>essere</b> au présent + participe passé : -are → <b>-ato</b>, -ere → <b>-uto</b>, -ire → <b>-ito</b>.",
            examples: [["Ho mangiato.", "J'ai mangé."], ["Hai venduto la macchina?", "Tu as vendu la voiture ?"], ["Abbiamo dormito bene.", "Nous avons bien dormi."]],
          },
          {
            title: "Avere ou essere ?",
            text: "<b>Essere</b> avec les verbes de mouvement et d'état (andare, venire, partire, arrivare, uscire, nascere, restare…), les verbes pronominaux et essere lui-même. Le participe s'<b>accorde</b> alors avec le sujet.",
            examples: [["Maria è andata a Roma.", "Maria est allée à Rome."], ["Siamo partiti presto.", "Nous sommes partis tôt."], ["Sono stato in Italia.", "J'ai été en Italie."]],
          },
          {
            title: "Participes irréguliers",
            text: "fare → <b>fatto</b> · dire → <b>detto</b> · prendere → <b>preso</b> · vedere → <b>visto</b> · scrivere → <b>scritto</b> · leggere → <b>letto</b> · aprire → <b>aperto</b> · venire → <b>venuto</b> · essere → <b>stato</b>.",
          },
        ],
        mnemo: "Les verbes qui prennent « être » en français prennent essere en italien. Bonus : essere se conjugue avec lui-même → sono stato (j'ai été).",
        vocab: [["ieri", "hier"], ["la settimana scorsa", "la semaine dernière"], ["fatto", "fait"], ["detto", "dit"], ["visto", "vu"], ["già", "déjà"], ["ancora", "encore"]],
        quiz: [
          mcq("Ieri Giulia ___ al mare.", ["ha andato", "è andato", "è andata", "ha andata"], 2, "Andare se conjugue avec essere, et le participe s'accorde au féminin : è andata."),
          fill("Ho ___ un bel film. (vedere)", ["visto", "veduto"], "Visto est le participe usuel de vedere."),
          mcq("Participe passé de « fare » :", ["fato", "fatto", "faciuto", "fasto"], 1, "Fare → fatto (irrégulier)."),
          fill("Noi ___ stati a Roma.", ["siamo"], "Essere se conjugue avec essere : siamo stati."),
          tr("Traduisez : J'ai mangé une pizza.", ["ho mangiato una pizza", "io ho mangiato una pizza"], "Ho mangiato una pizza."),
        ],
      },
      {
        id: "a2-ore", module: "nombres", title: "L'heure, les jours et les mois", emoji: "🕒",
        intro: "Fixer un rendez-vous, lire un horaire, donner une date : les nombres appliqués au temps.",
        sections: [
          {
            title: "Che ore sono?",
            text: "On dit <b>Sono le</b> + heure (pluriel), sauf pour une heure, midi et minuit : <b>È l'una, è mezzogiorno, è mezzanotte</b>. <i>e un quarto</i> = et quart, <i>e mezza</i> = et demie, <i>meno un quarto</i> = moins le quart.",
            examples: [["Sono le tre.", "Il est trois heures."], ["È l'una e mezza.", "Il est une heure et demie."], ["Sono le otto meno un quarto.", "Il est huit heures moins le quart."]],
          },
          {
            title: "Les jours de la semaine",
            text: "lunedì, martedì, mercoledì, giovedì, venerdì, sabato, domenica — <b>sans majuscule</b>. « Il lunedì » = tous les lundis.",
            examples: [["Ci vediamo sabato.", "On se voit samedi."], ["Il lunedì lavoro.", "Le lundi, je travaille."]],
          },
          {
            title: "Les mois et les dates",
            text: "gennaio, febbraio, marzo, aprile, maggio, giugno, luglio, agosto, settembre, ottobre, novembre, dicembre. Pour les dates, on utilise le nombre cardinal, sauf pour le 1er : <b>il primo maggio</b>, <i>il due giugno</i>.",
          },
        ],
        mnemo: "Les jours viennent des planètes, comme en français : lunedì (Lune), martedì (Mars), mercoledì (Mercure), giovedì (Giove = Jupiter), venerdì (Vénus).",
        vocab: [["che ore sono?", "quelle heure est-il ?"], ["mezzogiorno", "midi"], ["oggi", "aujourd'hui"], ["domani", "demain"], ["la settimana", "la semaine"], ["il mese", "le mois"]],
        quiz: [
          mcq("Il est 13 h 00. On dit :", ["Sono l'una", "È l'una", "È le tredici", "Sono una"], 1, "Une heure est au singulier : È l'una. Pour les autres heures : Sono le…"),
          mcq("Comment dit-on « 8 h 30 » ?", ["Sono le otto e mezza", "È le otto e mezzo", "Sono otto e trenta minuti", "Le otto meno mezza"], 0, "Sono le otto e mezza (ou e mezzo, les deux existent)."),
          match("Associez les jours", [["lunedì", "lundi"], ["giovedì", "jeudi"], ["sabato", "samedi"], ["domenica", "dimanche"]]),
          fill("Il ___ maggio è la festa dei lavoratori.", ["primo", "1°"], "Pour le 1er du mois on utilise l'ordinal : il primo maggio."),
          tr("Traduisez : demain", ["domani"], "Domani = demain ; dopodomani = après-demain."),
        ],
      },
      {
        id: "a2-preposizioni", module: "gram", title: "Les prépositions articulées", emoji: "🧩",
        intro: "Di, a, da, in, su… et leurs fusions avec l'article (del, al, nella…). Le point clé pour parler naturellement.",
        sections: [
          {
            title: "Les prépositions simples",
            text: "<b>di</b> (de) · <b>a</b> (à) · <b>da</b> (de / chez / depuis) · <b>in</b> (en, dans) · <b>con</b> (avec) · <b>su</b> (sur) · <b>per</b> (pour) · <b>tra / fra</b> (entre, dans [temps]).",
          },
          {
            title: "Préposition + article = une seule forme",
            text: "Di, a, da, in, su fusionnent avec l'article défini.",
            table: { cols: ["", "il", "lo", "la", "i", "gli", "le"], rows: [["di", "del", "dello", "della", "dei", "degli", "delle"], ["a", "al", "allo", "alla", "ai", "agli", "alle"], ["da", "dal", "dallo", "dalla", "dai", "dagli", "dalle"], ["in", "nel", "nello", "nella", "nei", "negli", "nelle"], ["su", "sul", "sullo", "sulla", "sui", "sugli", "sulle"]] },
          },
          {
            title: "Les usages clés",
            text: "Ville → <b>a</b> (a Roma). Pays, région → <b>in</b> (in Italia). Chez quelqu'un, depuis → <b>da</b>.",
            examples: [["Vado al cinema.", "Je vais au cinéma."], ["Vado dal medico.", "Je vais chez le médecin."], ["Abito qui da tre anni.", "J'habite ici depuis trois ans."]],
          },
        ],
        mnemo: "« DA » = chez / depuis / provenance : vado dal dentista, abito qui da due anni, vengo da Parigi.",
        vocab: [["dal medico", "chez le médecin"], ["al mare", "à la mer"], ["in montagna", "à la montagne"], ["sul tavolo", "sur la table"], ["nella borsa", "dans le sac"]],
        quiz: [
          mcq("Vado ___ Roma.", ["in", "a", "da", "per"], 1, "Villes → a. Pays et régions → in."),
          mcq("Il libro è ___ tavolo.", ["su il", "sul", "sullo", "sui"], 1, "Su + il = sul."),
          fill("Stasera vado ___ cinema.", ["al"], "A + il = al."),
          mcq("Studio italiano ___ due anni. (depuis)", ["per", "da", "di", "fra"], 1, "Da exprime une durée qui dure encore : depuis."),
          fill("Le chiavi sono ___ borsa. (dans le)", ["nella"], "In + la = nella."),
        ],
      },
    ],
    exam: [
      fill("Lei ___ (finire) il lavoro alle sei.", ["finisce"], "Finire (-isc) : lei finisce."),
      mcq("Siamo ___ in Italia l'estate scorsa.", ["andato", "andati", "andate", "andare"], 1, "Essere + accord au pluriel (masculin ou mixte) : andati."),
      mcq("Comment dit-on 15 h 45 ?", ["Sono le quattro meno un quarto", "È le tre e tre quarti", "Sono le cinque meno un quarto", "È le quattro meno quarto"], 0, "Sono le quattro meno un quarto (ou sono le quindici e quarantacinque)."),
      fill("Vado ___ dentista. (chez le)", ["dal"], "Da + il = dal."),
      fill("Ieri ho ___ una lettera. (scrivere)", ["scritto"], "Scrivere → scritto."),
      mcq("« Je fais » se dit :", ["faco", "faccio", "fao", "facio"], 1, "Fare → io faccio."),
      match("Associez les mois", [["gennaio", "janvier"], ["giugno", "juin"], ["luglio", "juillet"], ["dicembre", "décembre"]]),
      tr("Traduisez : Je pars demain.", ["parto domani", "domani parto", "io parto domani"], "Parto domani : le présent sert souvent de futur proche."),
    ],
  },

  /* ================================================================ B1 */
  {
    id: "B1", name: "Seuil", title: "Raconter et se projeter", emoji: "🛵", color: "#c98a1b",
    desc: "Imparfait, futur, conditionnel, pronoms et premières expressions.",
    lessons: [
      {
        id: "b1-imperfetto", module: "conj", title: "L'imparfait et son usage", emoji: "⏳",
        intro: "Décrire le passé, raconter des habitudes, planter le décor d'une histoire.",
        sections: [
          {
            title: "Une formation très régulière",
            text: "On retire <b>-re</b> de l'infinitif et on ajoute <b>-vo, -vi, -va, -vamo, -vate, -vano</b>. Seul essere est vraiment irrégulier : <b>ero, eri, era, eravamo, eravate, erano</b>. Fare → <i>facevo</i>, dire → <i>dicevo</i>, bere → <i>bevevo</i>.",
            examples: [["parlavo", "je parlais"], ["prendevamo", "nous prenions"], ["dormivano", "ils dormaient"]],
          },
          {
            title: "Imperfetto ou passato prossimo ?",
            text: "<b>Imperfetto</b> : description, habitude, action en cours. <b>Passato prossimo</b> : action ponctuelle et terminée.",
            examples: [["Mentre leggevo, è squillato il telefono.", "Pendant que je lisais, le téléphone a sonné."], ["Da bambino giocavo a calcio.", "Enfant, je jouais au foot."]],
          },
          {
            title: "Les mots-indices",
            text: "<i>da bambino, di solito, sempre, ogni giorno, mentre</i> → imperfetto. <i>ieri, all'improvviso, una volta, a un certo punto</i> → passato prossimo.",
          },
        ],
        mnemo: "L'imperfetto est le décor du film (il pleuvait, j'étais fatigué) ; le passato prossimo est l'action (soudain, le téléphone a sonné).",
        vocab: [["da bambino", "enfant (quand j'étais petit)"], ["di solito", "d'habitude"], ["mentre", "pendant que"], ["all'improvviso", "soudain"], ["squillare", "sonner (téléphone)"]],
        quiz: [
          fill("Da bambino ___ sempre al parco. (andare, io)", ["andavo"], "Habitude passée → imperfetto : andavo."),
          mcq("Mentre ___, è arrivato Luca.", ["ho cucinato", "cucinavo", "cucino", "cucinerò"], 1, "Action en cours (le décor) → imperfetto."),
          fill("Quando ero piccola, ___ molto timida. (essere, io)", ["ero"], "Description dans le passé : ero."),
          mcq("Choisissez la phrase correcte :", ["All'improvviso cominciava a piovere.", "All'improvviso ha cominciato a piovere.", "All'improvviso comincia a piovuto.", "All'improvviso era cominciato piovere."], 1, "Action soudaine et ponctuelle → passato prossimo."),
          tr("Traduisez : Il faisait beau.", ["faceva bel tempo", "era bel tempo", "c'era bel tempo"], "Description météo au passé : faceva bel tempo."),
        ],
      },
      {
        id: "b1-futuro", module: "conj", title: "Le futur et le conditionnel", emoji: "🔮",
        intro: "Parler de vos projets, faire des suppositions et formuler des demandes polies.",
        sections: [
          {
            title: "Le futur simple",
            text: "-are et -ere → <b>-erò</b>, -ire → <b>-irò</b> : parlerò, parlerai, parlerà, parleremo, parlerete, parleranno. Irréguliers : essere → <b>sarò</b>, avere → <b>avrò</b>, andare → <b>andrò</b>, fare → <b>farò</b>, venire → <b>verrò</b>, potere → <b>potrò</b>.",
            examples: [["L'anno prossimo andrò in Italia.", "L'an prochain j'irai en Italie."]],
          },
          {
            title: "Le futur de probabilité",
            text: "L'italien utilise le futur pour une <b>supposition</b> au présent.",
            examples: [["Che ore saranno?", "Quelle heure peut-il bien être ?"], ["Sarà a casa.", "Il doit être à la maison."]],
          },
          {
            title: "Le conditionnel présent",
            text: "Même radical que le futur + <b>-ei, -esti, -ebbe, -emmo, -este, -ebbero</b>.",
            examples: [["Vorrei un caffè.", "Je voudrais un café."], ["Potresti aiutarmi?", "Pourrais-tu m'aider ?"], ["Mi piacerebbe viaggiare.", "J'aimerais voyager."]],
          },
        ],
        mnemo: "Futur et conditionnel partagent le même radical. Connaître sarò, c'est connaître sarei ; avrò → avrei ; verrò → verrei.",
        vocab: [["l'anno prossimo", "l'an prochain"], ["fra una settimana", "dans une semaine"], ["vorrei", "je voudrais"], ["mi piacerebbe", "j'aimerais"], ["magari", "peut-être / si seulement"]],
        quiz: [
          fill("L'anno prossimo ___ in Italia. (andare, io)", ["andrò"], "Andare au futur : andrò."),
          mcq("« Vorrei un cappuccino » signifie :", ["Je veux un cappuccino", "Je voudrais un cappuccino", "J'ai voulu un cappuccino", "Je voulais un cappuccino"], 1, "Vorrei = conditionnel de volere."),
          mcq("Futur de « essere » (loro) :", ["esseranno", "saranno", "sarebbero", "sono"], 1, "Saranno. Sarebbero est le conditionnel."),
          fill("___ aiutarmi, per favore? (potere, tu, conditionnel)", ["potresti"], "Potere → potr- + esti = potresti."),
          mcq("« Dov'è Marco? — Sarà a casa. » Ici, « sarà » exprime :", ["un fait futur", "une supposition", "un passé", "une condition"], 1, "Futur de probabilité : il doit être à la maison."),
        ],
      },
      {
        id: "b1-pronomi", module: "gram", title: "Les pronoms compléments, ne et ci", emoji: "🧩",
        intro: "Éviter les répétitions comme un natif : lo, la, gli, le, ne, ci.",
        sections: [
          {
            title: "Les pronoms COD",
            text: "<b>mi, ti, lo, la, ci, vi, li, le</b>. Avant le verbe conjugué, ou attachés à l'infinitif.",
            examples: [["Lo vedo stasera.", "Je le vois ce soir."], ["Voglio vederla. / La voglio vedere.", "Je veux la voir."]],
          },
          {
            title: "Les pronoms COI",
            text: "<b>mi, ti, gli</b> (à lui), <b>le</b> (à elle), <b>Le</b> (à vous), <b>ci, vi, gli</b> (à eux).",
            examples: [["Gli scrivo una mail.", "Je lui écris un mail (à lui)."], ["Le telefono domani.", "Je lui téléphone demain (à elle)."], ["Mi piace la pizza.", "J'aime la pizza (elle me plaît)."]],
          },
          {
            title: "Ne et ci",
            text: "<b>ne</b> = en (quantité, « de cela ») · <b>ci</b> = y (lieu).",
            examples: [["Quanti caffè bevi? — Ne bevo tre.", "Combien de cafés bois-tu ? — J'en bois trois."], ["Vai a Roma? — Sì, ci vado domani.", "Tu vas à Rome ? — Oui, j'y vais demain."]],
          },
        ],
        mnemo: "Piacere = « plaire » : mi piace la pizza (la pizza me plaît), mi piacciono gli spaghetti (pluriel, car c'est le sujet !).",
        vocab: [["piacere", "plaire"], ["telefonare a", "téléphoner à"], ["ne", "en"], ["ci", "y"]],
        quiz: [
          mcq("Vedi Marco stasera? — Sì, ___ vedo alle otto.", ["gli", "lo", "la", "ne"], 1, "COD masculin : lo."),
          mcq("Hai telefonato a Giulia? — Sì, ___ ho telefonato.", ["la", "gli", "le", "lo"], 2, "Telefonare a qualcuno → COI ; au féminin : le."),
          fill("Quante mele vuoi? — ___ voglio due.", ["ne"], "Ne remplace une quantité : j'en veux deux."),
          mcq("___ piacciono i film italiani.", ["Mi", "Io", "Me", "Mio"], 0, "Mi piacciono : les films me plaisent."),
          fill("Vai spesso al mare? — Sì, ___ vado ogni estate.", ["ci"], "Ci remplace le lieu : j'y vais."),
        ],
      },
      {
        id: "b1-espressioni", module: "expr", title: "Expressions idiomatiques du quotidien", emoji: "💬",
        intro: "Ce qui fait passer d'un italien scolaire à un italien vivant.",
        sections: [
          {
            title: "Souhaiter bonne chance",
            text: "On dit <b>In bocca al lupo!</b> (« dans la gueule du loup ») et on répond <b>Crepi!</b> (« qu'il crève ! »). Ne répondez jamais <i>grazie</i>, cela porterait malheur.",
          },
          {
            title: "Les classiques",
            examples: [["Non vedo l'ora!", "J'ai hâte !"], ["Costa un occhio della testa.", "Ça coûte les yeux de la tête."], ["Sono al verde.", "Je suis fauché."], ["Che figura!", "La honte !"], ["Facciamo due passi?", "On fait un tour ?"]],
          },
          {
            title: "Les petits mots magiques",
            examples: [["Boh!", "Je ne sais pas."], ["Magari!", "Si seulement !"], ["Dai!", "Allez !"], ["Meno male!", "Heureusement !"], ["Figurati!", "De rien / penses-tu !"]],
          },
        ],
        mnemo: "« Fare bella figura » est une valeur culturelle centrale : soigner son image en public. Une « brutta figura » est une petite honte sociale.",
        vocab: [["in bocca al lupo", "bonne chance"], ["crepi", "réponse à « in bocca al lupo »"], ["non vedo l'ora", "j'ai hâte"], ["essere al verde", "être fauché"], ["boh", "je ne sais pas"], ["magari", "si seulement"], ["figurati", "de rien / penses-tu"], ["meno male", "heureusement"]],
        quiz: [
          mcq("Un ami vous dit « In bocca al lupo! » avant votre examen. Vous répondez :", ["Grazie mille!", "Crepi!", "Anche a te!", "Prego!"], 1, "La réponse traditionnelle est Crepi! (et jamais grazie)."),
          match("Associez", [["non vedo l'ora", "j'ai hâte"], ["essere al verde", "être fauché"], ["meno male", "heureusement"], ["figurati", "de rien / penses-tu"]]),
          mcq("« Questo telefono costa un occhio della testa » signifie :", ["Il est très cher", "Il est cassé", "Il est bon marché", "Il est très beau"], 0, "Même image qu'en français : les yeux de la tête."),
          mcq("« Vieni alla festa? — Boh... » La personne :", ["accepte avec joie", "ne sait pas", "refuse", "est en colère"], 1, "Boh exprime l'incertitude."),
          tr("Traduisez : J'ai hâte !", ["non vedo l'ora"], "Littéralement : « je ne vois pas l'heure »."),
        ],
      },
    ],
    exam: [
      fill("Quando avevo dieci anni, ___ (giocare, io) a calcio.", ["giocavo"], "Habitude passée : giocavo."),
      mcq("Domani ___ (fare, noi) una gita.", ["faremo", "fareremo", "farremo", "facessimo"], 0, "Fare au futur : faremo."),
      mcq("Hai visto le ragazze? — Sì, ___ ho viste.", ["li", "le", "gli", "ne"], 1, "COD féminin pluriel : le (et le participe s'accorde : viste)."),
      mcq("In bocca al lupo! — …", ["Crepi!", "Grazie!", "Prego!", "Salute!"], 0, "Crepi!"),
      fill("___ un caffè, per favore. (volere, conditionnel, io)", ["vorrei"], "Vorrei."),
      mcq("Mentre ___ la TV, è andata via la luce.", ["ho guardato", "guardavo", "guarderò", "guardassi"], 1, "Action en cours → imperfetto."),
      fill("Quanti fratelli hai? — ___ ho due.", ["ne"], "Ne ho due : j'en ai deux."),
      tr("Traduisez : Je suis fauché.", ["sono al verde"], "Essere al verde."),
    ],
  },

  /* ================================================================ B2 */
  {
    id: "B2", name: "Avancé", title: "Nuancer et argumenter", emoji: "🏛️", color: "#b8483f",
    desc: "Subjonctif, hypothèses et italien professionnel.",
    lessons: [
      {
        id: "b2-congiuntivo", module: "conj", title: "Le subjonctif présent (congiuntivo)", emoji: "⏳",
        intro: "Le grand marqueur du niveau B2 : exprimer opinion, désir, doute et émotion.",
        sections: [
          {
            title: "Quand l'utiliser ?",
            text: "Après les verbes d'<b>opinion</b> (penso che, credo che), de <b>volonté</b> (voglio che), de <b>sentiment</b> (sono contento che), de <b>doute</b> (dubito che) et certaines conjonctions (benché, affinché, prima che). Grande différence avec le français : « je pense que c'est vrai » → <i>penso che <b>sia</b> vero</i>.",
          },
          {
            title: "Formation",
            text: "-are → terminaisons en <b>-i</b> ; -ere/-ire → en <b>-a</b>. Les trois personnes du singulier sont identiques : gardez le pronom si c'est ambigu.",
            table: { cols: ["", "parlare", "prendere", "finire"], rows: [["che io/tu/lui", "parli", "prenda", "finisca"], ["che noi", "parliamo", "prendiamo", "finiamo"], ["che voi", "parliate", "prendiate", "finiate"], ["che loro", "parlino", "prendano", "finiscano"]] },
          },
          {
            title: "Les irréguliers à connaître",
            text: "essere → <b>sia</b> · avere → <b>abbia</b> · andare → <b>vada</b> · fare → <b>faccia</b> · venire → <b>venga</b> · potere → <b>possa</b> · volere → <b>voglia</b> · sapere → <b>sappia</b> · dare → <b>dia</b> · stare → <b>stia</b>.",
          },
        ],
        mnemo: "Ce qui se passe dans votre tête (opinion, désir, peur, doute) → congiuntivo. Ce qui est un fait certain → indicatif : so che è vero (je sais = certitude).",
        vocab: [["penso che", "je pense que"], ["credo che", "je crois que"], ["è importante che", "il est important que"], ["benché", "bien que"], ["affinché", "afin que"], ["sembra che", "il semble que"]],
        quiz: [
          fill("Penso che Marco ___ ragione. (avere)", ["abbia"], "Opinion → congiuntivo : abbia."),
          mcq("Voglio che tu ___ con me.", ["vieni", "venga", "verrai", "venire"], 1, "Volonté → congiuntivo : venga."),
          mcq("Laquelle est correcte en italien standard ?", ["So che sia vero.", "So che è vero.", "Penso che è vero.", "Credo che è vero."], 1, "Sapere exprime une certitude → indicatif. Penso/credo che → congiuntivo."),
          fill("È importante che voi ___ in orario. (arrivare)", ["arriviate"], "Voi au congiuntivo : arriviate."),
          mcq("Benché ___ tardi, restiamo ancora un po'.", ["è", "sia", "sarà", "fosse"], 1, "Benché + congiuntivo présent (principale au présent) : sia."),
        ],
      },
      {
        id: "b2-ipotesi", module: "gram", title: "L'hypothèse et le subjonctif imparfait", emoji: "🧩",
        intro: "« Si j'étais riche… » : le périodo ipotetico, piège classique des francophones.",
        sections: [
          {
            title: "Le congiuntivo imperfetto",
            text: "Radical de l'imparfait + <b>-ssi, -ssi, -sse, -ssimo, -ste, -ssero</b> : parlassi, prendessi, dormissi. Essere : <b>fossi, fossi, fosse, fossimo, foste, fossero</b>. Avere : <i>avessi</i>. Fare : <i>facessi</i>. Stare : <i>stessi</i>. Dare : <i>dessi</i>.",
          },
          {
            title: "Les trois types d'hypothèse",
            table: { cols: ["Type", "Se…", "Alors…"], rows: [["Réel", "Se piove,", "resto a casa."], ["Possible", "Se avessi tempo,", "viaggerei."], ["Irréel du passé", "Se avessi studiato,", "avrei passato l'esame."]] },
          },
          {
            title: "Le piège francophone",
            text: "Comme en français, <b>jamais de conditionnel après « se »</b>. Mais là où le français met l'imparfait, l'italien met le <b>subjonctif imparfait</b>.",
            examples: [["Se avrei soldi… ✗", "(faux)"], ["Se avessi soldi, viaggerei. ✓", "Si j'avais de l'argent, je voyagerais."]],
          },
        ],
        mnemo: "« Le conditionnel déteste le SE ». Après se → congiuntivo ; le conditionnel va dans l'autre moitié de la phrase.",
        vocab: [["se fossi in te", "à ta place"], ["magari fosse vero!", "si seulement c'était vrai !"], ["viaggiare", "voyager"], ["vincere la lotteria", "gagner au loto"]],
        quiz: [
          fill("Se ___ ricco, comprerei una villa in Toscana. (essere, io)", ["fossi"], "Hypothèse possible : se + congiuntivo imperfetto."),
          mcq("Se avessi tempo, ___ di più.", ["leggo", "leggerei", "leggessi", "avrei letto"], 1, "Conséquence → conditionnel présent : leggerei."),
          mcq("Choisissez la phrase correcte :", ["Se avrei soldi, viaggerei.", "Se avessi soldi, viaggerei.", "Se avessi soldi, viaggiassi.", "Se ho soldi, viaggerei."], 1, "Se + congiuntivo imperfetto, puis conditionnel."),
          fill("Se fossi in te, ___ l'offerta. (accettare)", ["accetterei"], "Conditionnel : accetterei."),
          tr("Traduisez : Si seulement c'était vrai !", ["magari fosse vero", "se solo fosse vero"], "Magari + congiuntivo imperfetto exprime un souhait."),
        ],
      },
      {
        id: "b2-lavoro", module: "vocab", title: "L'italien professionnel", emoji: "💼",
        intro: "Candidature, réunions, négociation et e-mails : le vocabulaire du monde du travail.",
        sections: [
          {
            title: "La recherche d'emploi",
            examples: [["il curriculum (vitae)", "le CV"], ["la lettera di presentazione", "la lettre de motivation"], ["il colloquio di lavoro", "l'entretien d'embauche"], ["il tirocinio / lo stage", "le stage"], ["candidarsi", "postuler"]],
          },
          {
            title: "Au bureau",
            examples: [["la riunione", "la réunion"], ["la scadenza", "l'échéance"], ["il fatturato", "le chiffre d'affaires"], ["il preventivo", "le devis"], ["il fornitore", "le fournisseur"]],
          },
          {
            title: "L'e-mail formel",
            text: "Ouvrez par <b>Gentile</b> (Gentile Dottoressa Bianchi) ou <b>Egregio</b> (très formel, masculin), fermez par <b>Cordiali saluti</b>.",
            examples: [["La ringrazio per la Sua risposta.", "Je vous remercie pour votre réponse."], ["Resto a disposizione per ulteriori chiarimenti.", "Je reste à disposition pour tout complément d'information."]],
          },
        ],
        mnemo: "En Italie, tout diplômé universitaire peut être appelé « Dottore / Dottoressa ». Dans le doute, c'est flatteur et poli.",
        vocab: [["il colloquio", "l'entretien"], ["il tirocinio", "le stage"], ["la scadenza", "l'échéance"], ["il fatturato", "le chiffre d'affaires"], ["il preventivo", "le devis"], ["il fornitore", "le fournisseur"], ["cordiali saluti", "cordialement"]],
        quiz: [
          match("Associez", [["il colloquio", "l'entretien"], ["la scadenza", "l'échéance"], ["il preventivo", "le devis"], ["il fornitore", "le fournisseur"]]),
          mcq("Comment terminer un e-mail professionnel ?", ["Ciao ciao", "Cordiali saluti", "Un bacio", "A presto bello"], 1, "Cordiali saluti = cordialement."),
          mcq("« Il fatturato » désigne :", ["la facture", "le chiffre d'affaires", "le salaire", "le fournisseur"], 1, "Piège ! La facture = la fattura ; il fatturato = le chiffre d'affaires."),
          fill("Resto a ___ per ulteriori chiarimenti.", ["disposizione", "sua disposizione", "vostra disposizione"], "Resto a disposizione : formule de clôture classique."),
          tr("Traduisez : un entretien d'embauche", ["un colloquio di lavoro", "colloquio di lavoro", "un colloquio"], "Un colloquio di lavoro."),
        ],
      },
    ],
    exam: [
      fill("Spero che tu ___ (stare) bene.", ["stia"], "Stare au congiuntivo : stia."),
      mcq("Se ___ di più, avresti passato l'esame.", ["studiavi", "avessi studiato", "avresti studiato", "studiassi"], 1, "Irréel du passé : se + congiuntivo trapassato."),
      mcq("Credo che loro ___ già partiti.", ["sono", "siano", "fossero", "sarebbero"], 1, "Opinion au présent sur un fait passé : siano partiti."),
      fill("Se ___ (avere, io) più tempo, imparerei il cinese.", ["avessi"], "Avessi."),
      mcq("L'entretien d'embauche :", ["il colloquio", "la colazione", "il collegio", "la riunione"], 0, "Il colloquio. (La colazione = le petit-déjeuner !)"),
      mcq("È necessario che voi ___ (fare) attenzione.", ["fate", "facciate", "faceste", "farete"], 1, "Facciate."),
      match("Associez", [["il datore di lavoro", "l'employeur"], ["la riunione", "la réunion"], ["la fattura", "la facture"], ["il tirocinio", "le stage"]]),
      tr("Traduisez : Si j'étais toi, je partirais.", ["se fossi in te partirei", "se fossi te partirei", "se io fossi in te partirei"], "Se fossi in te, partirei."),
    ],
  },

  /* ================================================================ C1 */
  {
    id: "C1", name: "Autonome", title: "Style et précision", emoji: "🎭", color: "#6a4c93",
    desc: "Passé simple, connecteurs du registre soutenu, idiomes avancés.",
    lessons: [
      {
        id: "c1-passato-remoto", module: "conj", title: "Le passé simple (passato remoto)", emoji: "⏳",
        intro: "Le temps du récit, de l'histoire et de la littérature — et de l'oral dans le sud de l'Italie.",
        sections: [
          {
            title: "Quand l'utiliser ?",
            text: "Pour une action <b>achevée et coupée du présent</b> : récit historique, biographie, roman.",
            examples: [["Dante nacque a Firenze nel 1265.", "Dante naquit à Florence en 1265."]],
          },
          {
            title: "Les verbes réguliers",
            table: { cols: ["", "parlare", "credere", "dormire"], rows: [["io", "parlai", "credei / credetti", "dormii"], ["tu", "parlasti", "credesti", "dormisti"], ["lui/lei", "parlò", "credé / credette", "dormì"], ["noi", "parlammo", "credemmo", "dormimmo"], ["voi", "parlaste", "credeste", "dormiste"], ["loro", "parlarono", "crederono / credettero", "dormirono"]] },
          },
          {
            title: "Les irréguliers",
            text: "essere : <b>fui, fosti, fu, fummo, foste, furono</b> · avere : <b>ebbi</b>, avesti, <b>ebbe</b>, avemmo, aveste, <b>ebbero</b> · fare : feci, fece · dire : dissi, disse · venire : venni, venne · nascere : nacqui, nacque · vedere : vidi · scrivere : scrissi · prendere : presi.",
          },
        ],
        mnemo: "Règle « 1-3-6 » : les irréguliers ne le sont qu'à io, lui et loro (ebbi, ebbe, ebbero). Les autres personnes sont régulières (avesti, avemmo, aveste).",
        vocab: [["nacque", "il/elle naquit"], ["morì", "il/elle mourut"], ["fu", "il/elle fut"], ["ebbe", "il/elle eut"], ["disse", "il/elle dit"], ["venne", "il/elle vint"]],
        quiz: [
          mcq("Passato remoto de « nascere » (lui) :", ["nascé", "nacque", "nascette", "nasquì"], 1, "Nascere → nacque (irrégulier)."),
          fill("Garibaldi ___ un eroe del Risorgimento. (essere, passato remoto)", ["fu"], "Essere → fu."),
          mcq("Passato remoto de « dire » (io) :", ["dicei", "dissi", "dicetti", "disi"], 1, "Dire → dissi."),
          mcq("« Ebbero » correspond à :", ["ils eurent (avere)", "ils furent (essere)", "ils firent (fare)", "ils virent (vedere)"], 0, "Avere → ebbero."),
          fill("Dante ___ la Divina Commedia. (scrivere, passato remoto)", ["scrisse"], "Scrivere → scrisse."),
        ],
      },
      {
        id: "c1-connettivi", module: "gram", title: "Connecteurs et registre soutenu", emoji: "🧩",
        intro: "Structurer un argumentaire, écrire un rapport, nuancer sa pensée.",
        sections: [
          {
            title: "Opposition et concession",
            text: "<b>tuttavia</b> (toutefois), <b>però</b> (mais), <b>eppure</b> (et pourtant), <b>benché / sebbene / nonostante</b> + congiuntivo (bien que), <b>malgrado</b>.",
          },
          {
            title: "Cause et conséquence",
            text: "<b>poiché</b>, <b>siccome</b> (en tête de phrase), <b>dato che</b> → cause. <b>pertanto, quindi, dunque, di conseguenza</b> → conséquence.",
            examples: [["Siccome pioveva, siamo rimasti a casa.", "Comme il pleuvait, nous sommes restés à la maison."], ["Il progetto è in ritardo; pertanto, rinviamo la riunione.", "Le projet est en retard ; par conséquent, nous reportons la réunion."]],
          },
          {
            title: "But et condition (+ congiuntivo)",
            text: "<b>affinché</b> (afin que), <b>purché</b> (pourvu que), <b>a meno che non</b> (à moins que), <b>qualora</b> (au cas où).",
            examples: [["Te lo spiego affinché tu capisca.", "Je te l'explique afin que tu comprennes."], ["Qualora ci fossero problemi, mi chiami.", "Au cas où il y aurait des problèmes, appelez-moi."]],
          },
        ],
        mnemo: "Les connecteurs de doute ou d'intention (benché, affinché, purché, qualora, a meno che) appellent le congiuntivo : ils introduisent quelque chose de non certain.",
        vocab: [["tuttavia", "toutefois"], ["eppure", "et pourtant"], ["pertanto", "par conséquent"], ["siccome", "comme (cause)"], ["affinché", "afin que"], ["purché", "pourvu que"], ["qualora", "au cas où"]],
        quiz: [
          mcq("Ti presto la macchina, ___ tu me la restituisca domani.", ["perché", "purché", "pertanto", "poiché"], 1, "Purché = pourvu que (+ congiuntivo)."),
          mcq("« Pertanto » signifie :", ["pourtant", "par conséquent", "pendant", "pourvu que"], 1, "Faux ami ! Pertanto = par conséquent. « Pourtant » = eppure / tuttavia."),
          fill("Nonostante ___ (piovere), siamo usciti.", ["piovesse"], "Principale au passé → congiuntivo imperfetto : piovesse."),
          match("Associez", [["tuttavia", "toutefois"], ["siccome", "comme (cause)"], ["qualora", "au cas où"], ["eppure", "et pourtant"]]),
          mcq("Parlo lentamente affinché tutti mi ___.", ["capiscono", "capiscano", "capirebbero", "capire"], 1, "Affinché + congiuntivo : capiscano."),
        ],
      },
      {
        id: "c1-idiomi", module: "expr", title: "Expressions idiomatiques avancées", emoji: "💬",
        intro: "Les images que les Italiens utilisent tous les jours et qu'aucun manuel scolaire n'enseigne.",
        sections: [
          {
            title: "Animaux et nature",
            examples: [["Prendere due piccioni con una fava", "Faire d'une pierre deux coups"], ["Essere una gatta da pelare", "Être un vrai casse-tête"], ["Piove sul bagnato", "Un malheur n'arrive jamais seul"]],
          },
          {
            title: "Le corps",
            examples: [["Avere un diavolo per capello", "Être furieux"], ["Acqua in bocca!", "Motus et bouche cousue !"], ["Parlare a quattr'occhi", "Parler en tête-à-tête"], ["Essere in gamba", "Être doué, capable"]],
          },
          {
            title: "La vie sociale",
            examples: [["Fare il ponte", "Faire le pont"], ["Tagliare la corda", "Filer en douce"], ["Essere al settimo cielo", "Être aux anges"], ["Rompere il ghiaccio", "Briser la glace"]],
          },
        ],
        mnemo: "Beaucoup d'expressions existent en français avec une autre image : « deux pigeons avec une fève » = « deux coups avec une pierre ». Retenez l'image italienne, c'est elle qui fait sourire les natifs.",
        vocab: [["essere in gamba", "être doué"], ["acqua in bocca", "motus"], ["fare il ponte", "faire le pont"], ["tagliare la corda", "filer en douce"], ["a quattr'occhi", "en tête-à-tête"], ["essere al settimo cielo", "être aux anges"]],
        quiz: [
          mcq("« Prendere due piccioni con una fava » =", ["faire d'une pierre deux coups", "avoir un appétit d'oiseau", "se faire pigeonner", "chercher la petite bête"], 0, "Deux pigeons avec une seule fève."),
          match("Associez", [["acqua in bocca", "motus et bouche cousue"], ["in gamba", "doué, capable"], ["tagliare la corda", "filer en douce"], ["a quattr'occhi", "en tête-à-tête"]]),
          mcq("Oggi il capo ha un diavolo per capello. Il est :", ["très joyeux", "furieux", "malade", "décoiffé"], 1, "Un diable par cheveu : il est furieux."),
          mcq("Giovedì è festa, quindi venerdì facciamo ___.", ["il ponte", "la corda", "il ghiaccio", "il cielo"], 0, "Fare il ponte = faire le pont."),
          fill("Dopo la promozione, Sara è al settimo ___.", ["cielo"], "Essere al settimo cielo = être aux anges."),
        ],
      },
    ],
    exam: [
      fill("Cristoforo Colombo ___ (arrivare, passato remoto) in America nel 1492.", ["arrivò"], "Arrivare → arrivò."),
      mcq("Passato remoto de « venire » (loro) :", ["venirono", "vennero", "venerono", "vennono"], 1, "Vennero (règle 1-3-6)."),
      mcq("Ti aiuto ___ tu mi aiuti.", ["purché", "pertanto", "tuttavia", "siccome"], 0, "Purché + congiuntivo."),
      mcq("___ era tardi, siamo tornati a casa.", ["Siccome", "Benché", "Affinché", "Purché"], 0, "Cause en tête de phrase : siccome."),
      fill("Benché ___ (essere) stanco, continua a lavorare.", ["sia"], "Benché + congiuntivo présent : sia."),
      mcq("« Acqua in bocca! » signifie :", ["bon appétit", "motus !", "il pleut", "à ta santé"], 1, "Motus et bouche cousue."),
      mcq("« Essere in gamba » :", ["être doué", "avoir mal aux jambes", "être pressé", "être debout"], 0, "Être doué, capable."),
      fill("Lui ___ (fare, passato remoto) un lungo viaggio.", ["fece"], "Fare → fece."),
    ],
  },

  /* ================================================================ C2 */
  {
    id: "C2", name: "Maîtrise", title: "Comme un natif", emoji: "👑", color: "#1f3a5f",
    desc: "Concordance des temps, faux amis, nuances et proverbes.",
    lessons: [
      {
        id: "c2-concordanza", module: "conj", title: "La concordance des temps", emoji: "⏳",
        intro: "Le niveau de précision d'un locuteur natif cultivé : les temps du subordonné s'accordent au principal.",
        sections: [
          {
            title: "Le principe",
            table: { cols: ["Principale", "Simultané", "Antérieur", "Postérieur"], rows: [["Penso che…", "venga", "sia venuto", "verrà"], ["Pensavo che…", "venisse", "fosse venuto", "sarebbe venuto"]] },
          },
          {
            title: "Le futur dans le passé",
            text: "Différence majeure avec le français : le futur vu du passé se met au <b>conditionnel passé</b>.",
            examples: [["Disse che sarebbe venuto.", "Il a dit qu'il viendrait."], ["Mi promise che mi avrebbe scritto.", "Il m'a promis qu'il m'écrirait."]],
          },
          {
            title: "Futur antérieur et subjonctif plus-que-parfait",
            examples: [["Quando avrai finito, chiamami.", "Quand tu auras fini, appelle-moi."], ["Avrà perso il treno.", "Il a dû rater le train (probabilité)."], ["Se l'avessi saputo, te l'avrei detto.", "Si je l'avais su, je te l'aurais dit."]],
          },
        ],
        mnemo: "« Le futur vu du passé porte déjà son passé » : en italien, ce qui est futur par rapport à un moment passé se met au condizionale passato.",
        vocab: [["sarebbe venuto", "il viendrait (futur dans le passé)"], ["avrebbe fatto", "il ferait / aurait fait"], ["fosse stato", "il eût été"], ["avrà perso", "il a dû perdre"]],
        quiz: [
          mcq("Marco mi ha detto che ___ il giorno dopo.", ["verrebbe", "sarebbe venuto", "venga", "venisse"], 1, "Futur dans le passé → condizionale passato."),
          fill("Credevo che tu fossi già ___. (partire)", ["partito", "partita"], "Congiuntivo trapassato : fossi partito/a."),
          mcq("Non risponde al telefono: ___ il cellulare a casa.", ["avrà dimenticato", "dimenticherà", "dimenticasse", "dimenticava"], 0, "Futur antérieur de probabilité : il a dû oublier."),
          fill("Se me l'avessi detto, ti ___ aiutato. (avere)", ["avrei"], "Irréel du passé : avrei aiutato."),
          mcq("Pensavo che ___ (essere) più facile.", ["è", "sia", "fosse", "sarà"], 2, "Principale au passé → congiuntivo imperfetto : fosse."),
        ],
      },
      {
        id: "c2-sfumature", module: "vocab", title: "Faux amis, suffixes et forme impersonnelle", emoji: "🎯",
        intro: "Les pièges que même les apprenants avancés font encore — et les outils de nuance des natifs.",
        sections: [
          {
            title: "Les faux amis",
            examples: [["la camera", "la chambre (≠ caméra)"], ["il burro", "le beurre"], ["salire", "monter (≠ salir)"], ["fermare", "arrêter (≠ fermer = chiudere)"], ["subito", "tout de suite"], ["la tasca", "la poche"]],
          },
          {
            title: "Les suffixes altératifs",
            text: "<b>-ino / -etto</b> : petit, affectueux · <b>-one</b> : grand · <b>-accio</b> : péjoratif · <b>-uccio</b> : tendre. Attention aux mots devenus autonomes : <i>il fumetto</i> (la BD), <i>il burrone</i> (le ravin).",
            examples: [["gattino", "chaton"], ["librone", "gros livre"], ["tempaccio", "sale temps"], ["parolaccia", "gros mot"]],
          },
          {
            title: "La forme impersonnelle « si »",
            text: "« On » se dit <b>si</b> + 3e personne. Le verbe s'accorde avec le complément pluriel.",
            examples: [["In Italia si mangia bene.", "En Italie, on mange bien."], ["Si vendono case.", "Maisons à vendre (on vend des maisons)."], ["Quando si è giovani…", "Quand on est jeune…"]],
          },
        ],
        mnemo: "Phrase piège à retenir en entier : « Salgo in camera » = « Je monte dans ma chambre ». Chaque mot y est un faux ami !",
        vocab: [["la camera", "la chambre"], ["il burro", "le beurre"], ["salire", "monter"], ["fermare", "arrêter"], ["subito", "tout de suite"], ["la parolaccia", "le gros mot"], ["il fumetto", "la bande dessinée"]],
        quiz: [
          mcq("« Fermare » signifie :", ["fermer", "arrêter", "enfermer", "affirmer"], 1, "Faux ami : fermer = chiudere ; fermare = arrêter."),
          match("Associez", [["la camera", "la chambre"], ["il burro", "le beurre"], ["subito", "tout de suite"], ["la tasca", "la poche"]]),
          mcq("« Che tempaccio! » signifie :", ["Quel beau temps !", "Quel sale temps !", "Quel long moment !", "Il est temps !"], 1, "-accio est péjoratif."),
          fill("In Italia ___ vendono molti prodotti biologici. (forme impersonnelle)", ["si"], "Si vendono : accord au pluriel avec « prodotti »."),
          tr("Traduisez : Je monte dans ma chambre.", ["salgo in camera", "salgo in camera mia", "salgo nella mia camera"], "Salgo in camera (mia)."),
        ],
      },
      {
        id: "c2-proverbi", module: "expr", title: "Proverbes et références culturelles", emoji: "📜",
        intro: "Placer le bon proverbe au bon moment : la touche finale de la maîtrise.",
        sections: [
          {
            title: "La sagesse populaire",
            examples: [["Chi va piano va sano e va lontano.", "Qui va lentement va sûrement."], ["Tra il dire e il fare c'è di mezzo il mare.", "Il y a loin de la coupe aux lèvres."], ["L'abito non fa il monaco.", "L'habit ne fait pas le moine."], ["Chi dorme non piglia pesci.", "L'avenir appartient à ceux qui se lèvent tôt."]],
          },
          {
            title: "À table et en voyage",
            examples: [["A tavola non s'invecchia.", "À table, on ne vieillit pas."], ["Paese che vai, usanza che trovi.", "À Rome, fais comme les Romains."], ["Non tutte le ciambelle riescono col buco.", "On ne réussit pas tout du premier coup."]],
          },
          {
            title: "Références culturelles",
            examples: [["Fare il portoghese", "Resquiller"], ["Avere un santo in paradiso", "Être pistonné"], ["Un lavoro da certosino", "Un travail de bénédictin"], ["Essere un Don Abbondio", "Être un lâche (personnage des Fiancés de Manzoni)"]],
          },
        ],
        mnemo: "Un proverbe bien placé montre que vous maîtrisez non seulement la langue mais aussi la culture : c'est l'un des marqueurs les plus sûrs d'un niveau C2.",
        vocab: [["chi dorme non piglia pesci", "l'avenir appartient à ceux qui se lèvent tôt"], ["l'abito non fa il monaco", "l'habit ne fait pas le moine"], ["fare il portoghese", "resquiller"], ["avere un santo in paradiso", "être pistonné"], ["paese che vai, usanza che trovi", "à Rome, fais comme les Romains"]],
        quiz: [
          mcq("Équivalent de « L'habit ne fait pas le moine » :", ["L'abito non fa il monaco", "Chi va piano va sano", "Meglio tardi che mai", "Chi dorme non piglia pesci"], 0, "L'abito non fa il monaco."),
          mcq("« Tra il dire e il fare c'è di mezzo il mare » signifie :", ["Il est plus facile de parler que d'agir", "La mer sépare les peuples", "Il faut toujours dire la vérité", "Les voyages forment la jeunesse"], 0, "Entre dire et faire, il y a la mer."),
          match("Associez", [["fare il portoghese", "resquiller"], ["avere un santo in paradiso", "être pistonné"], ["meglio tardi che mai", "mieux vaut tard que jamais"], ["chi dorme non piglia pesci", "le monde appartient aux lève-tôt"]]),
          fill("Paese che vai, ___ che trovi.", ["usanza"], "Paese che vai, usanza che trovi."),
          mcq("Un collègue ultra-minutieux fait un « lavoro da ___ ».", ["certosino", "portoghese", "monaco", "santo"], 0, "Les moines chartreux (certosini) étaient réputés pour leur minutie."),
        ],
      },
    ],
    exam: [
      mcq("Mi promise che mi ___.", ["scriverebbe", "avrebbe scritto", "scriva", "scrivesse"], 1, "Futur dans le passé → condizionale passato."),
      fill("Se l'avessi saputo, non ___ venuto. (essere, io)", ["sarei"], "Sarei venuto."),
      mcq("Sono le nove e Luca non è qui: ___ il treno.", ["avrà perso", "perderà", "perdesse", "perdeva"], 0, "Futur antérieur de probabilité."),
      mcq("« Salire » signifie :", ["salir", "monter", "saluer", "sauter"], 1, "Faux ami : salire = monter."),
      mcq("Une « parolaccia » est :", ["un long discours", "un gros mot", "un mot doux", "une promesse"], 1, "-accio péjoratif : un gros mot."),
      fill("Chi dorme non piglia ___.", ["pesci"], "Chi dorme non piglia pesci."),
      mcq("« Avere un santo in paradiso » :", ["être croyant", "être pistonné", "avoir de la chance au jeu", "être naïf"], 1, "Avoir un protecteur haut placé."),
      tr("Traduisez : Il a dit qu'il viendrait.", ["ha detto che sarebbe venuto", "disse che sarebbe venuto"], "Ha detto che sarebbe venuto."),
    ],
  },
];

/* ---------------------------------------------------------------------
   Index et accès rapides (calculés une seule fois au chargement)
--------------------------------------------------------------------- */
// Compléments A1 : ajoutés après les 5 leçons d'origine (progression conservée)
LEVELS[0].lessons.push(...A1_PLUS);
LEVELS[0].exam.push(...A1_EXAM_PLUS);
LEVELS[1].lessons.push(...A2_PLUS);
LEVELS[1].exam.push(...A2_EXAM_PLUS);
LEVELS[2].lessons.push(...B1_PLUS);
LEVELS[2].exam.push(...B1_EXAM_PLUS);
LEVELS[3].lessons.push(...B2_PLUS);
LEVELS[3].exam.push(...B2_EXAM_PLUS);
LEVELS[4].lessons.push(...C1_PLUS);
LEVELS[4].exam.push(...C1_EXAM_PLUS);
LEVELS[5].lessons.push(...C2_PLUS);
LEVELS[5].exam.push(...C2_EXAM_PLUS);

export const ALL_LESSONS = [];
LEVELS.forEach((level, li) => {
  level.lessons.forEach((lesson, i) => {
    lesson.levelId = level.id;
    lesson.levelIndex = li;
    lesson.index = i;
    ALL_LESSONS.push(lesson);
  });
});

export const getLevel = (id) => LEVELS.find((l) => l.id === id);
export const getLesson = (id) => ALL_LESSONS.find((l) => l.id === id);

/**
 * Référence unique d'une question : "a1-numeri:2" ou "exam-A1:4".
 * Permet de stocker les erreurs sans dupliquer le contenu.
 */
export function getQuestion(ref) {
  const [src, idx] = ref.split(":");
  if (src.startsWith("exam-")) return getLevel(src.slice(5))?.exam[+idx] || null;
  return getLesson(src)?.quiz[+idx] || null;
}

/** Libellé lisible de l'origine d'une question (pour le cahier d'erreurs) */
export function refLabel(ref) {
  const src = ref.split(":")[0];
  if (src.startsWith("exam-")) return `Examen ${src.slice(5)}`;
  const l = getLesson(src);
  return l ? `${l.levelId} · ${l.title}` : src;
}
