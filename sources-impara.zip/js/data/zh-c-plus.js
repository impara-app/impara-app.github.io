/* =====================================================================
   Mandarin — compléments des paliers HSK 5 (C1) et HSK 6 (C2)
   ---------------------------------------------------------------------
   HSK 5 : connecteurs de l'écrit (由于, 从而, 以便, 以免, 何况), degré et
   insistance (简直, 几乎, 未必, 并, 毕竟), double négation (非…不可,
   不得不), vocabulaire du travail, de la santé et des études.
   HSK 6 : traces du chinois classique (之, 乎, 者, 也, 其, 所), langue de
   la presse, parler avec tact, dialectes et variantes, poèmes Tang,
   langue d'internet.
   Les leçons s'ajoutent APRÈS les leçons d'origine de chaque palier.
   ===================================================================== */

const mcq = (q, options, answer, explain = "") => ({ type: "mcq", q, options, answer, explain });
const fill = (q, answer, explain = "") => ({ type: "fill", q, answer, explain });
const match = (q, pairs, explain = "") => ({ type: "match", q, pairs, explain });
const tr = (q, answer, explain = "") => ({ type: "translate", q, answer, explain });

/* =============================== HSK 5 =============================== */
export const HSK5_PLUS = [
  {
    id: "c1-youyu", module: "gram", title: "Les connecteurs de l'écrit : 由于, 从而, 以便, 以免, 何况", emoji: "🧷",
    intro: "Dans un article, un rapport ou un e-mail formel, 因为 et 所以 laissent la place à des connecteurs plus soutenus. Ils sont incontournables au HSK 5.",
    sections: [
      {
        title: "由于 : en raison de, du fait que",
        text: "<b>由于 yóuyú</b> remplace 因为 à l'écrit. Il peut introduire une phrase entière ou un simple nom : <i>由于天气原因</i> « pour des raisons météorologiques ». La conséquence est souvent marquée par <b>因此</b> ou <b>所以</b>.",
        examples: [["由于天气原因，航班推迟了。", "yóuyú tiānqì yuányīn, hángbān tuīchí le.", "En raison des conditions météo, le vol a été retardé."], ["由于工作太忙，他很少回家。", "yóuyú gōngzuò tài máng, tā hěn shǎo huí jiā.", "Comme il est très pris par son travail, il rentre rarement chez lui."]],
      },
      {
        title: "从而 : et par là même ; 以便 / 以免 : afin de / afin d'éviter",
        text: "<b>从而 cóng'ér</b> relie une action à son résultat (« ce qui permet de… »). <b>以便 yǐbiàn</b> exprime le but (« pour que »), <b>以免 yǐmiǎn</b> le but négatif (« pour éviter que »). Tous trois se placent en tête de la seconde partie de la phrase.",
        examples: [["他改进了方法，从而提高了效率。", "tā gǎijìn le fāngfǎ, cóng'ér tígāo le xiàolǜ.", "Il a amélioré sa méthode, ce qui a augmenté son efficacité."], ["请留下电话，以便我们联系您。", "qǐng liúxià diànhuà, yǐbiàn wǒmen liánxì nín.", "Laissez votre numéro, afin que nous puissions vous contacter."], ["出门多穿点儿，以免感冒。", "chūmén duō chuān diǎnr, yǐmiǎn gǎnmào.", "Couvre-toi en sortant, pour ne pas attraper froid."]],
      },
      {
        title: "何况 : à plus forte raison",
        text: "<b>何况 hékuàng</b> ajoute un argument encore plus fort. Souvent en corrélation avec <b>连…都 / 也</b> dans la première partie : « même X…, alors Y à plus forte raison ».",
        examples: [["连老师都不会，何况学生呢？", "lián lǎoshī dōu bú huì, hékuàng xuésheng ne?", "Même le professeur n'y arrive pas, alors les élèves, n'en parlons pas !"], ["这条路白天都不好走，何况晚上。", "zhè tiáo lù báitiān dōu bù hǎo zǒu, hékuàng wǎnshang.", "Cette route est difficile même de jour, à plus forte raison la nuit."]],
      },
    ],
    mnemo: "以便 : 便 « commode » → pour que ce soit plus facile. 以免 : 免 « éviter » → pour éviter. 从而 : « à partir de là » → résultat.",
    vocab: [["由于", "yóuyú", "en raison de"], ["从而", "cóng'ér", "par là même, ce qui permet de"], ["以便", "yǐbiàn", "afin que"], ["以免", "yǐmiǎn", "afin d'éviter"], ["何况", "hékuàng", "à plus forte raison"], ["原因", "yuányīn", "cause, raison"], ["效率", "xiàolǜ", "efficacité"], ["提高", "tígāo", "améliorer, augmenter"], ["改进", "gǎijìn", "améliorer (une méthode)"], ["联系", "liánxì", "contacter"]],
    quiz: [
      mcq("___ 天气原因，比赛取消了。", ["由于", "以便", "何况", "从而"], 0, "由于 + cause."),
      fill("多带一把伞，___ 下雨。(pour éviter)", ["以免", "yǐmiǎn", "yimian"], "以免 = afin d'éviter."),
      mcq("请提前到，___ 我们准备。", ["何况", "以便", "由于", "以免"], 1, "以便 = afin que (but positif)."),
      mcq("他每天练习，___ 提高了口语水平。", ["以免", "何况", "从而", "由于"], 2, "从而 = ce qui a permis de."),
      fill("大人都觉得难，___ 孩子呢？", ["何况", "hékuàng", "hekuang"], "何况 = à plus forte raison."),
      match("Associez", [["由于|yóuyú", "en raison de"], ["以便|yǐbiàn", "afin que"], ["以免|yǐmiǎn", "afin d'éviter"], ["何况|hékuàng", "à plus forte raison"]]),
      tr("Traduisez : En raison de la pluie, le vol a été retardé.", ["由于下雨航班推迟了", "由于下雨，航班推迟了", "因为下雨航班推迟了", "yóuyú xià yǔ hángbān tuīchí le", "youyu xia yu hangban tuichi le"], "由于 + cause, 推迟 = retarder."),
    ],
  },

  {
    id: "c1-jianzhi", module: "gram", title: "Nuancer et insister : 简直, 几乎, 未必, 并, 毕竟", emoji: "🎚️",
    intro: "Ces adverbes donnent du relief à une phrase : exagération, quasi-certitude, doute poli, démenti ou rappel d'une évidence.",
    sections: [
      {
        title: "简直 : carrément ; 几乎 : presque",
        text: "<b>简直 jiǎnzhí</b> exagère pour exprimer une émotion (« c'est carrément… »), souvent avec <b>太…了</b> ou <b>像</b>. <b>几乎 jīhū</b> est objectif : « presque, quasiment ».",
        examples: [["这里简直太美了！", "zhèlǐ jiǎnzhí tài měi le!", "C'est carrément magnifique ici !"], ["他简直像个孩子。", "tā jiǎnzhí xiàng ge háizi.", "On dirait vraiment un enfant."], ["我几乎每天都喝咖啡。", "wǒ jīhū měitiān dōu hē kāfēi.", "Je bois du café presque tous les jours."]],
      },
      {
        title: "未必 : pas forcément ; 并 + négation : pas du tout (contrairement à ce qu'on croit)",
        text: "<b>未必 wèibì</b> = 不一定, plus soutenu. <b>并 bìng</b> devant 不 / 没 dément une idée reçue : <i>我并不累</i> « je ne suis pas fatigué du tout (contrairement à ce que tu penses) ».",
        examples: [["贵的东西未必好。", "guì de dōngxi wèibì hǎo.", "Ce qui est cher n'est pas forcément bien."], ["这个问题并不难。", "zhège wèntí bìng bù nán.", "Ce problème n'est pas difficile du tout."], ["我并没有说过这句话。", "wǒ bìng méiyǒu shuō guo zhè jù huà.", "Je n'ai jamais dit ça, contrairement à ce qu'on prétend."]],
      },
      {
        title: "毕竟 : après tout",
        text: "<b>毕竟 bìjìng</b> rappelle un fait essentiel qui explique ou excuse : « après tout, il n'est qu'un enfant ». Synonyme oral : <b>到底</b> (dans ce sens).",
        examples: [["别生气了，他毕竟还是个孩子。", "bié shēngqì le, tā bìjìng hái shì ge háizi.", "Ne te fâche pas, après tout ce n'est qu'un enfant."], ["毕竟是第一次，紧张很正常。", "bìjìng shì dì yī cì, jǐnzhāng hěn zhèngcháng.", "Après tout c'est la première fois, c'est normal d'être stressé."]],
      },
    ],
    mnemo: "并 « mettre côte à côte » : on pose la réalité à côté de l'idée reçue pour la démentir.",
    vocab: [["简直", "jiǎnzhí", "carrément, vraiment"], ["几乎", "jīhū", "presque"], ["未必", "wèibì", "pas forcément"], ["并", "bìng", "pas du tout (+ négation)"], ["毕竟", "bìjìng", "après tout"], ["正常", "zhèngcháng", "normal"], ["紧张", "jǐnzhāng", "stressé, nerveux"], ["生气", "shēngqì", "se fâcher"]],
    quiz: [
      mcq("Ce film est carrément génial :", ["这部电影简直太好看了！", "这部电影几乎太好看了！", "这部电影未必太好看了！", "这部电影并太好看了！"], 0, "简直 exagère."),
      fill("他 ___ 每个周末都去爬山。(presque)", ["几乎", "jīhū", "jihu"], "几乎 = presque."),
      mcq("有钱的人 ___ 幸福。(pas forcément)", ["简直", "未必", "毕竟", "几乎"], 1, "未必 = pas forcément."),
      mcq("你以为我生气了？我 ___ 没生气。", ["毕竟", "几乎", "并", "简直"], 2, "并 + 没 dément une supposition."),
      fill("别怪他了，他 ___ 是新来的。(après tout)", ["毕竟", "bìjìng", "bijing"], "毕竟 = après tout."),
      match("Associez", [["简直|jiǎnzhí", "carrément"], ["几乎|jīhū", "presque"], ["未必|wèibì", "pas forcément"], ["毕竟|bìjìng", "après tout"]]),
      tr("Traduisez : Ce qui est cher n'est pas forcément bien.", ["贵的东西未必好", "贵的不一定好", "贵的东西不一定好", "guì de dōngxi wèibì hǎo", "gui de dongxi weibi hao"], "未必 = 不一定."),
    ],
  },

  {
    id: "c1-feibuke", module: "gram", title: "La double négation : 非…不可, 不得不, 不…不", emoji: "⛔",
    intro: "Deux négations valent une affirmation… renforcée. C'est la façon la plus chinoise de dire « absolument » ou « je n'ai pas le choix ».",
    sections: [
      {
        title: "非… 不可 : il faut absolument",
        text: "<b>非 fēi + verbe + 不可 bùkě</b> : « ne pas faire X n'est pas possible » → il faut absolument / je tiens à. À l'oral, <b>不可</b> tombe parfois : <i>我非去</i>.",
        examples: [["这件事你非去不可。", "zhè jiàn shì nǐ fēi qù bùkě.", "Pour cette affaire, tu dois absolument y aller."], ["他非要买那辆车不可。", "tā fēi yào mǎi nà liàng chē bùkě.", "Il tient absolument à acheter cette voiture."]],
      },
      {
        title: "不得不 : être obligé de",
        text: "<b>不得不 bùdébù</b> + verbe : « ne pas pouvoir ne pas » → être contraint de, à contrecœur.",
        examples: [["雨太大了，我们不得不取消活动。", "yǔ tài dà le, wǒmen bùdébù qǔxiāo huódòng.", "Il pleuvait trop, nous avons été obligés d'annuler l'activité."], ["他不得不承认自己错了。", "tā bùdébù chéngrèn zìjǐ cuò le.", "Il a été obligé de reconnaître qu'il avait tort."]],
      },
      {
        title: "不能不, 没有… 不, 不…不",
        text: "<b>不能不</b> = il faut bien. <b>没有 + nom + 不 + verbe</b> = tous sans exception : <i>没有人不知道</i> « tout le monde le sait ». <b>不 A 不 B</b> peut aussi dire « ni trop… ni trop… » : <i>不大不小</i> « juste la bonne taille ».",
        examples: [["没有人不喜欢他。", "méiyǒu rén bù xǐhuan tā.", "Tout le monde l'aime."], ["这双鞋不大不小，正合适。", "zhè shuāng xié bú dà bù xiǎo, zhèng héshì.", "Ces chaussures ne sont ni trop grandes ni trop petites, juste parfaites."], ["这么重要的会，我不能不去。", "zhème zhòngyào de huì, wǒ bù néng bú qù.", "Une réunion aussi importante, je ne peux pas ne pas y aller."]],
      },
    ],
    mnemo: "非…不可 = « non… impossible » : comme en latin, deux non font un oui très fort.",
    vocab: [["非…不可", "fēi… bùkě", "il faut absolument"], ["不得不", "bùdébù", "être obligé de"], ["承认", "chéngrèn", "reconnaître, admettre"], ["活动", "huódòng", "activité, événement"], ["合适", "héshì", "approprié, qui convient"], ["重要", "zhòngyào", "important"]],
    quiz: [
      fill("这本书太好了，你非看 ___ 。", ["不可", "bùkě", "buke"], "非… 不可."),
      mcq("« Nous avons été obligés de partir » :", ["我们不得不走了。", "我们得不得走了。", "我们非不走了。", "我们不能走不了。"], 0, "不得不 + verbe."),
      mcq("没有人 ___ 知道这件事。", ["没", "不", "非", "别"], 1, "没有人不… = tout le monde."),
      mcq("不大不小 signifie :", ["ni grand ni petit, juste bien", "très grand", "très petit", "on ne sait pas la taille"], 0, "不 A 不 B = la juste mesure."),
      fill("他 ___ 承认自己错了。(être obligé)", ["不得不", "bùdébù", "budebu"], "不得不."),
      match("Associez", [["不得不|bùdébù", "être obligé de"], ["承认|chéngrèn", "reconnaître"], ["合适|héshì", "qui convient"], ["活动|huódòng", "activité"]]),
      tr("Traduisez : Tout le monde l'aime.", ["没有人不喜欢他", "没有人不喜欢她", "大家都喜欢他", "méiyǒu rén bù xǐhuan tā", "meiyou ren bu xihuan ta"], "没有人不… = tout le monde."),
    ],
  },

  {
    id: "c1-gongzuo", module: "vocab", title: "Le monde du travail : emploi, entretien, entreprise", emoji: "💼",
    intro: "Chercher un emploi, passer un entretien, négocier son salaire, parler de la concurrence : le vocabulaire professionnel du HSK 5.",
    sections: [
      {
        title: "Chercher un emploi",
        text: "On <b>找工作</b> en envoyant son <b>简历 jiǎnlì</b> (CV), puis on passe un <b>面试 miànshì</b> (entretien). Si on est retenu, on est <b>录用 lùyòng</b> (embauché).",
        examples: [["我投了十几份简历。", "wǒ tóu le shí jǐ fèn jiǎnlì.", "J'ai envoyé une bonne dizaine de CV."], ["明天上午我有一个面试。", "míngtiān shàngwǔ wǒ yǒu yí ge miànshì.", "Demain matin j'ai un entretien."], ["恭喜你被录用了！", "gōngxǐ nǐ bèi lùyòng le!", "Félicitations, tu as été embauché !"]],
      },
      {
        title: "La vie au bureau",
        text: "<b>加班 jiābān</b> (faire des heures sup) est un sujet brûlant en Chine. On parle aussi de <b>工资 gōngzī</b> (salaire), <b>奖金 jiǎngjīn</b> (prime), <b>同事 tóngshì</b> (collègue) et de <b>辞职 cízhí</b> (démissionner).",
        examples: [["我们公司经常加班。", "wǒmen gōngsī jīngcháng jiābān.", "Dans notre entreprise, on fait souvent des heures sup."], ["她因为压力太大辞职了。", "tā yīnwèi yālì tài dà cízhí le.", "Elle a démissionné à cause d'une trop forte pression."]],
      },
      {
        title: "Économie et entreprise",
        text: "<b>经济 jīngjì</b> (économie), <b>竞争 jìngzhēng</b> (concurrence), <b>市场 shìchǎng</b> (marché), <b>创业 chuàngyè</b> (créer son entreprise), <b>失业 shīyè</b> (être au chômage).",
        examples: [["现在市场竞争很激烈。", "xiànzài shìchǎng jìngzhēng hěn jīliè.", "Aujourd'hui, la concurrence sur le marché est féroce."], ["他大学毕业后开始创业。", "tā dàxué bìyè hòu kāishǐ chuàngyè.", "Après la fac, il a créé son entreprise."]],
      },
    ],
    mnemo: "面试 = « examen du visage » : on vous juge en face à face.",
    vocab: [["简历", "jiǎnlì", "CV"], ["面试", "miànshì", "entretien d'embauche"], ["录用", "lùyòng", "embaucher"], ["加班", "jiābān", "faire des heures sup"], ["工资", "gōngzī", "salaire"], ["奖金", "jiǎngjīn", "prime"], ["同事", "tóngshì", "collègue"], ["辞职", "cízhí", "démissionner"], ["经济", "jīngjì", "économie"], ["竞争", "jìngzhēng", "concurrence"], ["创业", "chuàngyè", "créer une entreprise"], ["失业", "shīyè", "être au chômage"]],
    quiz: [
      mcq("« CV » :", ["简历", "面试", "工资", "同事"], 0, "简历 jiǎnlì."),
      fill("下周我有一个 ___ 。(entretien)", ["面试", "miànshì", "mianshi"], "面试 = entretien."),
      mcq("« Faire des heures supplémentaires » :", ["辞职", "加班", "创业", "失业"], 1, "加班 jiābān."),
      mcq("他不想再干了，决定 ___ 。", ["录用", "辞职", "加班", "竞争"], 1, "辞职 = démissionner."),
      fill("现在的市场 ___ 很激烈。(concurrence)", ["竞争", "jìngzhēng", "jingzheng"], "竞争 = concurrence."),
      match("Associez", [["工资|gōngzī", "salaire"], ["奖金|jiǎngjīn", "prime"], ["创业|chuàngyè", "créer une entreprise"], ["失业|shīyè", "être au chômage"]]),
      tr("Traduisez : Elle a démissionné.", ["她辞职了", "她辞职", "tā cízhí le", "ta cizhi le"], "辞职 + 了."),
    ],
  },

  {
    id: "c1-jiankang", module: "vocab", title: "La santé : chez le médecin, symptômes, ordonnance", emoji: "🩺",
    intro: "Prendre un ticket à l'hôpital, décrire ses symptômes, comprendre une ordonnance : de quoi se débrouiller en cas de pépin en Chine.",
    sections: [
      {
        title: "À l'hôpital",
        text: "En Chine, on va souvent directement à l'<b>医院 yīyuàn</b>. On commence par <b>挂号 guàhào</b> (s'inscrire, prendre un ticket), on choisit le service (<b>内科</b> médecine interne, <b>外科</b> chirurgie), puis on voit le médecin : <b>看病 kànbìng</b>.",
        examples: [["请先去一楼挂号。", "qǐng xiān qù yī lóu guàhào.", "Allez d'abord vous inscrire au rez-de-chaussée."], ["我想看内科。", "wǒ xiǎng kàn nèikē.", "Je voudrais consulter en médecine interne."]],
      },
      {
        title: "Décrire ses symptômes",
        text: "<b>发烧 fāshāo</b> (avoir de la fièvre), <b>咳嗽 késou</b> (tousser), <b>嗓子疼 sǎngzi téng</b> (mal à la gorge), <b>头晕 tóuyūn</b> (avoir la tête qui tourne), <b>过敏 guòmǐn</b> (allergie). Le médecin demande : <i>哪儿不舒服？</i>",
        examples: [["医生，我发烧两天了。", "yīshēng, wǒ fāshāo liǎng tiān le.", "Docteur, j'ai de la fièvre depuis deux jours."], ["我对花粉过敏。", "wǒ duì huāfěn guòmǐn.", "Je suis allergique au pollen."], ["我一直咳嗽，嗓子也疼。", "wǒ yìzhí késou, sǎngzi yě téng.", "Je tousse sans arrêt et j'ai mal à la gorge."]],
      },
      {
        title: "Traitement",
        text: "Le médecin fait une <b>处方 chǔfāng</b> (ordonnance) ; on <b>吃药</b> (prend des médicaments), parfois on <b>打针 dǎzhēn</b> (fait une piqûre). Une fois par an, on fait un <b>体检 tǐjiǎn</b> (bilan de santé).",
        examples: [["这个药一天吃三次，饭后吃。", "zhège yào yì tiān chī sān cì, fàn hòu chī.", "Ce médicament se prend trois fois par jour, après les repas."], ["公司每年安排一次体检。", "gōngsī měi nián ānpái yí cì tǐjiǎn.", "L'entreprise organise un bilan de santé chaque année."]],
      },
    ],
    mnemo: "挂号 = « accrocher un numéro » : autrefois on accrochait une plaquette numérotée pour attendre son tour.",
    vocab: [["挂号", "guàhào", "s'inscrire (à l'hôpital)"], ["看病", "kànbìng", "consulter un médecin"], ["发烧", "fāshāo", "avoir de la fièvre"], ["咳嗽", "késou", "tousser"], ["嗓子", "sǎngzi", "gorge"], ["头晕", "tóuyūn", "avoir des vertiges"], ["过敏", "guòmǐn", "être allergique"], ["处方", "chǔfāng", "ordonnance"], ["打针", "dǎzhēn", "faire une piqûre"], ["体检", "tǐjiǎn", "bilan de santé"]],
    quiz: [
      mcq("À l'hôpital, la première étape :", ["挂号", "打针", "体检", "吃药"], 0, "挂号 = s'inscrire."),
      fill("我 ___ 了，三十九度。(fièvre)", ["发烧", "fāshāo", "fashao"], "发烧 = avoir de la fièvre."),
      mcq("« Je suis allergique aux fruits de mer » :", ["我对海鲜过敏。", "我过敏海鲜。", "我给海鲜过敏。", "我跟海鲜过敏。"], 0, "对 + X + 过敏."),
      mcq("Le médecin demande :", ["你哪儿不舒服？", "你哪儿不方便？", "你哪儿不高兴？", "你哪儿不客气？"], 0, "哪儿不舒服 = où avez-vous mal ?"),
      fill("我一直 ___ ，嗓子很疼。(tousser)", ["咳嗽", "késou", "kesou"], "咳嗽 késou."),
      match("Associez", [["处方|chǔfāng", "ordonnance"], ["打针|dǎzhēn", "piqûre"], ["体检|tǐjiǎn", "bilan de santé"], ["头晕|tóuyūn", "vertiges"]]),
      tr("Traduisez : J'ai de la fièvre.", ["我发烧了", "我发烧", "wǒ fāshāo le", "wo fashao le"], "发烧 + 了."),
    ],
  },

  {
    id: "c1-jiaoyu", module: "vocab", title: "Études et éducation : 高考, université, pression", emoji: "🎓",
    intro: "Le 高考 (gāokǎo), le concours d'entrée à l'université, rythme la vie de millions de familles chinoises. Voici de quoi en parler, ainsi que des études en général.",
    sections: [
      {
        title: "Le 高考",
        text: "Chaque année début juin, les lycéens passent le <b>高考 gāokǎo</b>. La note détermine dans quelle université ils sont <b>录取 lùqǔ</b> (admis). Beaucoup suivent des <b>补习班 bǔxíbān</b> (cours du soir, soutien scolaire).",
        examples: [["他高考考了六百多分。", "tā gāokǎo kǎo le liùbǎi duō fēn.", "Il a eu plus de 600 points au gaokao."], ["她被北京大学录取了。", "tā bèi Běijīng Dàxué lùqǔ le.", "Elle a été admise à l'université de Pékin."], ["很多孩子周末还要上补习班。", "hěn duō háizi zhōumò hái yào shàng bǔxíbān.", "Beaucoup d'enfants ont encore des cours de soutien le week-end."]],
      },
      {
        title: "À l'université",
        text: "On choisit une <b>专业 zhuānyè</b> (spécialité), on peut obtenir une <b>奖学金 jiǎngxuéjīn</b> (bourse), on écrit une <b>论文 lùnwén</b> (mémoire, thèse) sous la direction d'un <b>导师 dǎoshī</b>, puis on <b>毕业 bìyè</b>.",
        examples: [["你学什么专业？", "nǐ xué shénme zhuānyè?", "Quelle est ta spécialité ?"], ["我正在写毕业论文。", "wǒ zhèngzài xiě bìyè lùnwén.", "Je suis en train d'écrire mon mémoire de fin d'études."]],
      },
      {
        title: "Partir étudier, la pression",
        text: "<b>留学 liúxué</b> = étudier à l'étranger. On parle beaucoup de <b>压力 yālì</b> (pression) et de <b>竞争</b> entre élèves.",
        examples: [["他打算去法国留学。", "tā dǎsuàn qù Fǎguó liúxué.", "Il compte partir étudier en France."], ["高三学生的压力特别大。", "gāo sān xuésheng de yālì tèbié dà.", "Les élèves de terminale subissent une pression énorme."]],
      },
    ],
    mnemo: "高考 = 高 (supérieur) + 考 (examen) : l'examen pour l'enseignement supérieur.",
    vocab: [["高考", "gāokǎo", "concours d'entrée à l'université"], ["录取", "lùqǔ", "admettre (dans une école)"], ["补习班", "bǔxíbān", "cours de soutien"], ["专业", "zhuānyè", "spécialité, filière"], ["奖学金", "jiǎngxuéjīn", "bourse d'études"], ["论文", "lùnwén", "mémoire, thèse"], ["导师", "dǎoshī", "directeur de recherche"], ["毕业", "bìyè", "obtenir son diplôme"], ["留学", "liúxué", "étudier à l'étranger"], ["压力", "yālì", "pression, stress"]],
    quiz: [
      mcq("Le concours d'entrée à l'université :", ["高考", "体检", "面试", "论文"], 0, "高考 gāokǎo."),
      fill("她被清华大学 ___ 了。(admise)", ["录取", "lùqǔ", "luqu"], "录取 = admettre."),
      mcq("« Quelle est ta spécialité ? » :", ["你学什么专业？", "你学什么论文？", "你学什么导师？", "你学什么留学？"], 0, "专业 = spécialité."),
      mcq("« Étudier à l'étranger » :", ["毕业", "留学", "录取", "补习"], 1, "留学 liúxué."),
      fill("他拿到了一笔 ___ 。(bourse)", ["奖学金", "jiǎngxuéjīn", "jiangxuejin"], "奖学金."),
      match("Associez", [["论文|lùnwén", "mémoire"], ["导师|dǎoshī", "directeur de recherche"], ["压力|yālì", "pression"], ["毕业|bìyè", "être diplômé"]]),
      tr("Traduisez : Il compte partir étudier en France.", ["他打算去法国留学", "他打算去法国留学。", "他想去法国留学", "tā dǎsuàn qù Fǎguó liúxué", "ta dasuan qu faguo liuxue"], "打算 + 去 + pays + 留学."),
    ],
  },
];

export const HSK5_EXAM_PLUS = [
  mcq("___ 天气原因，航班取消了。", ["由于", "以免", "何况", "从而"], 0, "由于 + cause."),
  fill("出门带伞，___ 淋雨。(pour éviter)", ["以免", "yǐmiǎn", "yimian"], "以免."),
  mcq("连专家都不懂，___ 我们呢？", ["从而", "以便", "何况", "由于"], 2, "连…都…，何况…"),
  mcq("这个问题 ___ 不难。(contrairement à ce qu'on croit)", ["并", "几乎", "简直", "毕竟"], 0, "并 + 不."),
  fill("这件事你非做 ___ 。", ["不可", "bùkě", "buke"], "非… 不可."),
  mcq("« Nous avons été obligés d'annuler » :", ["我们不得不取消。", "我们得不得取消。", "我们不能取消。", "我们非取消。"], 0, "不得不."),
  mcq("« Démissionner » :", ["加班", "辞职", "录用", "创业"], 1, "辞职 cízhí."),
  mcq("À l'hôpital on commence par :", ["挂号", "毕业", "面试", "留学"], 0, "挂号."),
  match("Associez", [["简历|jiǎnlì", "CV"], ["发烧|fāshāo", "fièvre"], ["专业|zhuānyè", "spécialité"], ["毕竟|bìjìng", "après tout"]]),
  tr("Traduisez : Ce qui est cher n'est pas forcément bien.", ["贵的东西未必好", "贵的不一定好", "贵的东西不一定好", "guì de dōngxi wèibì hǎo", "gui de dongxi weibi hao"], "未必."),
];

/* =============================== HSK 6 =============================== */
export const HSK6_PLUS = [
  {
    id: "c2-wenyan", module: "hanzi", title: "Traces du chinois classique : 之, 乎, 者, 也, 其, 所", emoji: "📜",
    intro: "Le chinois moderne écrit regorge de mots-outils hérités du chinois classique (文言文 wényánwén). Les reconnaître, c'est comprendre les titres, les slogans, les chengyu et la presse.",
    sections: [
      {
        title: "之 : particule (= 的) et pronom",
        text: "<b>之 zhī</b> remplace souvent <b>的</b> à l'écrit : <i>三分之一</i> « un tiers » (une part des trois), <i>之一</i> « l'un des », <i>总而言之</i> « en somme ». Il peut aussi être un pronom complément : <i>取而代之</i> « le remplacer ».",
        examples: [["他是世界上最有名的作家之一。", "tā shì shìjiè shang zuì yǒumíng de zuòjiā zhī yī.", "C'est l'un des écrivains les plus célèbres au monde."], ["三分之二的人同意。", "sān fēn zhī èr de rén tóngyì.", "Les deux tiers des gens sont d'accord."], ["总而言之，这个计划不错。", "zǒng ér yán zhī, zhège jìhuà búcuò.", "En somme, ce projet est bon."]],
      },
      {
        title: "者 : celui qui ; 也 : c'est (affirmation)",
        text: "<b>者 zhě</b> après un verbe ou un adjectif désigne la personne : <i>记者</i> journaliste, <i>作者</i> auteur, <i>读者</i> lecteur, <i>患者</i> patient. <b>也 yě</b> en fin de phrase classique marque une affirmation, comme dans la citation de Confucius <i>不亦乐乎</i> « n'est-ce pas une joie ? ».",
        examples: [["这本书的作者是谁？", "zhè běn shū de zuòzhě shì shéi?", "Qui est l'auteur de ce livre ?"], ["有朋自远方来，不亦乐乎？", "yǒu péng zì yuǎnfāng lái, bú yì lè hū?", "Recevoir un ami venu de loin, n'est-ce pas une joie ? (Confucius)"], ["忙得不亦乐乎。", "máng de bú yì lè hū.", "Être débordé (expression ironique moderne)."]],
      },
      {
        title: "其 : son, leur ; 所 : ce que",
        text: "<b>其 qí</b> = son / sa / leur (écrit) : <i>其中</i> « parmi eux », <i>其他</i> « les autres », <i>其实</i> « en réalité ». <b>所 suǒ</b> + verbe = « ce que » : <i>所说的话</i> « ce qui a été dit », <i>所谓</i> « ce qu'on appelle », <i>众所周知</i> « comme chacun sait ».",
        examples: [["我们班有三十人，其中十个是男生。", "wǒmen bān yǒu sānshí rén, qízhōng shí ge shì nánshēng.", "Notre classe compte trente élèves, dont dix garçons."], ["这就是所谓的“内卷”。", "zhè jiù shì suǒwèi de “nèijuǎn”.", "C'est ce qu'on appelle l'« involution »."], ["众所周知，熊猫是中国的国宝。", "zhòng suǒ zhōu zhī, xióngmāo shì Zhōngguó de guóbǎo.", "Comme chacun sait, le panda est un trésor national chinois."]],
      },
    ],
    mnemo: "之 = 的 en costume ; 者 = « -eur » français (lect-eur 读者, aut-eur 作者).",
    vocab: [["之一", "zhī yī", "l'un des"], ["三分之一", "sān fēn zhī yī", "un tiers"], ["总而言之", "zǒng ér yán zhī", "en somme"], ["作者", "zuòzhě", "auteur"], ["读者", "dúzhě", "lecteur"], ["其中", "qízhōng", "parmi eux, dont"], ["所谓", "suǒwèi", "ce qu'on appelle"], ["众所周知", "zhòng suǒ zhōu zhī", "comme chacun sait"], ["文言文", "wényánwén", "chinois classique"]],
    quiz: [
      mcq("« Un tiers » :", ["三分之一", "一分之三", "三之一分", "一之三分"], 0, "三分之一 : une part sur trois."),
      fill("他是中国最有名的歌手 ___ 。(l'un des)", ["之一", "zhī yī", "zhi yi"], "之一 = l'un des."),
      mcq("Le « lecteur » se dit :", ["读者", "作者", "记者", "患者"], 0, "读 lire + 者."),
      mcq("我买了五本书，___ 两本是小说。", ["所谓", "其中", "之一", "总而言之"], 1, "其中 = parmi eux."),
      fill("___ 周知，长城很长。", ["众所", "zhòng suǒ", "zhong suo"], "众所周知 = comme chacun sait."),
      match("Associez", [["作者|zuòzhě", "auteur"], ["所谓|suǒwèi", "ce qu'on appelle"], ["总而言之|zǒng ér yán zhī", "en somme"], ["其中|qízhōng", "dont, parmi"]]),
      tr("Traduisez : En somme, ce projet est bon.", ["总而言之这个计划不错", "总而言之，这个计划不错", "总而言之这个计划很好", "zǒng ér yán zhī zhège jìhuà búcuò", "zong er yan zhi zhege jihua bucuo"], "总而言之."),
    ],
  },

  {
    id: "c2-xinwen", module: "vocab", title: "Lire la presse : 据报道, 发布, 舆论", emoji: "📰",
    intro: "Les journaux et les sites d'information chinois utilisent des formules figées et un style très condensé. Les connaître permet de lire un titre en un coup d'œil.",
    sections: [
      {
        title: "Les formules d'introduction",
        text: "<b>据报道 jù bàodào</b> « selon les informations », <b>据了解</b> « selon nos informations », <b>据悉 jùxī</b> « on apprend que ». <b>据</b> = « d'après ».",
        examples: [["据报道，明天将有大雨。", "jù bàodào, míngtiān jiāng yǒu dà yǔ.", "Selon les informations, de fortes pluies sont attendues demain."], ["据悉，该公司将在上海开设新店。", "jùxī, gāi gōngsī jiāng zài Shànghǎi kāishè xīn diàn.", "On apprend que l'entreprise va ouvrir un nouveau magasin à Shanghai."]],
      },
      {
        title: "Les verbes de la presse",
        text: "<b>发布 fābù</b> (publier, annoncer officiellement), <b>宣布 xuānbù</b> (déclarer), <b>召开 zhàokāi</b> (tenir une réunion), <b>引起 yǐnqǐ</b> (susciter). Le style écrit utilise <b>将</b> (futur), <b>该</b> (ledit, ce) et <b>于</b> (à, en).",
        examples: [["政府发布了新的规定。", "zhèngfǔ fābù le xīn de guīdìng.", "Le gouvernement a publié une nouvelle réglementation."], ["会议将于下周召开。", "huìyì jiāng yú xià zhōu zhàokāi.", "La réunion se tiendra la semaine prochaine."], ["这件事引起了广泛关注。", "zhè jiàn shì yǐnqǐ le guǎngfàn guānzhù.", "Cette affaire a suscité une large attention."]],
      },
      {
        title: "Les acteurs de l'info",
        text: "<b>记者 jìzhě</b> (journaliste), <b>新闻发布会</b> (conférence de presse), <b>头条 tóutiáo</b> (la une), <b>舆论 yúlùn</b> (opinion publique), <b>热搜 rèsōu</b> (sujet tendance en ligne).",
        examples: [["这条新闻上了头条。", "zhè tiáo xīnwén shàng le tóutiáo.", "Cette nouvelle a fait la une."], ["这个话题上了热搜。", "zhège huàtí shàng le rèsōu.", "Ce sujet est devenu tendance."]],
      },
    ],
    mnemo: "据 = « d'après » : 据报道, 据说, 据悉… toute info commence par sa source.",
    vocab: [["据报道", "jù bàodào", "selon les informations"], ["据悉", "jùxī", "on apprend que"], ["发布", "fābù", "publier, annoncer"], ["宣布", "xuānbù", "déclarer, proclamer"], ["召开", "zhàokāi", "tenir (une réunion)"], ["引起", "yǐnqǐ", "susciter, provoquer"], ["关注", "guānzhù", "attention, suivre"], ["记者", "jìzhě", "journaliste"], ["头条", "tóutiáo", "la une"], ["舆论", "yúlùn", "opinion publique"], ["热搜", "rèsōu", "sujet tendance"]],
    quiz: [
      mcq("« Selon les informations » :", ["据报道", "总而言之", "其中", "所谓"], 0, "据报道."),
      fill("会议 ___ 于明天召开。(futur écrit)", ["将", "jiāng", "jiang"], "将 = futur à l'écrit."),
      mcq("« Le gouvernement a publié une nouvelle réglementation » :", ["政府发布了新的规定。", "政府引起了新的规定。", "政府召开了新的规定。", "政府头条了新的规定。"], 0, "发布 = publier."),
      mcq("Cette affaire a suscité l'attention :", ["这件事引起了关注。", "这件事发布了关注。", "这件事召开了关注。", "这件事宣布了关注。"], 0, "引起 = susciter."),
      fill("这条新闻上了 ___ 。(la une)", ["头条", "tóutiáo", "toutiao"], "头条."),
      match("Associez", [["记者|jìzhě", "journaliste"], ["舆论|yúlùn", "opinion publique"], ["热搜|rèsōu", "sujet tendance"], ["宣布|xuānbù", "déclarer"]]),
      tr("Traduisez : Selon les informations, il pleuvra demain.", ["据报道明天会下雨", "据报道，明天会下雨", "据报道明天将下雨", "据报道，明天将下雨", "jù bàodào míngtiān huì xià yǔ", "ju baodao mingtian hui xia yu"], "据报道 + info."),
    ],
  },

  {
    id: "c2-weiwan", module: "expr", title: "Parler avec tact : refus polis et euphémismes", emoji: "🕊️",
    intro: "En chinois, on dit rarement « non » frontalement. Savoir refuser, critiquer ou annoncer une mauvaise nouvelle avec tact (委婉 wěiwǎn) est une compétence clé du niveau C2.",
    sections: [
      {
        title: "Refuser sans dire non",
        text: "<b>我考虑一下</b> « je vais y réfléchir », <b>不太方便</b> « ce n'est pas très pratique », <b>改天吧</b> « une autre fois » ou <b>再说吧</b> « on verra » sont souvent des refus polis. Comprendre le sous-entendu est essentiel.",
        examples: [["这个周末我不太方便，改天吧。", "zhège zhōumò wǒ bú tài fāngbiàn, gǎitiān ba.", "Ce week-end ce n'est pas très pratique pour moi, une autre fois."], ["你的建议很好，我们再研究研究。", "nǐ de jiànyì hěn hǎo, wǒmen zài yánjiū yánjiū.", "Votre suggestion est très bonne, nous allons l'étudier (= probablement non)."]],
      },
      {
        title: "Critiquer en douceur",
        text: "On adoucit avec <b>有点儿</b>, <b>是不是</b>, <b>可能</b>, <b>稍微</b>, ou on commence par un compliment. <b>还可以</b> « ça peut aller » est souvent une critique déguisée.",
        examples: [["这个方案是不是可以再改改？", "zhège fāng'àn shì bu shì kěyǐ zài gǎigai?", "Est-ce qu'on ne pourrait pas retoucher un peu ce plan ?"], ["写得不错，不过可能稍微长了一点儿。", "xiě de búcuò, búguò kěnéng shāowēi cháng le yìdiǎnr.", "C'est bien écrit, mais c'est peut-être un tout petit peu long."]],
      },
      {
        title: "Les euphémismes",
        text: "Pour la mort : <b>去世 qùshì</b> (décéder), <b>走了</b> (« il est parti »). Pour les toilettes : <b>洗手间</b>, <b>去方便一下</b>. Pour l'âge : <b>上年纪了</b>. Pour un licenciement : <b>被优化了</b> (« être optimisé », ironique).",
        examples: [["他爷爷去年去世了。", "tā yéye qùnián qùshì le.", "Son grand-père est décédé l'année dernière."], ["不好意思，我去方便一下。", "bù hǎoyìsi, wǒ qù fāngbiàn yíxià.", "Excusez-moi, je m'absente un instant (aux toilettes)."]],
      },
    ],
    mnemo: "« 研究研究 » répété = on enterre poliment le projet.",
    vocab: [["委婉", "wěiwǎn", "avec tact, indirect"], ["考虑", "kǎolǜ", "réfléchir, envisager"], ["改天", "gǎitiān", "un autre jour"], ["方便", "fāngbiàn", "pratique ; aller aux toilettes (euph.)"], ["建议", "jiànyì", "suggestion"], ["稍微", "shāowēi", "un peu, légèrement"], ["去世", "qùshì", "décéder"], ["上年纪", "shàng niánji", "prendre de l'âge"]],
    quiz: [
      mcq("« 我考虑一下 » signifie souvent :", ["un refus poli", "un oui enthousiaste", "une colère", "une promesse"], 0, "Réfléchir = souvent non, poliment."),
      fill("这个周末不太方便，___ 吧。(une autre fois)", ["改天", "gǎitiān", "gaitian"], "改天 = un autre jour."),
      mcq("Euphémisme pour « mourir » :", ["去世", "去方便", "上年纪", "考虑"], 0, "去世 qùshì."),
      mcq("Critique adoucie :", ["可能稍微长了一点儿。", "太长了，不行。", "你写得很差。", "这个没用。"], 0, "可能 + 稍微 adoucissent."),
      fill("不好意思，我去 ___ 一下。(toilettes)", ["方便", "fāngbiàn", "fangbian"], "去方便一下."),
      match("Associez", [["委婉|wěiwǎn", "avec tact"], ["建议|jiànyì", "suggestion"], ["稍微|shāowēi", "légèrement"], ["上年纪|shàng niánji", "prendre de l'âge"]]),
      tr("Traduisez : Son grand-père est décédé.", ["他爷爷去世了", "她爷爷去世了", "他的爷爷去世了", "tā yéye qùshì le", "ta yeye qushi le"], "去世 = décéder."),
    ],
  },

  {
    id: "c2-fangyan", module: "expr", title: "Dialectes et variantes : 普通话, 粤语, 繁体字", emoji: "🗺️",
    intro: "Le mandarin standard (普通话) n'est qu'une des langues chinoises. Hong Kong, Taïwan ou Shanghai ont leurs usages : caractères, prononciation et vocabulaire.",
    sections: [
      {
        title: "普通话 et les dialectes",
        text: "<b>普通话 pǔtōnghuà</b> est la langue commune, fondée sur la prononciation de Pékin. Les <b>方言 fāngyán</b> (« dialectes ») comme le <b>粤语 Yuèyǔ</b> (cantonais) ou le <b>上海话</b> sont souvent incompréhensibles entre eux à l'oral, mais s'écrivent avec les mêmes caractères. À Taïwan, on dit <b>国语 guóyǔ</b> ; à Singapour, <b>华语 huáyǔ</b>.",
        examples: [["你会说粤语吗？", "nǐ huì shuō Yuèyǔ ma?", "Tu parles cantonais ?"], ["我听不懂上海话。", "wǒ tīng bu dǒng Shànghǎihuà.", "Je ne comprends pas le shanghaïen."]],
      },
      {
        title: "简体字 et 繁体字",
        text: "La Chine continentale et Singapour utilisent les <b>简体字 jiǎntǐzì</b> (simplifiés) ; Taïwan, Hong Kong et Macao les <b>繁体字 fántǐzì</b> (traditionnels) : 学 → <b>學</b>, 国 → <b>國</b>, 语 → <b>語</b>, 龙 → <b>龍</b>, 书 → <b>書</b>.",
        examples: [["“中国”的繁体字是“中國”。", "“Zhōngguó” de fántǐzì shì “Zhōngguó”.", "« Chine » en caractères traditionnels s'écrit 中國."], ["台湾用繁体字。", "Táiwān yòng fántǐzì.", "Taïwan utilise les caractères traditionnels."]],
      },
      {
        title: "Différences de vocabulaire",
        text: "Le même objet peut porter un nom différent : logiciel <b>软件</b> (continent) / <b>软体</b> (Taïwan) ; taxi <b>出租车</b> / <b>计程车</b> (Taïwan) / <b>的士</b> (Hong Kong). Taïwan utilise aussi le <b>注音</b> (bopomofo) plutôt que le pinyin. En cantonais, « merci » se dit <b>唔该</b> (m4 goi1) pour un service et <b>多谢</b> (do1 ze6) pour un cadeau.",
        examples: [["在台湾，出租车叫“计程车”。", "zài Táiwān, chūzūchē jiào “jìchéngchē”.", "À Taïwan, le taxi s'appelle « jìchéngchē »."], ["香港人常说“的士”。", "Xiānggǎng rén cháng shuō “díshì”.", "Les Hongkongais disent souvent « díshì » (taxi)."]],
      },
    ],
    mnemo: "的士 díshì vient de l'anglais « taxi » via le cantonais (dik1 si2).",
    vocab: [["普通话", "pǔtōnghuà", "mandarin standard"], ["方言", "fāngyán", "dialecte"], ["粤语", "Yuèyǔ", "cantonais"], ["国语", "guóyǔ", "mandarin (à Taïwan)"], ["简体字", "jiǎntǐzì", "caractères simplifiés"], ["繁体字", "fántǐzì", "caractères traditionnels"], ["计程车", "jìchéngchē", "taxi (Taïwan)"], ["的士", "díshì", "taxi (Hong Kong)"]],
    quiz: [
      mcq("Le cantonais se dit :", ["粤语", "国语", "普通话", "华语"], 0, "粤语 Yuèyǔ."),
      mcq("La forme traditionnelle de 学 :", ["學", "斈", "孝", "季"], 0, "学 → 學."),
      fill("台湾和香港用 ___ 。(caractères traditionnels)", ["繁体字", "fántǐzì", "fantizi", "繁体"], "繁体字."),
      mcq("À Taïwan, « taxi » se dit :", ["计程车", "出租车", "的士", "公交车"], 0, "计程车 jìchéngchē."),
      mcq("Le mandarin à Taïwan s'appelle :", ["国语", "粤语", "方言", "上海话"], 0, "国语 guóyǔ."),
      match("Associez", [["國|guó", "pays (traditionnel)"], ["書|shū", "livre (traditionnel)"], ["龍|lóng", "dragon (traditionnel)"], ["語|yǔ", "langue (traditionnel)"]]),
      tr("Traduisez : Tu parles cantonais ?", ["你会说粤语吗", "你会说粤语吗？", "你会讲粤语吗", "nǐ huì shuō Yuèyǔ ma", "ni hui shuo yueyu ma"], "会说 + langue + 吗."),
    ],
  },

  {
    id: "c2-shici", module: "expr", title: "Poèmes Tang : 李白, 孟浩然, 王之涣", emoji: "🌙",
    intro: "Tout Chinois connaît par cœur quelques poèmes de la dynastie Tang (618-907). Ils sont cités dans la conversation, les publicités et les discours. Voici les trois plus célèbres.",
    sections: [
      {
        title: "静夜思 — Pensée d'une nuit calme (李白 Lǐ Bái)",
        text: "Quatre vers de cinq caractères : le poète voit le clair de lune au pied de son lit et pense à son pays natal. <b>举头</b> lever la tête, <b>低头</b> baisser la tête, <b>故乡 gùxiāng</b> pays natal.",
        examples: [["床前明月光，疑是地上霜。", "chuáng qián míng yuè guāng, yí shì dì shang shuāng.", "Devant mon lit, la clarté de la lune ; on dirait du givre sur le sol."], ["举头望明月，低头思故乡。", "jǔ tóu wàng míng yuè, dī tóu sī gùxiāng.", "Je lève la tête, contemple la lune ; je baisse la tête, et pense à mon pays."]],
      },
      {
        title: "春晓 — Aube de printemps (孟浩然 Mèng Hàorán)",
        text: "Le poète dort si bien qu'il ne voit pas l'aube venir, puis se demande combien de fleurs l'orage de la nuit a fait tomber. <b>不觉</b> sans s'en rendre compte, <b>啼鸟</b> oiseaux qui chantent.",
        examples: [["春眠不觉晓，处处闻啼鸟。", "chūn mián bù jué xiǎo, chùchù wén tí niǎo.", "Au printemps, on dort sans voir l'aube ; partout on entend chanter les oiseaux."], ["夜来风雨声，花落知多少。", "yè lái fēng yǔ shēng, huā luò zhī duōshǎo.", "La nuit, le bruit du vent et de la pluie : combien de fleurs sont tombées ?"]],
      },
      {
        title: "登鹳雀楼 — Du haut du pavillon des Cigognes (王之涣 Wáng Zhīhuàn)",
        text: "Le dernier vers, <b>更上一层楼</b> « monter encore d'un étage », s'emploie aujourd'hui pour dire « progresser encore, viser plus haut ».",
        examples: [["白日依山尽，黄河入海流。", "bái rì yī shān jìn, Huáng Hé rù hǎi liú.", "Le soleil blanc s'efface contre la montagne ; le fleuve Jaune coule vers la mer."], ["欲穷千里目，更上一层楼。", "yù qióng qiān lǐ mù, gèng shàng yì céng lóu.", "Pour voir à mille lieues, montons encore d'un étage."], ["希望你的中文更上一层楼！", "xīwàng nǐ de Zhōngwén gèng shàng yì céng lóu!", "J'espère que ton chinois progressera encore !"]],
      },
    ],
    mnemo: "唐诗 Tángshī = poésie Tang ; 五言绝句 = quatrain de cinq caractères par vers : les trois poèmes de la leçon en sont.",
    vocab: [["唐诗", "Tángshī", "poésie Tang"], ["诗人", "shīrén", "poète"], ["明月", "míng yuè", "lune brillante"], ["故乡", "gùxiāng", "pays natal"], ["举头", "jǔ tóu", "lever la tête"], ["低头", "dī tóu", "baisser la tête"], ["霜", "shuāng", "givre"], ["更上一层楼", "gèng shàng yì céng lóu", "progresser encore"]],
    quiz: [
      mcq("Qui a écrit « 静夜思 » ?", ["李白", "孟浩然", "王之涣", "孔子"], 0, "李白 Lǐ Bái."),
      fill("举头望明月，低头思 ___ 。", ["故乡", "gùxiāng", "guxiang"], "思故乡 = penser au pays natal."),
      mcq("春眠不觉 ___ ，处处闻啼鸟。", ["晓", "月", "霜", "楼"], 0, "不觉晓 = sans voir l'aube."),
      mcq("« 更上一层楼 » s'emploie pour :", ["progresser encore", "déménager", "prendre l'ascenseur", "avoir le vertige"], 0, "Viser plus haut."),
      fill("床前明月光，疑是地上 ___ 。", ["霜", "shuāng", "shuang"], "霜 = givre."),
      match("Associez", [["李白|Lǐ Bái", "静夜思"], ["孟浩然|Mèng Hàorán", "春晓"], ["王之涣|Wáng Zhīhuàn", "登鹳雀楼"], ["唐诗|Tángshī", "poésie Tang"]]),
      tr("Traduisez : J'espère que ton chinois progressera encore.", ["希望你的中文更上一层楼", "希望你的中文更上一层楼！", "祝你的中文更上一层楼", "xīwàng nǐ de Zhōngwén gèng shàng yì céng lóu", "xiwang ni de zhongwen geng shang yi ceng lou"], "更上一层楼."),
    ],
  },

  {
    id: "c2-wangluo", module: "vocab", title: "La langue d'internet : 内卷, 躺平, 打卡", emoji: "📱",
    intro: "Les réseaux sociaux chinois créent sans cesse de nouveaux mots qui passent ensuite dans la langue courante et même dans la presse. Voici les incontournables.",
    sections: [
      {
        title: "La société : 内卷 et 躺平",
        text: "<b>内卷 nèijuǎn</b> (« involution ») décrit une compétition épuisante où chacun travaille plus sans que personne n'y gagne. En réaction, <b>躺平 tǎngpíng</b> (« rester allongé ») = refuser la course, faire le minimum. <b>佛系 fóxì</b> (« style bouddhiste ») = détaché, zen.",
        examples: [["现在各行各业都很内卷。", "xiànzài gè háng gè yè dōu hěn nèijuǎn.", "Aujourd'hui tous les secteurs sont dans la surenchère."], ["他不想卷了，决定躺平。", "tā bù xiǎng juǎn le, juédìng tǎngpíng.", "Il ne veut plus de cette course, il a décidé de lâcher prise."]],
      },
      {
        title: "Les réseaux : 打卡, 点赞, 网红",
        text: "<b>打卡 dǎkǎ</b> (pointer) = aller dans un lieu à la mode et le poster ; <b>网红 wǎnghóng</b> = influenceur ou lieu viral (<i>网红店</i>) ; <b>点赞 diǎnzàn</b> = liker ; <b>吐槽 tǔcáo</b> = râler, critiquer avec humour.",
        examples: [["这家网红咖啡店每天都有人来打卡。", "zhè jiā wǎnghóng kāfēidiàn měitiān dōu yǒu rén lái dǎkǎ.", "Tous les jours des gens viennent poster des photos de ce café à la mode."], ["别忘了给我点赞！", "bié wàng le gěi wǒ diǎnzàn!", "N'oublie pas de me liker !"], ["大家都在网上吐槽这部电影。", "dàjiā dōu zài wǎng shang tǔcáo zhè bù diànyǐng.", "Tout le monde se moque de ce film en ligne."]],
      },
      {
        title: "Les réactions : 666, 给力, 凡尔赛",
        text: "<b>666</b> (liù liù liù, son proche de 溜 « fluide, habile ») = trop fort ! <b>给力 gěilì</b> = génial, efficace. <b>凡尔赛 Fán'ěrsài</b> (« Versailles ») = se vanter en faisant mine de se plaindre. <b>破防 pòfáng</b> = être émotionnellement touché.",
        examples: [["你太厉害了，666！", "nǐ tài lìhai le, liù liù liù!", "T'es trop fort, bravo !"], ["“唉，我又胖了，才四十五公斤。”——别凡尔赛了！", "“ài, wǒ yòu pàng le, cái sìshíwǔ gōngjīn.” —— bié Fán'ěrsài le!", "« Pff, j'ai encore grossi, je ne fais que 45 kilos. » — Arrête de faire ta Versailles !"]],
      },
    ],
    mnemo: "躺平 = « allongé à plat » : l'image même de celui qui ne veut plus courir.",
    vocab: [["内卷", "nèijuǎn", "surenchère épuisante"], ["躺平", "tǎngpíng", "lâcher prise, faire le minimum"], ["佛系", "fóxì", "détaché, zen"], ["打卡", "dǎkǎ", "pointer ; poster un lieu visité"], ["网红", "wǎnghóng", "influenceur, viral"], ["点赞", "diǎnzàn", "liker"], ["吐槽", "tǔcáo", "râler, se moquer"], ["给力", "gěilì", "génial, efficace"], ["凡尔赛", "Fán'ěrsài", "fausse modestie (Versailles)"]],
    quiz: [
      mcq("Refuser la course, faire le minimum :", ["躺平", "内卷", "打卡", "点赞"], 0, "躺平 tǎngpíng."),
      fill("别忘了给我 ___ ！(liker)", ["点赞", "diǎnzàn", "dianzan"], "点赞."),
      mcq("Compétition épuisante où personne ne gagne :", ["佛系", "内卷", "给力", "吐槽"], 1, "内卷 nèijuǎn."),
      mcq("Aller poster une photo dans un lieu à la mode :", ["打卡", "躺平", "凡尔赛", "破防"], 0, "打卡 dǎkǎ."),
      fill("这家 ___ 店每天都排长队。(viral)", ["网红", "wǎnghóng", "wanghong"], "网红店."),
      match("Associez", [["吐槽|tǔcáo", "râler"], ["给力|gěilì", "génial"], ["佛系|fóxì", "zen, détaché"], ["凡尔赛|Fán'ěrsài", "fausse modestie"]]),
      tr("Traduisez : Il a décidé de lâcher prise.", ["他决定躺平", "他决定躺平了", "她决定躺平", "tā juédìng tǎngpíng", "ta jueding tangping"], "躺平."),
    ],
  },
];

export const HSK6_EXAM_PLUS = [
  mcq("« Deux tiers » :", ["三分之二", "二分之三", "三之二分", "二之三分"], 0, "三分之二."),
  fill("他是最有名的作家 ___ 。(l'un des)", ["之一", "zhī yī", "zhi yi"], "之一."),
  mcq("« Selon les informations » :", ["据报道", "众所周知", "总而言之", "所谓"], 0, "据报道."),
  mcq("« 我们再研究研究 » signifie souvent :", ["un refus poli", "une acceptation immédiate", "une menace", "un remerciement"], 0, "Refus poli."),
  mcq("La forme traditionnelle de 国 :", ["國", "囯", "圀", "固"], 0, "国 → 國."),
  fill("欲穷千里目，更上一层 ___ 。", ["楼", "lóu", "lou"], "更上一层楼."),
  mcq("Faire le minimum, refuser la compétition :", ["躺平", "内卷", "网红", "热搜"], 0, "躺平."),
  mcq("Euphémisme pour « décéder » :", ["去世", "去方便", "改天", "考虑"], 0, "去世."),
  match("Associez", [["记者|jìzhě", "journaliste"], ["粤语|Yuèyǔ", "cantonais"], ["故乡|gùxiāng", "pays natal"], ["点赞|diǎnzàn", "liker"]]),
  tr("Traduisez : Tu parles cantonais ?", ["你会说粤语吗", "你会说粤语吗？", "你会讲粤语吗", "nǐ huì shuō Yuèyǔ ma", "ni hui shuo yueyu ma"], "会说粤语."),
];
