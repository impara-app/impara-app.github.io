/* =====================================================================
   Mandarin — compléments du palier HSK 1
   ---------------------------------------------------------------------
   Avec les 5 leçons d'origine, ces 10 leçons couvrent les 150 mots de
   la liste officielle HSK 1 et sa grammaire : 有 / 没有, classificateur
   个, 几 et 多少, mots interrogatifs, 呢, dates et heure, 在, 想 / 会 /
   能, 喜欢, 太…了, 了, 都, 和, 怎么 / 怎么样, 的.
   Les leçons s'ajoutent APRÈS les 5 d'origine (identifiants inchangés).
   Vocabulaire et exemples : [caractères, pinyin, français].
   ===================================================================== */

const mcq = (q, options, answer, explain = "") => ({ type: "mcq", q, options, answer, explain });
const fill = (q, answer, explain = "") => ({ type: "fill", q, answer, explain });
const match = (q, pairs, explain = "") => ({ type: "match", q, pairs, explain });
const tr = (q, answer, explain = "") => ({ type: "translate", q, answer, explain });

export const HSK1_PLUS = [
  /* ------------------------------------------------------------ 6 */
  {
    id: "a1-famille", module: "vocab", title: "La famille, 有 et le classificateur 个", emoji: "👨‍👩‍👧",
    intro: "Parler de sa famille, dire ce qu'on a (ou pas) et compter les personnes avec le classificateur 个.",
    sections: [
      {
        title: "有 yǒu : avoir — négation 没有 méiyǒu",
        text: "La négation de <b>有</b> est toujours <b>没有</b> (jamais 不有). Question : <b>你有…吗？</b>",
        examples: [["我有一个儿子。", "wǒ yǒu yí ge érzi.", "J'ai un fils."], ["她没有狗。", "tā méiyǒu gǒu.", "Elle n'a pas de chien."], ["你有猫吗？", "nǐ yǒu māo ma?", "As-tu un chat ?"]],
      },
      {
        title: "Nombre + 个 + nom",
        text: "Entre un nombre et un nom, il faut un <b>classificateur</b>. <b>个 ge</b> est le plus courant (personnes, choses). Devant un classificateur, « deux » se dit <b>两 liǎng</b> et non 二.",
        examples: [["三个朋友", "sān ge péngyou", "trois amis"], ["两个女儿", "liǎng ge nǚ'ér", "deux filles"], ["一个同学", "yí ge tóngxué", "un camarade de classe"]],
      },
      {
        title: "几 jǐ : combien (petits nombres)",
        text: "<b>几</b> + classificateur pour une quantité attendue inférieure à 10. <b>家</b> = famille, maison.",
        examples: [["你家有几个人？", "nǐ jiā yǒu jǐ ge rén?", "Combien êtes-vous dans ta famille ?"], ["我家有四个人：爸爸、妈妈、我和我女儿。", "wǒ jiā yǒu sì ge rén: bàba, māma, wǒ hé wǒ nǚ'ér.", "Nous sommes quatre : papa, maman, moi et ma fille."]],
      },
    ],
    mnemo: "家 jiā : un toit (宀) au-dessus d'un cochon (豕). Dans la Chine ancienne, la famille et ses cochons vivaient sous le même toit !",
    vocab: [["家", "jiā", "famille, maison"], ["爸爸", "bàba", "papa"], ["妈妈", "māma", "maman"], ["儿子", "érzi", "fils"], ["女儿", "nǚ'ér", "fille (enfant)"], ["朋友", "péngyou", "ami"], ["同学", "tóngxué", "camarade de classe"], ["有", "yǒu", "avoir, il y a"], ["没有", "méiyǒu", "ne pas avoir"], ["个", "gè", "classificateur général"], ["几", "jǐ", "combien (petit nombre)"], ["狗", "gǒu", "chien"], ["猫", "māo", "chat"], ["爱", "ài", "aimer (d'amour)"]],
    quiz: [
      mcq("« Je n'ai pas de chat » :", ["我不有猫。", "我没有猫。", "我没猫有。", "我是没有猫。"], 1, "La négation de 有 est 没有."),
      fill("我有两 ___ 朋友。(classificateur)", ["个", "ge", "gè"], "Nombre + 个 + nom."),
      mcq("« Deux fils » :", ["二个儿子", "两个儿子", "两儿子", "二儿子个"], 1, "Devant un classificateur : 两."),
      mcq("Que signifie 你家有几个人？", ["Où est ta maison ?", "Combien êtes-vous dans ta famille ?", "As-tu des amis ?", "Qui est dans ta famille ?"], 1, "几个人 = combien de personnes."),
      match("Associez", [["儿子|érzi", "fils"], ["女儿|nǚ'ér", "fille"], ["朋友|péngyou", "ami"], ["狗|gǒu", "chien"]]),
      fill("你有猫 ___ ？(question)", ["吗", "ma"], "吗 en fin de phrase."),
      mcq("爱 ài signifie :", ["avoir", "aimer", "chien", "famille"], 1, "我爱你 = je t'aime."),
      tr("Traduisez : J'ai un chien.", ["我有一个狗", "我有一只狗", "wǒ yǒu yí ge gǒu", "wo you yi ge gou", "wǒ yǒu yì zhī gǒu", "wo you yi zhi gou"], "我有一个狗 (on dira aussi 一只狗, avec le classificateur des animaux, vu en HSK 2)."),
    ],
  },

  /* ------------------------------------------------------------ 7 */
  {
    id: "a1-questions", module: "gram", title: "Qui, quoi, lequel : 谁, 什么, 哪 et 呢", emoji: "❓",
    intro: "En chinois, le mot interrogatif reste à la place de la réponse : pas d'inversion, pas de 吗.",
    sections: [
      {
        title: "Le mot interrogatif à la place de la réponse",
        text: "Remplacez simplement l'information inconnue par <b>谁</b> (qui), <b>什么</b> (quoi), <b>哪</b> (lequel). On n'ajoute <b>pas</b> 吗.",
        examples: [["他是谁？— 他是我同学。", "tā shì shéi? — tā shì wǒ tóngxué.", "Qui est-il ? — C'est mon camarade."], ["这是什么？", "zhè shì shénme?", "Qu'est-ce que c'est ?"], ["你叫什么名字？", "nǐ jiào shénme míngzi?", "Comment t'appelles-tu ?"], ["你是哪国人？", "nǐ shì nǎ guó rén?", "De quel pays es-tu ?"]],
      },
      {
        title: "这 zhè / 那 nà : ceci / cela",
        examples: [["这是我朋友。", "zhè shì wǒ péngyou.", "Voici mon ami."], ["那是什么？", "nà shì shénme?", "Qu'est-ce que c'est, là-bas ?"]],
      },
      {
        title: "呢 ne : « et toi ? »",
        text: "<b>呢</b> renvoie la question : <b>你呢？</b> = et toi ? Utile pour enchaîner sans répéter.",
        examples: [["我很高兴，你呢？", "wǒ hěn gāoxìng, nǐ ne?", "Je suis content, et toi ?"], ["认识你很高兴！", "rènshi nǐ hěn gāoxìng!", "Ravi de te connaître !"], ["王先生，您好！", "Wáng xiānsheng, nín hǎo!", "Bonjour, monsieur Wang !"]],
      },
    ],
    mnemo: "Question chinoise = phrase affirmative + trou. « Tu es qui ? » → 你是谁？ Le mot interrogatif prend la place de la réponse.",
    vocab: [["谁", "shéi", "qui"], ["什么", "shénme", "quoi, quel"], ["哪", "nǎ", "lequel, quel"], ["这", "zhè", "ceci, ce"], ["那", "nà", "cela, ce…là"], ["呢", "ne", "et… ? (particule)"], ["叫", "jiào", "s'appeler, appeler"], ["认识", "rènshi", "connaître (qqn)"], ["高兴", "gāoxìng", "content, ravi"], ["先生", "xiānsheng", "monsieur"], ["小姐", "xiǎojiě", "mademoiselle"], ["中国", "Zhōngguó", "Chine"]],
    quiz: [
      mcq("« Comment t'appelles-tu ? » :", ["你叫什么名字？", "你叫什么名字吗？", "什么你叫名字？", "你名字谁？"], 0, "Pas de 吗 avec un mot interrogatif."),
      fill("他是 ___ ？— 他是我爸爸。(qui)", ["谁", "shéi", "shei", "shuí"], "谁 = qui."),
      mcq("这是什么？ signifie :", ["Qui est-ce ?", "Qu'est-ce que c'est ?", "Où est-ce ?", "C'est combien ?"], 1, "什么 = quoi."),
      fill("我很好，你 ___ ？(et toi ?)", ["呢", "ne"], "呢 renvoie la question."),
      mcq("« De quel pays es-tu ? » :", ["你是哪国人？", "你是什么人吗？", "你哪是国人？", "你是谁国人？"], 0, "哪国 = quel pays."),
      match("Associez", [["这|zhè", "ceci"], ["那|nà", "cela"], ["谁|shéi", "qui"], ["认识|rènshi", "connaître"]]),
      mcq("认识你很高兴 signifie :", ["Je te connais bien.", "Ravi de te connaître.", "Tu es très content.", "Je ne te connais pas."], 1, "Formule de présentation."),
      tr("Traduisez : Qui est-ce ?", ["这是谁", "他是谁", "她是谁", "zhè shì shéi", "zhe shi shei", "tā shì shéi", "ta shi shei"], "这是谁？"),
    ],
  },

  /* ------------------------------------------------------------ 8 */
  {
    id: "a1-dates", module: "nombres", title: "Chiffres, dates et âge", emoji: "📅",
    intro: "Les chiffres de 1 à 9, puis la date du jour, les jours de la semaine et l'âge : en chinois, tout est très logique.",
    sections: [
      {
        title: "Les chiffres de un à neuf",
        table: { cols: ["", "", ""], rows: [["一 yī — 1", "二 èr — 2", "三 sān — 3"], ["四 sì — 4", "五 wǔ — 5", "六 liù — 6"], ["七 qī — 7", "八 bā — 8", "九 jiǔ — 9"]] },
      },
      {
        title: "La date : du plus grand au plus petit",
        text: "Année <b>年 nián</b> → mois <b>月 yuè</b> → jour <b>号 hào</b> → jour de la semaine. Les mois et les jours se comptent : 一月 = janvier, 星期一 = lundi… <b>星期天</b> = dimanche.",
        examples: [["今天几月几号？", "jīntiān jǐ yuè jǐ hào?", "Quelle est la date d'aujourd'hui ?"], ["今天五月八号，星期三。", "jīntiān wǔ yuè bā hào, xīngqīsān.", "Aujourd'hui, c'est le 8 mai, mercredi."], ["明天星期天。", "míngtiān xīngqītiān.", "Demain, c'est dimanche."]],
      },
      {
        title: "L'âge : 岁 suì",
        text: "Pas de verbe 是 avec la date ni l'âge. Pour un enfant : <b>你几岁？</b> Pour un adulte : <b>你多大？</b>",
        examples: [["你女儿几岁？— 她六岁。", "nǐ nǚ'ér jǐ suì? — tā liù suì.", "Quel âge a ta fille ? — Elle a six ans."], ["我二十岁。", "wǒ èrshí suì.", "J'ai vingt ans."], ["昨天是星期几？", "zuótiān shì xīngqī jǐ?", "Quel jour étions-nous hier ?"]],
      },
    ],
    mnemo: "星期 + chiffre = jour de la semaine (lundi = 1, mardi = 2…). Seul dimanche est spécial : 星期天 (« jour du ciel »).",
    vocab: [["今天", "jīntiān", "aujourd'hui"], ["明天", "míngtiān", "demain"], ["昨天", "zuótiān", "hier"], ["年", "nián", "année"], ["号", "hào", "jour du mois, numéro"], ["星期", "xīngqī", "semaine"], ["岁", "suì", "an (âge)"], ["多", "duō", "beaucoup, combien (+ adj.)"], ["月", "yuè", "mois"], ["一月", "yīyuè", "janvier"], ["二月", "èryuè", "février"], ["三月", "sānyuè", "mars"], ["四月", "sìyuè", "avril"], ["五月", "wǔyuè", "mai"], ["六月", "liùyuè", "juin"], ["七月", "qīyuè", "juillet"], ["八月", "bāyuè", "août"], ["九月", "jiǔyuè", "septembre"], ["十月", "shíyuè", "octobre"], ["十一月", "shíyīyuè", "novembre"], ["十二月", "shí'èryuè", "décembre"], ["星期一", "xīngqīyī", "lundi"], ["星期二", "xīngqī'èr", "mardi"], ["星期三", "xīngqīsān", "mercredi"], ["星期四", "xīngqīsì", "jeudi"], ["星期五", "xīngqīwǔ", "vendredi"], ["星期六", "xīngqīliù", "samedi"], ["星期天", "xīngqītiān", "dimanche"]],
    quiz: [
      match("Associez", [["四|sì", "4"], ["七|qī", "7"], ["九|jiǔ", "9"], ["六|liù", "6"]]),
      mcq("« Lundi » :", ["星期天", "星期一", "一星期", "月一"], 1, "星期 + 一."),
      mcq("Ordre correct pour « le 3 mai 2025 » :", ["三号五月二〇二五年", "二〇二五年五月三号", "五月三号二〇二五年", "二〇二五年三号五月"], 1, "Du plus grand au plus petit."),
      fill("今天几月几 ___ ？(jour du mois)", ["号", "hào", "hao"], "几号 = quel jour du mois."),
      mcq("« Elle a huit ans » :", ["她是八岁。", "她八岁。", "她有八岁。", "她岁八。"], 1, "Pas de 是 ni de 有 avec l'âge."),
      fill("昨天星期二，今天星期 ___ 。", ["三", "sān", "san"], "mardi → mercredi."),
      mcq("明天 signifie :", ["hier", "aujourd'hui", "demain", "la semaine"], 2, "明天 = demain."),
      tr("Traduisez : Aujourd'hui, c'est dimanche.", ["今天星期天", "今天是星期天", "jīntiān xīngqītiān", "jintian xingqitian", "jīntiān shì xīngqītiān", "jintian shi xingqitian", "今天星期日"], "今天星期天。"),
    ],
  },

  /* ------------------------------------------------------------ 9 */
  {
    id: "a1-heure", module: "nombres", title: "L'heure et les moments de la journée", emoji: "🕘",
    intro: "Dire l'heure avec 点, situer une action dans la journée et demander « quand ? ».",
    sections: [
      {
        title: "现在几点？ Quelle heure est-il ?",
        text: "Heure + <b>点 diǎn</b> + minutes + <b>分 fēn</b>. « Et demie » : <b>半 bàn</b>. Deux heures : <b>两点</b>.",
        examples: [["现在几点？", "xiànzài jǐ diǎn?", "Quelle heure est-il ?"], ["现在八点。", "xiànzài bā diǎn.", "Il est huit heures."], ["两点十分", "liǎng diǎn shí fēn", "deux heures dix"], ["九点半", "jiǔ diǎn bàn", "neuf heures et demie"]],
      },
      {
        title: "Le moment vient AVANT le verbe",
        text: "L'expression de temps se place en début de phrase ou juste après le sujet, jamais à la fin.",
        examples: [["我上午工作，下午学习。", "wǒ shàngwǔ gōngzuò, xiàwǔ xuéxí.", "Je travaille le matin, j'étudie l'après-midi."], ["中午我们吃米饭。", "zhōngwǔ wǒmen chī mǐfàn.", "À midi, nous mangeons du riz."], ["他晚上十一点睡觉。", "tā wǎnshang shíyī diǎn shuìjiào.", "Il se couche à 23 h."]],
      },
      {
        title: "什么时候 : quand ?",
        examples: [["你什么时候回家？", "nǐ shénme shíhou huí jiā?", "Quand rentres-tu à la maison ?"], ["坐飞机要五个小时，四十分钟。", "zuò fēijī yào wǔ ge xiǎoshí, sìshí fēnzhōng.", "En avion, il faut cinq heures quarante minutes."]],
      },
    ],
    mnemo: "Quand ? avant quoi ! Le chinois annonce toujours le moment avant l'action : « Moi demain matin aller Pékin ».",
    vocab: [["现在", "xiànzài", "maintenant"], ["点", "diǎn", "heure (sur l'horloge)"], ["分钟", "fēnzhōng", "minute (durée)"], ["上午", "shàngwǔ", "matin"], ["中午", "zhōngwǔ", "midi"], ["下午", "xiàwǔ", "après-midi"], ["时候", "shíhou", "moment"], ["什么时候", "shénme shíhou", "quand"], ["睡觉", "shuìjiào", "dormir, se coucher"], ["半", "bàn", "demi"]],
    quiz: [
      mcq("« Il est trois heures » :", ["现在三点。", "现在是三时。", "三点现在。", "现在三个点。"], 0, "Heure + 点."),
      mcq("« Deux heures » :", ["二点", "两点", "二个点", "两个点"], 1, "Devant 点 : 两."),
      fill("现在七点 ___ 。(et demie)", ["半", "bàn", "ban"], "七点半."),
      mcq("Ordre correct :", ["我工作上午。", "我上午工作。", "工作我上午。", "上午工作我。"], 1, "Le temps avant le verbe."),
      fill("你 ___ 回家？(quand)", ["什么时候", "shénme shíhou", "shenme shihou"], "什么时候 = quand."),
      match("Associez", [["上午|shàngwǔ", "matin"], ["中午|zhōngwǔ", "midi"], ["下午|xiàwǔ", "après-midi"], ["现在|xiànzài", "maintenant"]]),
      mcq("睡觉 signifie :", ["se réveiller", "dormir", "manger", "travailler"], 1, "睡觉 shuìjiào."),
      tr("Traduisez : Quelle heure est-il ?", ["现在几点", "几点了", "xiànzài jǐ diǎn", "xianzai ji dian"], "现在几点？"),
    ],
  },

  /* ------------------------------------------------------------ 10 */
  {
    id: "a1-manger", module: "expr", title: "Manger, boire et commander", emoji: "🍵",
    intro: "Exprimer une envie, ce qu'on aime, et commander au restaurant.",
    sections: [
      {
        title: "想 xiǎng : avoir envie de / vouloir",
        text: "<b>想</b> + verbe = avoir envie de faire. <b>请</b> = s'il vous plaît / inviter.",
        examples: [["我想喝茶。", "wǒ xiǎng hē chá.", "J'ai envie de boire du thé."], ["你想吃什么？", "nǐ xiǎng chī shénme?", "Qu'est-ce que tu veux manger ?"], ["请喝水。", "qǐng hē shuǐ.", "Je vous en prie, buvez de l'eau."]],
      },
      {
        title: "喜欢 xǐhuan : aimer (bien)",
        examples: [["我喜欢吃苹果。", "wǒ xǐhuan chī píngguǒ.", "J'aime manger des pommes."], ["她不喜欢喝咖啡。", "tā bù xǐhuan hē kāfēi.", "Elle n'aime pas boire du café."]],
      },
      {
        title: "太…了 : trop / vraiment",
        text: "<b>太</b> + adjectif + <b>了</b> exprime l'excès ou l'enthousiasme.",
        examples: [["这个菜太好吃了！", "zhège cài tài hǎochī le!", "Ce plat est vraiment délicieux !"], ["这个饭店的米饭很好吃。", "zhège fàndiàn de mǐfàn hěn hǎochī.", "Le riz de ce restaurant est très bon."], ["请给我一杯水。", "qǐng gěi wǒ yì bēi shuǐ.", "Un verre d'eau, s'il vous plaît."]],
      },
    ],
    mnemo: "吃 chī (manger) a la clé de la bouche 口 ; 喝 hē (boire) aussi. Tout ce qui passe par la bouche porte souvent 口 !",
    vocab: [["吃", "chī", "manger"], ["喝", "hē", "boire"], ["茶", "chá", "thé"], ["水", "shuǐ", "eau"], ["米饭", "mǐfàn", "riz cuit"], ["菜", "cài", "plat, légume"], ["苹果", "píngguǒ", "pomme"], ["水果", "shuǐguǒ", "fruit"], ["杯子", "bēizi", "verre, tasse"], ["想", "xiǎng", "vouloir, avoir envie de"], ["喜欢", "xǐhuan", "aimer (bien)"], ["饭店", "fàndiàn", "restaurant, hôtel"], ["请", "qǐng", "s'il vous plaît, inviter"], ["太", "tài", "trop"]],
    quiz: [
      mcq("« J'ai envie de boire de l'eau » :", ["我想喝水。", "我喝想水。", "我想水喝。", "我是想喝水。"], 0, "想 + verbe + objet."),
      fill("我 ___ 吃苹果。(aimer)", ["喜欢", "xǐhuan", "xihuan"], "喜欢 + verbe."),
      mcq("太好吃了！ signifie :", ["Ce n'est pas bon.", "C'est vraiment délicieux !", "Je mange trop.", "J'ai trop faim."], 1, "太…了."),
      mcq("« Riz cuit » :", ["米饭", "饭店", "苹果", "菜"], 0, "米饭 mǐfàn."),
      fill("你想 ___ 什么？(manger)", ["吃", "chī", "chi"], "吃 = manger."),
      match("Associez", [["茶|chá", "thé"], ["水果|shuǐguǒ", "fruit"], ["杯子|bēizi", "verre"], ["饭店|fàndiàn", "restaurant"]]),
      mcq("请 dans 请喝茶 signifie :", ["vouloir", "je vous en prie", "boire", "inviter à dîner"], 1, "Formule de politesse."),
      tr("Traduisez : Je n'aime pas le thé.", ["我不喜欢茶", "我不喜欢喝茶", "wǒ bù xǐhuan chá", "wo bu xihuan cha", "wǒ bù xǐhuan hē chá", "wo bu xihuan he cha"], "我不喜欢喝茶。"),
    ],
  },

  /* ------------------------------------------------------------ 11 */
  {
    id: "a1-acheter", module: "expr", title: "Faire des achats : 买, 多少钱, 块", emoji: "🛍️",
    intro: "Acheter, demander un prix, parler de quantités et de tailles.",
    sections: [
      {
        title: "Combien ça coûte ?",
        text: "<b>多少钱？</b> À l'oral, l'unité monétaire est <b>块 kuài</b> (yuan). <b>几</b> pour les petits nombres, <b>多少</b> pour n'importe quel nombre.",
        examples: [["这个多少钱？", "zhège duōshao qián?", "Combien coûte celui-ci ?"], ["三十块。", "sānshí kuài.", "Trente yuans."], ["你想买什么？", "nǐ xiǎng mǎi shénme?", "Que veux-tu acheter ?"]],
      },
      {
        title: "Classificateurs utiles",
        text: "<b>本 běn</b> pour les livres, <b>杯 bēi</b> pour un verre de…, <b>些 xiē</b> = quelques (这些 = ces…-ci).",
        examples: [["我买两本书。", "wǒ mǎi liǎng běn shū.", "J'achète deux livres."], ["这些衣服很漂亮。", "zhèxiē yīfu hěn piàoliang.", "Ces vêtements sont très beaux."]],
      },
      {
        title: "Adjectifs : 很 + adjectif",
        text: "Un adjectif s'utilise sans 是 : <b>这个商店很大</b>. 很 est souvent juste un « liant ».",
        examples: [["这个商店很大。", "zhège shāngdiàn hěn dà.", "Ce magasin est grand."], ["东西很多，钱很少！", "dōngxi hěn duō, qián hěn shǎo!", "Beaucoup de choses, peu d'argent !"]],
      },
    ],
    mnemo: "东西 dōngxi = « est-ouest » = une chose. Les marchés de l'est et de l'ouest de Chang'an ont donné le mot « acheter des choses de l'est et de l'ouest ».",
    vocab: [["买", "mǎi", "acheter"], ["钱", "qián", "argent"], ["块", "kuài", "yuan (oral)"], ["多少", "duōshao", "combien"], ["东西", "dōngxi", "chose, objet"], ["衣服", "yīfu", "vêtement"], ["商店", "shāngdiàn", "magasin"], ["些", "xiē", "quelques"], ["本", "běn", "classificateur des livres"], ["书", "shū", "livre"], ["大", "dà", "grand"], ["小", "xiǎo", "petit"], ["少", "shǎo", "peu"], ["漂亮", "piàoliang", "beau, joli"]],
    quiz: [
      mcq("« Combien ça coûte ? » :", ["多少钱？", "几钱？", "钱多少吗？", "什么钱？"], 0, "多少钱？"),
      fill("我买三 ___ 书。(classificateur des livres)", ["本", "běn", "ben"], "本 pour les livres."),
      mcq("« Ce magasin est grand » :", ["这个商店是大。", "这个商店很大。", "这个大商店。", "商店这个很大。"], 1, "很 + adjectif, sans 是."),
      mcq("块 kuài à l'oral, c'est :", ["un morceau de pain", "l'unité monétaire (yuan)", "un magasin", "une minute"], 1, "三十块 = 30 yuans."),
      match("Associez", [["衣服|yīfu", "vêtement"], ["东西|dōngxi", "chose"], ["商店|shāngdiàn", "magasin"], ["少|shǎo", "peu"]]),
      fill("你想 ___ 什么？(acheter)", ["买", "mǎi", "mai"], "买 mǎi (3e ton) = acheter."),
      mcq("这些 signifie :", ["celui-ci", "ces… -ci", "cela", "combien"], 1, "这 + 些."),
      tr("Traduisez : C'est très joli.", ["很漂亮", "这个很漂亮", "这很漂亮", "hěn piàoliang", "hen piaoliang", "zhège hěn piàoliang", "zhege hen piaoliang"], "很漂亮。"),
    ],
  },

  /* ------------------------------------------------------------ 12 */
  {
    id: "a1-lieux", module: "gram", title: "Où ? 在, 住 et la position", emoji: "📍",
    intro: "Situer une personne ou un objet, dire où l'on habite et où l'on travaille.",
    sections: [
      {
        title: "在 zài : être à / se trouver",
        text: "Sujet + <b>在</b> + lieu. Question : <b>…在哪儿？</b>",
        examples: [["我在家。", "wǒ zài jiā.", "Je suis à la maison."], ["医院在哪儿？", "yīyuàn zài nǎr?", "Où est l'hôpital ?"], ["我妈妈在医院工作。", "wǒ māma zài yīyuàn gōngzuò.", "Ma mère travaille à l'hôpital."]],
      },
      {
        title: "Lieu + mot de position",
        text: "<b>里 lǐ</b> (dans), <b>上 shàng</b> (sur), <b>下 xià</b> (sous), <b>前面 qiánmiàn</b> (devant), <b>后面 hòumiàn</b> (derrière) se placent APRÈS le nom.",
        examples: [["书在桌子上。", "shū zài zhuōzi shang.", "Le livre est sur la table."], ["猫在椅子下面。", "māo zài yǐzi xiàmiàn.", "Le chat est sous la chaise."], ["学校后面有一个商店。", "xuéxiào hòumiàn yǒu yí ge shāngdiàn.", "Derrière l'école, il y a un magasin."]],
      },
      {
        title: "住 zhù : habiter",
        examples: [["你住在哪儿？", "nǐ zhù zài nǎr?", "Où habites-tu ?"], ["我住在北京。", "wǒ zhù zài Běijīng.", "J'habite à Pékin."], ["他是医生。", "tā shì yīshēng.", "Il est médecin."]],
      },
    ],
    mnemo: "En chinois, on dit « table-dessus » (桌子上) et non « sur la table » : le mot de position vient après, comme une étiquette.",
    vocab: [["在", "zài", "être à, se trouver"], ["哪儿", "nǎr", "où"], ["住", "zhù", "habiter"], ["学校", "xuéxiào", "école"], ["医院", "yīyuàn", "hôpital"], ["医生", "yīshēng", "médecin"], ["北京", "Běijīng", "Pékin"], ["里", "lǐ", "dans, intérieur"], ["上", "shàng", "sur, monter"], ["下", "xià", "sous, descendre"], ["前面", "qiánmiàn", "devant"], ["后面", "hòumiàn", "derrière"], ["桌子", "zhuōzi", "table"], ["椅子", "yǐzi", "chaise"], ["工作", "gōngzuò", "travailler, travail"]],
    quiz: [
      mcq("« Où es-tu ? » :", ["你在哪儿？", "你是哪儿？", "哪儿你在？", "你在哪儿吗？"], 0, "在 + 哪儿."),
      mcq("« Le livre est sur la table » :", ["书在上桌子。", "书在桌子上。", "书是桌子上。", "桌子上在书。"], 1, "Nom + 上."),
      fill("我住 ___ 北京。(à)", ["在", "zài", "zai"], "住在 + lieu."),
      fill("猫在椅子 ___ 面。(sous)", ["下", "xià", "xia"], "下面 = dessous."),
      match("Associez", [["学校|xuéxiào", "école"], ["医院|yīyuàn", "hôpital"], ["前面|qiánmiàn", "devant"], ["后面|hòumiàn", "derrière"]]),
      mcq("医生 signifie :", ["hôpital", "médecin", "étudiant", "professeur"], 1, "医生 yīshēng."),
      mcq("« Elle travaille à l'école » :", ["她工作在学校。", "她在学校工作。", "她学校在工作。", "在学校她是工作。"], 1, "在 + lieu AVANT le verbe."),
      tr("Traduisez : Où habites-tu ?", ["你住在哪儿", "你住哪儿", "nǐ zhù zài nǎr", "ni zhu zai nar", "你住在哪里", "nǐ zhù nǎr", "ni zhu nar"], "你住在哪儿？"),
    ],
  },

  /* ------------------------------------------------------------ 13 */
  {
    id: "a1-activites", module: "vocab", title: "Activités : 会, 能 et les loisirs", emoji: "📺",
    intro: "Parler de ce qu'on fait, de ce qu'on sait faire (会) et de ce qu'on peut faire (能).",
    sections: [
      {
        title: "会 huì : savoir faire (appris)",
        text: "<b>会</b> = savoir faire grâce à un apprentissage (langue, nager…). Négation : <b>不会</b>.",
        examples: [["我会说汉语。", "wǒ huì shuō Hànyǔ.", "Je sais parler chinois."], ["你会写汉字吗？", "nǐ huì xiě Hànzì ma?", "Sais-tu écrire les caractères ?"], ["他不会开车。", "tā bú huì kāi chē.", "Il ne sait pas conduire."]],
      },
      {
        title: "能 néng : pouvoir (possibilité)",
        examples: [["你能来吗？", "nǐ néng lái ma?", "Peux-tu venir ?"], ["今天我不能看电影。", "jīntiān wǒ bù néng kàn diànyǐng.", "Aujourd'hui, je ne peux pas aller voir un film."]],
      },
      {
        title: "Les activités du quotidien",
        examples: [["我在家看电视。", "wǒ zài jiā kàn diànshì.", "Je regarde la télé à la maison."], ["他喜欢听中国音乐。", "tā xǐhuan tīng Zhōngguó yīnyuè.", "Il aime écouter de la musique chinoise."], ["我每天学习汉语。", "wǒ měi tiān xuéxí Hànyǔ.", "J'étudie le chinois tous les jours."], ["你看见我的书了吗？", "nǐ kànjiàn wǒ de shū le ma?", "As-tu vu mon livre ?"]],
      },
    ],
    mnemo: "电 diàn = électricité : 电视 (vision électrique) = télé, 电影 (ombre électrique) = film, 电脑 (cerveau électrique) = ordinateur.",
    vocab: [["看", "kàn", "regarder, lire"], ["看见", "kànjiàn", "voir"], ["听", "tīng", "écouter"], ["说", "shuō", "parler, dire"], ["读", "dú", "lire (à voix haute)"], ["写", "xiě", "écrire"], ["字", "zì", "caractère"], ["学习", "xuéxí", "étudier"], ["汉语", "Hànyǔ", "langue chinoise"], ["会", "huì", "savoir faire"], ["能", "néng", "pouvoir"], ["电视", "diànshì", "télévision"], ["电影", "diànyǐng", "film"], ["电脑", "diànnǎo", "ordinateur"]],
    quiz: [
      mcq("« Je sais parler chinois » :", ["我能说汉语。", "我会说汉语。", "我说会汉语。", "我是说汉语。"], 1, "Compétence apprise : 会."),
      mcq("« Peux-tu venir demain ? » (possibilité) :", ["你明天会来吗？", "你明天能来吗？", "你能明天来吗？", "能你明天来吗？"], 1, "Possibilité : 能 ; le temps avant le verbe."),
      fill("我喜欢 ___ 电影。(regarder)", ["看", "kàn", "kan"], "看电影 = regarder un film."),
      mcq("电脑 signifie :", ["télévision", "film", "ordinateur", "téléphone"], 2, "« cerveau électrique »."),
      match("Associez", [["听|tīng", "écouter"], ["写|xiě", "écrire"], ["读|dú", "lire"], ["字|zì", "caractère"]]),
      fill("他不 ___ 写汉字。(savoir faire)", ["会", "huì", "hui"], "不会 = ne sait pas."),
      mcq("看见 signifie :", ["regarder", "voir", "lire", "revoir"], 1, "看 (regarder) + 见 (percevoir) = voir."),
      tr("Traduisez : J'étudie le chinois.", ["我学习汉语", "我学汉语", "wǒ xuéxí Hànyǔ", "wo xuexi hanyu", "我学中文"], "我学习汉语。"),
    ],
  },

  /* ------------------------------------------------------------ 14 */
  {
    id: "a1-transport", module: "temps", title: "Se déplacer et téléphoner : 去, 坐, 了", emoji: "🚕",
    intro: "Aller quelque part, prendre un moyen de transport, téléphoner et raconter une action accomplie avec 了.",
    sections: [
      {
        title: "去 / 来 / 回 + lieu",
        text: "<b>去</b> = aller (s'éloigner), <b>来</b> = venir (vers moi), <b>回</b> = rentrer. Pas de préposition : <b>我去北京</b>.",
        examples: [["我明天去北京。", "wǒ míngtiān qù Běijīng.", "Demain, je vais à Pékin."], ["你来我家吗？", "nǐ lái wǒ jiā ma?", "Tu viens chez moi ?"], ["他回家了。", "tā huí jiā le.", "Il est rentré à la maison."]],
      },
      {
        title: "坐 zuò + transport (+ 去 + lieu)",
        text: "<b>坐</b> = s'asseoir, et aussi prendre un transport : <b>坐出租车</b>, <b>坐飞机</b>. <b>开车</b> = conduire.",
        examples: [["我坐飞机去上海。", "wǒ zuò fēijī qù Shànghǎi.", "Je vais à Shanghai en avion."], ["我们坐出租车回家吧。", "wǒmen zuò chūzūchē huí jiā ba.", "Rentrons en taxi."], ["怎么去学校？", "zěnme qù xuéxiào?", "Comment va-t-on à l'école ?"]],
      },
      {
        title: "了 le : c'est fait !",
        text: "<b>了</b> après le verbe (ou en fin de phrase) indique qu'une action est réalisée. Au téléphone : <b>喂</b> (wéi) = allô.",
        examples: [["我买了一本书。", "wǒ mǎi le yì běn shū.", "J'ai acheté un livre."], ["喂，你好！我是小王。", "wéi, nǐ hǎo! wǒ shì Xiǎo Wáng.", "Allô, bonjour ! C'est Xiao Wang."], ["我给妈妈打电话了。", "wǒ gěi māma dǎ diànhuà le.", "J'ai appelé maman."]],
      },
    ],
    mnemo: "喂 wéi au téléphone se prononce souvent avec le 2e ton (wéi ?), comme une question : « allô ? ».",
    vocab: [["去", "qù", "aller"], ["来", "lái", "venir"], ["回", "huí", "rentrer, retourner"], ["坐", "zuò", "s'asseoir, prendre (transport)"], ["出租车", "chūzūchē", "taxi"], ["飞机", "fēijī", "avion"], ["开", "kāi", "ouvrir, conduire"], ["打电话", "dǎ diànhuà", "téléphoner"], ["喂", "wéi", "allô"], ["怎么", "zěnme", "comment"], ["了", "le", "particule d'action accomplie"]],
    quiz: [
      mcq("« Je vais à l'école » :", ["我去在学校。", "我去学校。", "我学校去。", "我是去学校。"], 1, "去 + lieu, sans préposition."),
      fill("我坐 ___ 去上海。(avion)", ["飞机", "fēijī", "feiji"], "坐飞机."),
      mcq("« J'ai acheté des fruits » :", ["我买水果了。", "我了买水果。", "我买了水果了吗。", "了我买水果。"], 0, "了 en fin de phrase (ou 我买了水果)."),
      mcq("Au téléphone, « allô » se dit :", ["你好吗", "喂", "请", "对不起"], 1, "喂 wéi."),
      fill("你 ___ 去北京？(comment)", ["怎么", "zěnme", "zenme"], "怎么 + verbe = comment."),
      match("Associez", [["来|lái", "venir"], ["回|huí", "rentrer"], ["出租车|chūzūchē", "taxi"], ["开|kāi", "ouvrir, conduire"]]),
      mcq("打电话 signifie :", ["ordinateur", "téléphoner", "regarder la télé", "taper"], 1, "打电话 dǎ diànhuà."),
      tr("Traduisez : Il est rentré à la maison.", ["他回家了", "tā huí jiā le", "ta hui jia le"], "他回家了。"),
    ],
  },

  /* ------------------------------------------------------------ 15 */
  {
    id: "a1-meteo", module: "gram", title: "Le temps qu'il fait, 都, 和 et 的", emoji: "🌦️",
    intro: "Parler de la météo, donner son avis avec 怎么样, et relier les mots avec 和, 都 et 的.",
    sections: [
      {
        title: "天气怎么样？",
        text: "<b>怎么样</b> = comment est… ? / qu'en penses-tu ? <b>下雨</b> = pleuvoir (littéralement « tomber pluie »).",
        examples: [["今天天气怎么样？", "jīntiān tiānqì zěnmeyàng?", "Quel temps fait-il aujourd'hui ?"], ["今天很冷。", "jīntiān hěn lěng.", "Il fait très froid aujourd'hui."], ["北京太热了！", "Běijīng tài rè le!", "Il fait trop chaud à Pékin !"], ["明天下雨。", "míngtiān xià yǔ.", "Demain, il pleuvra."]],
      },
      {
        title: "和 hé : et (entre deux noms) · 都 dōu : tous",
        text: "<b>和</b> relie des noms uniquement (pas deux phrases). <b>都</b> se place AVANT le verbe et reprend un sujet pluriel.",
        examples: [["我和我朋友都是学生。", "wǒ hé wǒ péngyou dōu shì xuésheng.", "Mon ami et moi sommes tous les deux étudiants."], ["他们都喜欢喝茶。", "tāmen dōu xǐhuan hē chá.", "Ils aiment tous boire du thé."]],
      },
      {
        title: "的 de : possession",
        text: "A <b>的</b> B = le B de A. Avec les proches, on l'omet souvent : 我妈妈.",
        examples: [["这是我的书。", "zhè shì wǒ de shū.", "C'est mon livre."], ["老师的电脑很漂亮。", "lǎoshī de diànnǎo hěn piàoliang.", "L'ordinateur du professeur est très joli."]],
      },
    ],
    mnemo: "都 = « tous » se colle devant le verbe, jamais devant le nom : 我们都去 (nous allons tous), pas « 都我们 ».",
    vocab: [["天气", "tiānqì", "temps, météo"], ["怎么样", "zěnmeyàng", "comment (est-ce) ?"], ["冷", "lěng", "froid"], ["热", "rè", "chaud"], ["下雨", "xià yǔ", "pleuvoir"], ["很", "hěn", "très"], ["和", "hé", "et (entre noms)"], ["都", "dōu", "tous"], ["的", "de", "particule de possession"], ["上海", "Shànghǎi", "Shanghai"]],
    quiz: [
      mcq("« Quel temps fait-il ? » :", ["天气什么？", "天气怎么样？", "天气怎么？", "什么天气吗？"], 1, "怎么样."),
      mcq("« Il fait chaud » :", ["很热。", "是热。", "有热。", "很冷。"], 0, "很 + adjectif."),
      fill("我 ___ 我妈妈都喜欢猫。(et)", ["和", "hé", "he"], "和 relie deux noms."),
      mcq("Où placer 都 ? « Nous sommes tous français. »", ["都我们是法国人。", "我们都是法国人。", "我们是都法国人。", "我们是法国人都。"], 1, "都 avant le verbe."),
      fill("这是我 ___ 电脑。(possession)", ["的", "de"], "我的电脑."),
      match("Associez", [["冷|lěng", "froid"], ["热|rè", "chaud"], ["下雨|xià yǔ", "pleuvoir"], ["天气|tiānqì", "météo"]]),
      mcq("北京太冷了 signifie :", ["Pékin est un peu froid.", "Il fait trop froid à Pékin !", "Pékin n'est pas froid.", "Il fera froid à Pékin."], 1, "太…了."),
      tr("Traduisez : Demain, il pleut.", ["明天下雨", "明天会下雨", "míngtiān xià yǔ", "mingtian xia yu"], "明天下雨。"),
    ],
  },
];

/** Questions ajoutées à l'examen HSK 1 (à la suite des 8 d'origine) */
export const HSK1_EXAM_PLUS = [
  mcq("« Je n'ai pas d'ordinateur » :", ["我不有电脑。", "我没有电脑。", "我没电脑有。", "我是没有电脑。"], 1, "没有."),
  fill("我有三 ___ 朋友。(classificateur)", ["个", "ge", "gè"], "个."),
  mcq("« Qui est-ce ? » :", ["这是谁吗？", "这是谁？", "谁是这吗？", "这谁是？"], 1, "Pas de 吗 avec 谁."),
  mcq("« Le 10 juin » :", ["十号六月", "六月十号", "六十月号", "月六号十"], 1, "Mois puis jour."),
  fill("现在几 ___ ？(heure)", ["点", "diǎn", "dian"], "几点 = quelle heure."),
  mcq("« Je travaille l'après-midi » :", ["我工作下午。", "我下午工作。", "下午工作我。", "我在下午了工作。"], 1, "Temps avant le verbe."),
  fill("这个多少 ___ ？(argent)", ["钱", "qián", "qian"], "多少钱."),
  mcq("« Le chat est sous la table » :", ["猫在下桌子。", "猫在桌子下。", "猫是桌子下。", "桌子下猫在。"], 1, "Nom + 下."),
  mcq("« Je sais nager / parler » (appris) se dit avec :", ["能", "会", "想", "要"], 1, "会 = savoir faire."),
  fill("我坐 ___ 回家。(taxi)", ["出租车", "chūzūchē", "chuzuche"], "坐出租车."),
  mcq("« Nous aimons tous le thé » :", ["我们都喜欢茶。", "都我们喜欢茶。", "我们喜欢都茶。", "我们喜欢茶都。"], 0, "都 avant le verbe."),
  tr("Traduisez : C'est mon livre.", ["这是我的书", "zhè shì wǒ de shū", "zhe shi wo de shu"], "这是我的书。"),
];
