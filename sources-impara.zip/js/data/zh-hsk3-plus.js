/* =====================================================================
   Mandarin — compléments du palier HSK 3
   ---------------------------------------------------------------------
   Avec les 4 leçons d'origine (比, 把, compléments de résultat et
   modaux, expressions), ces 12 leçons couvrent la grammaire et les
   thèmes de la liste officielle du HSK 3 (600 mots au total) :
   compléments de direction, 是…的, durée et fréquence, 越来越 /
   一边…一边 / 又…又, 先…再…然后, 刚 / 以后 / 的时候, 除了…以外 /
   只有…才 / 为了 / 关于, 连…都 et les pronoms interrogatifs indéfinis,
   et les thèmes santé, transports, école et travail, saisons et
   nature, sentiments, achats et banque.
   (Le passif 被 et les grandes paires de connecteurs sont travaillés
   au palier HSK 4.)
   Vocabulaire et exemples : [caractères, pinyin, français].
   ===================================================================== */

const mcq = (q, options, answer, explain = "") => ({ type: "mcq", q, options, answer, explain });
const fill = (q, answer, explain = "") => ({ type: "fill", q, answer, explain });
const match = (q, pairs, explain = "") => ({ type: "match", q, pairs, explain });
const tr = (q, answer, explain = "") => ({ type: "translate", q, answer, explain });

export const HSK3_PLUS = [
  /* ------------------------------------------------------------ 5 */
  {
    id: "b1-direction", module: "gram", title: "Monter, descendre, revenir : les compléments de direction", emoji: "↗️",
    intro: "En chinois, un verbe de mouvement est souvent suivi de 来 (vers moi) ou 去 (loin de moi), et de 上, 下, 进, 出, 回, 过, 起. C'est une des grandes nouveautés du HSK 3.",
    sections: [
      {
        title: "Verbe + 来 / 去",
        text: "<b>来</b> : le mouvement se rapproche de celui qui parle. <b>去</b> : il s'en éloigne. Le lieu se place AVANT 来 / 去.",
        examples: [["你快下来吧！", "nǐ kuài xiàlai ba!", "Descends vite (vers moi) !"], ["他上楼去了。", "tā shàng lóu qù le.", "Il est monté à l'étage (loin de moi)."], ["妈妈回家来了。", "māma huí jiā lái le.", "Maman est rentrée à la maison (ici)."], ["请进来！", "qǐng jìnlai!", "Entrez, je vous en prie !"]],
      },
      {
        title: "Directions composées",
        table: { cols: ["", "来 (vers moi)", "去 (loin de moi)"], rows: [["上 monter", "上来 shànglai", "上去 shàngqu"], ["下 descendre", "下来 xiàlai", "下去 xiàqu"], ["进 entrer", "进来 jìnlai", "进去 jìnqu"], ["出 sortir", "出来 chūlai", "出去 chūqu"], ["回 revenir", "回来 huílai", "回去 huíqu"], ["过 traverser", "过来 guòlai", "过去 guòqu"], ["起 se lever", "起来 qǐlai", "—"]] },
      },
      {
        title: "Avec un autre verbe",
        examples: [["他从包里拿出来一本书。", "tā cóng bāo lǐ ná chūlai yì běn shū.", "Il a sorti un livre de son sac."], ["她跑回宿舍去了。", "tā pǎo huí sùshè qù le.", "Elle est retournée en courant au dortoir."], ["大家站起来！", "dàjiā zhàn qǐlai!", "Tout le monde debout !"], ["把椅子搬过来。", "bǎ yǐzi bān guòlai.", "Apporte la chaise par ici."]],
      },
    ],
    mnemo: "来 = vers le locuteur, 去 = loin du locuteur. Au téléphone avec un ami en bas : « 你上来吧 » (monte !), car vous êtes en haut.",
    vocab: [["上来", "shànglai", "monter (vers ici)"], ["下去", "xiàqu", "descendre (là-bas)"], ["进来", "jìnlai", "entrer (ici)"], ["出去", "chūqu", "sortir (là-bas)"], ["回来", "huílai", "revenir"], ["过来", "guòlai", "venir par ici"], ["起来", "qǐlai", "se lever"], ["楼", "lóu", "étage, immeuble"], ["拿", "ná", "prendre (en main)"], ["搬", "bān", "déménager, transporter"], ["站", "zhàn", "se tenir debout"], ["包", "bāo", "sac"], ["宿舍", "sùshè", "dortoir"], ["椅子", "yǐzi", "chaise"]],
    quiz: [
      mcq("Vous êtes dans la chambre, votre ami frappe : « Entre ! »", ["你进去吧！", "你进来吧！", "你出来吧！", "你回去吧！"], 1, "Vers vous : 进来."),
      mcq("Où placer le lieu ? « Il est rentré chez lui »", ["他回来家了。", "他回家来了。", "他家回来了。", "他回了家来。"], 1, "Le lieu se place avant 来 / 去."),
      fill("请大家站 ___ 。(se lever)", ["起来", "qǐlai", "qilai"], "站起来."),
      mcq("Vous êtes en bas et appelez votre ami en haut :", ["你下来吧！", "你下去吧！", "你上来吧！", "你上去吧！"], 0, "Il descend vers vous : 下来."),
      match("Associez", [["拿|ná", "prendre"], ["搬|bān", "transporter"], ["楼|lóu", "étage"], ["椅子|yǐzi", "chaise"]]),
      fill("他从包里拿 ___ 一本书。(sortir vers moi)", ["出来", "chūlai", "chulai"], "拿出来."),
      mcq("出去 signifie :", ["entrer (ici)", "sortir (là-bas)", "revenir", "monter"], 1, "出 = sortir, 去 = loin."),
      tr("Traduisez : Maman est rentrée (à la maison).", ["妈妈回家来了", "妈妈回来了", "māma huí jiā lái le", "mama hui jia lai le"], "回家来了."),
    ],
  },

  /* ------------------------------------------------------------ 6 */
  {
    id: "b1-shi-de", module: "gram", title: "Quand ? Comment ? Avec qui ? : 是…的", emoji: "🔍",
    intro: "Pour une action déjà faite, on met en relief QUAND, OÙ, COMMENT ou AVEC QUI elle s'est passée : 我是坐飞机来的 (c'est en avion que je suis venu).",
    sections: [
      {
        title: "Sujet + 是 + précision + verbe + 的",
        text: "L'action est connue et passée ; on insiste sur une circonstance. <b>是</b> peut tomber à l'oral, <b>的</b> jamais. Négation : <b>不是…的</b>.",
        examples: [["你是什么时候来的？", "nǐ shì shénme shíhou lái de?", "Quand es-tu arrivé ?"], ["我是昨天到的。", "wǒ shì zuótiān dào de.", "Je suis arrivé hier."], ["我们是坐地铁来的。", "wǒmen shì zuò dìtiě lái de.", "C'est en métro que nous sommes venus."], ["他不是一个人去的，是跟朋友一起去的。", "tā bú shì yí ge rén qù de, shì gēn péngyou yìqǐ qù de.", "Il n'y est pas allé seul, il y est allé avec des amis."]],
      },
      {
        title: "Avec un complément d'objet",
        text: "L'objet se place souvent APRÈS 的 : <i>我是在北京学<b>的</b>中文</i>.",
        examples: [["你是在哪儿学的中文？", "nǐ shì zài nǎr xué de Zhōngwén?", "Où as-tu appris le chinois ?"], ["我是在大学学的。", "wǒ shì zài dàxué xué de.", "Je l'ai appris à l'université."], ["这个蛋糕是谁做的？", "zhège dàngāo shì shéi zuò de?", "Qui a fait ce gâteau ?"]],
      },
      {
        title: "了 ou 是…的 ?",
        text: "<b>了</b> annonce qu'une action a eu lieu (information nouvelle). <b>是…的</b> suppose qu'on le sait déjà et demande les détails.",
        examples: [["我去了上海。", "wǒ qù le Shànghǎi.", "Je suis allé à Shanghai (nouvelle)."], ["你是怎么去的？—— 我是坐火车去的。", "nǐ shì zěnme qù de? —— wǒ shì zuò huǒchē qù de.", "Comment y es-tu allé ? — En train."]],
      },
    ],
    mnemo: "了 raconte QUE ça s'est passé ; 是…的 raconte COMMENT ça s'est passé. Le 是 ouvre le projecteur, le 的 le referme.",
    vocab: [["是…的", "shì… de", "c'est… que (mise en relief)"], ["什么时候", "shénme shíhou", "quand"], ["怎么", "zěnme", "comment"], ["地铁", "dìtiě", "métro"], ["火车", "huǒchē", "train"], ["飞机", "fēijī", "avion"], ["一起", "yìqǐ", "ensemble"], ["跟", "gēn", "avec"], ["到", "dào", "arriver"], ["蛋糕", "dàngāo", "gâteau"], ["大学", "dàxué", "université"], ["刚", "gāng", "venir de"]],
    quiz: [
      mcq("« C'est en avion que je suis venu » :", ["我坐飞机来了。", "我是坐飞机来的。", "我是坐飞机来了。", "我来的坐飞机。"], 1, "是 + manière + verbe + 的."),
      fill("你是什么时候到 ___？", ["的", "de"], "是…的 se referme avec 的."),
      mcq("Négation correcte :", ["我没是坐地铁来的。", "我不是坐地铁来的。", "我是不坐地铁来的。", "我是坐地铁不来的。"], 1, "不是…的."),
      mcq("On sait que tu es allé à Pékin. On demande AVEC QUI :", ["你跟谁去了北京？", "你是跟谁去的北京？", "你去北京跟谁了？", "你跟谁是去北京？"], 1, "Détail d'une action connue → 是…的."),
      match("Associez", [["地铁|dìtiě", "métro"], ["火车|huǒchē", "train"], ["一起|yìqǐ", "ensemble"], ["蛋糕|dàngāo", "gâteau"]]),
      fill("这本书是谁买 ___ ？", ["的", "de"], "是谁买的."),
      mcq("Pour annoncer une NOUVELLE (« Je suis allé en Chine ! ») :", ["我去了中国。", "我是去中国的。", "我是去的中国。", "我去中国是的。"], 0, "Information nouvelle : 了."),
      tr("Traduisez : Je suis arrivé hier (mise en relief de « hier »).", ["我是昨天到的", "我是昨天来的", "wǒ shì zuótiān dào de", "wo shi zuotian dao de"], "是 + temps + verbe + 的."),
    ],
  },

  /* ------------------------------------------------------------ 7 */
  {
    id: "b1-duree", module: "temps", title: "Depuis combien de temps ? Combien de fois ?", emoji: "⏱️",
    intro: "« J'apprends le chinois depuis deux ans », « j'ai attendu une demi-heure », « je suis allé trois fois en Chine » : la durée et la fréquence se placent APRÈS le verbe.",
    sections: [
      {
        title: "Verbe + 了 + durée (+ 了)",
        text: "La durée suit le verbe. Un second <b>了</b> en fin de phrase dit que l'action <b>continue encore</b>.",
        examples: [["我等了半个小时。", "wǒ děng le bàn ge xiǎoshí.", "J'ai attendu une demi-heure (c'est fini)."], ["我学中文学了两年了。", "wǒ xué Zhōngwén xué le liǎng nián le.", "J'apprends le chinois depuis deux ans (et je continue)."], ["她在北京住了三个月。", "tā zài Běijīng zhù le sān ge yuè.", "Elle a habité trois mois à Pékin."]],
      },
      {
        title: "Avec un objet : répéter le verbe ou mettre l'objet après",
        text: "Deux possibilités : <i>我<b>学</b>中文<b>学</b>了两年</i> ou <i>我学了两年(的)中文</i>.",
        examples: [["他看电视看了一个晚上。", "tā kàn diànshì kàn le yí ge wǎnshang.", "Il a regardé la télé toute la soirée."], ["我们聊了一个小时(的)天。", "wǒmen liáo le yí ge xiǎoshí (de) tiān.", "Nous avons bavardé une heure."]],
      },
      {
        title: "Combien de fois : 次, 遍, 一下",
        text: "<b>次</b> = fois (occurrence). <b>遍</b> = fois, du début à la fin (lire, écouter, répéter). <b>一下</b> = un petit peu, rapidement.",
        examples: [["我去过三次长城。", "wǒ qù guo sān cì Chángchéng.", "Je suis allé trois fois à la Grande Muraille."], ["请再说一遍。", "qǐng zài shuō yí biàn.", "Répétez encore une fois, s'il vous plaît."], ["你等一下。", "nǐ děng yíxià.", "Attends un instant."]],
      },
    ],
    mnemo: "En chinois, la durée vient APRÈS le verbe, comme une étiquette : 等了十分钟 = « attendre-(fait)-dix minutes ».",
    vocab: [["半", "bàn", "demi"], ["小时", "xiǎoshí", "heure (durée)"], ["分钟", "fēnzhōng", "minute"], ["年", "nián", "an"], ["月", "yuè", "mois"], ["次", "cì", "fois"], ["遍", "biàn", "fois (en entier)"], ["一下", "yíxià", "un instant, un peu"], ["住", "zhù", "habiter"], ["聊天", "liáotiān", "bavarder"], ["电视", "diànshì", "télévision"], ["一直", "yìzhí", "tout le temps, continuellement"]],
    quiz: [
      mcq("« J'ai attendu dix minutes » :", ["我十分钟等了。", "我等了十分钟。", "我等十分钟了了。", "我了等十分钟。"], 1, "Verbe + 了 + durée."),
      mcq("« J'apprends le chinois depuis deux ans (et je continue) » :", ["我学了两年中文。", "我学中文学了两年了。", "我两年学中文。", "我学中文两年。"], 1, "Le 2e 了 = ça continue."),
      fill("请再说一 ___ 。(fois, en entier)", ["遍", "biàn", "bian"], "再说一遍."),
      mcq("« Je suis allé deux fois à Shanghai » :", ["我去过两次上海。", "我两次去过上海。", "我去上海两遍。", "我去了上海二次。"], 0, "去过 + 两次 + lieu."),
      match("Associez", [["次|cì", "fois"], ["分钟|fēnzhōng", "minute"], ["住|zhù", "habiter"], ["聊天|liáotiān", "bavarder"]]),
      fill("你等一 ___ ，我马上来。", ["下", "xià", "xia"], "等一下."),
      mcq("她在法国住了一年 ___ 。(et elle y vit encore)", ["的", "了", "过", "着"], 1, "了 final = situation actuelle."),
      tr("Traduisez : J'ai attendu une demi-heure.", ["我等了半个小时", "wǒ děng le bàn ge xiǎoshí", "wo deng le ban ge xiaoshi"], "等了半个小时."),
    ],
  },

  /* ------------------------------------------------------------ 8 */
  {
    id: "b1-yue", module: "gram", title: "De plus en plus, à la fois : 越来越, 一边…一边, 又…又", emoji: "📈",
    intro: "Décrire une évolution (il fait de plus en plus froid), deux actions simultanées (manger en regardant la télé) et deux qualités à la fois (bon et pas cher).",
    sections: [
      {
        title: "越来越 + adjectif / verbe d'état",
        text: "<b>越来越</b> remplace 很 : on ne dit jamais *越来越很冷. <b>越 A 越 B</b> = plus A, plus B.",
        examples: [["天气越来越冷了。", "tiānqì yuè lái yuè lěng le.", "Il fait de plus en plus froid."], ["你的中文越来越好了！", "nǐ de Zhōngwén yuè lái yuè hǎo le!", "Ton chinois est de mieux en mieux !"], ["雨越下越大。", "yǔ yuè xià yuè dà.", "Plus il pleut, plus la pluie est forte."], ["这个歌我越听越喜欢。", "zhège gē wǒ yuè tīng yuè xǐhuan.", "Plus j'écoute cette chanson, plus je l'aime."]],
      },
      {
        title: "一边 A 一边 B : faire deux choses en même temps",
        examples: [["他一边吃饭一边看手机。", "tā yìbiān chīfàn yìbiān kàn shǒujī.", "Il mange en regardant son téléphone."], ["我们一边走一边聊天。", "wǒmen yìbiān zǒu yìbiān liáotiān.", "Nous bavardons en marchant."]],
      },
      {
        title: "又 A 又 B : à la fois A et B",
        examples: [["这家饭馆的菜又好吃又便宜。", "zhè jiā fànguǎn de cài yòu hǎochī yòu piányi.", "La cuisine de ce restaurant est à la fois bonne et pas chère."], ["我又累又饿。", "wǒ yòu lèi yòu è.", "Je suis à la fois fatigué et affamé."]],
      },
    ],
    mnemo: "越来越 = « plus vient, plus » : comme une boule de neige qui grossit. Et jamais de 很 à côté !",
    vocab: [["越来越", "yuè lái yuè", "de plus en plus"], ["越…越", "yuè… yuè", "plus… plus"], ["一边…一边", "yìbiān… yìbiān", "tout en…"], ["又…又", "yòu… yòu", "à la fois… et"], ["天气", "tiānqì", "le temps (météo)"], ["冷", "lěng", "froid"], ["饿", "è", "avoir faim"], ["累", "lèi", "fatigué"], ["胖", "pàng", "gros"], ["瘦", "shòu", "mince"], ["歌", "gē", "chanson"], ["聪明", "cōngming", "intelligent"]],
    quiz: [
      mcq("« Il fait de plus en plus chaud » :", ["天气越来越很热了。", "天气越来越热了。", "天气越热越来了。", "天气很越来越热。"], 1, "Pas de 很 avec 越来越."),
      fill("他 ___ 走一边唱歌。", ["一边", "yìbiān", "yibian"], "一边…一边."),
      mcq("« Cette veste est à la fois belle et pas chère » :", ["这件衣服又漂亮又便宜。", "这件衣服也漂亮也便宜。", "这件衣服越漂亮越便宜。", "这件衣服一边漂亮一边便宜。"], 0, "又…又 pour deux qualités."),
      mcq("雨越下越大 signifie :", ["Il pleut de moins en moins", "Plus il pleut, plus la pluie est forte", "Il pleut et il fait chaud", "Il va pleuvoir beaucoup"], 1, "越 A 越 B."),
      match("Associez", [["饿|è", "avoir faim"], ["累|lèi", "fatigué"], ["瘦|shòu", "mince"], ["聪明|cōngming", "intelligent"]]),
      fill("我 ___ 累又饿。", ["又", "yòu", "you"], "又…又."),
      mcq("一边…一边 relie :", ["deux qualités", "deux actions simultanées", "une cause et une conséquence", "un avant et un après"], 1, "Actions en même temps."),
      tr("Traduisez : Ton chinois est de mieux en mieux.", ["你的中文越来越好了", "你的汉语越来越好了", "nǐ de Zhōngwén yuè lái yuè hǎo le", "ni de zhongwen yue lai yue hao le"], "越来越 + adjectif + 了."),
    ],
  },

  /* ------------------------------------------------------------ 9 */
  {
    id: "b1-xian-zai", module: "temps", title: "D'abord, ensuite, quand : 先…再…然后, 的时候, 以后", emoji: "🪜",
    intro: "Raconter une suite d'actions, situer un moment (« quand j'étais petit », « après le cours ») et dire ce qui vient juste d'arriver.",
    sections: [
      {
        title: "先 A，再 B，然后 C，最后 D",
        text: "<b>先</b> (d'abord) et <b>再</b> (ensuite, pour le futur) sont des adverbes : ils se placent devant le verbe. <b>然后</b> (puis) et <b>最后</b> (enfin) ouvrent la proposition.",
        examples: [["我们先吃饭，再去看电影。", "wǒmen xiān chīfàn, zài qù kàn diànyǐng.", "On mange d'abord, puis on va voir un film."], ["先往前走，然后往左拐。", "xiān wǎng qián zǒu, ránhòu wǎng zuǒ guǎi.", "D'abord tout droit, puis tournez à gauche."], ["最后我们坐出租车回家了。", "zuìhòu wǒmen zuò chūzūchē huí jiā le.", "Finalement, nous sommes rentrés en taxi."]],
      },
      {
        title: "…的时候, …以前, …以后",
        text: "Ces mots se placent APRÈS la proposition (contrairement au français « quand… »).",
        examples: [["我小的时候住在农村。", "wǒ xiǎo de shíhou zhù zài nóngcūn.", "Quand j'étais petit, j'habitais à la campagne."], ["睡觉以前，我会洗澡。", "shuìjiào yǐqián, wǒ huì xǐzǎo.", "Avant de dormir, je prends une douche."], ["下课以后，我们一起去图书馆吧。", "xiàkè yǐhòu, wǒmen yìqǐ qù túshūguǎn ba.", "Après le cours, allons ensemble à la bibliothèque."]],
      },
      {
        title: "刚 et 刚才 : « venir de »",
        text: "<b>刚</b> est un adverbe devant le verbe (je viens de). <b>刚才</b> est un moment (tout à l'heure), il peut se placer devant le sujet.",
        examples: [["我刚到家。", "wǒ gāng dào jiā.", "Je viens d'arriver à la maison."], ["刚才谁给我打电话了？", "gāngcái shéi gěi wǒ dǎ diànhuà le?", "Qui m'a téléphoné tout à l'heure ?"]],
      },
    ],
    mnemo: "Le chinois raconte dans l'ordre du temps : « je petit 的时候 », « cours fini 以后 ». Le repère temporel vient toujours en premier.",
    vocab: [["先", "xiān", "d'abord"], ["再", "zài", "ensuite, de nouveau"], ["然后", "ránhòu", "puis"], ["最后", "zuìhòu", "finalement"], ["的时候", "de shíhou", "quand, au moment où"], ["以前", "yǐqián", "avant"], ["以后", "yǐhòu", "après"], ["刚", "gāng", "venir de"], ["刚才", "gāngcái", "tout à l'heure"], ["洗澡", "xǐzǎo", "se doucher"], ["图书馆", "túshūguǎn", "bibliothèque"], ["拐", "guǎi", "tourner"]],
    quiz: [
      mcq("« Quand j'étais petit » :", ["的时候我小", "我小的时候", "时候的我小", "我的时候小"], 1, "Proposition + 的时候."),
      fill("我们 ___ 吃饭，再去看电影。(d'abord)", ["先", "xiān", "xian"], "先…再."),
      mcq("« Je viens d'arriver » :", ["我刚才到。", "我刚到。", "我到刚。", "我已经到刚。"], 1, "刚 + verbe."),
      mcq("« Après le cours » :", ["以后下课", "下课以后", "下课的以后", "以后的下课"], 1, "Action + 以后."),
      match("Associez", [["然后|ránhòu", "puis"], ["最后|zuìhòu", "finalement"], ["图书馆|túshūguǎn", "bibliothèque"], ["洗澡|xǐzǎo", "se doucher"]]),
      fill("睡觉 ___ ，我会看一会儿书。(avant)", ["以前", "yǐqián", "yiqian"], "以前 = avant."),
      mcq("刚才 signifie :", ["venir de (adverbe)", "tout à l'heure", "bientôt", "toujours"], 1, "刚才 = tout à l'heure."),
      tr("Traduisez : D'abord tout droit, puis tournez à gauche.", ["先往前走，然后往左拐", "先往前走然后往左拐", "xiān wǎng qián zǒu, ránhòu wǎng zuǒ guǎi"], "先… 然后…"),
    ],
  },

  /* ------------------------------------------------------------ 10 */
  {
    id: "b1-chule", module: "gram", title: "Sauf, seulement si, pour : 除了, 只有…才, 为了, 关于", emoji: "🧭",
    intro: "Des mots indispensables du HSK 3 pour préciser sa pensée : « à part le thé, j'aime aussi le café », « c'est seulement en travaillant que… », « pour réussir… », « au sujet de… ».",
    sections: [
      {
        title: "除了…以外，还 / 都",
        text: "<b>除了 X 以外，还…</b> = à part X, en plus (on ajoute). <b>除了 X 以外，都…</b> = sauf X, tous (on exclut).",
        examples: [["除了汉语以外，他还会说日语。", "chúle Hànyǔ yǐwài, tā hái huì shuō Rìyǔ.", "À part le chinois, il parle aussi japonais."], ["除了小王以外，大家都来了。", "chúle Xiǎo Wáng yǐwài, dàjiā dōu lái le.", "Sauf Xiao Wang, tout le monde est venu."]],
      },
      {
        title: "只有…才 : seulement si",
        examples: [["只有努力学习，才能考好。", "zhǐyǒu nǔlì xuéxí, cái néng kǎo hǎo.", "C'est seulement en étudiant sérieusement qu'on réussit l'examen."], ["他十点才起床。", "tā shí diǎn cái qǐchuáng.", "Il ne s'est levé qu'à 10 h (tard !)."]],
      },
      {
        title: "为了 (pour, afin de) et 关于 (au sujet de)",
        examples: [["为了学好中文，她每天看中国电影。", "wèile xué hǎo Zhōngwén, tā měi tiān kàn Zhōngguó diànyǐng.", "Pour bien apprendre le chinois, elle regarde des films chinois tous les jours."], ["这是一本关于中国历史的书。", "zhè shì yì běn guānyú Zhōngguó lìshǐ de shū.", "C'est un livre sur l'histoire de la Chine."], ["我对中国文化很感兴趣。", "wǒ duì Zhōngguó wénhuà hěn gǎn xìngqù.", "Je m'intéresse beaucoup à la culture chinoise."]],
      },
    ],
    mnemo: "才 = « pas avant / pas sans » : il marque que c'est tard, difficile ou conditionné. 就 (vu au HSK 2) dit l'inverse : tôt, facile.",
    vocab: [["除了…以外", "chúle… yǐwài", "à part, sauf"], ["只有…才", "zhǐyǒu… cái", "seulement si"], ["为了", "wèile", "pour, afin de"], ["关于", "guānyú", "au sujet de"], ["对…感兴趣", "duì… gǎn xìngqù", "s'intéresser à"], ["努力", "nǔlì", "faire des efforts"], ["考试", "kǎoshì", "examen"], ["历史", "lìshǐ", "histoire"], ["文化", "wénhuà", "culture"], ["日语", "Rìyǔ", "japonais"], ["大家", "dàjiā", "tout le monde"], ["还", "hái", "encore, aussi"]],
    quiz: [
      mcq("« À part le café, il aime aussi le thé » :", ["除了咖啡以外，他都喜欢茶。", "除了咖啡以外，他还喜欢茶。", "除了咖啡，他才喜欢茶。", "除了咖啡以外，他也不喜欢茶。"], 1, "Ajout : 还."),
      mcq("« Sauf lui, tout le monde est venu » :", ["除了他以外，大家还来了。", "除了他以外，大家都来了。", "只有他，大家都来了。", "为了他，大家都来了。"], 1, "Exclusion : 都."),
      fill("只有多练习，___ 能说得好。", ["才", "cái", "cai"], "只有…才."),
      mcq("« Pour réussir l'examen, il étudie tous les jours » :", ["为了考好，他每天学习。", "关于考好，他每天学习。", "除了考好，他每天学习。", "对考好，他每天学习。"], 0, "为了 = afin de."),
      match("Associez", [["历史|lìshǐ", "histoire"], ["文化|wénhuà", "culture"], ["努力|nǔlì", "faire des efforts"], ["关于|guānyú", "au sujet de"]]),
      fill("我 ___ 中国菜很感兴趣。", ["对", "duì", "dui"], "对…感兴趣."),
      mcq("他十点才来 suggère que :", ["il est venu tôt", "il est venu tard", "il n'est pas venu", "il viendra à 10 h"], 1, "才 = tard, pas avant."),
      tr("Traduisez : C'est un livre sur l'histoire de la Chine.", ["这是一本关于中国历史的书", "zhè shì yì běn guānyú Zhōngguó lìshǐ de shū"], "关于 + sujet + 的 + nom."),
    ],
  },

  /* ------------------------------------------------------------ 11 */
  {
    id: "b1-lian", module: "gram", title: "Même… : 连…都, 一点儿也不, 什么都", emoji: "😲",
    intro: "Renforcer une phrase : « même mon père sait le faire », « pas du tout cher », « il ne mange rien ».",
    sections: [
      {
        title: "连 X 都 / 也 : même X",
        examples: [["这个字连老师都不认识。", "zhège zì lián lǎoshī dōu bú rènshi.", "Même le professeur ne connaît pas ce caractère."], ["他忙得连饭都没吃。", "tā máng de lián fàn dōu méi chī.", "Il est tellement occupé qu'il n'a même pas mangé."]],
      },
      {
        title: "一点儿也不 / 一点儿都没 : pas du tout",
        text: "Devant un adjectif ou un verbe négatif. À ne pas confondre avec <b>有点儿</b> (un peu, souvent négatif) placé devant l'adjectif.",
        examples: [["这件衣服一点儿也不贵。", "zhè jiàn yīfu yìdiǎnr yě bú guì.", "Ce vêtement n'est pas cher du tout."], ["我一点儿都没听懂。", "wǒ yìdiǎnr dōu méi tīng dǒng.", "Je n'ai rien compris du tout."], ["今天有点儿冷。", "jīntiān yǒudiǎnr lěng.", "Aujourd'hui il fait un peu froid."]],
      },
      {
        title: "什么都 / 谁都 / 哪儿都 : tout, tout le monde, partout",
        text: "Un mot interrogatif + <b>都 / 也</b> devient indéfini : 什么都 (tout / rien au négatif), 谁都 (tout le monde / personne), 哪儿都 (partout / nulle part).",
        examples: [["他什么都吃。", "tā shénme dōu chī.", "Il mange de tout."], ["我今天哪儿也不想去。", "wǒ jīntiān nǎr yě bù xiǎng qù.", "Aujourd'hui je ne veux aller nulle part."], ["这件事谁都知道。", "zhè jiàn shì shéi dōu zhīdào.", "Tout le monde le sait."]],
      },
    ],
    mnemo: "有点儿 se met AVANT l'adjectif (有点儿贵 : un peu trop cher) ; 一点儿 se met APRÈS (便宜一点儿 : un peu moins cher).",
    vocab: [["连…都", "lián… dōu", "même…"], ["一点儿也不", "yìdiǎnr yě bù", "pas du tout"], ["有点儿", "yǒudiǎnr", "un peu (trop)"], ["什么都", "shénme dōu", "tout"], ["谁都", "shéi dōu", "tout le monde"], ["哪儿都", "nǎr dōu", "partout"], ["认识", "rènshi", "connaître"], ["忙", "máng", "occupé"], ["知道", "zhīdào", "savoir"], ["事", "shì", "affaire, chose"], ["字", "zì", "caractère"], ["奇怪", "qíguài", "bizarre"]],
    quiz: [
      mcq("« Même les enfants savent ça » :", ["连孩子都知道。", "孩子连都知道。", "连孩子知道都。", "都孩子连知道。"], 0, "连 + X + 都 + verbe."),
      fill("这个菜一点儿 ___ 不辣。", ["也", "都", "yě", "dōu"], "一点儿也不 / 一点儿都不."),
      mcq("« Il fait un peu froid (gênant) » :", ["今天一点儿冷。", "今天有点儿冷。", "今天冷有点儿。", "今天一点儿也冷。"], 1, "有点儿 + adjectif."),
      mcq("« Je ne veux rien manger » :", ["我什么都不想吃。", "我不想吃什么都。", "我什么不想吃都。", "我都什么不想吃。"], 0, "什么都 + négation."),
      match("Associez", [["认识|rènshi", "connaître"], ["忙|máng", "occupé"], ["奇怪|qíguài", "bizarre"], ["知道|zhīdào", "savoir"]]),
      fill("这件事 ___ 都知道。(tout le monde)", ["谁", "shéi", "shei"], "谁都."),
      mcq("« Moins cher, s'il vous plaît » :", ["有点儿便宜吧。", "便宜一点儿吧。", "一点儿便宜吧。", "便宜有点儿吧。"], 1, "Adjectif + 一点儿."),
      tr("Traduisez : Je n'ai rien compris du tout.", ["我一点儿都没听懂", "我一点儿也没听懂", "我一点儿都没懂", "wǒ yìdiǎnr dōu méi tīng dǒng"], "一点儿都没 + verbe."),
    ],
  },

  /* ------------------------------------------------------------ 12 */
  {
    id: "b1-shenti", module: "vocab", title: "Santé et sport : chez le médecin", emoji: "🩺",
    intro: "Dire où on a mal, comprendre le médecin, parler de sport et de bonnes habitudes : les mots santé du HSK 3.",
    sections: [
      {
        title: "Je suis malade",
        examples: [["我感冒了，头疼，还有点儿发烧。", "wǒ gǎnmào le, tóu téng, hái yǒudiǎnr fāshāo.", "J'ai attrapé un rhume, j'ai mal à la tête et un peu de fièvre."], ["我肚子不舒服。", "wǒ dùzi bù shūfu.", "J'ai mal au ventre."], ["你哪儿不舒服？", "nǐ nǎr bù shūfu?", "Où avez-vous mal ?"]],
      },
      {
        title: "Chez le médecin",
        examples: [["医生让我多喝水，多休息。", "yīshēng ràng wǒ duō hē shuǐ, duō xiūxi.", "Le médecin m'a dit de boire beaucoup d'eau et de me reposer."], ["这种药一天吃三次，饭后吃。", "zhè zhǒng yào yì tiān chī sān cì, fàn hòu chī.", "Ce médicament se prend trois fois par jour, après les repas."], ["你的身体没什么问题。", "nǐ de shēntǐ méi shénme wèntí.", "Vous n'avez pas de problème de santé."]],
      },
      {
        title: "Sport et bonnes habitudes",
        examples: [["为了健康，我每天锻炼一个小时。", "wèile jiànkāng, wǒ měi tiān duànliàn yí ge xiǎoshí.", "Pour ma santé, je fais une heure de sport par jour."], ["他游泳游得很好。", "tā yóuyǒng yóu de hěn hǎo.", "Il nage très bien."], ["少喝咖啡，早点儿睡觉！", "shǎo hē kāfēi, zǎo diǎnr shuìjiào!", "Bois moins de café et couche-toi plus tôt !"]],
      },
    ],
    mnemo: "不舒服 « pas confortable » est la façon polie et courante de dire qu'on est malade ou qu'on a mal quelque part.",
    vocab: [["感冒", "gǎnmào", "rhume, s'enrhumer"], ["发烧", "fāshāo", "avoir de la fièvre"], ["疼", "téng", "avoir mal"], ["头", "tóu", "tête"], ["肚子", "dùzi", "ventre"], ["舒服", "shūfu", "confortable, bien"], ["医生", "yīshēng", "médecin"], ["医院", "yīyuàn", "hôpital"], ["药", "yào", "médicament"], ["身体", "shēntǐ", "corps, santé"], ["健康", "jiànkāng", "santé, en bonne santé"], ["锻炼", "duànliàn", "faire de l'exercice"], ["游泳", "yóuyǒng", "nager"], ["检查", "jiǎnchá", "examiner, contrôle"]],
    quiz: [
      mcq("« J'ai mal à la tête » :", ["我疼头。", "我头疼。", "我的疼头。", "我头是疼。"], 1, "Partie du corps + 疼."),
      fill("我感冒了，还有点儿 ___ 。(fièvre)", ["发烧", "fāshāo", "fashao"], "发烧."),
      mcq("Le médecin demande « Où avez-vous mal ? » :", ["你哪儿不舒服？", "你什么疼？", "你为什么病？", "你舒服吗哪儿？"], 0, "哪儿不舒服."),
      mcq("« faire du sport, s'entraîner » :", ["锻炼", "检查", "健康", "舒服"], 0, "锻炼 duànliàn."),
      match("Associez", [["药|yào", "médicament"], ["医院|yīyuàn", "hôpital"], ["肚子|dùzi", "ventre"], ["健康|jiànkāng", "santé"]]),
      fill("这种药一天吃三 ___ 。(fois)", ["次", "cì", "ci"], "三次."),
      mcq("医生让我多休息 signifie :", ["Le médecin se repose beaucoup", "Le médecin m'a dit de me reposer davantage", "Le médecin m'a donné du repos", "Je me repose chez le médecin"], 1, "让 + personne + action."),
      tr("Traduisez : J'ai attrapé un rhume.", ["我感冒了", "wǒ gǎnmào le", "wo ganmao le"], "感冒了."),
    ],
  },

  /* ------------------------------------------------------------ 13 */
  {
    id: "b1-jiaotong", module: "vocab", title: "En ville : métro, retards et itinéraires", emoji: "🚇",
    intro: "Prendre le métro, changer de ligne, demander son chemin et s'excuser d'être en retard : la ville chinoise au quotidien.",
    sections: [
      {
        title: "Le métro et le bus",
        examples: [["坐地铁二号线，在人民广场站换四号线。", "zuò dìtiě èr hào xiàn, zài Rénmín Guǎngchǎng zhàn huàn sì hào xiàn.", "Prends la ligne 2 et change à la station Place du Peuple pour la ligne 4."], ["下一站是北京站。", "xià yí zhàn shì Běijīng zhàn.", "Prochaine station : gare de Pékin."], ["这路公共汽车到火车站吗？", "zhè lù gōnggòng qìchē dào huǒchēzhàn ma?", "Ce bus va-t-il à la gare ?"]],
      },
      {
        title: "Demander son chemin",
        examples: [["请问，附近有银行吗？", "qǐngwèn, fùjìn yǒu yínháng ma?", "Excusez-moi, y a-t-il une banque près d'ici ?"], ["一直往前走，过了马路就到了。", "yìzhí wǎng qián zǒu, guò le mǎlù jiù dào le.", "Allez tout droit, c'est juste après avoir traversé la rue."], ["你看一下地图吧。", "nǐ kàn yíxià dìtú ba.", "Regarde la carte."]],
      },
      {
        title: "En retard !",
        examples: [["对不起，我迟到了，路上堵车。", "duìbuqǐ, wǒ chídào le, lù shang dǔchē.", "Désolé, je suis en retard, il y avait des bouchons."], ["我差点儿没赶上飞机。", "wǒ chàdiǎnr méi gǎnshàng fēijī.", "J'ai failli rater l'avion."], ["骑自行车比坐车方便。", "qí zìxíngchē bǐ zuò chē fāngbiàn.", "Le vélo est plus pratique que la voiture."]],
      },
    ],
    mnemo: "骑 qí (monter à califourchon) pour le vélo et le cheval ; 坐 zuò (s'asseoir) pour le bus, le métro, l'avion ; 开 kāi pour conduire.",
    vocab: [["站", "zhàn", "station, arrêt"], ["换", "huàn", "changer"], ["号线", "hào xiàn", "ligne (de métro)"], ["公共汽车", "gōnggòng qìchē", "bus"], ["附近", "fùjìn", "à proximité"], ["银行", "yínháng", "banque"], ["马路", "mǎlù", "rue, route"], ["地图", "dìtú", "carte, plan"], ["迟到", "chídào", "être en retard"], ["堵车", "dǔchē", "embouteillage"], ["自行车", "zìxíngchē", "vélo"], ["骑", "qí", "monter (vélo, cheval)"], ["方便", "fāngbiàn", "pratique"], ["司机", "sījī", "chauffeur"]],
    quiz: [
      mcq("« Aller à vélo » :", ["坐自行车", "骑自行车", "开自行车", "走自行车"], 1, "骑 pour le vélo."),
      fill("对不起，我 ___ 了。(en retard)", ["迟到", "chídào", "chidao"], "迟到了."),
      mcq("« Changer pour la ligne 4 » :", ["换四号线", "变四号线", "坐换四号线", "四号线换了"], 0, "换 huàn = changer."),
      mcq("请问，附近有银行吗？ signifie :", ["Où est la banque la plus proche ?", "Y a-t-il une banque près d'ici ?", "La banque est-elle ouverte ?", "Puis-je aller à la banque ?"], 1, "附近 = à proximité."),
      match("Associez", [["堵车|dǔchē", "embouteillage"], ["地图|dìtú", "plan"], ["司机|sījī", "chauffeur"], ["方便|fāngbiàn", "pratique"]]),
      fill("下一 ___ 是北京站。(station)", ["站", "zhàn", "zhan"], "下一站."),
      mcq("我差点儿没赶上飞机 signifie :", ["J'ai raté l'avion", "J'ai failli rater l'avion", "J'ai pris l'avion de justesse… puis raté", "L'avion était en retard"], 1, "差点儿没 = faillir (+ négatif → on a réussi de justesse)."),
      tr("Traduisez : Il y avait des embouteillages.", ["路上堵车", "堵车了", "路上堵车了", "lù shang dǔchē", "du che le"], "堵车."),
    ],
  },

  /* ------------------------------------------------------------ 14 */
  {
    id: "b1-xuexiao", module: "vocab", title: "École et travail : examens, réunions, collègues", emoji: "🏫",
    intro: "Notes, devoirs, révisions, réunions et chef de service : parler de ses études et de son travail avec le vocabulaire du HSK 3.",
    sections: [
      {
        title: "À l'école",
        examples: [["明天有数学考试，我得复习。", "míngtiān yǒu shùxué kǎoshì, wǒ děi fùxí.", "Demain il y a un examen de maths, je dois réviser."], ["她的成绩一直很好。", "tā de chéngjì yìzhí hěn hǎo.", "Ses notes ont toujours été très bonnes."], ["老师让我们认真检查作业。", "lǎoshī ràng wǒmen rènzhēn jiǎnchá zuòyè.", "Le professeur nous a demandé de vérifier sérieusement nos devoirs."], ["我上三年级。", "wǒ shàng sān niánjí.", "Je suis en troisième année."]],
      },
      {
        title: "Au bureau",
        examples: [["经理在办公室开会。", "jīnglǐ zài bàngōngshì kāihuì.", "Le directeur est en réunion dans son bureau."], ["这个问题我已经解决了。", "zhège wèntí wǒ yǐjīng jiějué le.", "J'ai déjà résolu ce problème."], ["同事们都很热情。", "tóngshìmen dōu hěn rèqíng.", "Les collègues sont tous très accueillants."]],
      },
      {
        title: "Projets et efforts",
        examples: [["我打算明年去中国留学。", "wǒ dǎsuàn míngnián qù Zhōngguó liúxué.", "J'ai l'intention d'aller étudier en Chine l'année prochaine."], ["只要努力，你一定能完成。", "zhǐyào nǔlì, nǐ yídìng néng wánchéng.", "Il suffit de faire des efforts, tu y arriveras sûrement."]],
      },
    ],
    mnemo: "得 se lit dé (complément de degré), mais děi quand il veut dire « devoir » : 我得走了 = je dois y aller.",
    vocab: [["复习", "fùxí", "réviser"], ["成绩", "chéngjì", "notes, résultats"], ["认真", "rènzhēn", "sérieux, appliqué"], ["作业", "zuòyè", "devoirs"], ["年级", "niánjí", "année (scolaire)"], ["数学", "shùxué", "mathématiques"], ["经理", "jīnglǐ", "directeur, manager"], ["办公室", "bàngōngshì", "bureau"], ["开会", "kāihuì", "être en réunion"], ["解决", "jiějué", "résoudre"], ["同事", "tóngshì", "collègue"], ["打算", "dǎsuàn", "avoir l'intention de"], ["完成", "wánchéng", "achever"], ["得", "děi", "devoir"]],
    quiz: [
      mcq("« Je dois réviser » :", ["我得复习。", "我得到复习。", "我的复习。", "我地复习。"], 0, "得 děi = devoir."),
      fill("经理在办公室 ___ 。(être en réunion)", ["开会", "kāihuì", "kaihui"], "开会."),
      mcq("« Ses notes sont bonnes » :", ["他的作业很好。", "他的成绩很好。", "他的年级很好。", "他的考试很好。"], 1, "成绩 = résultats."),
      mcq("« J'ai l'intention d'étudier en Chine » :", ["我打算去中国留学。", "我认真去中国留学。", "我解决去中国留学。", "我完成去中国留学。"], 0, "打算 = avoir l'intention."),
      match("Associez", [["同事|tóngshì", "collègue"], ["解决|jiějué", "résoudre"], ["数学|shùxué", "mathématiques"], ["完成|wánchéng", "achever"]]),
      fill("请 ___ 检查一下作业。(sérieusement)", ["认真", "rènzhēn", "renzhen"], "认真."),
      mcq("我上三年级 signifie :", ["Je monte au 3e étage", "Je suis en 3e année", "J'ai trois ans", "J'ai passé trois examens"], 1, "年级 = année scolaire."),
      tr("Traduisez : J'ai déjà résolu ce problème.", ["这个问题我已经解决了", "我已经解决了这个问题", "wǒ yǐjīng jiějué le zhège wèntí"], "已经…了."),
    ],
  },

  /* ------------------------------------------------------------ 15 */
  {
    id: "b1-jijie", module: "vocab", title: "Saisons, nature et météo", emoji: "🍂",
    intro: "Les quatre saisons, le vent, la neige, les montagnes et les rivières : décrire le climat de chez soi et comparer le nord et le sud de la Chine.",
    sections: [
      {
        title: "Les quatre saisons",
        examples: [["北京的冬天很冷，常常刮风。", "Běijīng de dōngtiān hěn lěng, chángcháng guā fēng.", "L'hiver à Pékin est très froid, il y a souvent du vent."], ["我最喜欢秋天，不冷也不热。", "wǒ zuì xǐhuan qiūtiān, bù lěng yě bú rè.", "Je préfère l'automne : ni froid, ni chaud."], ["春天到了，花都开了。", "chūntiān dào le, huā dōu kāi le.", "Le printemps est arrivé, les fleurs sont toutes ouvertes."], ["南方的夏天又热又湿。", "nánfāng de xiàtiān yòu rè yòu shī.", "L'été dans le sud est chaud et humide."]],
      },
      {
        title: "La nature",
        examples: [["山上有很多树和草。", "shān shang yǒu hěn duō shù hé cǎo.", "Sur la montagne, il y a beaucoup d'arbres et d'herbe."], ["这条河很长。", "zhè tiáo hé hěn cháng.", "Ce fleuve est très long."], ["今天晚上的月亮特别亮。", "jīntiān wǎnshang de yuèliang tèbié liàng.", "Ce soir, la lune est particulièrement brillante."]],
      },
      {
        title: "Le temps qu'il fait",
        examples: [["天气预报说明天会下雪。", "tiānqì yùbào shuō míngtiān huì xià xuě.", "La météo dit qu'il va neiger demain."], ["外面刮大风了，多穿点儿衣服。", "wàimiàn guā dà fēng le, duō chuān diǎnr yīfu.", "Il y a beaucoup de vent dehors, couvre-toi bien."], ["这里的环境很好，空气很新鲜。", "zhèlǐ de huánjìng hěn hǎo, kōngqì hěn xīnxiān.", "L'environnement est très bon ici, l'air est très pur."]],
      },
    ],
    mnemo: "春夏秋冬 chūn xià qiū dōng : récitez les saisons dans l'ordre, chacune suivie de 天 tiān.",
    vocab: [["春天", "chūntiān", "printemps"], ["夏天", "xiàtiān", "été"], ["秋天", "qiūtiān", "automne"], ["冬天", "dōngtiān", "hiver"], ["季节", "jìjié", "saison"], ["刮风", "guā fēng", "y avoir du vent"], ["下雪", "xià xuě", "neiger"], ["山", "shān", "montagne"], ["河", "hé", "fleuve, rivière"], ["树", "shù", "arbre"], ["草", "cǎo", "herbe"], ["月亮", "yuèliang", "lune"], ["环境", "huánjìng", "environnement"], ["新鲜", "xīnxiān", "frais"]],
    quiz: [
      mcq("L'ordre des saisons à partir du printemps :", ["春夏秋冬", "夏春冬秋", "冬秋夏春", "春秋夏冬"], 0, "chūn xià qiū dōng."),
      fill("外面 ___ 风了。(il y a du vent)", ["刮", "guā", "gua"], "刮风."),
      mcq("« Il va neiger demain » :", ["明天会下雪。", "明天会刮雪。", "明天下雨雪。", "明天雪下。"], 0, "下雪."),
      mcq("新鲜 qualifie :", ["la fraîcheur (air, fruits)", "la chaleur (temps, plats)", "la vieillesse (objets, gens)", "la saison (été, hiver)"], 0, "新鲜 = frais."),
      match("Associez", [["季节|jìjié", "saison"], ["河|hé", "fleuve"], ["树|shù", "arbre"], ["月亮|yuèliang", "lune"]]),
      fill("我最喜欢 ___ 天。(automne)", ["秋", "qiū", "qiu"], "秋天."),
      mcq("Le classificateur de 河 (rivière) :", ["个", "条", "张", "本"], 1, "条 pour les choses longues."),
      tr("Traduisez : L'hiver est très froid.", ["冬天很冷", "dōngtiān hěn lěng", "dongtian hen leng"], "冬天很冷."),
    ],
  },

  /* ------------------------------------------------------------ 16 */
  {
    id: "b1-qinggan", module: "expr", title: "Sentiments : inquiet, en colère, rassuré", emoji: "💗",
    intro: "Exprimer ses émotions et réagir à celles des autres : s'inquiéter, se fâcher, être satisfait, rassurer quelqu'un.",
    sections: [
      {
        title: "Ce que je ressens",
        examples: [["我很担心明天的考试。", "wǒ hěn dānxīn míngtiān de kǎoshì.", "Je m'inquiète beaucoup pour l'examen de demain."], ["他为什么生气了？", "tā wèishénme shēngqì le?", "Pourquoi s'est-il fâché ?"], ["我害怕一个人走夜路。", "wǒ hàipà yí ge rén zǒu yèlù.", "J'ai peur de marcher seul la nuit."], ["听到这个消息，她很难过。", "tīng dào zhège xiāoxi, tā hěn nánguò.", "En apprenant cette nouvelle, elle était très triste."]],
      },
      {
        title: "Réagir et rassurer",
        examples: [["别着急，慢慢来。", "bié zháojí, mànmàn lái.", "Ne t'énerve pas, prends ton temps."], ["放心吧，没问题。", "fàngxīn ba, méi wèntí.", "Sois tranquille, pas de problème."], ["我相信你一定能做好。", "wǒ xiāngxìn nǐ yídìng néng zuò hǎo.", "Je suis sûr que tu vas y arriver."]],
      },
      {
        title: "Satisfait ou pas",
        examples: [["你对这个结果满意吗？", "nǐ duì zhège jiéguǒ mǎnyì ma?", "Es-tu satisfait de ce résultat ?"], ["谢谢你这么关心我。", "xièxie nǐ zhème guānxīn wǒ.", "Merci de te soucier autant de moi."]],
      },
    ],
    mnemo: "放心 « poser le cœur » = être rassuré ; 担心 « porter le cœur » = s'inquiéter. 心 xīn (cœur) est partout dans les émotions.",
    vocab: [["担心", "dānxīn", "s'inquiéter"], ["害怕", "hàipà", "avoir peur"], ["生气", "shēngqì", "se fâcher"], ["着急", "zháojí", "s'impatienter, s'énerver"], ["难过", "nánguò", "triste"], ["放心", "fàngxīn", "être rassuré"], ["满意", "mǎnyì", "satisfait"], ["关心", "guānxīn", "se soucier de"], ["相信", "xiāngxìn", "croire, avoir confiance"], ["消息", "xiāoxi", "nouvelle"], ["结果", "jiéguǒ", "résultat"], ["一定", "yídìng", "sûrement"]],
    quiz: [
      mcq("Un ami stresse pour un examen. Vous dites :", ["别着急，慢慢来。", "我很生气。", "你很难过。", "我害怕。"], 0, "别着急 = ne t'énerve pas."),
      fill("___ 吧，没问题。(sois rassuré)", ["放心", "fàngxīn", "fangxin"], "放心吧."),
      mcq("« Je m'inquiète pour toi » :", ["我很关心你。", "我很担心你。", "我很放心你。", "我很满意你。"], 1, "担心 = s'inquiéter."),
      mcq("你对结果满意吗？ demande :", ["si on est satisfait", "si on est en colère", "si on a peur", "si on est triste"], 0, "满意 = satisfait."),
      match("Associez", [["生气|shēngqì", "se fâcher"], ["害怕|hàipà", "avoir peur"], ["难过|nánguò", "triste"], ["相信|xiāngxìn", "avoir confiance"]]),
      fill("我 ___ 你一定能做好。(croire)", ["相信", "xiāngxìn", "xiangxin"], "相信."),
      mcq("Le caractère commun à 担心, 放心, 关心 :", ["心 (cœur)", "关 (fermer)", "放 (poser)", "担 (porter)"], 0, "心 xīn."),
      tr("Traduisez : Pourquoi s'est-il fâché ?", ["他为什么生气了", "tā wèishénme shēngqì le", "ta weishenme shengqi le"], "为什么 + 生气了."),
    ],
  },
];

/* Questions supplémentaires de l'examen HSK 3 */
export const HSK3_EXAM_PLUS = [
  mcq("Vous êtes en haut, votre ami est en bas : « Monte ! »", ["你上去吧！", "你上来吧！", "你下来吧！", "你下去吧！"], 1, "Vers vous : 上来."),
  mcq("« C'est en train que je suis venu » :", ["我坐火车来了。", "我是坐火车来的。", "我是坐火车来了。", "我坐火车是来的。"], 1, "是…的 pour la manière."),
  fill("我学中文学了三年 ___ 。(et je continue)", ["了", "le"], "了 final."),
  mcq("« Il fait de plus en plus froid » :", ["越来越很冷", "越来越冷了", "越冷越来了", "更来更冷"], 1, "越来越 + adj."),
  fill("我们 ___ 吃饭，再去看电影。(d'abord)", ["先", "xiān", "xian"], "先…再."),
  mcq("« À part le thé, il boit aussi du café » :", ["除了茶以外，他都喝咖啡。", "除了茶以外，他还喝咖啡。", "只有茶，他才喝咖啡。", "为了茶，他喝咖啡。"], 1, "除了…还 = en plus."),
  mcq("« Même le professeur ne sait pas » :", ["连老师都不知道。", "老师连都不知道。", "连老师不都知道。", "老师都连不知道。"], 0, "连…都."),
  mcq("« J'ai mal à la tête » :", ["我疼头。", "我头疼。", "我头是疼。", "我的疼头。"], 1, "头疼."),
  match("Associez", [["迟到|chídào", "être en retard"], ["复习|fùxí", "réviser"], ["担心|dānxīn", "s'inquiéter"], ["环境|huánjìng", "environnement"]]),
  fill("对不起，路上 ___ 车。(embouteillage)", ["堵", "dǔ", "du"], "堵车."),
  mcq("« Je ne veux aller nulle part » :", ["我哪儿也不想去。", "我不想去哪儿也。", "我也哪儿不想去。", "我哪儿不想去都。"], 0, "哪儿也不."),
  tr("Traduisez : Sois tranquille, pas de problème.", ["放心吧，没问题", "放心吧没问题", "fàngxīn ba, méi wèntí", "fangxin ba mei wenti"], "放心 + 没问题."),
];
