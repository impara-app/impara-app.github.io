/* =====================================================================
   Vue « Carnet de vocabulaire » — liste filtrable + mode flashcards
   ===================================================================== */

import { LEVELS, getLesson, lvlLabel, lvlBadge } from "../data/curriculum.js";
import { state } from "../core/storage.js";
import { esc, speakBtn, speak, shuffle, modal, toast } from "../core/ui.js";
import { commit } from "../core/storage.js";
import { charReading } from "../core/pinyin.js";
import { lookup } from "../core/words.js";
import { L } from "../core/lang.js";
import * as S from "../core/srs.js";
import * as P from "../core/progress.js";
import { haptic } from "../core/fx.js";
import { openWordSheet } from "./word-sheet.js";

// État local de la vue (non persisté : simple confort d'affichage)
const ui = { group: readType("wordGroup", "lesson"), query: "", level: "all", mode: "list", deck: [], pos: 0, flipped: false, cardType: readType("cardType", "hanzi"), study: readType("study", "srs"), dir: readType("cardDir", "target"), deckKey: null, done: 0, pack: "all" };

/* Types de flashcards (mandarin) : on garde le dernier choix */
const CARD_TYPES = [["hanzi", "汉字 + pinyin → sens"], ["pinyin", "Pinyin seul → sens"]];
const isZh = () => L.label === "Mandarin";
const ART_RE = /^(il|lo|la|i|gli|le|l'|un|uno|una|un')\s*/i;
/** Mandarin : le pinyin est TOUJOURS affiché (calculé caractère par caractère s'il manque) */
const pyOf = (w) => (isZh() ? w.py || [...w.zh].map((c) => charReading(c) || "").filter(Boolean).join(" ") : w.py || "");
function readType(k, def) { try { return localStorage.getItem("impara." + k) || def; } catch { return def; } }
function saveType(t, study) { try { localStorage.setItem("impara.cardType", t); localStorage.setItem("impara.study", study); } catch {} }

/** Ouvre directement la révision du jour (lien « mots à réviser ») */
export function openReview() { ui.mode = "cards"; ui.study = "srs"; ui.deckKey = null; }

export function renderCarnet(app) {
  const all = Object.values(state.vocab).sort((a, b) => b.added - a.added);

  const lvlName = (id) => (id === "all" ? "Tous les paliers" : lvlLabel(id));
  app.innerHTML = `
  <section class="carnet ${ui.mode === "cards" ? "cards-mode" : ""}">
  <a class="back-link" href="#entrainement">← Entraînement</a>
  <header class="page-head">
    <p class="eyebrow">Mes mots</p>
    <h1>📒 ${all.length} mot${all.length > 1 ? "s" : ""} et expressions</h1>
    <p class="muted carnet-sub">La liste de tous vos mots et leurs flashcards. Chaque leçon réussie en ajoute de nouveaux.</p>
    <button type="button" class="btn ghost small add-word" data-add-word>＋ Ajouter un mot à moi</button>
  </header>
  ${all.length ? `
  <div class="toolbar carnet-bar">
    <div class="seg" role="group" aria-label="Mode d'affichage">
      <button class="${ui.mode === "list" ? "on" : ""}" data-mode="list">Liste</button>
      <button class="${ui.mode === "cards" ? "on" : ""}" data-mode="cards">Flashcards</button>
    </div>
    <div class="lvl-drop">
      <button type="button" class="chip-btn lvl-btn" aria-haspopup="menu" aria-expanded="false">${esc(lvlName(ui.level))} <span aria-hidden="true">▾</span></button>
      <div class="lvl-menu" role="menu" hidden>
        ${["all", ...LEVELS.map((l) => l.id)].map((id) => `<button type="button" role="menuitemradio" aria-checked="${ui.level === id}" class="${ui.level === id ? "on" : ""} ${id !== "all" && !all.some((w) => w.levelId === id) ? "empty" : ""}" data-level="${id}">${esc(lvlName(id))}<span class="n">${id === "all" ? all.length : all.filter((w) => w.levelId === id).length}</span></button>`).join("")}
      </div>
    </div>
    <input type="search" class="search" placeholder="${esc(L.search)}" value="${esc(ui.query)}" aria-label="Rechercher">
  </div>
  <div class="carnet-body"></div>`
  : `<div class="empty-state"><span>📭</span><p>Vous n'avez encore aucun mot.</p><a class="btn primary" href="#parcours">Commencer une leçon</a></div>`}
  </section>`;

  app.querySelector("[data-add-word]")?.addEventListener("click", () => addWord(app));
  if (!all.length) return;

  const body = app.querySelector(".carnet-body");
  const filtered = () => all.filter((w) =>
    (ui.level === "all" || w.levelId === ui.level) &&
    (!ui.query || (w.zh + " " + (w.py || "") + " " + (w.py || "").normalize("NFD").replace(/[\u0300-\u036f]/g, "") + " " + w.fr).toLowerCase().includes(ui.query.toLowerCase())));

  function draw() {
    const list = filtered();
    if (ui.mode === "list") {
      const row = (w) => `
        <li data-open="${esc(w.zh)}" tabindex="0" role="button" aria-label="Détails de « ${esc(w.zh)} »">${speakBtn(w.zh)}
          <span class="it"><span class="${L.wordClass}">${esc(w.zh)}</span>${pyOf(w) ? ` <span class="py">${esc(pyOf(w))}</span>` : ""}</span>
          <span class="fr">${esc(w.fr)}</span>
          ${w.from === "perso" ? `<span class="tag perso" title="Ajouté par vous${w.note ? " · " + esc(w.note) : ""}">Perso</span><button type="button" class="icon-btn del-word" data-del="${esc(w.zh)}" aria-label="Supprimer « ${esc(w.zh)} »">✕</button>`
            : `<span class="tag" style="--lvl:${LEVELS.find((l) => l.id === w.levelId)?.color}" title="${esc(getLesson(w.lessonId)?.title || "")}">${lvlLabel(w.levelId)}</span>`}
          <span class="wl-more" aria-hidden="true">›</span>
        </li>`;
      const groupBar = `<div class="seg wl-group" role="group" aria-label="Classer les mots">
        ${[["lesson", "Par thème"], ["recent", "Récents"], ["az", "A → Z"]].map(([k, t]) => `<button class="${ui.group === k ? "on" : ""}" data-group="${k}">${t}</button>`).join("")}</div>`;
      let html = "";
      if (!list.length) html = `<p class="empty">Aucun résultat.</p>`;
      else if (ui.group === "lesson") {
        // Un groupe par leçon (nombres, jours, couleurs… restent ensemble, dans l'ordre de la leçon)
        const order = new Map(); let n = 0;
        LEVELS.forEach((lv) => lv.lessons.forEach((l) => order.set(l.id, n++)));
        const groups = new Map();
        list.forEach((w) => { const k = w.from === "perso" ? "~perso" : w.lessonId && order.has(w.lessonId) ? w.lessonId : "~autres"; (groups.get(k) || groups.set(k, []).get(k)).push(w); });
        const keys = [...groups.keys()].sort((a, b) => (a === "~perso" ? -1 : b === "~perso" ? 1 : a === "~autres" ? 1 : b === "~autres" ? -1 : order.get(a) - order.get(b)));
        html = keys.map((k) => {
          const ws = groups.get(k), l = getLesson(k);
          if (l) { const idx = new Map((l.vocab || []).map((v, i) => [v[0], i])); ws.sort((a, b) => (idx.get(a.zh) ?? 999) - (idx.get(b.zh) ?? 999)); }
          const title = k === "~perso" ? "✍️ Mes ajouts" : k === "~autres" ? "📖 Ajoutés en lisant" : `${l.emoji || "📘"} ${esc(l.title)}`;
          return `<section class="wl-sec"><h3 class="wl-h">${title}<span class="n">${ws.length}</span>${l ? `<small>${lvlLabel(l.levelId)}</small>` : ""}</h3><ul class="word-list">${ws.map(row).join("")}</ul></section>`;
        }).join("");
      } else {
        const sorted = ui.group === "az" ? [...list].sort((a, b) => (isZh() ? pyOf(a) : a.zh).replace(ART_RE, "").localeCompare((isZh() ? pyOf(b) : b.zh).replace(ART_RE, ""), "it")) : list;
        html = `<ul class="word-list">${sorted.map(row).join("")}</ul>`;
      }
      body.innerHTML = groupBar + html;
      body.querySelectorAll("[data-group]").forEach((b) => (b.onclick = () => { ui.group = b.dataset.group; try { localStorage.setItem("impara.wordGroup", ui.group); } catch {} draw(); }));
    } else {
      drawCards(list);
    }
  }

  /* ----------------------------- Flashcards ---------------------------- */
  /* Paquets : tous les mots, mes ajouts, mots fragiles ou une seule leçon */
  const fragile = (w) => { const c = state.srs?.[w.zh]; return !!c && (c.lapses > 0 || ((c.box || 0) <= 1 && c.last)); };
  const PACKS = () => {
    const out = [["all", "Tous les mots", all.length], ["perso", "✍️ Mes ajouts", all.filter((w) => w.from === "perso").length], ["fragile", "⚠️ Mots fragiles", all.filter(fragile).length]];
    const byLesson = new Map();
    all.forEach((w) => { if (w.lessonId) byLesson.set(w.lessonId, (byLesson.get(w.lessonId) || 0) + 1); });
    const lessons = LEVELS.flatMap((lv) => lv.lessons.filter((l) => byLesson.has(l.id)).map((l) => [`lesson:${l.id}`, `${lvlLabel(lv)} · ${l.title}`, byLesson.get(l.id)]));
    return { main: out, lessons };
  };
  const inPack = (w) => ui.pack === "all" || (ui.pack === "perso" ? w.from === "perso" : ui.pack === "fragile" ? fragile(w) : w.lessonId === ui.pack.slice(7));
  function packSelect() {
    const { main, lessons } = PACKS();
    if (ui.pack !== "all" && ![...main, ...lessons].some(([k]) => k === ui.pack)) ui.pack = "all";
    const o = ([k, label, n]) => `<option value="${esc(k)}" ${ui.pack === k ? "selected" : ""} ${n || k === "all" ? "" : "disabled"}>${esc(label)} (${n})</option>`;
    return `<label class="flash-pack"><span>📦 Paquet</span><select aria-label="Paquet de flashcards">${main.map(o).join("")}${lessons.length ? `<optgroup label="Une seule leçon">${lessons.map(o).join("")}</optgroup>` : ""}</select></label>`;
  }

  function drawCards(list) {
    list = list.filter(inPack);
    const hasPinyin = isZh();
    const pinyinMode = hasPinyin && ui.cardType === "pinyin";
    const pool = pinyinMode ? list.filter((w) => pyOf(w)) : list;
    const srs = ui.study === "srs";
    const st = S.srsStats(pool);
    const source = srs ? S.dueWords(pool) : pool;
    const key = `${ui.study}|${ui.cardType}|${ui.level}|${ui.query}|${ui.pack}`;
    if (ui.deckKey !== key || (!srs && ui.deck.some((w) => !pool.includes(w)))) {
      ui.deckKey = key;
      // Révision : d'abord les mots déjà vus et dus, puis les nouveaux (20 max par séance)
      ui.deck = srs ? [...shuffle(source.filter((w) => !S.isNew(w))), ...shuffle(source.filter(S.isNew)).slice(0, 20)] : shuffle(pool);
      ui.pos = 0; ui.flipped = false; ui.done = 0; ui.known = 0; ui.missed = 0;
    }
    const w = ui.deck[ui.pos];

    const studySwitch = packSelect() + `<div class="seg flash-study" role="group" aria-label="Mode de révision">
        <button class="${srs ? "on" : ""}" data-study="srs">📅 Révision du jour${st.todo ? ` <span class="count-pill">${st.todo}</span>` : ""}</button>
        <button class="${!srs ? "on" : ""}" data-study="free">🔀 Libre</button></div>`;
    const lang = L.label;
    const dirSwitch = `<div class="seg card-dir" role="group" aria-label="Sens des cartes">
        <button class="${ui.dir !== "fr" ? "on" : ""}" data-dir="target">${esc(lang)} → Français</button>
        <button class="${ui.dir === "fr" ? "on" : ""}" data-dir="fr">Français → ${esc(lang)}</button></div>`;
    const typeSwitch = dirSwitch + (hasPinyin && ui.dir !== "fr" ? `<div class="seg card-type" role="group" aria-label="Type de flashcard">
        ${CARD_TYPES.map(([t, label]) => `<button class="${ui.cardType === t ? "on" : ""}" data-type="${t}">${label}</button>`).join("")}</div>` : "");
    // Réglages des cartes : repliés sous la carte pour qu'elle reste l'élément principal
    const options = `<details class="flash-opts"${ui.optsOpen ? " open" : ""}><summary>⚙️ Sens des cartes</summary><div class="flash-opts-in">${typeSwitch}</div></details>`;
    const statsLine = `<p class="srs-stats small muted">🆕 ${st.fresh} nouveau${st.fresh > 1 ? "x" : ""} · 🔁 ${st.due} à revoir · ✅ ${st.known} bien connu${st.known > 1 ? "s" : ""}</p>`;

    if (!w) {
      const free = !srs && pool.length;
      body.innerHTML = `<div class="flash-wrap">${studySwitch}
        <div class="card srs-done"><span class="big-emoji">🎉</span>
          <h2>${srs ? (ui.pack === "all" ? "Révision du jour terminée !" : "Rien à réviser dans ce paquet aujourd'hui") : free ? "Paquet terminé !" : "Aucun mot pour ce filtre."}</h2>
          ${srs ? `<p class="muted">${ui.done ? `${ui.done} carte${ui.done > 1 ? "s" : ""} révisée${ui.done > 1 ? "s" : ""}. ` : ""}Revenez demain : les mots reviendront au bon moment.</p>
          <button class="btn ghost" data-study="free">🔀 Continuer en mode libre</button>` : ""}
          ${free ? `<p class="muted">✅ ${ui.known || 0} su${(ui.known || 0) > 1 ? "s" : ""} du premier coup · 🔁 ${ui.missed || 0} revu${(ui.missed || 0) > 1 ? "s" : ""}</p>
          <button class="btn primary" data-restart>🔀 Recommencer</button>` : ""}
        </div>${options}${srs ? statsLine : ""}</div>`;
      body.querySelector("[data-restart]")?.addEventListener("click", () => { ui.deckKey = null; draw(); });
      bindCardControls(pool);
      return;
    }

    const toFr = ui.dir !== "fr"; // sens : langue étudiée → français (par défaut) ou français → langue étudiée
    const facesOf = (w) => { const py = pyOf(w); return !toFr
      ? `<span class="face front"><small>Français</small><b>${esc(String(w.fr).split(" — ")[0])}</b><em>Comment dit-on en ${esc(L.label.toLowerCase())} ?</em></span>
         <span class="face back"><small>${esc(L.cardFront)}</small><b class="${L.wordClass ? L.wordClass + " big-zh" : ""}">${esc(w.zh)}</b>${py ? `<em class="big-py small-py">${esc(py)}</em>` : `<em>${esc(w.fr)}</em>`}</span>`
      : pinyinMode
      ? `<span class="face front"><small>Pinyin</small><b class="big-py">${esc(py)}</b><em>Touchez pour voir la traduction</em></span>
         <span class="face back"><small>${esc(py)}</small><b>${esc(w.fr)}</b><em class="${L.wordClass}">${esc(w.zh)}</em></span>`
      : `<span class="face front"><small>${esc(L.cardFront)}</small><b class="${L.wordClass ? L.wordClass + " big-zh" : ""}">${esc(w.zh)}</b>${py ? `<em class="big-py small-py">${esc(py)}</em>` : `<em>${esc(L.cardHint)}</em>`}</span>
         <span class="face back"><small>${esc(py || "Français")}</small><b>${esc(w.fr)}</b><em class="${L.wordClass}">${esc(w.zh)}</em></span>`; };
    const faces = facesOf(w);
    // Carte suivante, déjà prête derrière : elle avance quand la carte du dessus s'envole
    const nextW = ui.deck.length > 1 ? ui.deck[(ui.pos + 1) % ui.deck.length] : null;
    const pv = S.preview(w);
    const controls = srs && ui.flipped
      ? `<div class="grade-row">
          <button class="btn grade again" data-grade="again">😕 À revoir<small>${pv.again}</small></button>
          <button class="btn grade hard" data-grade="hard">🤔 Difficile<small>${pv.hard}</small></button>
          <button class="btn grade good" data-grade="good">😄 Je savais<small>${pv.good}</small></button></div>`
      : `<div class="swipe-row">
          <button class="btn swipe-btn no" data-grade="again" aria-label="Je ne savais pas">✕</button>
          <span class="swipe-hint">← Je ne sais pas · Je sais →</span>
          <button class="btn swipe-btn yes" data-grade="good" aria-label="Je savais">✓</button></div>`;

    body.innerHTML = `
      <div class="flash-wrap">
        ${studySwitch}
        <p class="flash-count">${srs && S.isNew(w) ? `<span class="chip new-chip">🆕 Nouveau mot</span>` : ""}<span>${ui.pos + 1} / ${ui.deck.length}</span></p>
        <div class="flash-stage">
          ${nextW && nextW !== w ? `<div class="flashcard ghost" aria-hidden="true">${facesOf(nextW)}</div>` : ""}
          <button class="flashcard top ${ui.flipped ? "flipped" : ""} ${ui.enter ? "enter" : ""}" aria-label="Retourner la carte">${faces}
            <span class="swipe-tag yes" aria-hidden="true">Je sais ✓</span><span class="swipe-tag no" aria-hidden="true">✕ À revoir</span></button>
        </div>
        ${controls}
        ${options}
        ${srs ? statsLine : `<button class="btn ghost small" data-shuffle>🔀 Mélanger</button>`}
      </div>`;

    const card = body.querySelector(".flashcard.top"), ghost = body.querySelector(".flashcard.ghost");
    ui.enter = false;
    const flip = () => {
      ui.flipped = !ui.flipped;
      card.classList.toggle("flipped", ui.flipped);
      if (ui.flipped) speak(w.zh);
      if (srs) setTimeout(draw, 420);   // affiche les 3 boutons de notation
    };
    // Réponse : « good » (je sais) ou « again » (à revoir), au glissement ou aux boutons.
    // L'affichage passe d'abord à la carte suivante ; l'enregistrement (plus lourd) suit juste après.
    let busy = false;
    const answer = (g) => {
      ui.deck.splice(ui.pos, 1);
      if (g === "again") ui.deck.push(w);            // revient en fin de paquet
      if (ui.pos >= ui.deck.length) ui.pos = 0;
      if (srs) ui.done++;
      else if (g === "good") ui.known = (ui.known || 0) + 1;
      else ui.missed = (ui.missed || 0) + 1;
      ui.flipped = false; ui.enter = !ghost; draw();
      if (srs) setTimeout(() => {
        S.grade(w, g);
        if (g === "good") P.recordPractice({ label: "Flashcards", score: 1, total: 0, xpPer: 2, key: `flash:${w.zh}` });
      }, 30);
    };
    const fly = (g, vx = 0) => {
      if (busy) return; busy = true;
      haptic(g === "good" ? 12 : [10, 30, 10]);
      const dir = g === "good" ? 1 : -1, from = dx;
      const dist = innerWidth * 1.1 - Math.abs(from);
      const dur = Math.max(160, Math.min(320, dist / Math.max(1.4, Math.abs(vx))));  // plus le geste est vif, plus la carte part vite
      card.style.transition = `transform ${dur}ms cubic-bezier(.2,.6,.35,1), opacity ${dur}ms ease`;
      card.style.transform = `translateX(${dir * innerWidth * 1.1}px) rotate(${dir * 22}deg)`;
      card.style.opacity = "0";
      ghost?.classList.add("promote");
      setTimeout(() => answer(g), dur);
    };

    /* Glisser la carte : à droite = je sais, à gauche = à revoir */
    let x0 = null, y0 = 0, dx = 0, moved = false, pid = null, raf = 0, lastX = 0, lastT = 0, vx = 0;
    const paint = () => {
      raf = 0;
      card.style.transform = `translate3d(${dx}px,0,0) rotate(${dx / 18}deg)`;
      const r = Math.max(-1, Math.min(1, dx / 110));
      card.style.setProperty("--yes", Math.max(0, r)); card.style.setProperty("--no", Math.max(0, -r));
      if (ghost) ghost.style.setProperty("--p", Math.min(1, Math.abs(dx) / 140));
    };
    card.addEventListener("pointerdown", (e) => { if (busy) return; x0 = e.clientX; y0 = e.clientY; dx = 0; moved = false; pid = e.pointerId; lastX = x0; lastT = e.timeStamp; vx = 0; });
    card.addEventListener("pointermove", (e) => {
      if (x0 == null || e.pointerId !== pid) return;
      dx = e.clientX - x0;
      const dt = e.timeStamp - lastT; if (dt > 0) { vx = 0.7 * vx + 0.3 * ((e.clientX - lastX) / dt); lastX = e.clientX; lastT = e.timeStamp; }
      if (!moved && Math.abs(dx) > 8 && Math.abs(dx) > Math.abs(e.clientY - y0)) { moved = true; card.setPointerCapture?.(pid); card.classList.add("dragging"); }
      if (moved && !raf) raf = requestAnimationFrame(paint);
    });
    const end = () => {
      if (x0 == null) return;
      x0 = null; cancelAnimationFrame(raf); raf = 0; card.classList.remove("dragging");
      // On garde la carte si on l'a lancée assez loin, ou d'un petit geste rapide
      if (moved && (Math.abs(dx) > 90 || (Math.abs(vx) > 0.6 && Math.abs(dx) > 30))) { fly(dx > 0 ? "good" : "again", vx); return; }
      card.style.transform = ""; dx = 0;
      card.style.setProperty("--yes", 0); card.style.setProperty("--no", 0);
      ghost?.style.setProperty("--p", 0);
    };
    card.addEventListener("pointerup", end);
    card.addEventListener("pointercancel", end);
    card.addEventListener("click", (e) => { if (moved) { e.preventDefault(); moved = false; return; } flip(); });
    body.querySelectorAll("[data-grade]").forEach((b) => (b.onclick = () => {
      const g = b.dataset.grade;
      if (g === "hard") { S.grade(w, "hard"); ui.done++; ui.deck.splice(ui.pos, 1); if (ui.pos >= ui.deck.length) ui.pos = 0; ui.flipped = false; draw(); return; }
      dx = 0; fly(g, 2);
    }));
    body.querySelector("[data-shuffle]")?.addEventListener("click", () => { ui.deck = shuffle(pool); ui.pos = 0; ui.flipped = false; ui.known = ui.missed = 0; draw(); });
    body.querySelector(".flash-opts")?.addEventListener("toggle", (e) => { ui.optsOpen = e.target.open; });
    bindCardControls(pool);
  }

  function bindCardControls() {
    const sel = body.querySelector(".flash-pack select");
    if (sel) sel.onchange = () => { ui.pack = sel.value; ui.deckKey = null; ui.flipped = false; draw(); };
    body.querySelectorAll("[data-study]").forEach((b) => (b.onclick = () => {
      if (ui.study === b.dataset.study) return;
      ui.study = b.dataset.study; saveType(ui.cardType, ui.study); ui.deckKey = null; draw();
    }));
    body.querySelectorAll("[data-dir]").forEach((b) => (b.onclick = () => {
      if (ui.dir === b.dataset.dir) return;
      ui.dir = b.dataset.dir; try { localStorage.setItem("impara.cardDir", ui.dir); } catch {}
      ui.flipped = false; draw();
    }));
    body.querySelectorAll("[data-type]").forEach((b) => (b.onclick = () => {
      if (ui.cardType === b.dataset.type) return;
      ui.cardType = b.dataset.type; saveType(ui.cardType, ui.study); ui.deckKey = null; draw();
    }));
  }

  body.addEventListener("keydown", (e) => { if ((e.key === "Enter" || e.key === " ") && e.target.matches("[data-open]")) { e.preventDefault(); openWordSheet(state.vocab[e.target.dataset.open]); } });
  body.addEventListener("click", async (e) => {
    const b = e.target.closest("[data-del]");
    if (!b) {
      const o = e.target.closest("[data-open]");
      if (o && !e.target.closest(".speak, .speak-pair") && state.vocab[o.dataset.open]) openWordSheet(state.vocab[o.dataset.open]);
      return;
    }
    const k = b.dataset.del;
    const v = await modal({ title: "Supprimer ce mot ?", body: `<p>« ${esc(k)} » sera retiré de vos mots.</p>`, actions: [{ label: "Annuler", value: "" }, { label: "Supprimer", value: "del", kind: "primary" }] });
    if (v !== "del") return;
    commit((s) => { delete s.vocab[k]; if (s.srs) delete s.srs[k]; });
    renderCarnet(app);
  });
  app.querySelector(".search").oninput = (e) => { ui.query = e.target.value; draw(); };
  // Choix du palier : un seul bouton qui ouvre un petit menu
  const lb = app.querySelector(".lvl-btn"), lm = app.querySelector(".lvl-menu");
  const openMenu = (v) => { lm.hidden = !v; lb.setAttribute("aria-expanded", String(v)); };
  lb.onclick = (e) => { e.stopPropagation(); openMenu(lm.hidden); };
  const outside = (e) => { if (!lm.hidden && !e.target.closest(".lvl-drop")) openMenu(false); };
  document.addEventListener("click", outside);
  app._cleanup = () => document.removeEventListener("click", outside);
  lm.querySelectorAll("[data-level]").forEach((b) => (b.onclick = () => {
    ui.level = b.dataset.level;
    lm.querySelectorAll("[data-level]").forEach((x) => { x.classList.toggle("on", x === b); x.setAttribute("aria-checked", x === b); });
    lb.innerHTML = `${esc(lvlName(ui.level))} <span aria-hidden="true">▾</span>`;
    lb.classList.toggle("on", ui.level !== "all");
    openMenu(false); draw();
  }));
  lb.classList.toggle("on", ui.level !== "all");
  app.querySelectorAll("[data-mode]").forEach((b) => (b.onclick = () => {
    ui.mode = b.dataset.mode; ui.flipped = false;
    app.querySelector(".carnet").classList.toggle("cards-mode", ui.mode === "cards");
    app.querySelectorAll("[data-mode]").forEach((x) => x.classList.toggle("on", x === b)); draw();
  }));
  draw();
}

/* ---------------- Mots personnels : vu dans un film, en voyage… ---------------- */
async function addWord(app) {
  const zh = L.code === "zh";
  let word = "", fr = "", py = "", note = "";
  const v = await modal({
    title: "＋ Ajouter un mot",
    body: `<label class="field"><span>${zh ? "Mot en chinois (caractères)" : "Mot ou expression en italien"}</span><input class="aw-w" maxlength="40" autocomplete="off" autocapitalize="off" spellcheck="false" placeholder="${zh ? "ex. 电影" : "ex. il biglietto"}"></label>
      ${zh ? `<label class="field"><span>Pinyin <small class="muted">(rempli automatiquement, modifiable)</small></span><input class="aw-py" maxlength="60" autocomplete="off" autocapitalize="off" spellcheck="false" placeholder="ex. diànyǐng"></label>` : ""}
      <label class="field"><span>Traduction en français</span><input class="aw-fr" maxlength="60" autocomplete="off" placeholder="ex. le billet"></label>
      <label class="field"><span>Où l'avez-vous vu ? <small class="muted">(facultatif)</small></span><input class="aw-n" maxlength="60" autocomplete="off" placeholder="ex. un film, un voyage à Rome"></label>
      <p class="aw-hint small muted"></p>`,
    actions: [{ label: "Annuler", value: "" }, { label: "Ajouter", value: "add", kind: "primary" }],
    onOpen: (root) => {
      const $ = (s) => root.querySelector(s), btn = root.querySelector('[data-value="add"]');
      const sync = () => { btn.disabled = !(word && fr); };
      $(".aw-w").oninput = (e) => {
        word = e.target.value.trim();
        const known = lookup(word);
        if (known && !fr) { $(".aw-fr").value = fr = known.fr; }
        if (zh && $(".aw-py") && !$(".aw-py").dataset.edited) $(".aw-py").value = py = known?.py || [...word].map((c) => charReading(c) || "").filter(Boolean).join(" ");
        $(".aw-hint").textContent = state.vocab[word] ? "Ce mot est déjà dans vos mots." : known ? "Mot connu du cours : la traduction est proposée." : "";
        sync();
      };
      $(".aw-py")?.addEventListener("input", (e) => { py = e.target.value.trim(); e.target.dataset.edited = "1"; });
      $(".aw-fr").oninput = (e) => { fr = e.target.value.trim(); sync(); };
      $(".aw-n").oninput = (e) => { note = e.target.value.trim(); };
      sync(); setTimeout(() => $(".aw-w").focus(), 50);
    },
  });
  if (v !== "add" || !word || !fr) return;
  commit((s) => { s.vocab[word] = { zh: word, py: zh ? py : "", fr, levelId: P.currentLevel().id, lessonId: null, added: Date.now(), from: "perso", note }; });
  toast(`« ${word} » ajouté à vos mots ✓`, "ok");
  speak(word, { force: true });
  renderCarnet(app);
}
