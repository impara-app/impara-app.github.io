/* =====================================================================
   Vue « Compte » — connexion, inscription, synchronisation
   ===================================================================== */

import { state } from "../core/storage.js";
import { L } from "../core/lang.js";
import { esc, toast, modal } from "../core/ui.js";
import * as C from "../core/cloud.js";

let mode = "login"; // login | signup | forgot

const STATUS = {
  off: ["⚪", "Mode local"],
  guest: ["⚪", "Non connecté"],
  syncing: ["🔄", "Synchronisation…"],
  synced: ["✅", "Synchronisé"],
  offline: ["📴", "Hors ligne — les changements partiront au retour du réseau"],
  error: ["⚠️", "Problème de synchronisation"],
};

export function renderCompte(app) {
  const i = C.cloudInfo();

  // ---- Site non relié à un serveur
  if (!C.isConfigured()) {
    app.innerHTML = `
    <header class="page-head"><p class="eyebrow">Compte</p><h1>☁️ Comptes et synchronisation</h1></header>
    <section class="card account-card">
      <p>Ce site fonctionne en <b>mode local</b> : la progression est enregistrée dans ce navigateur uniquement.</p>
      <p class="muted small">Pour activer les comptes (une sauvegarde en ligne par personne, sur tous ses appareils), l'administrateur du site doit renseigner <code>js/config.js</code> avec les clés de son projet Supabase — voir <code>GUIDE-MISE-EN-LIGNE.md</code>.</p>
      <a class="btn ghost" href="#${state.profile ? "reglages" : "parcours"}">← Retour</a>
    </section>`;
    return;
  }

  // ---- Lien « mot de passe oublié » : choisir un nouveau mot de passe
  if (i.recovery) {
    app.innerHTML = `
    <header class="page-head"><p class="eyebrow">Compte</p><h1>🔑 Nouveau mot de passe</h1></header>
    <form class="card account-card auth-form" data-form="recovery">
      <label class="field"><span>Nouveau mot de passe</span><input name="password" type="password" minlength="6" required autocomplete="new-password"></label>
      <p class="form-msg" role="alert"></p>
      <button class="btn primary big" type="submit">Enregistrer</button>
    </form>`;
    bindForm(app, async (f) => { await C.updatePassword(f.password.value); toast("Mot de passe modifié ✓", "ok"); location.hash = "parcours"; });
    return;
  }

  // ---- Connecté
  if (i.user) {
    const [icon, label] = STATUS[i.status] || STATUS.synced;
    app.innerHTML = `
    <header class="page-head"><p class="eyebrow">Compte</p><h1>☁️ Mon compte</h1></header>
    <section class="card account-card">
      <div class="acc-row"><span class="acc-avatar">${esc(state.profile?.avatar || "👤")}</span>
        <div><b>${esc(state.profile?.pseudo || "")}</b><p class="muted small">${esc(i.user.email)}</p></div></div>
      <div class="sync-box sync-${i.status}">
        <span class="sync-icon">${icon}</span>
        <div><b>${label}</b>
          <p class="small muted">${i.lastSync ? `Dernière synchronisation : ${new Date(i.lastSync).toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" })}` : ""}
          ${i.message ? `<br>${esc(i.message)}` : ""}</p></div>
      </div>
      <p class="small muted">Votre progression en <b>${L.label.toLowerCase()}</b> est sauvegardée en ligne et vous suit sur tous vos appareils : connectez-vous avec le même e-mail.
      Chaque langue a sa propre sauvegarde ; votre profil est partagé.</p>
      <div class="btn-row">
        <button class="btn ghost" data-sync>🔄 Synchroniser maintenant</button>
        <button class="btn danger" data-logout>Se déconnecter</button>
      </div>
    </section>`;
    app.querySelector("[data-sync]").onclick = async () => { await C.syncNow(); toast(C.cloudInfo().status === "synced" ? "Synchronisé ✓" : C.cloudInfo().message, C.cloudInfo().status === "synced" ? "ok" : "warn"); };
    app.querySelector("[data-logout]").onclick = async () => {
      const v = await modal({
        title: "Se déconnecter ?",
        body: "<p>Votre progression est sauvegardée en ligne. Elle sera retirée de cet appareil et vous la retrouverez en vous reconnectant.</p>",
        actions: [{ label: "Annuler", value: "no" }, { label: "Se déconnecter", value: "yes", kind: "danger" }],
      });
      if (v === "yes") { await C.signOut(); toast("Déconnecté", "ok"); location.hash = "parcours"; window.dispatchEvent(new HashChangeEvent("hashchange")); }
    };
    return;
  }

  // ---- Déconnecté : connexion / inscription / mot de passe oublié
  const guestProgress = Object.keys(state.lessons).length;
  app.innerHTML = `
  <header class="page-head">
    <p class="eyebrow">Compte</p>
    <h1>☁️ ${mode === "signup" ? "Créer mon compte" : mode === "forgot" ? "Mot de passe oublié" : "Se connecter"}</h1>
    <p class="muted">Un compte gratuit sauvegarde votre progression en ligne et la retrouve sur tous vos appareils.</p>
  </header>
  <form class="card account-card auth-form" data-form="${mode}">
    ${mode !== "forgot" ? `<div class="seg wide">
      <button type="button" data-mode="login" class="${mode === "login" ? "on" : ""}">Connexion</button>
      <button type="button" data-mode="signup" class="${mode === "signup" ? "on" : ""}">Inscription</button>
    </div>` : ""}
    <label class="field"><span>E-mail</span><input name="email" type="email" required autocomplete="email" placeholder="vous@exemple.com"></label>
    ${mode !== "forgot" ? `<label class="field"><span>Mot de passe</span>
      <input name="password" type="password" minlength="6" required autocomplete="${mode === "signup" ? "new-password" : "current-password"}" placeholder="6 caractères minimum"></label>` : ""}
    ${mode === "signup" && guestProgress ? `<p class="small hint-ok">✓ Votre progression actuelle (${guestProgress} leçon${guestProgress > 1 ? "s" : ""}) sera rattachée à votre nouveau compte.</p>` : ""}
    <p class="form-msg" role="alert"></p>
    <button class="btn primary big" type="submit">${mode === "signup" ? "Créer mon compte" : mode === "forgot" ? "Recevoir le lien" : "Se connecter"}</button>
    <p class="small center">
      ${mode === "login" ? `<a href="#compte" data-mode="forgot">Mot de passe oublié ?</a>` : `<a href="#compte" data-mode="login">← Retour à la connexion</a>`}
    </p>
    ${!state.profile ? `<p class="small center"><a href="#parcours">Continuer sans compte</a></p>` : ""}
  </form>`;

  app.querySelectorAll("[data-mode]").forEach((b) => (b.onclick = (e) => { e.preventDefault(); mode = b.dataset.mode; renderCompte(app); }));
  bindForm(app, async (f) => {
    const email = f.email.value.trim();
    if (mode === "forgot") {
      await C.resetPassword(email);
      return "📧 Si un compte existe, un lien de réinitialisation vient d'être envoyé.";
    }
    if (mode === "signup") {
      const r = await C.signUp(email, f.password.value);
      if (r.needsConfirmation) return "📧 Compte créé ! Cliquez sur le lien de confirmation reçu par e-mail, puis connectez-vous.";
    } else {
      await C.signIn(email, f.password.value);
    }
    toast("Connecté ✓", "ok");
    mode = "login";
    location.hash = state.profile ? "tableau" : "parcours";
    window.dispatchEvent(new HashChangeEvent("hashchange"));
  });
}

/** Gestion commune des formulaires : bouton occupé, messages d'erreur */
function bindForm(app, handler) {
  const form = app.querySelector("form[data-form]");
  const msg = form.querySelector(".form-msg");
  const btn = form.querySelector("button[type=submit]");
  form.onsubmit = async (e) => {
    e.preventDefault();
    msg.className = "form-msg"; msg.textContent = "";
    btn.disabled = true; const label = btn.textContent; btn.textContent = "Patientez…";
    try {
      const info = await handler(form);
      if (info) { msg.className = "form-msg ok"; msg.textContent = info; }
    } catch (err) {
      msg.className = "form-msg error"; msg.textContent = err.message || String(err);
    } finally {
      btn.disabled = false; btn.textContent = label;
    }
  };
  setTimeout(() => form.querySelector("input")?.focus(), 50);
}
