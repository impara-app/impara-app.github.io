/* =====================================================================
   Vue « Tableau de bord » — statistiques et suivi
   ===================================================================== */

import { LEVELS, ALL_LESSONS, lvlLabel, lvlBadge } from "../data/curriculum.js";
import { state } from "../core/storage.js";
import * as P from "../core/progress.js";
import { pyText } from "../core/pinyin.js";
import { esc, ring } from "../core/ui.js";
import { L } from "../core/lang.js";
import { getLesson, refLabel } from "../data/curriculum.js";
import { cardOf, MAX_BOX } from "../core/srs.js";

/* ------------------------- Jours et journal d'XP ------------------------- */
const dk = (d) => P.dayKey(d);
const xpOn = (key) => state.dayLog?.[key] || 0;
const MONTHS = ["janv.", "févr.", "mars", "avr.", "mai", "juin", "juil.", "août", "sept.", "oct.", "nov.", "déc."];

/** Calendrier de pratique : 17 semaines, une colonne par semaine (lundi → dimanche) */
function heatmap() {
  const WEEKS = 17, today = new Date(); today.setHours(12, 0, 0, 0);
  const start = new Date(today); start.setDate(today.getDate() - ((today.getDay() + 6) % 7) - (WEEKS - 1) * 7);
  const lvl = (x) => (x <= 0 ? 0 : x < 20 ? 1 : x < 50 ? 2 : x < 100 ? 3 : 4);
  let cols = "", months = "", active = 0, total = 0, lastMonth = -1;
  for (let w = 0; w < WEEKS; w++) {
    let cells = "";
    const first = new Date(start); first.setDate(start.getDate() + w * 7);
    if (first.getMonth() !== lastMonth) { months += `<span style="grid-column:${w + 1}">${MONTHS[first.getMonth()]}</span>`; lastMonth = first.getMonth(); }
    for (let d = 0; d < 7; d++) {
      const day = new Date(start); day.setDate(start.getDate() + w * 7 + d);
      const k = dk(day), x = xpOn(k), future = day > today;
      if (x > 0) { active++; total += x; }
      cells += `<i class="hm-c l${future ? "x" : lvl(x)} ${k === dk(today) ? "today" : ""}" title="${day.toLocaleDateString("fr-FR", { weekday: "long", day: "numeric", month: "long" })} : ${x} XP"></i>`;
    }
    cols += `<div class="hm-col">${cells}</div>`;
  }
  // Meilleure série dans le journal
  let best = 0, run = 0;
  for (let i = WEEKS * 7; i >= 0; i--) { const d = new Date(today); d.setDate(today.getDate() - i); if (xpOn(dk(d)) > 0) best = Math.max(best, ++run); else run = 0; }
  return `<section class="card dash-wide">
    <div class="dw-head"><h2 class="h3">📅 Calendrier de pratique</h2><span class="muted small">${active} jour${active > 1 ? "s" : ""} actif${active > 1 ? "s" : ""} · meilleure série ${best} j</span></div>
    <div class="hm-wrap"><div class="hm-days"><span>L</span><span></span><span>M</span><span></span><span>V</span><span></span><span>D</span></div>
      <div class="hm"><div class="hm-months">${months}</div><div class="hm-grid">${cols}</div></div></div>
    <div class="hm-legend"><span>Moins</span>${[0, 1, 2, 3, 4].map((n) => `<i class="hm-c l${n}"></i>`).join("")}<span>Plus</span></div>
  </section>`;
}

/** Courbe des XP sur 30 jours */
function xpCurve() {
  const N = 30, pts = [];
  for (let i = N - 1; i >= 0; i--) { const d = new Date(); d.setDate(d.getDate() - i); pts.push({ d, x: xpOn(dk(d)) }); }
  const max = Math.max(50, ...pts.map((p) => p.x)), W = 320, H = 120, pad = 6;
  const X = (i) => pad + (i * (W - 2 * pad)) / (N - 1), Y = (v) => H - pad - (v / max) * (H - 2 * pad - 10);
  const line = pts.map((p, i) => `${i ? "L" : "M"}${X(i).toFixed(1)},${Y(p.x).toFixed(1)}`).join(" ");
  const area = `${line} L${X(N - 1).toFixed(1)},${H - pad} L${X(0).toFixed(1)},${H - pad} Z`;
  const sum = pts.reduce((n, p) => n + p.x, 0), bestP = pts.reduce((a, b) => (b.x > a.x ? b : a), pts[0]);
  const goal = state.profile?.dailyGoal || 50;
  const ticks = [0, 7, 14, 21, 29].map((i) => `<span style="left:${(X(i) / W) * 100}%">${pts[i].d.getDate()} ${MONTHS[pts[i].d.getMonth()]}</span>`).join("");
  return `<section class="card dash-wide">
    <div class="dw-head"><h2 class="h3">📈 XP des 30 derniers jours</h2><span class="muted small">${sum} XP · ${Math.round(sum / N)} / jour en moyenne</span></div>
    <div class="xc">
      <svg viewBox="0 0 ${W} ${H}" preserveAspectRatio="none" class="xc-svg" aria-hidden="true">
        <defs><linearGradient id="xcg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="var(--lvl-c)" stop-opacity=".35"/><stop offset="1" stop-color="var(--lvl-c)" stop-opacity="0"/></linearGradient></defs>
        <line x1="0" x2="${W}" y1="${Y(goal).toFixed(1)}" y2="${Y(goal).toFixed(1)}" class="xc-goal"/>
        <path d="${area}" fill="url(#xcg)"/><path d="${line}" class="xc-line" fill="none" vector-effect="non-scaling-stroke"/>
      </svg>
      ${pts.map((p, i) => p.x ? `<i class="xc-dot ${p === bestP ? "best" : ""}" style="left:${(X(i) / W) * 100}%;top:${(Y(p.x) / H) * 100}%" title="${p.d.toLocaleDateString("fr-FR")} : ${p.x} XP"></i>` : "").join("")}
      <span class="xc-goal-l" style="top:${(Y(goal) / H) * 100}%">objectif ${goal}</span>
    </div>
    <div class="xc-ticks">${ticks}</div>
    ${bestP.x ? `<p class="small muted">🏅 Meilleur jour : <b>${bestP.x} XP</b> le ${bestP.d.toLocaleDateString("fr-FR", { day: "numeric", month: "long" })}</p>` : `<p class="small muted">Gagnez des XP pour voir votre courbe se dessiner.</p>`}
  </section>`;
}

/** Mots : maîtrisés, en cours, nouveaux, et les plus fragiles */
function wordsCard() {
  const words = Object.values(state.vocab);
  let known = 0, learning = 0, fresh = 0;
  words.forEach((w) => { const c = cardOf(w); if (!c) fresh++; else if (c.box >= 4) known++; else learning++; });
  const tot = Math.max(1, words.length), pc = (n) => Math.round((n / tot) * 100);
  const fragile = words.map((w) => ({ w, c: cardOf(w) })).filter(({ c }) => c && (c.lapses || 0) > 0 && c.box < 4)
    .sort((a, b) => (b.c.lapses || 0) - (a.c.lapses || 0) || a.c.box - b.c.box).slice(0, 6);
  return `<section class="card">
    <h2 class="h3">📒 Mes mots</h2>
    <div class="wm-bar"><span class="k" style="width:${pc(known)}%"></span><span class="l" style="width:${pc(learning)}%"></span><span class="n" style="width:${pc(fresh)}%"></span></div>
    <div class="wm-legend"><span><i class="k"></i>${known} maîtrisé${known > 1 ? "s" : ""}</span><span><i class="l"></i>${learning} en cours</span><span><i class="n"></i>${fresh} jamais révisé${fresh > 1 ? "s" : ""}</span></div>
    <h3 class="wm-h">⚠️ Mots fragiles</h3>
    ${fragile.length ? `<ul class="wm-list">${fragile.map(({ w, c }) => `<li><b class="${L.wordClass}">${esc(w.zh)}</b>${w.py ? `<small class="py">${esc(w.py)}</small>` : ""}<span>${esc(String(w.fr).split(" — ")[0])}</span><em>${c.lapses}×</em></li>`).join("")}</ul>
      <a class="btn ghost small" href="#reviser">🃏 Les réviser en flashcards</a>`
      : `<p class="small muted">${words.length ? "Aucun mot oublié récemment 👍 Les mots ratés en flashcards apparaîtront ici." : "Terminez une leçon pour remplir votre carnet."}</p>`}
  </section>`;
}

/** Points faibles : leçons qui concentrent les erreurs */
function weakCard() {
  const by = {};
  Object.values(state.errors).forEach((e) => { const src = String(e.ref).split(":")[0]; by[src] = (by[src] || 0) + (e.count || 1); });
  const top = Object.entries(by).sort((a, b) => b[1] - a[1]).slice(0, 5), max = Math.max(1, ...top.map((t) => t[1]));
  return `<section class="card">
    <h2 class="h3">🎯 Points faibles</h2>
    ${top.length ? `<ul class="wk-list">${top.map(([src, n]) => {
      const lesson = getLesson(src), label = lesson ? `${lesson.emoji} ${lesson.title}` : refLabel(src + ":0");
      return `<li><a href="${lesson ? `#lecon-${lesson.id}` : "#erreurs"}"><span class="wk-l">${pyText(lesson?.levelId || "", label)}</span><span class="wk-bar"><i style="width:${(n / max) * 100}%"></i></span><b>${n}</b></a></li>`;
    }).join("")}</ul><a class="btn primary small" href="#revision">🔁 Réviser mes erreurs</a>`
      : `<p class="small muted">Aucune erreur en attente : bravo ! Vos erreurs de quiz s'afficheront ici, regroupées par leçon.</p>`}
  </section>`;
}

export function renderDashboard(app) {
  const g = P.globalProgress();
  const goal = state.profile?.dailyGoal || 50;
  const today = P.dailyXp();
  const goalPct = Math.min(100, Math.round((today / goal) * 100));
  const lessonsDone = ALL_LESSONS.filter((l) => P.isLessonDone(l.id)).length;
  const words = Object.keys(state.vocab).length;
  const errors = Object.keys(state.errors).length;
  const next = P.nextStep();
  const attempts = state.history.filter((h) => h.kind !== "review");
  const avg = attempts.length ? Math.round((attempts.reduce((a, h) => a + h.score / h.total, 0) / attempts.length) * 100) : 0;

  app.innerHTML = `
  <header class="page-head">
    <p class="eyebrow">Tableau de bord</p>
    <h1>${esc(state.profile?.avatar || "")} ${esc(state.profile?.pseudo || "")}, voici votre progression</h1>
  </header>

  <div class="dash-grid">
    <section class="card dash-main">
      ${ring(g.pct, 168, 14)}
      <div>
        <p class="eyebrow">Progression globale ${lvlLabel(LEVELS[0])} → ${lvlLabel(LEVELS[LEVELS.length - 1])}</p>
        <h2>${g.done} / ${g.total} étapes</h2>
        <p class="muted">Niveau actuel : <b>${lvlLabel(P.currentLevel())} · ${P.currentLevel().name}</b></p>
        ${next ? `<a class="btn primary dash-resume" href="#${P.stepHref(next)}">
          <span class="dr-txt">${next.kind === "lesson" ? "Reprendre : " + pyText(next.lesson.levelId, next.lesson.title) : next.kind === "checkpoint" ? "Test de mi-palier " + lvlLabel(next.level) : "Passer l'examen " + lvlLabel(next.level)}</span><span class="dr-arrow" aria-hidden="true">→</span></a>` : ""}
      </div>
    </section>

    <section class="card goal">
      ${ring(goalPct, 96, 9, `${today}`)}
      <div>
        <p class="eyebrow">Objectif du jour</p>
        <h3>${today} / ${goal} XP</h3>
        <p class="small muted">${goalPct >= 100 ? `Objectif atteint, ${L.goalDone} ! 🎉` : `Encore ${goal - today} XP aujourd'hui.`}</p>
      </div>
    </section>

    <section class="stats">
      ${stat("🔥", P.streakCount(), "jour(s) de série")}
      ${stat("⚡", state.xp, "XP au total")}
      ${stat("✅", lessonsDone, `leçon(s) sur ${ALL_LESSONS.length}`)}
      ${stat("🎯", avg + "%", "réussite moyenne")}
      <a class="stat link" href="#carnet">${statInner("📒", words, "mots dans le carnet")}</a>
      <a class="stat link ${errors ? "warn" : ""}" href="#erreurs">${statInner("🔁", errors, "erreur(s) à revoir")}</a>
    </section>

    ${heatmap()}
    ${xpCurve()}
    ${wordsCard()}
    ${weakCard()}

    <section class="card levels-card">
      <h2 class="h3">Progression par palier</h2>
      <ul class="level-bars">
        ${LEVELS.map((l, i) => {
          const p = P.levelProgress(i), open = P.isLevelUnlocked(i);
          return `<li class="${open ? "" : "locked"}" style="--lvl:${l.color}">
            <span class="lb-id">${lvlLabel(l)}</span>
            <span class="lb-name">${l.name}${l.hsk && !l.label ? ` · ${l.hsk}` : ""}${P.isExamPassed(l.id) ? " 🏆" : ""}</span>
            <span class="lb-bar"><i style="width:${p.pct}%"></i></span>
            <span class="lb-pct">${open ? p.pct + "%" : "🔒"}</span>
          </li>`;
        }).join("")}
      </ul>
    </section>

    <section class="card history-card">
      <h2 class="h3">Activité récente</h2>
      ${state.history.length ? `<ul class="history">${state.history.slice(0, 8).map((h) => `
        <li>
          <span class="h-dot ${h.passed ? "ok" : "ko"}"></span>
          <span class="h-label">${esc(h.label)}</span>
          <span class="h-score">${h.score}/${h.total}</span>
          <time>${new Date(h.date).toLocaleDateString("fr-FR", { day: "numeric", month: "short" })}</time>
        </li>`).join("")}</ul>`
        : `<p class="empty">Aucune activité pour l'instant. <a href="#parcours">Commencez votre première leçon</a> !</p>`}
    </section>
  </div>`;
}

const statInner = (icon, val, label) => `<span class="stat-icon">${icon}</span><b>${val}</b><small>${label}</small>`;
const stat = (icon, val, label) => `<div class="stat">${statInner(icon, val, label)}</div>`;
