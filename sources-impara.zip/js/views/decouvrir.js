/* =====================================================================
   Vue « Découvrir » (#decouvrir, #joueur-<nom>)
   Onglet facultatif (Paramètres › Compte) : chiffres de la communauté,
   classement général d'XP et de la semaine, profils des autres joueurs.
   Seuls les joueurs qui ont choisi d'apparaître sont listés
   (supabase/discover.sql).
   ===================================================================== */

import { recapHtml, bindRecap } from "./recap.js";
import { state } from "../core/storage.js";
import { LANGS, code, flagSVG } from "../core/lang.js";
import { esc, toast } from "../core/ui.js";
import { isConfigured } from "../core/cloud.js";
import * as So from "../core/social.js";
import * as C from "../core/cosmetics.js";
import { icon } from "../core/icons.js";

const who = (p) => esc(p?.pseudo || p?.username || "Joueur");
const av = (p, cls = "") => `<span class="s-avatar ${cls} ${C.frameClass(p?.frame)}"${p?.color ? ` style="background:${esc(p.color)}"` : ""}>${esc(p?.avatar || "👤")}</span>`;
const fmt = (n) => Number(n || 0).toLocaleString("fr-FR");
const MEDALS = ["🥇", "🥈", "🥉"];
let tab = "all", cache = null;

function gate(app) {
  if (!isConfigured() || !So.isAvailable()) {
    app.innerHTML = `<header class="page-head"><h1>🧭 Découvrir</h1></header>
      <section class="card"><p>Connectez-vous à votre compte (Paramètres › Compte) pour découvrir les autres joueurs.</p>
      <a class="btn primary" href="#reglages-compte">Se connecter</a></section>`;
    return true;
  }
  return false;
}
const loadingHtml = `<div class="dc-skel" aria-busy="true">${"<span></span>".repeat(5)}</div>`;

/* ================================ Accueil ================================ */
export async function renderDecouvrir(app) {
  if (gate(app)) return true;
  const hash = location.hash;
  app.innerHTML = `<header class="page-head dc-head"><h1>🧭 Découvrir</h1>
    <p class="muted">La communauté ${esc(LANGS[code]?.label ? `· ${LANGS[code].label}` : "")}</p></header>
    <div data-zone="dc">${cache ? "" : loadingHtml}</div>`;
  if (cache) paint(app, cache);
  try {
    if (!So.social().ready) await So.refresh();
    cache = await So.discoverOverview();
  } catch (e) {
    if (location.hash !== hash) return true;
    if (!cache) app.querySelector('[data-zone="dc"]').innerHTML = `<section class="card"><p class="form-msg error">${esc(e.message)}</p></section>`;
    return true;
  }
  if (location.hash === hash) paint(app, cache);
  return true;
}

function paint(app, d) {
  const z = app.querySelector('[data-zone="dc"]');
  if (!z) return;
  const me = So.social().me;
  const list = tab === "week" ? d.week || [] : d.top || [];
  z.innerHTML = `
    <section class="dc-stats">
      <div class="dc-stat"><span>👥</span><b>${fmt(d.players)}</b><small>joueurs inscrits</small></div>
      <div class="dc-stat"><span>🔥</span><b>${fmt(d.active)}</b><small>actifs cette semaine</small></div>
      <div class="dc-stat"><span>⚡</span><b>${fmt(d.xp)}</b><small>XP gagnés en ${esc(LANGS[code]?.label?.toLowerCase() || "")}</small></div>
      <div class="dc-stat"><span>🏆</span><b>${d.my_rank ? `${d.my_rank}<sup>${d.my_rank === 1 ? "er" : "e"}</sup>` : "–"}</b><small>votre place sur ${fmt(d.learners)}</small></div>
    </section>
    ${d.me_visible ? "" : `<section class="card dc-join"><p><b>Vous n'apparaissez pas encore dans le classement.</b><br><span class="muted small">Votre pseudo, votre avatar et votre XP deviendront visibles des autres joueurs.</span></p>
      <button class="btn primary" data-join>Apparaître</button></section>`}
    <section class="card dc-board">
      <div class="seg wide dc-tabs" role="tablist">
        <button data-dtab="all" class="${tab === "all" ? "on" : ""}">XP au total</button>
        <button data-dtab="week" class="${tab === "week" ? "on" : ""}">Cette semaine</button>
      </div>
      ${list.length ? `<ol class="s-board dc-list">${list.map((p, i) => {
        const mine = p.id === me?.id;
        return `<li class="${mine ? "me" : ""}"><a href="#joueur-${esc(p.username)}">
          <span class="s-rank">${i < 3 ? MEDALS[i] : i + 1}</span>${av(p, "sm")}
          <span class="s-board-name">${mine ? "Vous" : who(p)}<small>@${esc(p.username)}${tab === "all" && p.level ? ` · ${esc(p.level)}` : ""}${tab === "all" && p.streak ? ` · 🔥 ${p.streak}` : ""}</small></span>
          <b>${fmt(p.xp)} XP</b></a></li>`;
      }).join("")}</ol>` : `<p class="muted small dc-empty">${tab === "week" ? "Personne n'a encore gagné d'XP cette semaine." : "Aucun joueur visible pour le moment."}</p>`}
      <p class="fr-foot">${fmt(d.visible)} joueur${d.visible > 1 ? "s" : ""} visible${d.visible > 1 ? "s" : ""} · seuls ceux qui l'ont choisi apparaissent.</p>
    </section>
    <form class="card dc-search" data-search><input name="u" placeholder="Rechercher un joueur (@nom)" autocomplete="off" autocapitalize="none"><button class="btn ghost small">Voir</button></form>`;
  z.querySelectorAll("[data-dtab]").forEach((b) => (b.onclick = () => { tab = b.dataset.dtab; paint(app, d); }));
  z.querySelector("[data-join]")?.addEventListener("click", async (e) => {
    e.currentTarget.disabled = true;
    try { await So.setDiscoverable(true); cache = await So.discoverOverview(); paint(app, cache); toast("Vous apparaissez dans Découvrir ✓", "ok"); }
    catch (err) { toast(err.message || "Erreur", "warn"); e.currentTarget.disabled = false; }
  });
  z.querySelector("[data-search]").onsubmit = (e) => {
    e.preventDefault();
    const u = e.currentTarget.u.value.trim().toLowerCase().replace(/^@/, "");
    if (u) location.hash = `joueur-${u}`;
  };
}

/* ================================ Profil ================================ */
export async function renderJoueur(app, username) {
  if (gate(app)) return true;
  const hash = location.hash;
  app.innerHTML = `<a class="back-link" href="#decouvrir">← Découvrir</a>${loadingHtml}`;
  let p;
  try { if (!So.social().ready) await So.refresh(); p = await So.discoverProfile(username); }
  catch (e) { if (location.hash === hash) app.innerHTML = `<a class="back-link" href="#decouvrir">← Découvrir</a><section class="card"><p class="form-msg error">${esc(e.message)}</p></section>`; return true; }
  if (location.hash !== hash) return true;
  if (!p || p.hidden) {
    app.innerHTML = `<a class="back-link" href="#decouvrir">← Découvrir</a><section class="card"><p>${!p ? `Aucun joueur ne s'appelle @${esc(username)}.` : `@${esc(username)} n'apparaît pas dans Découvrir.`}</p></section>`;
    return true;
  }
  if (p.rel === "friend") { location.replace(`#ami-${p.username}`); return true; }
  if (p.rel === "me") { location.replace("#profil"); return true; }
  const stats = p.stats || {}, langs = Object.keys(LANGS).filter((c) => stats[c]);
  const color = p.color || "#cfe6ff", fb = C.bannerStyle(p.banner);
  const ink = (() => { const n = parseInt(color.slice(1), 16); return ((n >> 16) * 299 + ((n >> 8) & 255) * 587 + (n & 255) * 114) / 1000 > 150 ? "#1d2733" : "#ffffff"; })();
  const streak = Math.max(0, ...langs.map((c) => stats[c].streak || 0));
  const total = langs.reduce((n, c) => n + (stats[c].xp || 0), 0);
  const action = { none: `<button class="btn primary" data-add>${icon("user-plus", { size: 18 })} Ajouter en ami</button>`,
    sent: `<button class="btn ghost" disabled>Demande envoyée</button>`,
    received: `<a class="btn primary" href="#amis">Répondre à sa demande</a>` }[p.rel] || "";
  app.innerHTML = `<div class="pf fp">
    <section class="fh-banner ${fb ? "has-pattern" : ""}" style="--banner:${esc(color)};--banner-ink:${fb ? fb.ink : ink}${fb ? `;--banner-bg:${fb.bg}` : ""}">
      <a class="fh-btn" href="#decouvrir" aria-label="Retour">‹</a>
      <span class="fh-avatar ${C.frameClass(p.frame)}">${esc(p.avatar || "👤")}</span>
    </section>
    <section class="pf-body fh-body">
      <h1 class="fh-name">${who(p)}</h1>
      <p class="fh-handle">@${esc(p.username)} · inscrit depuis ${new Date(p.since).toLocaleDateString("fr-FR", { month: "long", year: "numeric" })}</p>
      <div class="fh-chips">
        ${streak ? `<span class="fh-chip fire">🔥 ${streak} j de série</span>` : ""}
        <span class="fh-chip gold">⚡ ${fmt(total)} XP</span>
        ${langs.map((c) => `<span class="fh-chip"><span class="flag mini">${flagSVG(c)}</span>${esc(stats[c].level || "")}</span>`).join("")}
      </div>
      <div class="dc-act">${action}</div>
      <div data-recap>${recapHtml(stats, langs, null, `${who(p)} n'a pas encore commencé de parcours.`)}</div>
    </section></div>`;
  const rz = app.querySelector("[data-recap]");
  const pick = (l) => { rz.innerHTML = recapHtml(stats, langs, l, ""); bindRecap(rz, pick); };
  bindRecap(rz, pick);
  app.querySelector("[data-add]")?.addEventListener("click", async (e) => {
    const b = e.currentTarget; b.disabled = true;
    try { const r = await So.addFriend(p.username); toast(r === "accepted" ? "Vous êtes maintenant amis 🎉" : "Demande d'ami envoyée ✓", "ok"); b.outerHTML = `<button class="btn ghost" disabled>${r === "accepted" ? "✓ Amis" : "Demande envoyée"}</button>`; }
    catch (err) { toast(err.message, "warn"); b.disabled = false; }
  });
  return true;
}

export const discoverTabOn = () => !!state.settings.discoverTab;
