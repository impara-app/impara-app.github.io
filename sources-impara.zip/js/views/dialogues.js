/* =====================================================================
   Vue « Dialogues » (#dialogues, #dialogue-<id>)
   Une petite scène (café, gare, médecin…) : à chaque tour, on choisit
   sa réplique parmi trois — juste, maladroite ou fausse — et on voit
   pourquoi. 2 points pour une bonne réponse du premier coup, 1 pour une
   réponse maladroite, 0 si l'on s'est trompé.
   ===================================================================== */

import { state, commit } from "../core/storage.js";
import { code, L } from "../core/lang.js";
import { esc, speak, celebrate, ring, shuffle } from "../core/ui.js";
import * as P from "../core/progress.js";
import { getLesson, lvlLabel } from "../data/curriculum.js";
import { levelWantsPinyin } from "../core/pinyin.js";
import { wordsHtml } from "../core/words.js";
import { reportButton, setReportContext } from "../core/report.js";

const SOURCES = { it: () => import("../data/dialogues-it.js"), zh: () => import("../data/dialogues-zh.js") };
const LIST = (await (SOURCES[code] || SOURCES.it)()).default;
const unlocked = (d) => P.isLessonDone(d.after);
const zh = () => code === "zh";

export const dialogueCount = () => ({ total: LIST.length, open: LIST.filter(unlocked).length, done: LIST.filter((d) => state.dialogues?.[d.id]?.done).length });

/* =============================== Liste ============================== */
export function renderDialogues(app) {
  app.innerHTML = `
  <a class="back-link" href="#entrainement">← Entraînement</a>
  <header class="page-head"><p class="eyebrow">Parler en situation</p><h1>💬 Dialogues</h1>
    <p class="muted">Une scène de la vie réelle : à chaque tour, choisissez la réplique qui convient. Attention aux réponses maladroites !</p></header>
  <div class="story-list">
    ${LIST.map((d) => {
      const ok = unlocked(d), rec = state.dialogues?.[d.id], lesson = getLesson(d.after);
      return `<a class="story-item ${ok ? "" : "locked"}" ${ok ? `href="#dialogue-${d.id}"` : `aria-disabled="true"`}>
        <span class="story-emoji">${ok ? d.emoji : "🔒"}</span>
        <span class="story-txt"><b class="${zh() ? "zh" : ""}">${esc(d.title)} <em class="story-lvl">${esc(lvlLabel(d.level))}</em></b>
          ${d.titlePy ? `<small class="py">${esc(d.titlePy)}</small>` : ""}
          <small>${ok ? esc(d.intro) : `Se débloque après la leçon « ${esc(lesson?.title || d.after)} »`}</small></span>
        ${rec?.done ? `<span class="story-done" title="Meilleur score">${rec.best} %</span>` : ""}
      </a>`;
    }).join("")}
  </div>`;
  return true;
}

/* ============================== Dialogue ============================ */
export function renderDialogue(app, id) {
  const d = LIST.find((x) => x.id === id);
  if (!d || !unlocked(d)) return false;
  const showPy = zh() && levelWantsPinyin(d.level);
  const turns = d.turns.filter((t) => t.choices).length;
  let step = 0, points = 0, showFr = false;

  document.body.classList.add("focus-mode");
  app.innerHTML = `
  <section class="story dlg">
    <div class="story-top">
      <button class="btn ghost small" data-quit aria-label="Quitter">✕</button>
      <div class="progress"><span class="story-bar"></span></div>
      ${reportButton()}
    </div>
    <header class="story-head"><span class="big-emoji">${d.emoji}</span>
      <h1 class="${zh() ? "zh" : ""}">${esc(d.title)}</h1>${d.titlePy ? `<p class="py">${esc(d.titlePy)}</p>` : ""}
      <p class="muted">${esc(d.intro)}</p></header>
    <div class="story-lines"></div>
    <div class="dlg-pick" hidden></div>
    <div class="story-foot"><button class="btn primary big" data-next>Commencer</button></div>
  </section>`;
  const $ = (q) => app.querySelector(q);
  const box = $(".story-lines"), pick = $(".dlg-pick"), next = $("[data-next]");
  $("[data-quit]").onclick = () => { document.body.classList.remove("focus-mode"); location.hash = "dialogues"; };

  // Deux voix : vous parlez avec votre voix, votre interlocuteur avec l'autre
  const say = (t, mine = true) => speak(t, { force: true, voice: mine ? null : "alt" });
  let shown = null;
  setReportContext(() => ({ place: `Dialogue · ${d.title}`, audio: shown?.t ?? shown?.npc ?? "", question: shown?.fr || "", expected: shown?.py || "" }));
  function bubble(line, mine) {
    shown = line;
    const el = document.createElement("div");
    el.className = `sl talk ${mine ? "me" : ""}`;
    el.style.setProperty("--who", mine ? "var(--verde)" : "#3b82c4");
    el.innerHTML = `<span class="sl-who">${mine ? "Vous" : esc(d.npc)}</span>
      <div class="sl-bubble"><p class="sl-t ${zh() ? "zh" : ""}">${wordsHtml(line.t ?? line.npc)}</p>
        ${line.py ? `<p class="sl-py ${showPy ? "" : "hidden"}">${esc(line.py)}</p>` : ""}
        <p class="sl-fr hidden">${esc(line.fr)}</p></div>
      <button class="speak" data-say aria-label="Réécouter">🔊</button>`;
    el.querySelector("[data-say]").onclick = (e) => { e.stopPropagation(); say(line.t ?? line.npc, mine); };
    el.onclick = () => { el.querySelector(".sl-fr").classList.toggle("hidden"); el.querySelector(".sl-py")?.classList.remove("hidden"); };
    box.appendChild(el);
    say(line.t ?? line.npc, mine);
    el.scrollIntoView({ behavior: "smooth", block: "end" });
  }

  function ask(turn) {
    const opts = shuffle(turn.choices.map((c, i) => ({ ...c, i })));
    let tries = 0;
    next.hidden = true;
    pick.hidden = false;
    pick.innerHTML = `<div class="dlg-head"><p class="eyebrow">À vous : que répondez-vous ?</p>
        <button class="btn ghost small" data-fr>${showFr ? "Masquer" : "Voir"} les traductions</button></div>
      <div class="dlg-opts">${opts.map((c) => `<button class="option dlg-opt" data-i="${c.i}">
        <span><b class="${zh() ? "zh" : ""}">${esc(c.t)}</b>${c.py && showPy ? `<small class="py">${esc(c.py)}</small>` : ""}<small class="dlg-fr" ${showFr ? "" : "hidden"}>${esc(c.fr)}</small></span>
        <i class="dlg-say" data-hear="${c.i}" role="button" aria-label="Écouter">🔊</i></button>`).join("")}</div>
      <div class="dlg-fb" aria-live="polite"></div>`;
    pick.querySelector("[data-fr]").onclick = (e) => {
      showFr = !showFr;
      pick.querySelectorAll(".dlg-fr").forEach((x) => (x.hidden = !showFr));
      e.currentTarget.textContent = `${showFr ? "Masquer" : "Voir"} les traductions`;
    };
    pick.querySelectorAll("[data-hear]").forEach((h) => (h.onclick = (e) => { e.stopPropagation(); say(turn.choices[+h.dataset.hear].t); }));
    pick.scrollIntoView({ behavior: "smooth", block: "end" });
    pick.querySelectorAll(".dlg-opt").forEach((b) => (b.onclick = () => {
      if (b.disabled) return;
      const c = turn.choices[+b.dataset.i];
      tries++;
      const fb = pick.querySelector(".dlg-fb");
      if (c.ok === 0) {
        b.disabled = true; b.classList.add("wrong");
        fb.innerHTML = `<div class="dlg-res ko"><b>✗ Ça ne va pas</b><p>${esc(c.why)}</p><p class="small muted">Choisissez une autre réponse.</p></div>`;
        return;
      }
      // Réponse acceptée : la meilleure réplique est jouée dans la conversation
      const best = turn.choices.find((x) => x.ok === 2) || c;
      if (tries === 1) points += c.ok;
      pick.querySelectorAll(".dlg-opt").forEach((x) => { x.disabled = true; if (+x.dataset.i === turn.choices.indexOf(best)) x.classList.add("correct"); });
      if (c.ok === 1) b.classList.add("meh");
      fb.innerHTML = c.ok === 2
        ? `<div class="dlg-res ok"><b>✓ Parfait !</b><p>${esc(c.why)}</p></div>`
        : `<div class="dlg-res meh"><b>≈ Compréhensible, mais maladroit</b><p>${esc(c.why)}</p><p class="small">Plus naturel : <b class="${zh() ? "zh" : ""}">${esc(best.t)}</b></p></div>`;
      next.hidden = false; next.textContent = "Continuer"; next.focus();
      next.onclick = () => { pick.hidden = true; pick.innerHTML = ""; bubble(c.ok === 2 ? c : best, true); advance(); };
    }));
  }

  function advance() {
    if (step >= d.turns.length) { next.hidden = false; next.textContent = "Terminer"; next.onclick = finish; return; }
    const t = d.turns[step++];
    $(".story-bar").style.width = `${Math.round((step / d.turns.length) * 100)}%`;
    if (t.choices) return ask(t);
    bubble(t, false);
    // Réplique suivante du personnage, ou à vous de répondre
    if (d.turns[step]?.choices) setTimeout(() => advance(), 700);
    else { next.hidden = false; next.textContent = step >= d.turns.length ? "Terminer" : "Continuer"; next.onclick = step >= d.turns.length ? finish : advance; }
  }

  function finish() {
    const pct = Math.round((points / (2 * turns)) * 100);
    const rec = state.dialogues?.[d.id], first = !rec?.done;
    const r = P.recordPractice({ label: `Dialogue · ${d.title}`, score: points, total: 2 * turns, xpPer: 5, key: `dialogue:${d.id}` });
    let bonus = 0;
    if (first) { bonus = 20; P.recordPractice({ label: "", score: 1, total: 0, xpPer: bonus }); }
    commit((s) => { s.dialogues = { ...(s.dialogues || {}), [d.id]: { done: true, best: Math.max(rec?.best || 0, pct), date: Date.now() } }; });
    document.body.classList.remove("focus-mode");
    const nextD = LIST.find((x) => unlocked(x) && !state.dialogues?.[x.id]?.done);
    app.innerHTML = `
    <section class="results ${pct >= 60 ? "ok" : "ko"}">
      ${ring(pct, 150, 12)}
      <h1>${pct === 100 ? "Comme un natif ! 🎉" : pct >= 60 ? "Bien joué !" : "Dialogue terminé"}</h1>
      <p class="lead">${points} / ${2 * turns} points · ${turns} répliques</p>
      <div class="result-chips">${r.capped && !bonus ? `<span class="chip muted-chip">⏳ XP déjà gagnés aujourd'hui</span>` : `<span class="chip">⚡ +${r.xpGained + bonus} XP</span>`}${bonus ? `<span class="chip">💬 Nouveau dialogue</span>` : ""}</div>
      <div class="result-actions">
        ${nextD ? `<a class="btn primary big" href="#dialogue-${nextD.id}">Dialogue suivant →</a>` : `<a class="btn primary big" href="#dialogues">Tous les dialogues</a>`}
        <a class="btn ghost" href="#dialogue-${d.id}" data-reload>Rejouer</a>
      </div>
    </section>`;
    if (pct === 100) celebrate();
  }

  next.onclick = () => advance();
  return true;
}
