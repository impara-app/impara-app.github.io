/* =====================================================================
   Vue « Dictée » (#dictee)
   On entend une phrase à vitesse réelle, on l'écrit, puis on voit la
   correction mot à mot (ou caractère par caractère).
   - Italien  : on écrit la phrase ; un accent oublié compte à moitié.
   - Mandarin : on écrit le pinyin (tons facultatifs : chiffres ou
                accents) ou directement les caractères.
   Les phrases viennent des exemples des leçons débloquées et des
   histoires déjà accessibles.
   ===================================================================== */

import { state, commit } from "../core/storage.js";
import { code } from "../core/lang.js";
import { esc, shuffle, speak, ring, celebrate, stopSpeaking, splitDialog } from "../core/ui.js";
import * as P from "../core/progress.js";
import { ALL_LESSONS } from "../data/curriculum.js";
import { STORIES } from "../data/stories.js";
import { xpChip } from "./entrainement.js";
import { reportButton, setReportContext } from "../core/report.js";

const N = 8;
const PASS = 0.8;
const isZh = () => code === "zh";
const HAN = /[㐀-鿿]/g;

/* ---------------------------- Phrases ------------------------------ */
const words = (t) => t.split(/\s+/).filter((w) => /[a-zà-ÿ]/i.test(w)).length;
const hanCount = (t) => (t.match(HAN) || []).length;
function fits(t) {
  if (isZh()) { const n = hanCount(t); return n >= 3 && n <= 18; }
  const n = words(t); return n >= 3 && n <= 14;
}

export function sentencePool() {
  const out = new Map();
  const add = (t, py, fr) => {
    t = String(t || "").replace(/\|.*$/, "").trim(); fr = String(fr || "").split(" — ")[0].trim();
    if (!t || !fr || out.has(t) || !fits(t)) return;
    if (isZh() && !py) return;
    out.set(t, { t, py: String(py || "").trim(), fr });
  };
  // Exemples des leçons débloquées (les répliques « A — B » sont séparées)
  ALL_LESSONS.filter((l) => P.isLessonUnlocked(l)).forEach((l) => (l.sections || []).flatMap((s) => s.examples || []).forEach((ex) => {
    splitDialog(ex).forEach(([t, py, fr]) => add(t, py, fr));
  }));
  // Répliques des histoires accessibles
  (STORIES[code] || []).filter((s) => P.isLessonDone(s.after)).forEach((s) => s.lines.forEach((l) => { if (!l.q) add(l.t, l.py, l.fr); }));
  return [...out.values()];
}

/* --------------------------- Correction ---------------------------- */
const stripAcc = (s) => s.normalize("NFD").replace(/[̀-ͯ]/g, "");

/** Alignement LCS de deux listes ; eq(a, b) → bool. Renvoie, pour chaque élément de A, l'indice apparié dans B (ou -1). */
function align(A, B, eq) {
  const d = Array.from({ length: A.length + 1 }, () => new Array(B.length + 1).fill(0));
  for (let i = A.length - 1; i >= 0; i--) for (let j = B.length - 1; j >= 0; j--)
    d[i][j] = eq(A[i], B[j]) ? d[i + 1][j + 1] + 1 : Math.max(d[i + 1][j], d[i][j + 1]);
  const map = new Array(A.length).fill(-1);
  for (let i = 0, j = 0; i < A.length && j < B.length;) {
    if (eq(A[i], B[j])) { map[i] = j; i++; j++; } else if (d[i + 1][j] >= d[i][j + 1]) i++; else j++;
  }
  return map;
}

/* Italien : mots (les élisions « l' », « un' » restent attachées à leur apostrophe) */
const itTokens = (s) => s.toLowerCase().replace(/[’`]/g, "'").replace(/'/g, "' ").replace(/[^a-zà-ÿ0-9' ]+/gi, " ").split(/\s+/).filter(Boolean);
function gradeIt(target, answer) {
  const T = itTokens(target), U = itTokens(answer);
  const key = (w) => w.replace(/'/g, "");               // « l amico » vaut « l'amico »
  const loose = (a, b) => stripAcc(key(a)) === stripAcc(key(b));
  const m = align(T, U, loose);
  const parts = T.map((w, i) => ({ w, st: m[i] < 0 ? "miss" : key(U[m[i]]) === key(w) ? "ok" : "acc" }));
  const pts = parts.reduce((n, p) => n + (p.st === "ok" ? 1 : p.st === "acc" ? 0.5 : 0), 0);
  const extra = U.length - m.filter((x) => x >= 0).length;
  // Mots en trop : petite pénalité pour éviter de « tout taper »
  const ratio = Math.max(0, (pts - Math.max(0, extra - 1) * 0.5) / T.length);
  // Découpage d'affichage : on reprend les mots de la phrase d'origine
  const shown = target.split(/(\s+)/);
  let k = 0;
  const html = shown.map((chunk) => {
    if (/^\s+$/.test(chunk) || !chunk) return chunk;
    // un mot affiché peut contenir 1 ou 2 jetons (l'amico → l' + amico)
    const n = itTokens(chunk).length;
    if (!n) return esc(chunk);
    const sts = parts.slice(k, k + n).map((p) => p.st); k += n;
    const st = sts.includes("miss") ? "miss" : sts.includes("acc") ? "acc" : "ok";
    return `<span class="dk-${st}">${esc(chunk)}</span>`;
  }).join("");
  const notes = [];
  if (parts.some((p) => p.st === "acc")) notes.push("Attention aux accents (è, à, ù…) : ils changent souvent le sens.");
  if (extra > 1) notes.push(`${extra} mot${extra > 1 ? "s" : ""} en trop dans votre réponse.`);
  return { ratio, html, notes };
}

/* Mandarin, caractères : comparaison caractère par caractère */
function gradeHanzi(target, answer) {
  const T = target.match(HAN) || [], U = answer.match(HAN) || [];
  const m = align(T, U, (a, b) => a === b);
  let i = 0;
  const html = [...target].map((c) => (/[㐀-鿿]/.test(c) ? `<span class="dk-${m[i++] >= 0 ? "ok" : "miss"}">${esc(c)}</span>` : esc(c))).join("");
  const ok = m.filter((x) => x >= 0).length;
  const extra = U.length - ok;
  return { ratio: Math.max(0, (ok - Math.max(0, extra - 1) * 0.5) / T.length), html, notes: U.length ? [] : ["Utilisez le clavier chinois (pinyin) de votre téléphone pour écrire les caractères."] };
}

/* Mandarin, pinyin : sons d'abord (espaces libres), tons en bonus */
const MARKS = { ā: "a1", á: "a2", ǎ: "a3", à: "a4", ē: "e1", é: "e2", ě: "e3", è: "e4", ī: "i1", í: "i2", ǐ: "i3", ì: "i4", ō: "o1", ó: "o2", ǒ: "o3", ò: "o4", ū: "u1", ú: "u2", ǔ: "u3", ù: "u4", ǖ: "v1", ǘ: "v2", ǚ: "v3", ǜ: "v4", ü: "v0" };
/** « nǐ » / « ni3 » → { base: "ni", tones: "3" } (ü s'écrit indifféremment u, v ou ü) */
function pyWord(w) {
  let base = "", tones = "";
  for (const ch of w.toLowerCase().replace(/u:/g, "ü")) {
    if (MARKS[ch]) { base += MARKS[ch][0]; if (MARKS[ch][1] !== "0") tones += MARKS[ch][1]; }
    else if (/[1-4]/.test(ch)) tones += ch;
    else if (/[a-z]/.test(ch)) base += ch;
  }
  return { base: base.replace(/v/g, "u"), tones };
}
const pyTokens = (s) => s.replace(/[—–-]/g, " ").split(/\s+/).map(pyWord).filter((x) => x.base);
function gradePinyin(target, answer) {
  const T = pyTokens(target), U = pyTokens(answer);
  const joined = U.map((u) => u.base).join("");
  // Chaque mot attendu est cherché dans la saisie, sans tenir compte des espaces
  let pos = 0;
  const found = T.map((t) => {
    const at = joined.indexOf(t.base, pos);
    if (at >= 0 && at - pos <= 6) { pos = at + t.base.length; return true; }
    return false;
  });
  const ok = found.filter(Boolean).length;
  const extraChars = Math.max(0, joined.length - T.filter((_, i) => found[i]).reduce((n, t) => n + t.base.length, 0));
  // Tons : suite des tons tapés comparée à la suite attendue (ton neutre ignoré)
  const want = T.map((t) => t.tones).join(""), got = U.map((u) => u.tones).join("");
  let toneRatio = null;
  if (got && want) {
    const m = align([...want], [...got], (a, b) => a === b);
    toneRatio = m.filter((x) => x >= 0).length / want.length;
  }
  // Affichage : le pinyin d'origine, mot par mot
  let k = 0;
  const html = target.split(/(\s+)/).map((chunk) => {
    if (!chunk || /^\s+$/.test(chunk) || !pyWord(chunk).base) return esc(chunk);
    return `<span class="dk-${found[k++] ? "ok" : "miss"}">${esc(chunk)}</span>`;
  }).join("");
  const notes = [];
  if (toneRatio == null) notes.push("Astuce : ajoutez les tons (ni3 hao3 ou nǐ hǎo) pour vous entraîner aussi aux tons.");
  else notes.push(`Tons : ${Math.round(toneRatio * 100)} % justes.`);
  let ratio = Math.max(0, (ok - Math.max(0, extraChars - 3) / 6) / T.length);
  if (toneRatio != null) ratio *= 0.5 + 0.5 * toneRatio;   // tons donnés : ils comptent pour moitié
  return { ratio, html, notes, toneRatio };
}

/* ------------------------------- Vue ------------------------------- */
export function renderDictee(app) {
  const pool = sentencePool();
  if (pool.length < 3) return false;
  const items = shuffle(pool).slice(0, N);
  const realRate = isZh() ? 1 : 1.05;
  let mode = isZh() ? (state.settings.dictMode === "hanzi" ? "hanzi" : "pinyin") : "it";
  let i = 0, score = 0, sum = 0, checked = false;

  document.body.classList.add("focus-mode");
  app.innerHTML = `
  <section class="pron dictee">
    <div class="story-top">
      <button class="btn ghost small" data-quit aria-label="Quitter">✕</button>
      <div class="progress"><span class="story-bar"></span></div>
      ${reportButton()}
    </div>
    <p class="eyebrow">Dictée · écoutez et écrivez</p>
    ${isZh() ? `<div class="seg dk-mode" role="tablist">
        <button type="button" data-mode="pinyin" class="${mode === "pinyin" ? "on" : ""}">Pinyin</button>
        <button type="button" data-mode="hanzi" class="${mode === "hanzi" ? "on" : ""}">汉字 Caractères</button></div>` : ""}
    <div class="card dk-card">
      <button class="dk-play" data-play aria-label="Écouter la phrase"><span>🔊</span></button>
      <div class="btn-row center"><button class="btn ghost small" data-play>🔁 Réécouter</button><button class="btn ghost small" data-slow>🐢 Lentement</button></div>
      <p class="dk-hint muted small"></p>
      <textarea class="dk-input" rows="2" autocomplete="off" autocapitalize="off" spellcheck="false" aria-label="Votre réponse"></textarea>
      <div class="dk-res" aria-live="polite"></div>
    </div>
    <div class="story-foot"><button class="btn ghost" data-skip>Je ne sais pas</button><button class="btn primary" data-check>Vérifier</button></div>
  </section>`;

  const $ = (s) => app.querySelector(s);
  const input = $(".dk-input"), check = $("[data-check]"), skip = $("[data-skip]");
  const quit = () => { stopSpeaking(); document.body.classList.remove("focus-mode"); location.hash = "entrainement"; };
  $("[data-quit]").onclick = quit;
  const play = (slow = false) => speak(items[i].t, { force: true, slow, rate: slow ? null : realRate });
  app.querySelectorAll("[data-play]").forEach((b) => (b.onclick = () => { play(); input.focus(); }));
  $("[data-slow]").onclick = () => { play(true); input.focus(); };

  const hint = () => {
    $(".dk-hint").textContent = mode === "pinyin" ? "Écrivez le pinyin. Tons facultatifs : chiffres (ni3 hao3) ou accents (nǐ hǎo)."
      : mode === "hanzi" ? "Écrivez les caractères avec le clavier chinois. La ponctuation ne compte pas."
      : "Écrivez la phrase. La ponctuation et les majuscules ne comptent pas ; les accents, si !";
    input.placeholder = mode === "pinyin" ? "ni3 hao3…" : mode === "hanzi" ? "你好…" : "Scrivi qui…";
    input.lang = mode === "hanzi" ? "zh-Hans" : mode === "pinyin" ? "zh-Latn" : "it";
  };
  app.querySelectorAll("[data-mode]").forEach((b) => (b.onclick = () => {
    if (checked) return;
    mode = b.dataset.mode;
    commit((s) => { s.settings.dictMode = mode; }, { touch: false });
    app.querySelectorAll("[data-mode]").forEach((x) => x.classList.toggle("on", x === b));
    hint(); input.focus();
  }));

  setReportContext(() => { const it = items[i] || {}; return { place: `Dictée · phrase ${i + 1}/${items.length}`, audio: it.t, expected: [it.t, it.py].filter(Boolean).join(" · "), given: input.value, question: it.fr }; });
  function show() {
    checked = false;
    $(".story-bar").style.width = `${Math.round((i / items.length) * 100)}%`;
    input.value = ""; input.disabled = false; input.className = "dk-input";
    $(".dk-res").innerHTML = "";
    check.textContent = "Vérifier"; skip.hidden = false;
    hint();
    setTimeout(() => play(), 350);
    input.focus();
  }

  function correct(giveUp = false) {
    const it = items[i], ans = giveUp ? "" : input.value.trim();
    if (!giveUp && !ans) { input.focus(); return; }
    checked = true;
    // Mandarin : on corrige selon ce qui a été tapé (caractères ou pinyin), quel que soit l'onglet
    const how = !isZh() ? "it" : ans && /[㐀-鿿]/.test(ans) ? "hanzi" : ans ? "pinyin" : mode;
    const target = how === "pinyin" ? it.py : it.t;
    const r = how === "pinyin" ? gradePinyin(target, ans) : how === "hanzi" ? gradeHanzi(target, ans) : gradeIt(target, ans);
    const pct = Math.round(r.ratio * 100), ok = r.ratio >= PASS;
    sum += r.ratio; if (ok) score++;
    input.disabled = true; input.classList.add(ok ? "ok" : "ko");
    const head = pct === 100 ? "✓ Parfait !" : ok ? "✓ Bien joué !" : giveUp ? "Voici la phrase" : "✗ Pas encore";
    $(".dk-res").innerHTML = `<div class="pron-out ${ok ? "ok" : "ko"}"><b>${head}</b> <span class="dk-pct">${pct} %</span>
      <p class="dk-target ${how === "hanzi" ? "zh" : ""}">${r.html}</p>
      ${how === "pinyin" ? `<p class="zh dk-sub">${esc(it.t)}</p>` : isZh() ? `<p class="py dk-sub">${esc(it.py)}</p>` : ""}
      <p class="small muted">${esc(it.fr)}</p>
      ${r.notes.map((n) => `<p class="small">${esc(n)}</p>`).join("")}</div>`;
    check.textContent = i + 1 >= items.length ? "Terminer" : "Suivant →"; skip.hidden = true;
    check.focus();
  }

  function finish() {
    stopSpeaking();
    document.body.classList.remove("focus-mode");
    const r = P.recordPractice({ label: "Dictée", score, total: items.length, xpPer: 8, key: "dictee" });
    const avg = Math.round((sum / items.length) * 100);
    app.innerHTML = `
    <section class="results ${score / items.length >= 0.6 ? "ok" : "ko"}">
      ${ring(avg, 150, 12)}
      <h1>${avg === 100 ? "Dictée parfaite ! 🎉" : score / items.length >= 0.6 ? "Belle dictée !" : "Continuez, l'oreille se travaille !"}</h1>
      <p class="lead">${score} / ${items.length} phrases réussies · ${avg} % de mots justes</p>
      <div class="result-chips">${xpChip(r)}</div>${r.capped ? `<p class="muted small">XP déjà gagnés avec cet exercice dans les dernières 24 h : de nouveau dans <b>${P.waitLabel(r.readyAt)}</b>.</p>` : ""}
      <div class="result-actions">
        <a class="btn primary big" href="#dictee" data-reload>Nouvelle dictée</a>
        <a class="btn ghost" href="#entrainement">Autres exercices</a>
      </div>
    </section>`;
    if (avg === 100) celebrate();
  }

  check.onclick = () => { if (!checked) return correct(); i++; if (i >= items.length) finish(); else show(); };
  skip.onclick = () => { if (!checked) correct(true); };
  input.addEventListener("keydown", (e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); check.click(); } });
  show();
  return true;
}

/* Exposé pour les tests */
export const _grade = { gradeIt, gradePinyin, gradeHanzi };
