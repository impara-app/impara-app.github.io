/* =====================================================================
   Vue « Épreuve en conditions réelles » (#epreuve, #epreuve-<palier>)
   Inspirée du format des certifications (CELI pour l'italien, HSK pour
   le mandarin) : trois sections chronométrées, sans correction pendant
   l'épreuve, puis une note sur 100 et la revue des erreurs.
     1. Compréhension orale  : phrases entendues, mots à écrire
     2. Compréhension écrite : phrases à comprendre, questions de langue
     3. Production écrite    : traductions et phrases à compléter
   Rien n'est validé : c'est un entraînement (quelques XP par 24 h).
   ===================================================================== */

import { LEVELS, getLevel, lvlLabel } from "../data/curriculum.js";
import { state, commit } from "../core/storage.js";
import * as P from "../core/progress.js";
import { runQuiz, mistakesHtml } from "../core/quiz-engine.js";
import { esc, shuffle, ring, celebrate, tri, splitDialog } from "../core/ui.js";
import { L } from "../core/lang.js";

const isZh = () => L.label === "Mandarin";
const CERT = () => (isZh() ? "HSK" : "CELI");
export const PASS = 60;
const SECTIONS = [
  { key: "oral", name: "Compréhension orale", emoji: "🎧", min: 8 },
  { key: "lecture", name: "Compréhension écrite", emoji: "📖", min: 8 },
  { key: "ecrit", name: "Production écrite", emoji: "✍️", min: 10 },
];
const N = 10;
const noTones = (s) => s.normalize("NFD").replace(/[̀-ͯ]/g, "");

/** Phrases d'exemple et mots du palier : [{ t, py, fr, ref }] */
function material(level) {
  const ex = [], words = [];
  level.lessons.forEach((l) => {
    (l.sections || []).flatMap((s) => s.examples || []).flatMap(splitDialog).forEach(([t, py, fr]) => {
      if (t && fr && t.length <= (isZh() ? 26 : 90)) ex.push({ t, py, fr: String(fr).split(" — ")[0], ref: `${l.id}:ep` });
    });
    (l.vocab || []).map(tri).forEach(([t, py, fr]) => { if (t && fr) words.push({ t, py, fr, ref: `${l.id}:ep` }); });
  });
  const uniq = (a) => [...new Map(a.map((x) => [x.t, x])).values()];
  return { ex: shuffle(uniq(ex)), words: shuffle(uniq(words)) };
}

/** 3 traductions françaises différentes de la bonne, prises dans le palier */
function distract(pool, good) {
  const out = [];
  for (const x of shuffle(pool)) { if (out.length >= 3) break; if (x.fr !== good && !out.includes(x.fr)) out.push(x.fr); }
  return out;
}
const mcqOf = (good, others) => { const options = shuffle([good, ...others]); return { options, answer: options.indexOf(good) }; };

/** Questions des quiz et de l'examen du palier, d'un type donné */
function bank(level, types) {
  const all = [
    ...level.exam.map((q, i) => ({ ref: `exam-${level.id}:${i}`, q })),
    ...level.lessons.flatMap((l) => l.quiz.map((q, i) => ({ ref: `${l.id}:${i}`, q }))),
  ];
  return shuffle(all.filter((x) => types.includes(x.q.type)));
}

export function buildSections(level) {
  const { ex, words } = material(level);
  const used = new Set();
  const take = (arr, n) => { const out = []; for (const x of arr) { if (out.length >= n) break; if (!used.has(x.t)) { used.add(x.t); out.push(x); } } return out; };

  // 1. Oral : 7 phrases à comprendre + 3 mots à écrire
  const oral = [
    ...take(ex, 7).map((x) => ({ ref: x.ref, q: { type: "listen", say: x.t, q: "Que signifie la phrase entendue ?", ...mcqOf(x.fr, distract(ex, x.fr)), reveal: x.py ? `${x.t} (${x.py})` : x.t } })),
    ...take(words, 3).map((x) => ({ ref: x.ref, q: { type: "listen", write: true, say: x.t, q: isZh() ? "Écrivez le mot entendu (caractères ou pinyin)" : "Écrivez le mot entendu",
      answer: isZh() ? [x.t, x.py, noTones(x.py)].filter(Boolean) : [x.t], reveal: `${x.t}${x.py ? ` ${x.py}` : ""} — ${x.fr}` } })),
  ];
  // 2. Écrit : 5 phrases à lire + 5 questions de langue (QCM)
  const lecture = [
    ...take(ex, 5).map((x) => ({ ref: x.ref, q: { type: "mcq", q: x.t, ...mcqOf(x.fr, distract(ex, x.fr)), explain: x.py ? `${x.py} — ${x.fr}` : "" } })),
    ...bank(level, ["mcq"]).slice(0, N - 5),
  ];
  // 3. Production : traductions et phrases à compléter
  const tr = bank(level, ["translate"]), fi = bank(level, ["fill"]);
  const ecrit = [...tr.slice(0, 5), ...fi.slice(0, N - Math.min(5, tr.length))];
  if (ecrit.length < N) { const seen = new Set(lecture.map((x) => x.ref)); ecrit.push(...bank(level, ["mcq"]).filter((x) => !seen.has(x.ref)).slice(0, N - ecrit.length)); }
  return [oral, lecture, ecrit].map((qs) => shuffle(qs).slice(0, N));
}

/* ------------------------------ Accueil ----------------------------- */
export function renderEpreuveHub(app) {
  const open = LEVELS.map((l, i) => ({ l, i })).filter(({ i }) => P.isLevelUnlocked(i));
  app.innerHTML = `
  <a class="back-link" href="#entrainement">← Entraînement</a>
  <section class="card blanc-intro">
    <p class="eyebrow">Conditions réelles</p>
    <h1>⏱️ Épreuve type ${CERT()}</h1>
    <p class="lead">Trois sections chronométrées, comme le jour d'une certification. Choisissez le niveau :</p>
    <div class="ep-levels">${open.map(({ l }) => { const r = state.epreuve?.[l.id];
      return `<a class="ep-level" href="#epreuve-${l.id}"><b>${esc(lvlLabel(l))}</b><small>${r ? `Meilleure note ${r.best}/100` : "Pas encore tentée"}</small></a>`; }).join("")}</div>
  </section>`;
  return true;
}

export function renderEpreuve(app, levelId) {
  const level = getLevel(levelId), li = LEVELS.indexOf(level);
  if (!level || !P.isLevelUnlocked(li)) return false;
  const rec = state.epreuve?.[levelId];
  const total = SECTIONS.reduce((a, s) => a + s.min, 0);
  app.innerHTML = `
  <a class="back-link" href="#epreuve">← Épreuves</a>
  <section class="card blanc-intro">
    <p class="eyebrow">Conditions réelles · inspirée du ${CERT()}</p>
    <h1>⏱️ Épreuve ${esc(lvlLabel(level))}</h1>
    <p class="lead">${SECTIONS.length * N} questions en ${total} minutes, sans correction pendant l'épreuve.</p>
    <ol class="ep-plan">${SECTIONS.map((s) => `<li><span>${s.emoji}</span><b>${s.name}</b><small>${N} questions · ${s.min} min</small></li>`).join("")}</ol>
    <ul class="defi-rules">
      <li>🔇 Aucune correction avant la fin : comme à l'examen</li>
      <li>⏱️ Chaque section a son chrono ; à zéro, les questions restantes comptent comme fausses</li>
      <li>🎯 Note sur 100 ; ${PASS}/100 pour réussir</li>
      <li>🎧 Mettez des écouteurs : la première section est à l'oral</li>
      <li>🧪 Rien n'est validé ni ajouté au cahier d'erreurs</li>
    </ul>
    ${rec ? `<p class="muted small">Meilleure note : <b>${rec.best}/100</b> · dernière : ${rec.last}/100</p>` : ""}
    <button class="btn primary big" data-go>Commencer l'épreuve</button>
  </section>`;
  app.querySelector("[data-go]").onclick = () => { const secs = buildSections(level); section(app, level, secs, 0, []); };
  return true;
}

/* --------------------------- Déroulement ---------------------------- */
function section(app, level, secs, k, done) {
  const S = SECTIONS[k];
  document.body.classList.add("focus-mode");
  runQuiz(app, {
    title: `${S.emoji} ${S.name} · ${lvlLabel(level)}`,
    questions: secs[k], silent: true, deadline: Date.now() + S.min * 60000,
    countText: (i, n) => `${k + 1}/${SECTIONS.length} · ${i + 1}/${n}`,
    onQuit: () => { document.body.classList.remove("focus-mode"); location.hash = `epreuve-${level.id}`; },
    onFinish: (results) => {
      const all = [...done, results];
      if (k + 1 < SECTIONS.length) return pause(app, level, secs, k + 1, all);
      document.body.classList.remove("focus-mode");
      finish(app, level, all);
    },
  });
}

function pause(app, level, secs, k, done) {
  const S = SECTIONS[k], prev = done[done.length - 1];
  const timeout = prev.some((r) => r.timeout);
  app.innerHTML = `
  <section class="card blanc-intro ep-pause">
    <p class="eyebrow">Section ${k}/${SECTIONS.length} terminée${timeout ? " · temps écoulé" : ""}</p>
    <h1>${S.emoji} Section suivante : ${S.name}</h1>
    <p class="lead">${N} questions · ${S.min} minutes</p>
    <p class="muted small">Les résultats seront affichés à la fin de l'épreuve. Respirez un coup !</p>
    <button class="btn primary big" data-go>Commencer la section</button>
  </section>`;
  app.querySelector("[data-go]").onclick = () => section(app, level, secs, k, done);
}

function finish(app, level, parts) {
  const scores = parts.map((rs) => Math.round((rs.filter((r) => r.correct).length / Math.max(1, rs.length)) * 100));
  const note = Math.round(scores.reduce((a, b) => a + b, 0) / scores.length);
  const ok = note >= PASS;
  const all = parts.flat();
  const right = all.filter((r) => r.correct).length;
  const prev = state.epreuve?.[level.id];
  commit((s) => { s.epreuve = { ...(s.epreuve || {}), [level.id]: { best: Math.max(prev?.best || 0, note), last: note, date: Date.now() } }; });
  const r = P.recordPractice({ label: `Épreuve ${CERT()} ${lvlLabel(level)}`, score: right, total: all.length, xpPer: 3, key: `epreuve-${level.id}` });
  const weak = SECTIONS[scores.indexOf(Math.min(...scores))];
  app.innerHTML = `
  <section class="results ${ok ? "ok" : "ko"}">
    <p class="eyebrow">Épreuve type ${CERT()} · ${esc(lvlLabel(level))}</p>
    ${ring(note, 150, 12)}
    <h1>${note === 100 ? "Note parfaite ! 🏆" : ok ? "Épreuve réussie 🎉" : "Pas encore, mais vous y êtes presque"}</h1>
    <p class="lead"><b>${note}/100</b>${prev && note > prev.best ? " · nouveau record !" : ""}</p>
    <div class="ep-scores">${SECTIONS.map((s, i) => `<div class="ep-score ${scores[i] >= PASS ? "ok" : "ko"}"><span>${s.emoji}</span><b>${scores[i]}</b><small>${s.name}</small></div>`).join("")}</div>
    ${!ok || scores.some((x) => x < PASS) ? `<p class="muted">Point à travailler : <b>${weak.name.toLowerCase()}</b>.</p>` : ""}
    <div class="result-chips">${r.capped ? `<span class="chip muted-chip">⏳ XP déjà gagnés aujourd'hui</span>` : `<span class="chip">⚡ +${r.xpGained} XP</span>`}</div>
    ${mistakesHtml(all, { open: false })}
    <div class="result-actions">
      <a class="btn primary big" href="#epreuve-${level.id}" data-reload>Refaire une épreuve</a>
      <a class="btn ghost" href="#entrainement">Retour à l'entraînement</a>
    </div>
  </section>`;
  if (ok) celebrate();
}
