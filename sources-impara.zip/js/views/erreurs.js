/* =====================================================================
   Vue « Cahier d'erreurs » — révision intelligente
   ===================================================================== */

import { getQuestion, refLabel } from "../data/curriculum.js";
import { state } from "../core/storage.js";
import { MASTERY_STREAK } from "../core/progress.js";
import { esc, plain } from "../core/ui.js";
import { ruby, wantPinyin } from "../core/pinyin.js";

/** Bonne réponse lisible, quel que soit le type de question */
function expected(q) {
  if (q.type === "mcq") return q.options[q.answer];
  if (q.type === "match") return q.pairs.map((p) => `${plain(p[0])} = ${plain(p[1])}`).join(" · ");
  return q.answer[0];
}

export function renderErreurs(app) {
  const items = Object.values(state.errors)
    .map((e) => ({ ...e, q: getQuestion(e.ref), t: wantPinyin(e.ref) ? ruby : esc }))
    .filter((e) => e.q)
    .sort((a, b) => b.count - a.count);

  app.innerHTML = `
  <a class="back-link" href="#entrainement">← Entraînement</a>
  <header class="page-head">
    <p class="eyebrow">Cahier d'erreurs</p>
    <h1>🔁 ${items.length ? `${items.length} notion${items.length > 1 ? "s" : ""} à retravailler` : "Rien à revoir"}</h1>
    <p class="muted">Chaque question ratée est rangée ici. Elle disparaît après <b>${MASTERY_STREAK} bonnes réponses d'affilée</b>. ${state.mastered ? `Déjà <b>${state.mastered}</b> notion(s) maîtrisée(s) !` : ""}</p>
    ${items.length ? `<a class="btn primary big" href="#revision">Lancer une révision (${Math.min(10, items.length)} question${items.length > 1 ? "s" : ""}) →</a>` : ""}
  </header>
  ${items.length ? `<ul class="error-list">${items.map((e) => `
    <li class="card error-item">
      <div class="err-top">
        <span class="tag">${e.t(refLabel(e.ref))}</span>
        <span class="err-count" title="Nombre d'erreurs">✗ ${e.count}</span>
        <span class="err-mastery" title="Progression vers la maîtrise">${"●".repeat(e.streak)}${"○".repeat(MASTERY_STREAK - e.streak)}</span>
      </div>
      <p class="err-q">${e.t(e.q.q)}</p>
      ${e.lastAnswer ? `<p class="err-given">Votre réponse : <s>${e.t(e.lastAnswer)}</s></p>` : ""}
      <p class="err-ok">Bonne réponse : <b>${e.t(expected(e.q))}</b></p>
      ${e.q.explain ? `<p class="err-explain">💡 ${e.t(e.q.explain)}</p>` : ""}
    </li>`).join("")}</ul>`
  : `<div class="empty-state"><span>🌟</span><p>Aucune erreur en attente. Continuez comme ça !</p><a class="btn primary" href="#parcours">Retour au parcours</a></div>`}`;
}
