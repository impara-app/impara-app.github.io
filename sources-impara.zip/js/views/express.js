/* =====================================================================
   Vue « Séance express » (#express) — « J'ai 3 minutes »
   6 questions en 3 minutes maximum, idéale depuis une notification :
   mots à réviser (flashcards), une erreur récente, de l'écoute.
   ===================================================================== */
import { state } from "../core/storage.js";
import { shuffle, ring, esc } from "../core/ui.js";
import { runQuiz, mistakesHtml } from "../core/quiz-engine.js";
import * as P from "../core/progress.js";
import { grade } from "../core/srs.js";
import { mascot, line } from "../core/mascot.js";
import { warmupQuestions } from "./seance.js";
import { listeningQuestions, wordPool } from "./entrainement.js";
import { buildChallengeQuestions } from "../core/challenge-gen.js";

const N = 6, MIN = 3;

function questions() {
  const warm = warmupQuestions();
  const errs = warm.filter((x) => !x.ref.startsWith("srs:")).slice(0, 1);
  const srs = warm.filter((x) => x.ref.startsWith("srs:")).slice(0, 3);
  const listen = listeningQuestions(2);
  let out = [...srs, ...errs, ...listen];
  if (out.length < N) { try { out.push(...buildChallengeQuestions(N - out.length)); } catch {} }
  return shuffle(out).slice(0, N);
}

export function renderExpress(app) {
  if (wordPool().length < 4) {
    app.innerHTML = `<a class="back-link" href="#parcours">← Parcours</a>
    <section class="card blanc-intro"><h1>⚡ Séance express</h1><p class="lead">Terminez une ou deux leçons d'abord : la séance express révise les mots que vous avez appris.</p>
    <a class="btn primary" href="#parcours">Aller au parcours</a></section>`;
    return true;
  }
  const qs = questions();
  const words = new Map(Object.values(state.vocab || {}).map((w) => [w.zh, w]));
  const t0 = Date.now();
  document.body.classList.add("focus-mode");
  runQuiz(app, {
    title: "⚡ Séance express · 3 minutes",
    questions: qs, xpPerAnswer: 5, deadline: Date.now() + MIN * 60000,
    onAnswer: ({ index, correct }) => {
      const ref = qs[index]?.ref || "";
      if (ref.startsWith("srs:gen:")) { const w = words.get(ref.slice(8)); if (w) grade(w, correct ? "good" : "again"); }
    },
    onQuit: () => { document.body.classList.remove("focus-mode"); location.hash = "parcours"; },
    onFinish: (results) => {
      document.body.classList.remove("focus-mode");
      const score = results.filter((r) => r.correct).length, total = results.length;
      const r = P.recordPractice({ label: "Séance express", score, total, xpPer: 5, key: "express" });
      const sec = Math.round((Date.now() - t0) / 1000), pct = Math.round((score / Math.max(1, total)) * 100);
      app.innerHTML = `
      <section class="results ${pct >= 50 ? "ok" : "ko"}">
        <div class="res-hero happy"><span class="res-mascot">${mascot(pct >= 50 ? "cheer" : "idle", { size: 110 })}</span><span class="m-bubble res-bubble">${esc(line(pct >= 50 ? "win" : "good"))}</span></div>
        <h1>${pct === 100 ? "Sans faute, et en express ! ⚡" : "Séance express terminée"}</h1>
        <p class="lead">${score} / ${total} bonnes réponses en ${Math.floor(sec / 60)} min ${String(sec % 60).padStart(2, "0")}</p>
        <div class="res-tiles">
          <div class="rt t-streak"><small>Série</small><b>${P.streakCount()} j</b><span>🔥</span></div>
          <div class="rt t-xp"><small>${r.capped ? "XP" : "Gagnés"}</small><b>${r.capped ? "déjà pris" : `+${r.xpGained}`}</b><span>⚡</span></div>
        </div>
        ${mistakesHtml(results, { open: false })}
        <div class="result-actions">
          <a class="btn primary big" href="#express" data-reload>Encore 3 minutes</a>
          <a class="btn ghost" href="#seance">Séance complète (≈ 10 min)</a>
        </div>
      </section>`;
    },
  });
  return true;
}
