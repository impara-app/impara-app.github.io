/* =====================================================================
   Vue « Leçon » — contenu pédagogique d'une mini-leçon
   ===================================================================== */

import { getLesson, getLevel, MODULES, lvlLabel, lvlBadge } from "../data/curriculum.js";
import { state } from "../core/storage.js";
import { isLessonUnlocked, starsFor } from "../core/progress.js";
import * as P from "../core/progress.js";
import { esc, speakBtn, tri } from "../core/ui.js";
import { L } from "../core/lang.js";
import { pyText, pyHtml } from "../core/pinyin.js";
import { wordsHtml } from "../core/words.js";

export function renderLecon(app, id) {
  const lesson = getLesson(id);
  if (!lesson || !isLessonUnlocked(lesson)) return false; // le routeur redirige
  const level = getLevel(lesson.levelId);
  const mod = MODULES[lesson.module];
  const rec = state.lessons[id];
  const lessons = level.lessons;

  app.innerHTML = `
  <article class="lesson" style="--lvl:${level.color}">
    <a class="back" href="#parcours">← Parcours</a>
    <header class="lesson-head">
      <div class="lesson-emoji">${lesson.emoji}</div>
      <div>
        <p class="eyebrow">${lvlLabel(level)}${level.hsk && !level.label ? ` (${level.hsk})` : ""} · ${mod.icon} ${mod.label} · Leçon ${lesson.index + 1}/${lessons.length}</p>
        <h1>${pyText(level.id, lesson.title)}</h1>
        <p class="lead">${pyHtml(level.id, lesson.intro)}</p>
        ${rec ? `<p class="small muted">Meilleur score : ${rec.best}/${rec.total} ${"★".repeat(P.lessonStars(rec))}</p>` : ""}
      </div>
    </header>

    <nav class="lesson-steps" aria-label="Sections">
      ${lesson.sections.map((s, i) => `<a href="#s${i}" data-scroll="s${i}">${i + 1}. ${pyText(level.id, s.title)}</a>`).join("")}
    </nav>

    ${lesson.sections.map((s, i) => section(s, i, level.id)).join("")}

    <aside class="mnemo">
      <span class="mnemo-icon">🧠</span>
      <div><p class="eyebrow">Astuce mnémotechnique</p><p>${pyHtml(level.id, lesson.mnemo)}</p></div>
    </aside>

    <section class="card">
      <h2 class="h3">📒 Mots de la leçon</h2>
      <p class="small muted">Ils rejoindront vos mots (Entraînement › Mes mots) dès que vous réussirez le quiz.${L.code === "zh" ? " Touchez un mot pour voir les clés de ses caractères." : ""}</p>
      <ul class="vocab-grid">
        ${lesson.vocab.map(tri).map(([w, py, fr]) => `<li class="${py ? "has-py" : ""}">${speakBtn(w)}<span class="it ${L.wordClass}">${L.code === "zh" ? `<span class="wd" data-wd="${esc(w)}" role="button" tabindex="0">${esc(w)}</span>` : esc(w)}</span>${py ? `<span class="py">${esc(py)}</span>` : ""}<span class="fr">${esc(fr)}</span></li>`).join("")}
      </ul>
    </section>

    <div class="lesson-cta">
      <p>${P.LESSON_QUIZ_N} questions · 80 % pour valider (${Math.ceil(P.PASS_LESSON * P.LESSON_QUIZ_N)}/${P.LESSON_QUIZ_N})</p>
      <a class="btn primary big" href="#quiz-${lesson.id}">Je suis prêt·e : quiz →</a>
    </div>
  </article>`;
  return true;
}

export function section(s, i, lv) {
  return `
  <section class="card lesson-section" id="s${i}">
    <h2 class="h3"><span class="num">${i + 1}</span><span>${pyText(lv, s.title)}</span></h2>
    ${s.text ? `<p>${pyHtml(lv, s.text)}</p>` : ""}
    ${s.table ? table(s.table, lv) : ""}
    ${s.examples ? `<ul class="examples">${s.examples
      .map(tri).map(([w, py, fr]) => `<li>${speakBtn(w)}<div><span class="it ${L.wordClass}">${wordsHtml(w)}</span>${py ? `<span class="py">${esc(py)}</span>` : ""}<span class="fr">${esc(fr)}</span></div></li>`)
      .join("")}</ul>` : ""}
  </section>`;
}

export function table({ cols, rows }, lv) {
  const hasHead = cols.some((c) => c);
  return `<div class="table-wrap"><table>
    ${hasHead ? `<thead><tr>${cols.map((c) => `<th>${pyText(lv, c)}</th>`).join("")}</tr></thead>` : ""}
    <tbody>${rows.map((r) => `<tr>${r.map((c, k) => `<td class="${k === 0 && hasHead ? "first" : ""}">${pyText(lv, c)}</td>`).join("")}</tr>`).join("")}</tbody>
  </table></div>`;
}
