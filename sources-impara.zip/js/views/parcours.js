/* =====================================================================
   Vue « Parcours » — carte des paliers A1 → C2 (accueil)
   ===================================================================== */

import { LEVELS, MODULES, lvlLabel, lvlBadge } from "../data/curriculum.js";
import { srsStats } from "../core/srs.js";
const srsTodo = () => srsStats(Object.values(state.vocab)).todo;
import { state } from "../core/storage.js";
import * as P from "../core/progress.js";
import { esc } from "../core/ui.js";
import { pyText } from "../core/pinyin.js";
import { L, code } from "../core/lang.js";
import { mascot, mascotName, line, buddy } from "../core/mascot.js";
import { icon, moduleIcon } from "../core/icons.js";
import { runTour } from "../core/tour.js";
import { wordOfDay } from "../core/wotd.js";
import { commit } from "../core/storage.js";
import { toast, speakBtn } from "../core/ui.js";

/* Décor de chaque palier : une ville ou un paysage du pays */
const SCENES = {
  it: {
    A1: ["Roma", "🏛️", ["#ffd9a8", "#fff1db"], "#c8794a"], A2: ["Venezia", "🛶", ["#bfe3f2", "#eef8fb"], "#4f97b3"],
    B1: ["Firenze", "⛪", ["#ffd2b5", "#fff0e4"], "#b8673c"], B2: ["Milano", "🏙️", ["#d6dcf5", "#f3f5fc"], "#6f79a8"],
    C1: ["Napoli", "🌋", ["#ffc9c0", "#ffeeea"], "#a4504a"], C2: ["Sicilia", "🏝️", ["#b8ecdf", "#ecfbf6"], "#3c9a83"],
  },
  zh: {
    A1: ["北京 Pékin", "🏯", ["#ffd0c7", "#fff0ec"], "#b8453a"], A2: ["上海 Shanghai", "🌆", ["#d9d2f7", "#f4f1fd"], "#6c5bb3"],
    B1: ["长城 La Grande Muraille", "⛰️", ["#cfe8c8", "#f0f9ee"], "#5c8f4f"], B2: ["西安 Xi'an", "🏮", ["#ffd8a6", "#fff3e0"], "#b9772d"],
    C1: ["桂林 Guilin", "🏞️", ["#bfe6e0", "#ecf8f6"], "#3f8f84"], C2: ["香港 Hong Kong", "🌃", ["#c9d3ec", "#eef1f9"], "#4a5b8f"],
  },
};
function scene(lvl) {
  const sc = SCENES[code]?.[lvl.id];
  if (!sc) return "";
  const [place, icon, [sky1, sky2], ground] = sc;
  return `<div class="level-scene" style="--sky1:${sky1};--sky2:${sky2};--ground:${ground}" aria-hidden="true">
    <span class="sc-cloud c1">☁️</span><span class="sc-cloud c2">☁️</span>
    <svg class="sc-hills" viewBox="0 0 400 60" preserveAspectRatio="none"><path d="M0,42 C60,18 110,22 160,36 C210,50 250,20 310,26 C350,30 380,40 400,34 L400,60 L0,60 Z" fill="var(--ground)" opacity=".35"/>
      <path d="M0,52 C70,38 120,46 190,50 C260,54 320,38 400,46 L400,60 L0,60 Z" fill="var(--ground)" opacity=".6"/></svg>
    <span class="sc-icon">${icon}</span>
    <span class="sc-place">📍 ${place}</span>
  </div>`;
}

// Décalage horizontal des nœuds pour dessiner un chemin sinueux
const OFFSETS = [0, 56, 84, 56, 0, -56, -84, -56];

/* « Séance du jour » : état lu directement (la vue complète est chargée à la demande) */
function seanceState() {
  const d = new Date(), today = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
  const p = state.seance?.date === today ? state.seance : null;
  return p ? { done: p.steps.filter((x) => x.done).length, total: p.steps.length, finished: !!p.finished } : { done: 0, total: 0, finished: false };
}
function seanceCard(se) {
  if (se.finished) return `<a class="se-card finished" href="#seance"><span class="se-c-ico">${icon("check", { size: 20, stroke: 3.2 })}</span><span class="se-c-txt"><b>Séance du jour terminée</b><small>Bravo ! La prochaine sera prête demain.</small></span></a>`;
  const pct = se.total ? Math.round((se.done / se.total) * 100) : 0;
  return `<a class="se-card" href="#seance">
    <span class="se-c-ico">${icon("play", { size: 24, stroke: 2.5, fill: "currentColor" })}</span>
    <span class="se-c-txt"><b>${se.done ? "Reprendre la séance du jour" : "Séance du jour"}</b>
      <small>${se.done ? `${se.done}/${se.total} étapes faites · on termine ?` : "≈ 10 min · révisions, nouvelle leçon et écoute"}</small>
      ${se.done ? `<span class="se-c-bar"><i style="width:${pct}%"></i></span>` : ""}</span>
    <span class="se-c-go" aria-hidden="true">→</span></a>`;
}

/** Carte « Mot du jour » */
function wotdCard() {
  const x = wordOfDay();
  if (!x || state.wotdDone === x.day) return "";
  return `<section class="card wotd" aria-label="Mot du jour">
    <div class="wotd-head"><p class="eyebrow">✨ Mot du jour</p><button type="button" class="wotd-done" data-wotd-done="${x.day}" aria-label="Mot du jour vu : le masquer jusqu'à demain" title="Vu ! (masqué jusqu'à demain)">✓</button></div>
    <div class="wotd-main">${speakBtn(x.w)}<div><b class="wotd-w ${L.wordClass}">${esc(x.w)}</b>${x.py ? `<span class="wotd-py">${esc(x.py)}</span>` : ""}<span class="wotd-fr">${esc(x.fr)}</span></div></div>
    ${x.ex ? `<p class="wotd-ex"><button class="speak mini" data-speak="${esc(x.ex.t)}" aria-label="Écouter l'exemple">🔊</button><span><span class="${L.wordClass}">${esc(x.ex.t)}</span>${x.ex.py ? `<small class="py">${esc(x.ex.py)}</small>` : ""}<small>${esc(x.ex.fr)}</small></span></p>` : ""}
    ${x.known ? `<p class="wotd-known small muted">✓ Déjà dans votre carnet</p>` : `<button class="btn ghost small" data-wotd-add>＋ Ajouter au carnet</button>`}
  </section>`;
}

export function renderParcours(app) {
  bindPops();
  const g = P.globalProgress();
  const next = P.nextStep();
  const pseudo = esc(state.profile?.pseudo || "");
  const se = seanceState();

  app.innerHTML = `
    <section class="hero">
      <div class="hero-main">
        <button class="hero-mascot" type="button" aria-label="${mascotName()}">${mascot("idle", { size: 86 })}<span class="m-bubble">${esc(line(P.streakCount() ? "welcome" : "welcome"))}</span></button>
        <p class="eyebrow">${L.hello} ${pseudo} 👋</p>
        ${seanceCard(se)}
        ${next
          ? `<a class="btn ${se.finished ? "primary big" : "ghost hero-next"}" href="#${P.stepHref(next)}">
               ${se.finished ? "" : "Ou directement : "}${next.kind === "lesson" ? `${se.finished ? "Continuer : " : ""}${pyText(next.lesson.levelId, next.lesson.title)}` : next.kind === "checkpoint" ? `Test de mi-palier ${lvlLabel(next.level)}` : `Passer l'examen ${lvlLabel(next.level)}`} →</a>`
          : `<p class="badge-done">🏆 Parcours terminé — ${L.done}</p>`}
        ${!state.placement && !Object.keys(state.lessons).length ? `<div class="hero-links"><a class="btn ghost small" href="#test-niveau">🧭 Déjà des bases ? Test de niveau</a></div>` : ""}
        ${se.finished && srsTodo() ? `<div class="hero-links"><a class="btn ghost small" href="#reviser">📅 ${srsTodo()} mot${srsTodo() > 1 ? "s" : ""} à réviser</a></div>` : ""}
      </div>
      <div class="hero-meter" aria-label="Progression globale ${g.pct} %">
        <div class="meter-track"><span style="width:${g.pct}%"></span></div>
        <div class="meter-labels">${LEVELS.map((l, i) => `<span class="${P.isLevelUnlocked(i) ? "on" : ""}">${lvlLabel(l)}</span>`).join("")}</div>
      </div>
    </section>

    ${wotdCard()}
    <div class="path">
      ${LEVELS.map((lvl, li) => levelBlock(lvl, li)).join("")}
    </div>`;
  drawPaths(app);
  app.querySelector("[data-wotd-done]")?.addEventListener("click", (e) => {
    const day = e.currentTarget.dataset.wotdDone, card = e.currentTarget.closest(".wotd");
    commit((s) => { s.wotdDone = day; });
    card.classList.add("gone");
    setTimeout(() => card.remove(), 320);
    toast("✓ Mot du jour vu : le prochain arrive demain", "ok");
  });
  app.querySelector("[data-wotd-add]")?.addEventListener("click", (e) => {
    const x = wordOfDay();
    commit((s) => { if (!s.vocab[x.w]) s.vocab[x.w] = { zh: x.w, py: x.py, fr: x.fr, levelId: x.levelId, lessonId: x.lessonId, added: Date.now(), from: "mot du jour" }; });
    e.currentTarget.outerHTML = `<p class="wotd-known small muted">✓ Ajouté au carnet</p>`;
    toast("Mot ajouté au carnet ✓", "ok");
  });
  // La mascotte réagit quand on la touche
  const mb = app.querySelector(".hero-mascot");
  mb?.addEventListener("click", () => {
    mb.innerHTML = `${mascot(Math.random() < .5 ? "cheer" : "happy", { size: 86 })}<span class="m-bubble">${esc(line(Math.random() < .5 ? "good" : "welcome"))}</span>`;
    mb.classList.remove("hop"); void mb.offsetWidth; mb.classList.add("hop");
  });
  // Mascottes du parcours : une petite réplique au toucher
  app.querySelectorAll(".buddy").forEach((b) => b.addEventListener("click", (e) => {
    e.stopPropagation();
    app.querySelectorAll(".buddy .m-bubble").forEach((x) => x.remove());
    b.insertAdjacentHTML("beforeend", `<span class="m-bubble bd-bubble">${esc(line(Math.random() < .5 ? "welcome" : "good"))}</span>`);
    b.classList.remove("hop"); void b.offsetWidth; b.classList.add("hop");
    clearTimeout(b._t); b._t = setTimeout(() => b.querySelector(".m-bubble")?.remove(), 3500);
  }));
  const redraw = () => drawPaths(app);
  addEventListener("resize", redraw);
  document.fonts?.ready.then(redraw);
  app._cleanup = () => removeEventListener("resize", redraw);
  // Premier lancement : après la première leçon, 3 bulles d'aide (séance du jour, série, XP)
  const newbie = (state.profile?.createdAt || 0) > Date.parse("2026-11-04T20:00:00Z");
  if (newbie && !state.settings.tours?.first && Object.values(state.lessons).some((l) => l.passed)) {
    setTimeout(() => location.hash === "#parcours" || !location.hash ? runTour([
      { sel: ".se-card", title: "La séance du jour", text: "Environ 10 minutes chaque jour : révisions, nouvelle leçon et écoute. C'est la façon la plus simple de progresser." },
      { sel: "#hdr-streak-pill", title: "Votre série", text: "Faites au moins un exercice par jour pour allumer la flamme. Chaque jour d'affilée fait grandir votre série." },
      { sel: [".tabbar [data-tab=tableau]", ".topnav [data-tab=tableau]"], title: "Vos XP", text: "Chaque bonne réponse rapporte des XP. Objectif du jour, progression et statistiques : tout est dans Suivi." },
    ], "first") : null, 700);
  }
}

/* ----------- Chemin dessiné entre les nœuds (coloré quand c'est fait) ----------- */
function drawPaths(app) {
  app.querySelectorAll("ol.nodes").forEach((ol) => {
    ol.querySelector(":scope > svg.trail")?.remove();
    const nodes = [...ol.querySelectorAll(":scope > .node-wrap > .node")];
    if (nodes.length < 2) return;
    const box = ol.getBoundingClientRect();
    if (!box.width) return;
    const pts = nodes.map((n) => { const r = n.getBoundingClientRect(); return { x: r.left - box.left + r.width / 2, y: r.top - box.top + r.height / 2, done: n.classList.contains("done") }; });
    let segs = "";
    for (let k = 0; k < pts.length - 1; k++) {
      const a = pts[k], b = pts[k + 1], dy = b.y - a.y;
      const d = `M${a.x.toFixed(1)},${a.y.toFixed(1)} C${a.x.toFixed(1)},${(a.y + dy * .55).toFixed(1)} ${b.x.toFixed(1)},${(b.y - dy * .55).toFixed(1)} ${b.x.toFixed(1)},${b.y.toFixed(1)}`;
      const lit = a.done && (b.done || !nodes[k + 1].classList.contains("locked"));
      segs += `<path class="${lit ? "lit" : "dim"}" d="${d}"/>`;
    }
    ol.insertAdjacentHTML("afterbegin", `<svg class="trail" aria-hidden="true" width="${box.width}" height="${box.height}" viewBox="0 0 ${box.width.toFixed(1)} ${box.height.toFixed(1)}">${segs}</svg>`);
  });
}

function levelBlock(lvl, li) {
  const unlocked = P.isLevelUnlocked(li);
  const prog = P.levelProgress(li);
  const examOpen = P.isExamUnlocked(li);
  const examDone = P.isExamPassed(lvl.id);
  const examOffset = OFFSETS[lvl.lessons.length % OFFSETS.length];

  return `
  <section class="level ${unlocked ? "" : "locked"}" style="--lvl:${lvl.color}" id="palier-${lvl.id}">
    ${scene(lvl)}
    <header class="level-head">
      <div class="level-badge">${lvlBadge(lvl)}</div>
      <div class="level-info">
        <p class="eyebrow">${lvl.emoji} Palier ${lvlLabel(lvl)} · ${lvl.name}${lvl.hsk && !lvl.label ? ` · repère ${lvl.hsk}` : ""}</p>
        <h2>${pyText(lvl.id, lvl.title)}</h2>
        <p class="muted small">${pyText(lvl.id, lvl.desc)}</p>
      </div>
      <div class="level-prog">
        ${unlocked ? `<span>${prog.pct}%</span><div class="mini-bar"><i style="width:${prog.pct}%"></i></div>` : `<span class="lock">${icon("lock", { size: 20 })}</span>`}
      </div>
    </header>
    ${unlocked ? "" : `<p class="level-locked-msg">Réussissez l'examen ${lvlLabel(LEVELS[li - 1])} pour débloquer ce palier.</p>`}
    <ol class="nodes">
      ${lvl.lessons.map((lesson, i) => (i === P.checkpointIndex(lvl) ? checkpointNode(lvl, li, unlocked) : "") + node(lesson, OFFSETS[i % OFFSETS.length], i % 4 === 2 ? li * 3 + (i >> 2) : -1)).join("")}
      <li class="node-wrap" style="--x:${examOffset}px">
        <a class="node exam ${examDone ? "done" : examOpen ? "open" : "locked"}"
           ${examOpen ? `href="#examen-${lvl.id}"` : `aria-disabled="true"`}
           ${examOpen ? popData({ title: `Examen ${lvlLabel(lvl)}`, sub: `${P.EXAM_N} questions · sans faute requis · 🃏 ${P.JOKERS_EXAM} jokers pour les fautes de frappe`, note: examDone ? `Validé avec ${state.exams[lvl.id].best}/${state.exams[lvl.id].total}` : "Entraînez-vous d'abord avec un examen blanc", cta: examDone ? "Repasser l'examen" : "Passer l'examen", href: `#examen-${lvl.id}`, alt: "Examen blanc", altHref: `#blanc-${lvl.id}` })
             : popData({ title: `Examen ${lvlLabel(lvl)}`, locked: "1", sub: `${P.EXAM_N} questions · sans faute (100 %) requis`, note: "🔒 Terminez toutes les leçons du palier (et le test de mi-palier) pour passer l'examen.", alt: unlocked ? "S'entraîner avec un examen blanc" : "", altHref: `#blanc-${lvl.id}` })}
           aria-label="Examen de fin de palier ${lvlLabel(lvl)}${examDone ? ", validé" : examOpen ? "" : ", verrouillé"}">
          <span class="node-icon">${icon(examDone ? "trophy" : examOpen ? "grad" : "lock", { size: 38, stroke: 2.4 })}</span>
        </a>
        ${unlocked ? `<a class="blanc-link" href="#blanc-${lvl.id}">📝 Examen blanc${state.blanc?.[lvl.id] ? ` · ${state.blanc[lvl.id].best}/${state.blanc[lvl.id].total}` : ""}</a><a class="blanc-link" href="#epreuve-${lvl.id}">⏱️ Épreuve chronométrée${state.epreuve?.[lvl.id] ? ` · ${state.epreuve[lvl.id].best}/100` : ""}</a>` : ""}
      </li>
    </ol>
  </section>`;
}

function checkpointNode(lvl, li, unlocked) {
  const done = P.isCheckpointPassed(lvl), open = P.isCheckpointUnlocked(li), rec = state.checkpoints?.[P.ckKey(lvl.id)];
  return `<li class="node-wrap cp-wrap">
    <a class="node checkpoint ${done ? "done" : open ? "open" : "locked"}" ${open ? `href="#mipalier-${lvl.id}"` : `aria-disabled="true"`}
       ${open ? popData({ title: `Test de mi-palier ${lvlLabel(lvl)}`, sub: `${P.CHECKPOINT_N} questions sur la 1re moitié du palier · sans faute requis · 🃏 ${P.JOKERS_CHECKPOINT} jokers pour les fautes de frappe`, note: done && rec ? `Validé avec ${rec.best}/${rec.total}` : "", cta: done ? "Refaire le test" : "Commencer le test", href: `#mipalier-${lvl.id}` })
         : popData({ title: `Test de mi-palier ${lvlLabel(lvl)}`, locked: "1", sub: `${P.CHECKPOINT_N} questions · sans faute (100 %) requis`, note: "🔒 Terminez d'abord les leçons de la 1re moitié du palier." })}
       aria-label="Test de mi-palier ${lvlLabel(lvl)}${done ? ", validé" : open ? "" : ", verrouillé"}">
      <span class="node-icon">${icon(done ? "shield-check" : open ? "shield" : "lock", { size: 32, stroke: 2.5 })}</span></a>
  </li>`;
}

/** Attributs data-* décrivant la bulle « Commencer » d'un nœud */
function popData(o) {
  return Object.entries(o).filter(([, v]) => v != null && v !== "").map(([k, v]) => `data-pop-${k}="${esc(v)}"`).join(" ");
}

/* --------- Bulle d'un nœud : un clic l'ouvre, le bouton lance le cours --------- */
function closePop() {
  document.querySelectorAll(".node-pop").forEach((x) => { x.closest(".node-wrap")?.classList.remove("has-pop"); x.remove(); });
  document.querySelectorAll(".node.popped").forEach((x) => x.classList.remove("popped"));
}
function openPop(nodeEl) {
  const d = nodeEl.dataset, wrap = nodeEl.closest(".node-wrap");
  closePop();
  nodeEl.classList.add("popped");
  wrap.classList.add("has-pop"); // la bulle passe au-dessus des nœuds suivants
  const title = d.popLv ? pyText(d.popLv, d.popTitle) : esc(d.popTitle);
  wrap.insertAdjacentHTML("beforeend", `<div class="node-pop ${d.popLocked ? "locked" : nodeEl.classList.contains("perfect") ? "perfect" : nodeEl.classList.contains("done") ? "done" : ""}" role="dialog">
    <b class="np-title">${title}</b>
    ${d.popSub ? `<small class="np-sub">${esc(d.popSub)}</small>` : ""}
    ${d.popNote ? `<small class="np-note">${esc(d.popNote)}</small>` : ""}
    ${d.popCta ? `<a class="np-cta" href="${esc(d.popHref)}">${esc(d.popCta)}</a>` : `<span class="np-cta np-locked">🔒 Verrouillé</span>`}
    ${d.popAlt ? `<a class="np-alt" href="${esc(d.popAlthref)}">${esc(d.popAlt)}</a>` : ""}
  </div>`);
  const pop = wrap.querySelector(".node-pop");
  // Bas du palier (examen…) : la bulle s'ouvre au-dessus pour ne pas être coupée
  const box = wrap.closest(".level")?.getBoundingClientRect();
  if (box && pop.getBoundingClientRect().bottom > box.bottom - 8) pop.classList.add("up");
  requestAnimationFrame(() => pop.classList.add("in"));
  pop.querySelector("a.np-cta, a.np-alt")?.focus({ preventScroll: true });
  const r = pop.getBoundingClientRect();
  if (r.bottom > innerHeight - 80) scrollBy({ top: r.bottom - innerHeight + 100, behavior: "smooth" });
}
let popBound = false;
function bindPops() {
  if (popBound) return; popBound = true;
  document.addEventListener("click", (e) => {
    const n = e.target.closest(".nodes a.node[data-pop-title]");
    if (n) {
      e.preventDefault(); e.stopPropagation();
      if (n.classList.contains("popped")) closePop(); else openPop(n);
      return;
    }
    if (!e.target.closest(".node-pop")) closePop();
  }, true);
  document.addEventListener("keydown", (e) => { if (e.key === "Escape") closePop(); });
  window.addEventListener("hashchange", closePop);
}

function node(lesson, x, buddyN = -1) {
  const done = P.isLessonDone(lesson.id);
  const open = P.isLessonUnlocked(lesson);
  const rec = state.lessons[lesson.id];
  const stars = P.lessonStars(rec);
  const mod = MODULES[lesson.module];
  const isCurrent = open && !done;

  const perfect = done && stars === 3;
  const lvl = LEVELS[lesson.levelIndex];
  const pop = !open ? popData({
    title: lesson.title, lv: lesson.levelId, locked: "1",
    sub: `Leçon ${lesson.index + 1}/${lvl.lessons.length} · ${mod.icon} ${mod.label}`,
    note: "🔒 Terminez les étapes précédentes pour débloquer cette leçon.",
  }) : popData({
    title: lesson.title, lv: lesson.levelId,
    sub: done ? `${"★".repeat(stars)}${"☆".repeat(3 - stars)} · meilleur score ${rec.best}/${rec.total}` : `Leçon ${lesson.index + 1}/${lvl.lessons.length} · ${mod.icon} ${mod.label}`,
    note: done && !perfect ? "Refaites le quiz sans faute pour obtenir les 3 étoiles 👑" : perfect ? "Leçon maîtrisée à la perfection 👑" : "",
    cta: done ? "Revoir la leçon" : "Commencer", href: `#lecon-${lesson.id}`,
    alt: done ? (perfect ? "Refaire le quiz" : "Viser les 3 étoiles") : "", altHref: `#quiz-${lesson.id}`,
  });
  return `
  <li class="node-wrap" style="--x:${x}px">
    <a class="node ${done ? "done" : open ? "open" : "locked"} ${perfect ? "perfect" : ""} ${isCurrent ? "current" : ""}"
       ${open ? `href="#lecon-${lesson.id}"` : `aria-disabled="true"`} ${pop}
       aria-label="${esc(lesson.title)}${perfect ? ", 3 étoiles" : done ? ", terminée" : open ? "" : ", verrouillée"}">
      <span class="node-icon">${open ? moduleIcon(lesson.module, { size: 34, stroke: 2.5 }) : icon("lock", { size: 28, stroke: 2.5 })}</span>
      ${perfect ? `<span class="node-crown" aria-hidden="true">${icon("crown", { size: 24, stroke: 2, fill: "#ffd24a" })}</span>` : ""}
      ${isCurrent ? `<span class="node-start">Commencer</span>` : ""}
    </a>
    ${done ? `<span class="node-stars" aria-hidden="true">${"★".repeat(stars)}${"☆".repeat(3 - stars)}</span>` : ""}
    ${buddyN >= 0 ? `<button type="button" class="buddy ${x > 0 ? "left" : "right"}" aria-label="${esc(mascotName())}">${buddy(buddyN)}</button>` : ""}
  </li>`;
}
