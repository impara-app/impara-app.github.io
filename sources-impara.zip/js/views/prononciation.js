/* =====================================================================
   Vue « Prononciation » (#prononciation)
   Vous lisez le mot à voix haute. La reconnaissance vocale du
   navigateur dit ce qu'elle a entendu (texte en direct), et la voix
   est enregistrée en même temps pour pouvoir la réécouter.
   En mandarin, la hauteur de la voix est analysée syllabe par syllabe
   (js/core/pitch.js) : chaque ton est jugé même si la reconnaissance
   vocale du chinois n'est pas disponible sur l'appareil.
   ===================================================================== */

import { L, code } from "../core/lang.js";
import { esc, shuffle, speak, ring, celebrate, stopSpeaking } from "../core/ui.js";
import * as P from "../core/progress.js";
import { wordPool, xpChip } from "./entrainement.js";
import { PINYIN_MAP as MAP } from "../core/pinyin.js";
import { startRecorder, analyse, toWav, tonesOf, sandhi } from "../core/pitch.js";
import { reportButton, setReportContext } from "../core/report.js";

const SR = typeof window !== "undefined" && (window.SpeechRecognition || window.webkitSpeechRecognition);
export const canRecognize = () => !!SR;
const isZh = () => code === "zh";
const HAN = /[㐀-鿿]/g;
const N = 10;

/* -------------------------- Comparaison ---------------------------- */
const stripAcc = (s) => s.normalize("NFD").replace(/[̀-ͯ]/g, "");
const norm = (s) => stripAcc(String(s).toLowerCase()).replace(/['’]/g, " ").replace(/[^a-z0-9 ]/g, " ").replace(/\s+/g, " ").trim();

function lev(a, b) {
  const d = Array.from({ length: a.length + 1 }, (_, i) => [i]);
  for (let j = 1; j <= b.length; j++) d[0][j] = j;
  for (let i = 1; i <= a.length; i++) for (let j = 1; j <= b.length; j++)
    d[i][j] = Math.min(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1));
  return d[a.length][b.length];
}
const sim = (a, b) => (a || b ? 1 - lev(a, b) / Math.max(a.length, b.length) : 1);

// Pinyin des caractères reconnus : bibliothèque complète si le réseau le permet, sinon le dictionnaire du cours
let PP = null;
const loadPinyin = () => (PP ||= import("https://cdn.jsdelivr.net/npm/pinyin-pro@3.26.0/+esm").then((m) => m.pinyin).catch(() => null));
async function pyOf(text) {
  const chars = (text.match(HAN) || []).join("");
  if (!chars) return [];
  const fn = await loadPinyin();
  if (fn) return fn(chars, { type: "array" });
  return [...chars].map((c) => MAP[c] || "?");
}
const toneless = (s) => stripAcc(s).replace(/ü/g, "v").toLowerCase();

/** Note un essai : { level: "perfect" | "good" | "tone" | "miss", heard, note } */
async function grade(word, alts) {
  if (!isZh()) {
    const target = norm(word.zh).replace(/^(il|lo|la|l|i|gli|le|un|una|uno) /, "");
    let best = { s: 0, heard: alts[0] || "" };
    for (const a of alts) {
      const h = norm(a);
      const s = h.includes(target) ? 1 : Math.max(sim(h, target), sim(h, norm(word.zh)));
      if (s > best.s) best = { s, heard: a };
    }
    if (best.s >= 0.95) return { level: "perfect", heard: best.heard };
    if (best.s >= 0.75) return { level: "good", heard: best.heard, note: "Presque parfait : écoutez le modèle et comparez." };
    return { level: "miss", heard: best.heard };
  }
  const target = (word.zh.match(HAN) || []).join("");
  const want = (word.py ? word.py.toLowerCase().replace(/['’]/g, " ").split(/\s+/).join("") : (await pyOf(target)).join(""));
  let best = { level: "miss", heard: alts[0] || "" };
  for (const a of alts) {
    const chars = (a.match(HAN) || []).join("");
    if (chars.includes(target)) return { level: "perfect", heard: a };
    const got = (await pyOf(chars)).join("");
    if (!got) continue;
    if (got.includes(want)) return { level: "good", heard: a, note: `Homophone reconnu (${got}) : la prononciation et les tons sont bons.` };
    if (toneless(got).includes(toneless(want)) && best.level === "miss") best = { level: "tone", heard: a, note: `J'ai entendu « ${got} » : les sons sont bons, mais attention aux tons (« ${word.py} »).` };
  }
  return best;
}

/* ------------------------------ Vue -------------------------------- */
// Courbes « modèles » des tons (demi-tons autour du milieu de la voix), pour le dessin
const MODEL = {
  1: [3, 3, 3, 3, 3, 3, 3, 3, 3],
  2: [-1.5, -1.7, -1.3, -0.5, 0.6, 1.8, 3, 4, 4.6],
  3: [-1, -2.4, -3.6, -4.4, -4.8, -4.6, -3.8, -2.6, -1.4],
  4: [4, 3.8, 3.2, 2.2, 0.8, -0.8, -2.4, -3.8, -5],
};
const TONE_SHORT = { 1: "1er ton", 2: "2e ton", 3: "3e ton", 4: "4e ton", 5: "ton neutre" };

/** Petit graphique : courbe attendue (pointillés) et la vôtre (trait plein) */
function curveSvg(want, got) {
  const W = 72, H = 44, y = (v) => (H / 2 - Math.max(-7, Math.min(7, v)) * (H / 16)).toFixed(1);
  const path = (c) => c.map((v, i) => `${i ? "L" : "M"}${(4 + (i * (W - 8)) / (c.length - 1)).toFixed(1)} ${y(v)}`).join(" ");
  const m = MODEL[want];
  return `<svg class="pc-svg" viewBox="0 0 ${W} ${H}" width="${W}" height="${H}" aria-hidden="true">
    ${m ? `<path class="pc-model" d="${path(m)}"/>` : `<circle class="pc-model-dot" cx="${W / 2}" cy="${H / 2}" r="3"/>`}
    ${got && got.length > 2 ? `<path class="pc-you" d="${path(got)}"/>` : ""}</svg>`;
}

// Repère de hauteur de la voix de l'utilisateur (moyenne glissante), pour mieux juger « haut » et « grave »
const REF_KEY = "impara.voiceRef";
function voiceRef() { try { const r = JSON.parse(localStorage.getItem(REF_KEY) || "null"); return r && r.n >= 3 ? r.hz : 0; } catch { return 0; } }
function learnVoice(hz) {
  try {
    const r = JSON.parse(localStorage.getItem(REF_KEY) || "null") || { hz, n: 0 };
    r.hz = r.n ? r.hz * 0.8 + hz * 0.2 : hz; r.n++;
    localStorage.setItem(REF_KEY, JSON.stringify(r));
  } catch {}
}
// iPhone : si la reconnaissance vocale ne marche pas en même temps que l'enregistrement, on les sépare
const SOLO_KEY = "impara.pron.solo";
const soloMode = () => { try { return localStorage.getItem(SOLO_KEY) === "1"; } catch { return false; } };

export function renderPrononciation(app) {
  const canRecord = !!navigator.mediaDevices?.getUserMedia;
  if (!SR && !(isZh() && canRecord)) {
    app.innerHTML = `<a class="back-link" href="#entrainement">← Entraînement</a>
    <section class="card empty-state"><p class="big-emoji">🎤</p><h1 class="h3">Reconnaissance vocale indisponible</h1>
      <p class="muted">Ce navigateur ne sait pas reconnaître la voix. Utilisez <b>Chrome</b> (ordinateur ou Android) ou <b>Safari</b> sur iPhone.</p></section>`;
    return true;
  }
  const pool = wordPool().filter((w) => w.zh.length <= (isZh() ? 6 : 24) && (!isZh() || w.py));
  if (pool.length < 3) return false;
  const words = shuffle(pool).slice(0, N);
  let i = 0, score = 0, tries = 0, scored = false, busy = false, session = null, voiceUrl = null, hintShown = false;

  document.body.classList.add("focus-mode");
  app.innerHTML = `
  <section class="pron">
    <div class="story-top">
      <button class="btn ghost small" data-quit aria-label="Quitter">✕</button>
      <div class="progress"><span class="story-bar"></span></div>
      ${reportButton()}
    </div>
    <div class="card pron-card">
      <div class="pron-word"></div><p class="pron-py py"></p><p class="pron-fr muted"></p>
      <div class="btn-row center"><button class="btn ghost small" data-model>🔊 Modèle</button><button class="btn ghost small" data-slow>🐢 Lentement</button><button class="btn ghost small" data-me hidden>▶ Ma voix</button></div>
    </div>
    <button class="mic" data-mic aria-label="Appuyez puis parlez"><span>🎤</span></button>
    <p class="pron-hint muted small"></p>
    <p class="pron-live" aria-live="polite"></p>
    <div class="pron-res" aria-live="polite"></div>
    <div class="story-foot"><button class="btn ghost" data-skip>Passer</button><button class="btn primary" data-next hidden>Suivant →</button></div>
  </section>`;

  const $ = (s) => app.querySelector(s);
  const HINT = "Appuyez sur le micro et dites le mot.";
  const cleanup = () => { try { session?.cancel(); } catch {} session = null; if (voiceUrl) URL.revokeObjectURL(voiceUrl); voiceUrl = null; };
  const quit = () => { cleanup(); document.body.classList.remove("focus-mode"); location.hash = "entrainement"; };
  $("[data-quit]").onclick = quit;

  // Syllabes du mot (mandarin) : caractère, pinyin, ton attendu (avec les changements de ton à l'oral)
  function syllables(w) {
    const chars = (w.zh.match(HAN) || []);
    const pys = w.py.toLowerCase().replace(/[^a-zāáǎàēéěèīíǐìōóǒòūúǔùǖǘǚǜü\s'’]/g, " ").split(/[\s'’]+/).filter(Boolean);
    const cit = tonesOf(w.py), oral = sandhi(chars, cit);
    return cit.map((t, k) => ({ ch: chars.length === cit.length ? chars[k] : "", py: pys[k] || "", cit: t, want: oral[k] }));
  }

  function wordHtml(w, marks) {
    if (!isZh()) return `<p class="pron-it">${esc(w.zh)}</p>`;
    const syl = syllables(w);
    return `<div class="pc-row">${syl.map((s, k) => {
      const m = marks?.[k];
      return `<div class="pc ${m ? m.st : ""}">
        <span class="pc-ch zh">${esc(s.ch || s.py)}</span>${s.ch ? `<span class="pc-py">${esc(s.py)}</span>` : ""}
        ${curveSvg(s.want, m?.curve)}
        <span class="pc-lbl">${m && m.st !== "ok" && m.label ? esc(m.label) : TONE_SHORT[s.want]}</span></div>`;
    }).join("")}</div>`;
  }

  setReportContext(() => { const w = words[i] || {}; return { place: `Prononciation · mot ${i + 1}/${words.length}`, audio: w.zh, expected: [w.zh, w.py].filter(Boolean).join(" · "), question: w.fr, given: $(".pron-live")?.textContent || "" }; });
  function show() {
    const w = words[i];
    tries = 0; scored = false; cleanup();
    $(".story-bar").style.width = `${Math.round((i / words.length) * 100)}%`;
    $(".pron-word").innerHTML = wordHtml(w);
    $(".pron-py").textContent = isZh() ? "" : (w.py || "");
    $(".pron-fr").textContent = w.fr;
    $(".pron-res").innerHTML = ""; $(".pron-live").textContent = "";
    $("[data-me]").hidden = true;
    $("[data-next]").hidden = true; $("[data-skip]").hidden = false;
    $(".pron-hint").textContent = HINT;
  }

  /* ----------- Écoute : enregistrement + reconnaissance vocale en même temps ----------- */
  async function listen() {
    if (busy) return;
    if (session) { session.stop(); return; }
    stopSpeaking();
    const w = words[i], mic = $("[data-mic]");
    let rec = null, recorder = null, finals = [], interim = "", srDone = !SR, srErr = "", stopped = false;
    const useRec = canRecord && (isZh() || !soloMode() || !SR);
    const useSR = !!SR && (!isZh() || !soloMode() || !canRecord);
    $(".pron-res").innerHTML = ""; $(".pron-live").textContent = "";

    let finish;
    const ended = new Promise((r) => (finish = r));
    const stop = () => {
      if (stopped) return; stopped = true;
      mic.classList.remove("on"); mic.style.removeProperty("--lvl");
      $(".pron-hint").textContent = "Analyse…";
      try { rec?.stop(); } catch {}
      finish();
    };
    session = { stop, cancel: () => { stopped = true; try { rec?.abort(); } catch {} try { recorder?.cancel(); } catch {} } };

    if (useRec) {
      try {
        recorder = await startRecorder({
          maxMs: isZh() ? 5000 : 6000,
          onLevel: (v) => mic.style.setProperty("--lvl", v.toFixed(2)),
          onSilence: () => stop(),
        });
      } catch { recorder = null; }
    }
    if (useSR) {
      rec = new SR();
      rec.lang = L.speech; rec.interimResults = true; rec.maxAlternatives = 5; rec.continuous = false;
      rec.onresult = (e) => {
        interim = "";
        for (let k = e.resultIndex; k < e.results.length; k++) {
          const r = e.results[k];
          if (r.isFinal) finals = [...r].map((a) => a.transcript.trim()).filter(Boolean);
          else interim += r[0].transcript;
        }
        const live = (finals[0] || interim).trim();
        if (live) $(".pron-live").innerHTML = `J'entends : <b class="${isZh() ? "zh" : ""}">${esc(live)}</b>`;
      };
      rec.onerror = (e) => { srErr = e.error; };
      rec.onend = () => { srDone = true; if (!recorder) stop(); };
      try { rec.start(); } catch { srDone = true; rec = null; }
    }
    if (!recorder && !rec) {
      session = null;
      $(".pron-res").innerHTML = `<p class="small muted">Micro inaccessible : autorisez le micro pour ce site dans les réglages du navigateur.</p>`;
      return;
    }
    mic.classList.add("on");
    $(".pron-hint").textContent = "J'écoute… parlez maintenant";

    await ended;
    busy = true;
    const pcm = recorder ? await recorder.stop().catch(() => null) : null;
    // la reconnaissance vocale rend son résultat juste après l'arrêt
    for (let k = 0; k < 30 && !srDone; k++) await new Promise((r) => setTimeout(r, 50));
    try { rec?.abort(); } catch {}
    session = null;
    const alts = finals.length ? finals : interim.trim() ? [interim.trim()] : [];

    // Réécouter sa voix
    if (pcm && pcm.length > 1600) {
      if (voiceUrl) URL.revokeObjectURL(voiceUrl);
      voiceUrl = URL.createObjectURL(toWav(pcm));
      $("[data-me]").hidden = false;
    }
    // Sur iPhone, les deux ensemble peuvent rendre la reconnaissance muette : on retient pour la suite
    if (!isZh() && recorder && rec && !alts.length && pcm && analyse(pcm, [1])) { try { localStorage.setItem(SOLO_KEY, "1"); } catch {} }

    try { await judge(w, alts, pcm, srErr); } finally { busy = false; $(".pron-hint").textContent = HINT; }
  }

  /* -------------------------------- Résultat -------------------------------- */
  async function judge(w, alts, pcm, srErr) {
    if (!isZh()) {
      if (!alts.length) return nothing(srErr);
      return result(await grade(w, alts));
    }
    const syl = syllables(w);
    const ref = voiceRef();
    const pa = pcm ? analyse(pcm, syl.map((s) => s.want), ref) : null;
    if (!pa && !alts.length) return nothing(srErr);
    if (pa) learnVoice(pa.median);

    // Sons : d'après ce que la reconnaissance vocale a compris (si elle a compris quelque chose)
    let sounds = null, srGrade = null;
    if (alts.some((a) => /[㐀-鿿]/.test(a))) {
      srGrade = await grade(w, alts);
      const heard = (srGrade.heard.match(HAN) || []).join("");
      const got = (await pyOf(heard)).map(toneless);
      const want = syl.map((s) => toneless(s.py));
      sounds = srGrade.level === "miss" ? lcsMarks(want, got) : want.map(() => true);
    }
    const marks = syl.map((s, k) => {
      const y = pa?.syl[k];
      const toneOk = !y || y.ok || y.got === s.cit;
      const soundOk = !sounds || sounds[k];
      const st = !soundOk ? "ko" : toneOk ? "ok" : "tone";
      const label = !soundOk ? "son à revoir" : !toneOk && y?.got ? `→ ${TONE_SHORT[y.got]}` : "";
      return { st, curve: y?.curve, label, got: y?.got };
    });
    $(".pron-word").innerHTML = wordHtml(w, marks);

    const nTone = syl.filter((s) => s.want !== 5).length;
    const toneGood = !pa ? null : !nTone ? 1 : marks.filter((m, k) => syl[k].want !== 5 && m.st === "ok").length / nTone;
    const soundGood = sounds ? sounds.every(Boolean) : null;
    let level;
    if (soundGood === false) level = "miss";
    else if (toneGood == null) level = srGrade.level;
    else level = toneGood >= 0.99 ? (soundGood ? "perfect" : "good") : toneGood >= 0.66 && syl.length > 2 ? "good" : "tone";

    const wrong = marks.map((m, k) => ({ ...m, s: syl[k] })).filter((m) => m.st === "tone");
    let note = "";
    if (level === "tone" && wrong.length) {
      const m = wrong[0];
      note = `${m.s.ch || m.s.py} (${m.s.py}) : il faut un ${TONE_SHORT[m.s.want]}${m.got ? `, j'ai entendu plutôt un ${TONE_SHORT[m.got]}` : ""}. Comparez les courbes : pointillés = attendu, trait plein = vous.`;
    } else if (level === "miss") note = "Certains sons ne sont pas reconnus (en rouge). Écoutez le modèle et réessayez.";
    else if (level === "good" && wrong.length) note = "Presque : un ton est à peaufiner (en orange).";
    const tip = !sounds && pa && !hintShown && /iP(hone|ad)/.test(navigator.userAgent)
      ? `<p class="small muted">Seuls les tons sont vérifiés ici. Pour que les sons le soient aussi, ajoutez le clavier « Chinois (simplifié) » dans Réglages › Général › Clavier.</p>` : "";
    if (tip) hintShown = true;
    result({ level, heard: alts[0] || "", note, tip, tonesOnly: !sounds && toneGood != null });
  }

  function nothing(srErr) {
    const msg = {
      "not-allowed": "Micro refusé : autorisez le micro pour ce site dans les réglages du navigateur.",
      "service-not-allowed": "La reconnaissance vocale est bloquée ici. Sur iPhone, essayez dans Safari.",
      network: "La reconnaissance vocale a besoin d'Internet.",
      "audio-capture": "Aucun micro détecté.",
    }[srErr] || "Je n'ai rien entendu. Parlez un peu plus fort, près du micro.";
    $(".pron-res").innerHTML = `<p class="small muted">${esc(msg)}</p>`;
  }

  function result(r) {
    const w = words[i];
    tries++;
    const ok = r.level === "perfect" || r.level === "good";
    if (ok && !scored) { score++; scored = true; }
    const head = r.tonesOnly && ok ? "✓ Tons justes !" : { perfect: "✓ Parfait !", good: "✓ Bien !", tone: "≈ Presque : attention au ton", miss: "✗ Pas encore" }[r.level];
    $(".pron-res").innerHTML = `<div class="pron-out ${ok ? "ok" : r.level === "tone" ? "tone" : "ko"}"><b>${head}</b>
      ${r.heard && !isZh() ? `<p class="small">J'ai entendu : « ${esc(r.heard)} »</p>` : ""}
      ${r.note ? `<p class="small">${esc(r.note)}</p>` : ""}${r.tip || ""}
      ${!ok && tries < 3 ? `<p class="small muted">Encore ${3 - tries} essai${3 - tries > 1 ? "s" : ""}.</p>` : ""}</div>`;
    if (ok || tries >= 3) { $("[data-next]").hidden = false; $("[data-skip]").hidden = true; if (!ok) speak(w.zh, { force: true }); }
  }

  function finish() {
    cleanup();
    document.body.classList.remove("focus-mode");
    const r = P.recordPractice({ label: "Prononciation", score, total: words.length, key: "prononciation" });
    const pct = Math.round(r.ratio * 100);
    app.innerHTML = `
    <section class="results ${pct >= 60 ? "ok" : "ko"}">
      ${ring(pct, 150, 12)}
      <h1>${pct === 100 ? "Prononciation parfaite ! 🎉" : pct >= 60 ? "Bien prononcé !" : "Continuez, ça viendra !"}</h1>
      <p class="lead">${score} / ${words.length} mots bien prononcés</p>
      <div class="result-chips">${xpChip(r)}</div>${r.capped ? `<p class="muted small">XP déjà gagnés avec cet exercice dans les dernières 24 h : de nouveau dans <b>${P.waitLabel(r.readyAt)}</b>.</p>` : ""}
      <div class="result-actions">
        <a class="btn primary big" href="#prononciation" data-reload>Recommencer</a>
        <a class="btn ghost" href="#entrainement">Autres exercices</a>
      </div>
    </section>`;
    if (pct === 100) celebrate();
  }

  $("[data-mic]").onclick = listen;
  $("[data-model]").onclick = () => speak(words[i].zh, { force: true });
  $("[data-slow]").onclick = () => speak(words[i].zh, { force: true, slow: true });
  $("[data-me]").onclick = () => { if (voiceUrl) { stopSpeaking(); new Audio(voiceUrl).play().catch(() => {}); } };
  const advance = () => { if (busy) return; cleanup(); i++; if (i >= words.length) finish(); else show(); };
  $("[data-next]").onclick = advance;
  $("[data-skip]").onclick = advance;
  show();
  if (isZh()) loadPinyin();
  return true;
}

/* =====================================================================
   « Répéter des phrases » (#repeter) — shadowing
   On écoute une phrase entière, on la répète, puis on voit mot par mot
   ce qui a été bien dit (vert), presque (orange : ton à revoir) ou pas
   reconnu (rouge). Option : cacher le texte pour travailler à l'oreille.
   ===================================================================== */
/** Pour chaque élément de a : retrouvé dans b, dans l'ordre (plus longue sous-suite commune) ? */
function lcsMarks(a, b, eq = (x, y) => x === y) {
  const n = a.length, m = b.length;
  const d = Array.from({ length: n + 1 }, () => new Array(m + 1).fill(0));
  for (let i = n - 1; i >= 0; i--) for (let j = m - 1; j >= 0; j--) d[i][j] = eq(a[i], b[j]) ? d[i + 1][j + 1] + 1 : Math.max(d[i + 1][j], d[i][j + 1]);
  const out = new Array(n).fill(false);
  for (let i = 0, j = 0; i < n && j < m;) { if (eq(a[i], b[j])) { out[i] = true; i++; j++; } else if (d[i + 1][j] >= d[i][j + 1]) i++; else j++; }
  return out;
}

/** Compare la phrase visée à ce qui a été entendu : [{ t, st: "ok" | "tone" | "ko" }], score 0-1 */
async function compareSentence(s, heard) {
  if (!isZh()) {
    const parts = s.t.match(/[\p{L}\p{M}'’]+|[^\p{L}\p{M}'’]+/gu) || [];
    const words = parts.filter((p) => /\p{L}/u.test(p)).map(norm);
    const got = norm(heard).split(" ").filter(Boolean);
    // Un mot « presque » reconnu (1 lettre près, ou élision) compte
    const marks = lcsMarks(words, got, (x, y) => x === y || (x.length > 3 && sim(x, y) >= 0.75));
    let k = 0;
    const out = parts.map((p) => (/\p{L}/u.test(p) ? { t: p, st: marks[k++] ? "ok" : "ko" } : { t: p, st: "sep" }));
    return { parts: out, score: words.length ? marks.filter(Boolean).length / words.length : 0 };
  }
  const chars = [...s.t];
  const han = chars.filter((c) => /[㐀-鿿]/.test(c));
  const heardHan = (heard.match(HAN) || []);
  const byChar = lcsMarks(han, heardHan);
  // Homophones : même syllabe (avec le ton) = bien dit ; mêmes sons mais autre ton = presque
  const [pyT, pyH] = await Promise.all([pyOf(han.join("")), pyOf(heardHan.join(""))]);
  const byPy = lcsMarks(pyT, pyH);
  const byPyNoTone = lcsMarks(pyT.map(toneless), pyH.map(toneless));
  let k = 0, good = 0;
  const out = chars.map((c) => {
    if (!/[㐀-鿿]/.test(c)) return { t: c, st: "sep" };
    const i = k++;
    const st = byChar[i] || byPy[i] ? "ok" : byPyNoTone[i] ? "tone" : "ko";
    good += st === "ok" ? 1 : st === "tone" ? 0.5 : 0;
    return { t: c, st, py: pyT[i] };
  });
  return { parts: out, score: han.length ? good / han.length : 0 };
}

export async function renderShadowing(app) {
  if (!SR) {
    app.innerHTML = `<a class="back-link" href="#entrainement">← Entraînement</a>
    <section class="card empty-state"><p class="big-emoji">🎤</p><h1 class="h3">Reconnaissance vocale indisponible</h1>
      <p class="muted">Ce navigateur ne sait pas reconnaître la voix. Utilisez <b>Chrome</b> (ordinateur ou Android) ou <b>Safari</b> sur iPhone.</p></section>`;
    return true;
  }
  const { sentencePool } = await import("./dictee.js");
  const fitsLen = (t) => (isZh() ? (t.match(HAN) || []).length <= 14 : t.split(/\s+/).length <= 10);
  const pool = sentencePool().filter((x) => fitsLen(x.t));
  if (pool.length < 3) return false;
  const list = shuffle(pool).slice(0, 8);
  let i = 0, best = 0, tries = 0, done = 0, rec = null, listening = false, hidden = false;

  document.body.classList.add("focus-mode");
  app.innerHTML = `
  <section class="pron shadow">
    <div class="story-top">
      <button class="btn ghost small" data-quit aria-label="Quitter">✕</button>
      <div class="progress"><span class="story-bar"></span></div>
      ${reportButton()}
    </div>
    <p class="eyebrow">Répéter · écoutez puis dites la phrase</p>
    <div class="card pron-card">
      <p class="sh-t"></p><p class="sh-py py"></p><p class="sh-fr muted"></p>
      <div class="btn-row center"><button class="btn ghost small" data-model>🔊 Écouter</button><button class="btn ghost small" data-slow>🐢 Lentement</button><button class="btn ghost small" data-hide>🙈 Cacher le texte</button></div>
    </div>
    <button class="mic" data-mic aria-label="Appuyez puis répétez la phrase"><span>🎤</span></button>
    <p class="pron-hint muted small">Écoutez, puis appuyez sur le micro et répétez la phrase.</p>
    <div class="pron-res" aria-live="polite"></div>
    <div class="story-foot"><button class="btn ghost" data-skip>Passer</button><button class="btn primary" data-next hidden>Suivant →</button></div>
  </section>`;
  const $ = (q) => app.querySelector(q);
  const quit = () => { try { rec?.abort(); } catch {} document.body.classList.remove("focus-mode"); location.hash = "entrainement"; };
  $("[data-quit]").onclick = quit;

  const model = (slow = false) => speak(list[i].t, { force: true, slow });
  function paintText(parts = null) {
    const s = list[i];
    $(".sh-t").className = `sh-t ${isZh() ? "zh" : ""} ${hidden && !parts ? "blur" : ""}`;
    $(".sh-t").innerHTML = parts ? parts.map((p) => (p.st === "sep" ? esc(p.t) : `<span class="sh-w ${p.st}">${esc(p.t)}</span>`)).join("") : esc(s.t);
    $(".sh-py").textContent = s.py || "";
    $(".sh-py").classList.toggle("blur", hidden && !parts);
    $(".sh-fr").textContent = s.fr;
  }
  setReportContext(() => { const s = list[i] || {}; return { place: `Répéter · phrase ${i + 1}/${list.length}`, audio: s.t, expected: [s.t, s.py].filter(Boolean).join(" · "), question: s.fr }; });
  function show() {
    best = 0; tries = 0;
    $(".story-bar").style.width = `${Math.round((i / list.length) * 100)}%`;
    paintText();
    $(".pron-res").innerHTML = "";
    $("[data-next]").hidden = true; $("[data-skip]").hidden = false;
    setTimeout(() => model(), 300);
  }
  async function result(alts) {
    const s = list[i];
    let r = null;
    for (const a of alts) { const x = await compareSentence(s, a); if (!r || x.score > r.score) r = { ...x, heard: a }; }
    tries++;
    best = Math.max(best, r.score);
    const pct = Math.round(r.score * 100);
    paintText(r.parts);
    const tone = r.parts.some((p) => p.st === "tone");
    const head = pct >= 85 ? "✓ Très bien !" : pct >= 60 ? "≈ Presque !" : "✗ À retravailler";
    $(".pron-res").innerHTML = `<div class="pron-out ${pct >= 60 ? "ok" : "ko"}"><b>${head} · ${pct} %</b>
      <p class="small">J'ai entendu : « <span class="${isZh() ? "zh" : ""}">${esc(r.heard)}</span> »</p>
      ${tone ? `<p class="small">En orange : les sons sont bons, mais le ton est à revoir.</p>` : ""}
      ${pct < 85 && tries < 3 ? `<p class="small muted">Réécoutez le modèle 🔊 et réessayez (${3 - tries} essai${3 - tries > 1 ? "s" : ""}).</p>` : ""}</div>`;
    if (pct >= 85 || tries >= 3) { $("[data-next]").hidden = false; $("[data-skip]").hidden = true; }
  }
  function listen() {
    if (listening) { try { rec.stop(); } catch {} return; }
    stopSpeaking();
    rec = new SR();
    rec.lang = L.speech; rec.interimResults = true; rec.maxAlternatives = 5; rec.continuous = false;
    let got = false, interim = "";
    rec.onresult = (e) => {
      const r = e.results[e.results.length - 1];
      if (!r.isFinal) { interim = r[0].transcript.trim(); if (interim) $(".pron-res").innerHTML = `<p class="pron-live">J'entends : <b class="${isZh() ? "zh" : ""}">${esc(interim)}</b></p>`; return; }
      if (got) return;
      got = true; result([...r].map((a) => a.transcript.trim()).filter(Boolean));
    };
    rec.onerror = (e) => {
      got = true;
      const msg = { "not-allowed": "Micro refusé : autorisez le micro pour ce site dans les réglages du navigateur.", "no-speech": "Je n'ai rien entendu. Rapprochez-vous du micro et réessayez.", network: "La reconnaissance vocale a besoin d'Internet." }[e.error] || "La reconnaissance vocale a échoué, réessayez.";
      $(".pron-res").innerHTML = `<p class="small muted">${esc(msg)}</p>`;
    };
    rec.onend = () => { listening = false; $("[data-mic]").classList.remove("on"); $(".pron-hint").textContent = "Écoutez, puis appuyez sur le micro et répétez la phrase."; if (!got && interim) { got = true; result([interim]); } else if (!got) $(".pron-res").innerHTML = `<p class="small muted">Je n'ai rien entendu. Réessayez.</p>`; };
    try { rec.start(); listening = true; $("[data-mic]").classList.add("on"); $(".pron-hint").textContent = "J'écoute… répétez la phrase"; $(".pron-res").innerHTML = ""; } catch { listening = false; }
  }
  function finish() {
    document.body.classList.remove("focus-mode");
    const r = P.recordPractice({ label: "Répéter des phrases", score: done, total: list.length, key: "repeter" });
    const pct = Math.round(r.ratio * 100);
    app.innerHTML = `<section class="results ${pct >= 60 ? "ok" : "ko"}">
      ${ring(pct, 150, 12)}
      <h1>${pct === 100 ? "Comme un natif ! 🎉" : pct >= 60 ? "Bien répété !" : "Continuez, ça viendra !"}</h1>
      <p class="lead">${done} / ${list.length} phrases bien répétées</p>
      <div class="result-chips">${xpChip(r)}</div>${r.capped ? `<p class="muted small">XP déjà gagnés avec cet exercice dans les dernières 24 h : de nouveau dans <b>${P.waitLabel(r.readyAt)}</b>.</p>` : ""}
      <div class="result-actions"><a class="btn primary big" href="#repeter" data-reload>Recommencer</a><a class="btn ghost" href="#entrainement">Autres exercices</a></div>
    </section>`;
    if (pct === 100) celebrate();
  }
  $("[data-mic]").onclick = listen;
  $("[data-model]").onclick = () => model();
  $("[data-slow]").onclick = () => model(true);
  $("[data-hide]").onclick = (e) => { hidden = !hidden; e.currentTarget.textContent = hidden ? "👁️ Montrer le texte" : "🙈 Cacher le texte"; paintText(); };
  const advance = (counted) => { try { rec?.abort(); } catch {} if (counted && best >= 0.8) done++; i++; if (i >= list.length) finish(); else show(); };
  $("[data-next]").onclick = () => advance(true);
  $("[data-skip]").onclick = () => advance(false);
  show();
  if (isZh()) loadPinyin();
  return true;
}
