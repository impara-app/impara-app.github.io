/* =====================================================================
   Vue « Quiz » — quiz de leçon, examen de palier et révision d'erreurs
   ===================================================================== */

import { getLesson, getLevel, getQuestion, LEVELS, lvlLabel, lvlBadge } from "../data/curriculum.js";
import { state, commit } from "../core/storage.js";
import * as P from "../core/progress.js";
import { seanceWaits } from "./seance.js";
import { runQuiz, mistakesHtml, offerResume } from "../core/quiz-engine.js";
import { esc, celebrate, shuffle, ring } from "../core/ui.js";
import { L } from "../core/lang.js";
import { buildLessonQuestions } from "../core/challenge-gen.js";
import { orderQuestions, lessonSentences } from "../core/order.js";
import { sfx } from "../core/fx.js";
import { mascot, line } from "../core/mascot.js";

/** Quiz de fin de leçon */
export function renderQuiz(app, id) {
  const lesson = getLesson(id);
  if (!lesson || !P.isLessonUnlocked(lesson)) return false;
  start(app, {
    kind: "lesson", id, label: lesson.title,
    title: `Quiz · ${lesson.title}`,
    questions: lessonQuestions(lesson),
    back: `#lecon-${id}`,
  });
  return true;
}

/**
 * Questions d'une leçon : la première fois, celles du cours (ordre mélangé) ;
 * ensuite, environ 40 % sont remplacées par des questions générées sur les
 * mots de la leçon, avec des formulations différentes à chaque essai.
 */
function lessonQuestions(lesson) {
  const N = P.LESSON_QUIZ_N;
  // Questions du cours : les moins souvent posées d'abord (rotation entre les essais)
  const seen = state.qAsked || {};
  const base = shuffle(lesson.quiz.map((q, i) => ({ ref: `${lesson.id}:${i}`, q }))).sort((a, b) => (seen[a.ref] || 0) - (seen[b.ref] || 0));
  // 1er essai : toutes les questions du cours ; ensuite de plus en plus de questions
  // générées sur TOUS les mots de la leçon (60 % du cours, puis 40 % à partir du 3e essai)
  const att = state.lessons[lesson.id]?.attempts || 0;
  const keepN = Math.min(base.length, !att ? N : Math.round(N * (att >= 2 ? 0.4 : 0.6)));
  // Une phrase à remettre dans l'ordre (si la leçon a des exemples qui s'y prêtent)
  const ord = orderQuestions(lessonSentences(lesson), 1, `${lesson.id}:ord`, lesson.levelId);
  const kept = base.slice(0, Math.min(keepN, N - ord.length));
  const gen = buildLessonQuestions(lesson, N - kept.length - ord.length);
  // S'il manque des questions générées, on complète avec le reste du cours
  const extra = base.slice(kept.length, kept.length + Math.max(0, N - kept.length - gen.length - ord.length));
  const all = [...kept, ...gen, ...ord, ...extra];
  commit((s) => { const a = s.qAsked ||= {}; all.forEach((x) => { if (!x.ref.includes(":gen:") && !x.ref.endsWith(":ord")) a[x.ref] = (a[x.ref] || 0) + 1; }); });
  return shuffle(all);
}

/**
 * Tire n questions dans les quiz des leçons, à tour de rôle (tirage équilibré).
 * S'il n'y en a pas assez, on complète avec des questions générées sur les mots
 * de ces leçons. `base` : questions imposées (ex. celles de l'examen).
 */
function drawQuestions(lessons, n, base = []) {
  const picked = [...base];
  const per = shuffle(lessons).map((l) => shuffle(l.quiz.map((q, i) => ({ ref: `${l.id}:${i}`, q, lesson: l }))));
  for (let k = 0; picked.length < n && per.some((a) => a.length); k++) { const a = per[k % per.length]; if (a.length) picked.push(a.pop()); }
  for (let k = 0, tries = 0; picked.length < n && tries < lessons.length * 3; k++, tries++) {
    const l = lessons[k % lessons.length];
    const g = buildLessonQuestions(l, Math.min(3, n - picked.length));
    g.forEach((x) => picked.push({ ...x, lesson: l }));
  }
  return shuffle(picked.slice(0, n));
}
/** Questions de l'examen de fin de palier : toutes celles de l'examen + les quiz des leçons (50 en tout) */
const examQuestions = (level) => drawQuestions(level.lessons, P.EXAM_N, shuffle(level.exam.map((q, i) => ({ ref: `exam-${level.id}:${i}`, q }))).slice(0, P.EXAM_N));

/** Test de mi-palier : 25 questions sur la 1re moitié du palier, sans faute */
export function renderMiPalier(app, levelId) {
  const level = getLevel(levelId), li = LEVELS.indexOf(level);
  if (!level || !P.isCheckpointUnlocked(li)) return false;
  const half = level.lessons.slice(0, P.checkpointIndex(level));
  const picked = drawQuestions(half, P.CHECKPOINT_N).map(({ ref, q }) => ({ ref, q }));
  start(app, {
    kind: "checkpoint", id: levelId, label: `Mi-palier ${lvlLabel(level)}`,
    title: `Test de mi-palier ${lvlLabel(level)}`,
    questions: shuffle(picked),
    back: "#parcours",
  });
  return true;
}

/** Examen de fin de palier */
export function renderExamen(app, levelId) {
  const level = getLevel(levelId);
  const li = LEVELS.indexOf(level);
  if (!level || !P.isExamUnlocked(li)) return false;
  start(app, {
    kind: "exam", id: levelId, label: `Examen ${lvlLabel(levelId)}`,
    title: `Examen de fin de palier ${lvlLabel(levelId)}`,
    questions: examQuestions(level).map(({ ref, q }) => ({ ref, q })),
    back: "#parcours",
  });
  return true;
}

/**
 * Examen blanc : même format et même nombre de questions que le vrai
 * examen, tirées des quiz de TOUTES les leçons du palier (même celles qui
 * ne sont pas encore faites). Ne valide rien, ne touche pas au cahier
 * d'erreurs ; quelques XP une fois par 24 h.
 */
export function renderBlanc(app, levelId) {
  const level = getLevel(levelId), li = LEVELS.indexOf(level);
  if (!level || !P.isLevelUnlocked(li)) return false;
  const n = P.EXAM_N;
  const done = level.lessons.filter((l) => P.isLessonDone(l.id)).length;
  const rec = state.blanc?.[levelId];
  app.innerHTML = `
  <a class="back-link" href="#parcours">← Parcours</a>
  <section class="card blanc-intro">
    <p class="eyebrow">Entraînement à l'examen</p>
    <h1>📝 Examen blanc ${esc(lvlLabel(level))}</h1>
    <p class="lead">${n} questions tirées de <b>toutes les leçons</b> du palier, comme le jour de l'examen.</p>
    <ul class="defi-rules">
      <li>🎯 Il faut <b>${Math.round(P.PASS_EXAM * 100)} %</b> pour réussir le vrai examen</li>
      <li>🃏 ${P.JOKERS_EXAM} jokers : une faute de frappe (une lettre fausse, en trop ou manquante) est pardonnée</li>
      <li>📚 Vous avez terminé <b>${done}/${level.lessons.length}</b> leçons : les autres apparaîtront aussi</li>
      <li>🧪 Rien n'est validé ni ajouté au cahier d'erreurs : c'est un essai</li>
      <li>📋 À la fin : les leçons à revoir en priorité</li>
    </ul>
    ${rec ? `<p class="muted small">Meilleur examen blanc : <b>${rec.best}/${rec.total}</b> · dernier : ${rec.last}/${rec.total}</p>` : ""}
    <button class="btn primary big" data-go>Commencer l'examen blanc</button>
  </section>`;
  app.querySelector("[data-go]").onclick = () => startBlanc(app, level);
  return true;
}

function startBlanc(app, level) {
  // Même format que le vrai examen, mais tiré uniquement des leçons (pour savoir quoi revoir)
  const questions = drawQuestions(level.lessons, P.EXAM_N);
  document.body.classList.add("focus-mode");
  runQuiz(app, {
    title: `Examen blanc ${lvlLabel(level)}`,
    questions: questions.map(({ ref, q }) => ({ ref, q })),
    jokers: P.JOKERS_EXAM,
    onQuit: () => { document.body.classList.remove("focus-mode"); location.hash = "parcours"; },
    onFinish: (results) => {
      document.body.classList.remove("focus-mode");
      const score = results.filter((r) => r.correct).length, total = results.length;
      const r = P.recordPractice({ label: `Examen blanc ${lvlLabel(level)}`, score, total, xpPer: 2, key: `blanc:${level.id}` });
      commit((s) => {
        const prev = s.blanc?.[level.id];
        s.blanc = { ...(s.blanc || {}), [level.id]: { best: Math.max(prev?.best || 0, score), last: score, total, date: Date.now() } };
      });
      // Erreurs par leçon
      const wrong = {};
      results.forEach((res, i) => { if (!res.correct) { const l = questions[i].lesson; wrong[l.id] = (wrong[l.id] || 0) + 1; } });
      const toReview = level.lessons.filter((l) => wrong[l.id]).sort((a, b) => wrong[b.id] - wrong[a.id]);
      const pct = Math.round((score / total) * 100), need = Math.ceil(P.PASS_EXAM * total), ok = score >= need;
      const realOpen = P.isExamUnlocked(LEVELS.indexOf(level));
      app.innerHTML = `
      <section class="results ${ok ? "ok" : "ko"}">
        ${ring(pct, 150, 12)}
        <h1>${ok ? "Vous auriez réussi l'examen ! 🎓" : "Pas encore tout à fait"}</h1>
        <p class="lead">${score} / ${total} bonnes réponses · ${need} nécessaires</p>
        <p class="muted">${ok ? (realOpen ? "Vous êtes prêt·e : lancez-vous pour de vrai !" : "Terminez les leçons du palier pour débloquer le vrai examen.") : `Il vous manque ${need - score} bonne${need - score > 1 ? "s" : ""} réponse${need - score > 1 ? "s" : ""}. Voici quoi revoir en priorité.`}</p>
        <div class="result-chips">${r.capped ? `<span class="chip muted-chip">⏳ XP déjà gagnés aujourd'hui</span>` : `<span class="chip">⚡ +${r.xpGained} XP</span>`}</div>
        ${toReview.length ? `<div class="card blanc-review"><h2 class="h3">📋 À revoir</h2><ul>${toReview.map((l) => {
          const open = P.isLessonUnlocked(l);
          return `<li><span>${l.emoji} ${esc(l.title)}</span><small>${wrong[l.id]} erreur${wrong[l.id] > 1 ? "s" : ""}</small>
            ${open ? `<a class="btn ghost small" href="#lecon-${l.id}">Revoir</a>` : `<span class="muted small">🔒 pas encore faite</span>`}</li>`;
        }).join("")}</ul></div>` : ""}
        ${mistakesHtml(results, { open: false })}
        <div class="result-actions">
          ${ok && realOpen ? `<a class="btn primary big" href="#examen-${level.id}">Passer le vrai examen →</a>` : `<a class="btn primary big" href="#blanc-${level.id}" data-reload>Refaire un examen blanc</a>`}
          <a class="btn ghost" href="#parcours">Retour au parcours</a>
        </div>
      </section>`;
      if (ok) celebrate();
    },
  });
}

/** Révision intelligente : les erreurs les plus fréquentes d'abord */
export function renderRevision(app) {
  const errs = Object.values(state.errors)
    .sort((a, b) => b.count - a.count || a.lastWrong - b.lastWrong)
    .slice(0, 10)
    .map((e) => ({ ref: e.ref, q: getQuestion(e.ref) }))
    .filter((x) => x.q);
  if (!errs.length) { location.hash = "erreurs"; return true; }
  start(app, { kind: "review", id: "review", label: "Révision des erreurs", title: "Révision de vos erreurs", questions: shuffle(errs), back: "#erreurs" });
  return true;
}

async function start(app, cfg) {
  const saveKey = `${cfg.kind}:${cfg.id}`;
  const hash = location.hash;
  app.innerHTML = "";
  const resume = await offerResume(saveKey);
  if (location.hash !== hash) return;
  document.body.classList.add("focus-mode"); // masque la navigation pendant le quiz
  cfg.t0 = resume?.ts ? Date.now() - 60000 : Date.now();
  runQuiz(app, {
    title: cfg.title,
    questions: cfg.questions, saveKey, resume,
    xpPerAnswer: P.XP_PER_CORRECT,
    jokers: cfg.kind === "exam" ? P.JOKERS_EXAM : cfg.kind === "checkpoint" ? P.JOKERS_CHECKPOINT : 0,
    onQuit: () => { document.body.classList.remove("focus-mode"); location.hash = cfg.back.slice(1); },
    onFinish: (results) => {
      document.body.classList.remove("focus-mode");
      const sum = P.recordQuiz({ kind: cfg.kind, id: cfg.id, label: cfg.label, results });
      sum.ms = Date.now() - cfg.t0;
      sum.results = results;
      showResults(app, cfg, sum);
      // Premier examen de palier réussi : grand écran de célébration
      if (cfg.kind === "exam" && sum.passed && sum.firstPass) import("./levelup.js").then((m) => m.showLevelUp(cfg.id)).catch(() => {});
    },
  });
}

function showResults(app, cfg, s) {
  const pct = Math.round(s.ratio * 100);
  const next = P.nextStep();
  let headline, msg, primary;

  if (cfg.kind === "review") {
    headline = pct === 100 ? "Sans faute ! 💪" : "Révision terminée";
    msg = s.mastered ? `${s.mastered} notion(s) maîtrisée(s) et retirée(s) du cahier d'erreurs.` : "Une erreur disparaît du cahier après 2 bonnes réponses d'affilée.";
    primary = Object.keys(state.errors).length ? `<a class="btn primary big" href="#revision" data-reload>Nouvelle révision</a>` : `<a class="btn primary big" href="#parcours">Retour au parcours</a>`;
  } else if (s.passed) {
    headline = cfg.kind === "exam" ? `Palier ${lvlLabel(cfg.id)} validé ! 🎓` : cfg.kind === "checkpoint" ? "Mi-palier franchi ! 🛡️" : L.resultHeads[s.stars - 1] || L.resultHeads[0];
    msg = cfg.kind === "checkpoint" ? "La deuxième moitié du palier est débloquée."
      : cfg.kind === "exam"
      ? (LEVELS[LEVELS.findIndex((l) => l.id === cfg.id) + 1] ? `Le palier ${lvlLabel(LEVELS[LEVELS.findIndex((l) => l.id === cfg.id) + 1])} est maintenant débloqué.` : L.finished)
      : s.newWords ? `${s.newWords} nouveaux mots ajoutés à vos mots.` : "Leçon validée.";
    primary = next
      ? `<a class="btn primary big" href="#${P.stepHref(next)}">${next.kind === "lesson" ? "Leçon suivante" : next.kind === "checkpoint" ? `Test de mi-palier ${lvlLabel(next.level)}` : `Examen ${lvlLabel(next.level)}`} →</a>`
      : `<a class="btn primary big" href="#tableau">Voir mon tableau de bord</a>`;
  } else {
    headline = L.almost;
    const need = Math.ceil(s.passMark * s.total);
    msg = cfg.kind === "exam" ? `L'examen se valide sans aucune faute (${s.total}/${s.total}). Il vous en manquait ${s.total - s.score}. Vos erreurs sont dans le cahier : révisez-les, puis réessayez.`
      : cfg.kind === "checkpoint" ? `Il faut ${need}/${s.total} pour franchir le mi-palier. Révisez les leçons concernées (vos erreurs sont dans le cahier), puis réessayez : les questions changent.`
      : `Il faut ${Math.round(s.passMark * 100)} % pour valider. Relisez la leçon, vos erreurs sont dans le cahier.`;
    primary = `<a class="btn primary big" href="#${cfg.kind === "exam" ? "examen-" + cfg.id : cfg.kind === "checkpoint" ? "mipalier-" + cfg.id : "quiz-" + cfg.id}" data-reload>Réessayer</a>`;
  }

  // Étape de la « Séance du jour » : on propose de revenir à la séance
  if (cfg.kind !== "review" && seanceWaits(cfg.kind, cfg.id)) {
    primary = `<a class="btn primary big" href="#seance">Continuer la séance du jour →</a>` + (s.passed ? "" : primary.replace("btn primary big", "btn ghost"));
  }
  const secs = Math.round((s.ms || 0) / 1000), time = secs >= 60 ? `${Math.floor(secs / 60)}:${String(secs % 60).padStart(2, "0")}` : `${secs} s`;
  const streak = P.streakCount();
  const tile = (icon, label, value, cls, count = null) => `<div class="rt ${cls}"><small>${label}</small><b ${count != null ? `data-count="${count}"` : ""}>${count != null ? 0 : value}</b><span>${icon}</span></div>`;
  app.innerHTML = `
  <section class="results ${s.passed ? "ok" : "ko"} rich">
    <div class="res-hero ${s.passed ? "happy" : "sad"}">
      <span class="res-mascot">${mascot(s.passed ? "cheer" : "sad", { size: 132 })}</span>
      <span class="res-me">${esc(state.profile?.avatar || "🙂")}</span>
      <span class="m-bubble res-bubble">${esc(line(s.passed ? "win" : "fail"))}</span>
    </div>
    ${cfg.kind !== "review" ? `<div class="stars" aria-label="${s.stars} étoiles sur 3">${[1, 2, 3].map((n) => `<span class="${n <= s.stars ? "on" : ""}" style="--d:${n * 160}ms">★</span>`).join("")}</div>` : ""}
    <h1>${headline}</h1>
    <p class="muted">${esc(msg)}</p>
    <div class="res-tiles">
      ${tile("⚡", "XP gagnés", s.xpGained, "t-xp", s.xpGained)}
      ${tile("🎯", "Précision", `${pct} %`, pct >= 80 ? "t-acc" : "t-acc low", null)}
      ${tile("⏱️", "Temps", time, "t-time")}
      ${tile("🔥", "Série", `${streak} j`, "t-streak")}
    </div>
    <div class="result-chips">
      <span class="chip">✅ ${s.score} / ${s.total}</span>
      ${s.newWords ? `<span class="chip">📒 +${s.newWords} mots</span>` : ""}
      ${s.total - s.score ? `<span class="chip warn">🔁 ${s.total - s.score} à revoir</span>` : ""}
    </div>
    ${mistakesHtml(s.results, { open: (s.total - s.score) <= 6 })}
    <div class="result-actions">
      ${primary}
      <a class="btn ghost" href="${cfg.back}">${cfg.kind === "lesson" ? "Relire la leçon" : "Retour"}</a>
    </div>
  </section>`;

  // Les XP défilent jusqu'à leur valeur
  app.querySelectorAll("[data-count]").forEach((el) => {
    const end = +el.dataset.count, t0 = performance.now();
    const step = (t) => { const k = Math.min(1, (t - t0) / 900); el.textContent = Math.round(end * (1 - Math.pow(1 - k, 3))); if (k < 1) requestAnimationFrame(step); };
    requestAnimationFrame(step);
  });
  if (cfg.kind === "exam" && s.passed && s.firstPass) { celebrate({ sound: "fanfare" }); setTimeout(() => showDiploma(cfg.id, s), 900); }
  else if (s.passed && (s.firstPass || s.ratio === 1)) celebrate();
  else if (s.passed) sfx("win");
}

/** Diplôme plein écran quand un palier est validé pour la première fois */
function showDiploma(levelId, s) {
  const level = getLevel(levelId), li = LEVELS.indexOf(level), next = LEVELS[li + 1];
  const name = state.profile?.pseudo || "";
  const date = new Date().toLocaleDateString("fr-FR", { day: "numeric", month: "long", year: "numeric" });
  const el = document.createElement("div");
  el.className = "diploma-screen";
  el.innerHTML = `
    <div class="dip-card" role="dialog" aria-label="Diplôme ${esc(lvlLabel(level))}">
      <div class="dip-ribbon">🎓</div>
      <p class="dip-kicker">Diplôme</p>
      <h2>Palier ${esc(lvlLabel(level))}</h2>
      <p class="dip-level">${esc(level.name)} · ${esc(level.title)}</p>
      <p class="dip-to">décerné à</p>
      <p class="dip-name">${esc(name)} ${esc(state.profile?.avatar || "")}</p>
      <p class="dip-meta">${esc(L.label)} · ${s.score}/${s.total} · ${date}</p>
      <div class="dip-seal">${esc(L.brand)}</div>
      <div class="dip-actions">
        ${next ? `<a class="btn primary big" href="#parcours" data-next="${next.id}">Découvrir le palier ${esc(lvlLabel(next))} →</a>` : `<a class="btn primary big" href="#tableau">Voir mon parcours</a>`}
        ${navigator.share ? `<button class="btn ghost" data-share>Partager</button>` : ""}
        <button class="btn ghost" data-close>Fermer</button>
      </div>
    </div>`;
  document.body.appendChild(el);
  requestAnimationFrame(() => el.classList.add("in"));
  const close = () => { el.classList.remove("in"); setTimeout(() => el.remove(), 250); };
  el.querySelector("[data-close]").onclick = close;
  el.querySelector("[data-next]")?.addEventListener("click", () => { close(); setTimeout(() => document.getElementById(`palier-${next.id}`)?.scrollIntoView({ behavior: "smooth" }), 400); });
  el.querySelector("[data-share]")?.addEventListener("click", () => navigator.share({ title: `Diplôme ${lvlLabel(level)}`, text: `🎓 J'ai validé le palier ${lvlLabel(level)} en ${L.label.toLowerCase()} sur ${L.brand} !`, url: location.origin + location.pathname }).catch(() => {}));
}
