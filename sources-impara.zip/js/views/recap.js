/* =====================================================================
   recap.js — Récap d'un joueur sur UNE langue (la plus avancée par défaut),
   avec des drapeaux pour passer à l'autre langue s'il l'étudie aussi.
   Utilisé par le profil d'un ami et par les profils de Découvrir.
   ===================================================================== */
import { LANGS, flagSVG } from "../core/lang.js";
import { esc } from "../core/ui.js";

const fmt = (n) => (n == null ? "–" : Number(n).toLocaleString("fr-FR"));
/** Langue la plus avancée : parcours le plus avancé, puis le plus d'XP */
export const bestLang = (stats, langs) => [...langs].sort((a, b) => (stats[b].pct || 0) - (stats[a].pct || 0) || (stats[b].xp || 0) - (stats[a].xp || 0))[0];

export function recapHtml(stats, langs, chosen, emptyMsg) {
  if (!langs.length) return `<p class="muted small">${emptyMsg}</p>`;
  const c = langs.includes(chosen) ? chosen : bestLang(stats, langs), t = stats[c];
  return `<div class="fp-recap">
    <div class="fp-lang-row">
      <p class="fp-lang"><span class="flag mini">${flagSVG(c)}</span>${esc(LANGS[c].label)} · <b>${esc(t.level || "")}</b> <small>${esc(t.levelName || "")}</small></p>
      ${langs.length > 1 ? `<div class="fp-lang-pick" role="group" aria-label="Choisir la langue du récap">${langs.map((x) => `<button type="button" class="${x === c ? "on" : ""}" data-recap-lang="${x}" aria-pressed="${x === c}" aria-label="Voir le récap en ${esc(LANGS[x].label.toLowerCase())}"><span class="flag mini">${flagSVG(x)}</span></button>`).join("")}</div>` : ""}
    </div>
    <div class="pf-grid">
      <div class="pf-card"><span>🔥</span><b>${t.streak || 0} j</b><small>Série</small></div>
      <div class="pf-card"><span>⚡</span><b>${fmt(t.xp)}</b><small>XP au total</small></div>
      <div class="pf-card"><span>📈</span><b>${t.pct ?? 0} %</b><small>du parcours</small></div>
      <div class="pf-card"><span>📒</span><b>${fmt(t.words)}</b><small>Mots appris</small></div>
      <div class="pf-card"><span>✅</span><b>${t.lessons ?? "–"}</b><small>Leçons</small></div>
      <div class="pf-card"><span>🏅</span><b>${esc(t.level || "–")}</b><small>Niveau</small></div>
    </div></div>`;
}
/** Branche les drapeaux : `onPick(lang)` redessine le récap */
export function bindRecap(zone, onPick) {
  zone.querySelectorAll("[data-recap-lang]").forEach((b) => (b.onclick = () => onPick(b.dataset.recapLang)));
}
