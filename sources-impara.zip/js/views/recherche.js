/* =====================================================================
   Vue « Recherche » (#recherche) — la loupe de l'en-tête
   Un seul champ pour trouver :
     - un mot (en italien/mandarin, en français ou en pinyin sans tons),
       dans toutes les leçons et dans « Mes mots » → fiche du mot ;
     - une leçon (titre) ;
     - une fiche de grammaire (titre ou contenu d'une section).
   Les leçons pas encore débloquées sont signalées par un cadenas.
   ===================================================================== */
import { LEVELS, lvlLabel } from "../data/curriculum.js";
import { state } from "../core/storage.js";
import * as P from "../core/progress.js";
import { esc, tri } from "../core/ui.js";
import { L, code } from "../core/lang.js";
import { pyText } from "../core/pinyin.js";
import { openWordSheet } from "./word-sheet.js";

const isZh = () => code === "zh";
const fold = (s) => String(s || "").normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase().replace(/[’']/g, "'").replace(/\s+/g, " ").trim();
const strip = (s) => String(s || "").replace(/<[^>]+>/g, " ");
let index = null, indexLang = null, lastQ = "";

function buildIndex() {
  if (index && indexLang === code) return index;
  const words = new Map(), lessons = [], fiches = [];
  LEVELS.forEach((lv) => lv.lessons.forEach((l) => {
    lessons.push({ l, lv, k: fold(`${l.title} ${l.intro || ""}`) });
    (l.vocab || []).map(tri).forEach(([w, py, fr]) => {
      if (!w || words.has(w)) return;
      words.set(w, { zh: w, py: py || "", fr: String(fr || "").split(" — ")[0], levelId: lv.id, lessonId: l.id, k: fold(w), kfr: fold(fr), kpy: fold(py).replace(/\s/g, "") });
    });
    if (l.module !== "vocab") (l.sections || []).forEach((s, i) => fiches.push({ l, lv, s, i, kt: fold(strip(s.title)), kb: fold(strip([s.text, ...(s.examples || []).flat()].join(" "))) }));
  }));
  Object.values(state.vocab || {}).forEach((w) => {
    if (!words.has(w.zh)) words.set(w.zh, { ...w, k: fold(w.zh), kfr: fold(w.fr), kpy: fold(w.py).replace(/\s/g, "") });
  });
  indexLang = code;
  return (index = { words: [...words.values()], lessons, fiches });
}

function search(q) {
  const { words, lessons, fiches } = buildIndex();
  const f = fold(q), fpy = f.replace(/\s/g, "");
  if (!f) return null;
  const score = (k) => (k === f ? 0 : k.startsWith(f) ? 1 : new RegExp(`(^|[^a-z])${f.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}`).test(k) ? 2 : k.includes(f) ? 3 : 9);
  const W = words.map((w) => {
    let s = Math.min(score(w.k), score(w.kfr) + .5);
    if (isZh() && fpy.length > 1 && /^[a-z]+$/.test(fpy)) s = Math.min(s, w.kpy === fpy ? 0 : w.kpy.startsWith(fpy) ? 1.2 : 9);
    return [s, w];
  }).filter(([s]) => s < 9).sort((a, b) => a[0] - b[0] || a[1].zh.length - b[1].zh.length).map(([, w]) => w);
  const Ls = lessons.map((x) => [score(x.k), x]).filter(([s]) => s < 9).sort((a, b) => a[0] - b[0]).map(([, x]) => x);
  const Fs = fiches.map((x) => [score(x.kt) < 9 ? score(x.kt) : f.length > 2 && x.kb.includes(f) ? 5 : 9, x]).filter(([s]) => s < 9).sort((a, b) => a[0] - b[0]).map(([, x]) => x);
  return { W, Ls, Fs };
}

const open = (l) => P.isLessonUnlocked(l) || P.isLessonDone(l.id);
const hl = (txt, q) => {
  const t = esc(txt), f = fold(q);
  if (!f) return t;
  const i = fold(txt).indexOf(f);
  return i < 0 || fold(txt).length !== String(txt).length ? t : `${esc(txt.slice(0, i))}<mark>${esc(txt.slice(i, i + f.length))}</mark>${esc(txt.slice(i + f.length))}`;
};

function results(q) {
  const r = search(q);
  if (!r) return `<div class="gs-hint"><p class="muted">Tapez un mot ${isZh() ? "en chinois, en pinyin (sans les tons)" : "en italien"} ou en français, le nom d'une leçon ou d'un point de grammaire.</p>
    <div class="chips">${(isZh() ? ["你好", "chi", "了", "famille", "comparaison"] : ["casa", "mangiare", "subjonctif", "famille", "articles"]).map((x) => `<button type="button" class="chip-btn" data-try="${esc(x)}">${esc(x)}</button>`).join("")}</div></div>`;
  const { W, Ls, Fs } = r;
  if (!W.length && !Ls.length && !Fs.length) return `<p class="empty">Aucun résultat pour « ${esc(q)} ».</p>`;
  const sec = (title, n, html, more = 0) => `<section class="gs-sec"><h2 class="h3">${title} <small class="muted">${n}</small></h2>${html}${more ? `<p class="muted small">… et ${more} autre${more > 1 ? "s" : ""}. Précisez la recherche.</p>` : ""}</section>`;
  return [
    W.length ? sec("📒 Mots", W.length, `<ul class="gs-list">${W.slice(0, 30).map((w, i) => {
      const lv = LEVELS.find((x) => x.id === w.levelId);
      return `<li><button type="button" class="gs-item" data-w="${i}"><span class="gs-w ${L.wordClass}"><span>${hl(w.zh, q)}</span>${isZh() && w.py ? `<small class="py">${esc(w.py)}</small>` : ""}</span><span class="gs-fr">${hl(w.fr, q)}</span>${lv ? `<span class="tag" style="--lvl:${lv.color}">${esc(lvlLabel(lv))}</span>` : `<span class="tag perso">Perso</span>`}</button></li>`;
    }).join("")}</ul>`, Math.max(0, W.length - 30)) : "",
    Ls.length ? sec("📘 Leçons", Ls.length, `<ul class="gs-list">${Ls.slice(0, 12).map(({ l, lv }) => item(l, lv, `${l.emoji || "📘"} ${pyText(lv.id, l.title)}`, P.isLessonDone(l.id) ? "✓ Faite" : "")).join("")}</ul>`) : "",
    Fs.length ? sec("📋 Fiches", Fs.length, `<ul class="gs-list">${Fs.slice(0, 15).map(({ l, lv, s }) => item(l, lv, pyText(lv.id, strip(s.title)), esc(l.title))).join("")}</ul>`, Math.max(0, Fs.length - 15)) : "",
  ].join("");
}
function item(l, lv, title, sub) {
  const ok = open(l);
  return `<li><a class="gs-item ${ok ? "" : "locked"}" ${ok ? `href="#lecon-${l.id}"` : `aria-disabled="true"`}><span class="gs-t">${title}${sub ? `<small class="muted">${sub}</small>` : ""}</span><span class="tag" style="--lvl:${lv.color}">${ok ? "" : "🔒 "}${esc(lvlLabel(lv))}</span></a></li>`;
}

export function renderRecherche(app) {
  app.innerHTML = `
  <header class="page-head gs-head">
    <h1>🔎 Rechercher</h1>
    <input type="search" class="search gs-input" placeholder="${isZh() ? "Mot, pinyin, leçon, grammaire…" : "Mot, leçon, grammaire…"}" value="${esc(lastQ)}" aria-label="Rechercher" enterkeyhint="search" autocomplete="off" autocapitalize="off" spellcheck="false">
  </header>
  <div class="gs-out"></div>`;
  const input = app.querySelector(".gs-input"), out = app.querySelector(".gs-out");
  let cur = [];
  const draw = () => { lastQ = input.value; out.innerHTML = results(lastQ); cur = search(lastQ)?.W || []; };
  let t = 0;
  input.addEventListener("input", () => { clearTimeout(t); t = setTimeout(draw, 120); });
  input.addEventListener("keydown", (e) => { if (e.key === "Enter") input.blur(); });
  out.addEventListener("click", (e) => {
    const tr = e.target.closest("[data-try]");
    if (tr) { input.value = tr.dataset.try; draw(); return; }
    const w = e.target.closest("[data-w]");
    if (w) openWordSheet(cur[+w.dataset.w]);
  });
  draw();
  setTimeout(() => input.focus({ preventScroll: true }), 60);
  return true;
}
