/* =====================================================================
   Vue « Paramètres » (roue ⚙️ en haut à droite)
   Une liste de catégories (#reglages) ; chacune s'ouvre sur sa page
   (#reglages-compte, -preferences, -notifications, -cours).
   Chaque choix est enregistré immédiatement.
   ===================================================================== */

import { state, commit, replaceState, exportState, defaultState, isPersistent } from "../core/storage.js";
import { esc, toast, modal, speak, VOICE_SPEEDS, listVoices, setVoice, currentVoice, onVoices } from "../core/ui.js";
import { loadAudioIndex, audioInfo, VOICES, mainVoice, tonesFixed } from "../core/audio.js";
import { L, LANGS, code, flagSVG, setLang } from "../core/lang.js";
import * as C from "../core/cloud.js";
import * as So from "../core/social.js";
import * as PWA from "../core/pwa.js";
import { PINYIN_MODES } from "../core/pinyin.js";
import { GOALS } from "./profil.js";
import { getTheme, setTheme, getLangTheme, setLangTheme } from "../core/theme.js";
import { sfx, haptic } from "../core/fx.js";
import { icon } from "../core/icons.js";
import { CHANGELOG, whenLabel } from "../data/changelog.js";
import { unseenNews, markNewsSeen } from "../core/news.js";

const SYNC = {
  off: "Mode local", guest: "Non connecté", syncing: "Synchronisation…", synced: "Synchronisé",
  offline: "Hors ligne", error: "Problème de synchronisation",
};
const SAMPLE = { it: "Ciao! Come stai? Oggi impariamo l'italiano insieme.", zh: "你好！我们今天一起学习中文。" };
const saved = () => toast("Enregistré ✓", "ok");
const chev = () => `<span class="st-chev">${icon("chevron", { size: 18, stroke: 2.4 })}</span>`;

/* ----------------------------- Briques ------------------------------ */
const seg = (name, items, current) => `<div class="seg wide st-seg" role="group">${items.map(([v, l, small]) =>
  `<button type="button" data-${name}="${v}" class="${String(v) === String(current) ? "on" : ""}">${l}${small ? `<small>${small}</small>` : ""}</button>`).join("")}</div>`;
const item = (href, ico, title, value = "", cls = "") =>
  `<a class="st-item ${cls}" href="#${href}"><span class="st-ico">${ico}</span><span class="st-t">${title}</span>${value ? `<span class="st-v">${value}</span>` : ""}${chev()}</a>`;
const toggle = (attr, title, on, sub = "") =>
  `<label class="st-item st-tog"><span class="st-t">${title}${sub ? `<small>${sub}</small>` : ""}</span><input type="checkbox" ${attr} ${on ? "checked" : ""}><i class="st-sw" aria-hidden="true"></i></label>`;
const block = (title, inner) => `<div class="st-item st-block"><span class="st-t">${title}</span>${inner}</div>`;
const slider = (key, title, value, off = false) =>
  `<div class="st-item st-block st-slider ${off ? "off" : ""}" data-slider="${key}"><span class="st-t">${title}<output>${value} %</output></span>
    <input type="range" min="0" max="100" step="5" value="${value}" aria-label="${title}"></div>`;
const action = (attr, ico, title, cls = "") => `<button type="button" class="st-item st-act ${cls}" ${attr}><span class="st-ico">${ico}</span><span class="st-t">${title}</span></button>`;
const section = (title, rows) => `${title ? `<p class="st-sec">${title}</p>` : ""}<div class="st-list">${rows}</div>`;
const page = (title, body, back = true) => `<div class="st">
  <header class="st-head">${back ? `<a class="st-back" href="#reglages" aria-label="Retour">${icon("back", { size: 22, stroke: 2.4 })}</a>` : ""}<h1>${title}</h1></header>
  ${body}</div>`;

const PAGES = { compte: renderCompte, preferences: renderPreferences, notifications: renderNotifications, cours: renderCours, nouveautes: renderNews };

export function renderReglages(app, sub = "") {
  if (sub && PAGES[sub]) return PAGES[sub](app);
  const p = state.profile, i = C.cloudInfo();
  const notifLabel = state.settings.pushOn ? "Activées" : "";
  app.innerHTML = page("Paramètres", `
    ${section("Compte", `
      ${item("reglages-compte", esc(p.avatar || "👤"), "Compte", esc(i.user ? p.pseudo || "" : C.isConfigured() ? "Non connecté" : "Mode local"))}
      ${item("reglages-notifications", "🔔", "Notifications", `<span data-notif-v>${notifLabel}</span>`)}`)}
    ${section("Application", `
      ${item("reglages-preferences", "🎨", "Préférences")}
      ${item("reglages-cours", `<span class="flag mini">${flagSVG(code)}</span>`, "Cours", esc(L.label))}
      ${item("reglages-nouveautes", "📣", "Nouveautés", unseenNews() ? `<span class="st-badge">${unseenNews()}</span>` : "")}
      <div data-zone="install"></div>`)}
    <p class="st-foot">Impara · italien &amp; mandarin · <a href="sources-impara.zip">code source</a></p>`, false);
  // Valeur « Activées » / « Désactivées » de la ligne Notifications
  PWA.pushState().then((st) => { const v = app.querySelector("[data-notif-v]"); if (v) v.textContent = st === "on" ? "Activées" : "Désactivées"; });
  // Installer l'application (si possible et pas déjà fait)
  if (!PWA.isStandalone() && PWA.canPrompt()) {
    const z = app.querySelector('[data-zone="install"]');
    z.outerHTML = action("data-install", "📲", "Installer l'application");
    app.querySelector("[data-install]").onclick = async () => { if (await PWA.promptInstall()) toast("Application installée ✓", "ok"); };
  }
  return true;
}

/* ------------------------------ Compte ------------------------------ */
function renderCompte(app) {
  const paint = () => {
    const p = state.profile, i = C.cloudInfo();
    const head = `<div class="st-profile"><span class="st-avatar">${esc(p.avatar || "👤")}</span>
      <div><b>${esc(p.pseudo || "")}</b><small>${i.user ? esc(i.user.email) : C.isConfigured() ? "Pas encore de compte en ligne" : "Progression gardée sur cet appareil"}</small></div></div>`;
    let cloud = "";
    if (C.isConfigured() && !i.user) cloud = section("", item("compte", "☁️", "Se connecter / créer un compte"));
    else if (i.user) {
      const when = i.lastSync ? ` · ${new Date(i.lastSync).toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" })}` : "";
      cloud = section("", `
        ${action("data-sync", i.status === "synced" ? "✅" : i.status === "error" ? "⚠️" : "🔄", `Synchronisation<small>${SYNC[i.status] || ""}${when}</small>`)}
        ${action("data-logout", "🚪", "Se déconnecter", "danger")}`);
    }
    const me = So.social().me;
    const disc = i.user ? section("Découvrir", `
        ${toggle("data-dtab", "🧭 Onglet Découvrir", !!state.settings.discoverTab, "Classement général et profils des joueurs")}
        ${me ? toggle("data-dvis", "Apparaître dans Découvrir", !!me.discover, "Pseudo, avatar et XP visibles des autres joueurs") : ""}`) : "";
    app.innerHTML = page("Compte", `
      ${head}
      ${section("", item("profil", "✏️", "Modifier le profil"))}
      ${cloud}
      ${disc}
      ${section("Sauvegarde", `
        ${action("data-export", "📋", "Copier ma sauvegarde")}
        <label class="st-item st-act"><span class="st-ico">📂</span><span class="st-t">Importer un fichier</span><input type="file" accept=".json,application/json" hidden></label>
        ${action("data-paste", "📝", "Coller une sauvegarde")}`)}
      ${!isPersistent() ? `<p class="st-note warn">⚠️ Ce navigateur ne garde pas la progression : copiez votre sauvegarde avant de fermer.</p>` : ""}
      ${section("Zone sensible", action("data-reset", "🗑️", `Réinitialiser ma progression<small>${esc(L.label)} : leçons, carnet et erreurs</small>`, "danger"))}`);
    bind();
  };
  const doImport = (text) => {
    try {
      const data = JSON.parse(text);
      if (!data || typeof data !== "object" || !("lessons" in data)) throw new Error();
      replaceState(data); toast("Sauvegarde importée ✓", "ok"); location.hash = "tableau";
    } catch { toast("Fichier de sauvegarde invalide", "error"); }
  };
  const bind = () => {
    const $ = (s) => app.querySelector(s);
    $("[data-sync]")?.addEventListener("click", async () => {
      await C.syncNow();
      const ok = C.cloudInfo().status === "synced";
      toast(ok ? "Synchronisé ✓" : C.cloudInfo().message, ok ? "ok" : "warn");
    });
    $("[data-logout]")?.addEventListener("click", async () => {
      const v = await modal({ title: "Se déconnecter ?", body: "<p>Votre progression reste en ligne : vous la retrouverez en vous reconnectant.</p>",
        actions: [{ label: "Annuler", value: "no" }, { label: "Se déconnecter", value: "yes", kind: "danger" }] });
      if (v === "yes") { await C.signOut(); toast("Déconnecté", "ok"); location.hash = "parcours"; window.dispatchEvent(new HashChangeEvent("hashchange")); }
    });
    $("[data-dtab]")?.addEventListener("change", (e) => { commit((st) => { st.settings.discoverTab = e.target.checked; }); saved(); });
    $("[data-dvis]")?.addEventListener("change", async (e) => {
      try { await So.setDiscoverable(e.target.checked); saved(); }
      catch (err) { e.target.checked = !e.target.checked; toast(So.socialError(err), "warn"); }
    });
    $("[data-export]").onclick = async () => {
      try { await navigator.clipboard.writeText(exportState()); toast("Sauvegarde copiée ✓", "ok"); }
      catch {
        modal({ title: "Votre sauvegarde", body: `<textarea class="export-box" rows="8" readonly>${esc(exportState())}</textarea>` });
        setTimeout(() => document.querySelector(".export-box")?.select(), 50);
      }
    };
    $("input[type=file]").onchange = (e) => { const f = e.target.files[0]; if (!f) return; const r = new FileReader(); r.onload = () => doImport(r.result); r.readAsText(f); };
    $("[data-paste]").onclick = async () => {
      let t = "";
      const v = await modal({ title: "Coller une sauvegarde", body: `<textarea class="export-box paste-box" rows="7" placeholder='{"version":1, …}'></textarea>`,
        actions: [{ label: "Annuler", value: "" }, { label: "Importer", value: "go", kind: "primary" }],
        onOpen: () => { const ta = document.querySelector(".paste-box"); ta?.addEventListener("input", () => (t = ta.value)); setTimeout(() => ta?.focus(), 50); } });
      if (v === "go" && t.trim()) doImport(t);
    };
    $("[data-reset]").onclick = async () => {
      const v = await modal({ title: "Tout réinitialiser ?",
        body: `<p>Votre progression en ${esc(L.label.toLowerCase())}, votre carnet et votre cahier d'erreurs seront effacés. C'est irréversible.</p>`,
        actions: [{ label: "Annuler", value: "no", kind: "ghost" }, { label: "Oui, tout effacer", value: "yes", kind: "danger" }] });
      if (v === "yes") { replaceState(defaultState()); location.hash = "parcours"; window.dispatchEvent(new HashChangeEvent("hashchange")); }
    };
  };
  paint();
  const off = C.onCloud(() => { if (app.querySelector(".st")) paint(); });
  // « Apparaître dans Découvrir » dépend du profil en ligne : on l'affiche dès qu'il est chargé
  if (C.cloudInfo().user && !So.social().ready) So.refresh().then(() => { if (app.querySelector(".st") && location.hash === "#reglages-compte") paint(); }).catch(() => {});
  app._cleanup = off;
  return true;
}

/* ---------------------------- Préférences ---------------------------- */
function renderPreferences(app) {
  const p = state.profile;
  const ios = PWA.isIOS();
  app.innerHTML = page("Préférences", `
    ${section("Apparence", `
      <div class="st-item st-block"><div class="theme-pick">${[["auto", "Auto", "t-auto"], ["light", "Clair", "t-light"], ["dark", "Sombre", "t-dark"]].map(([v, l, c]) =>
        `<button type="button" class="theme-opt ${getTheme() === v ? "on" : ""}" data-theme-opt="${v}"><i class="${c}"></i>${l}</button>`).join("")}</div></div>
      ${toggle("data-lang-theme", "Couleurs de la langue", getLangTheme(), code === "zh" ? "Rouge et or" : "Vert, blanc, rouge")}`)}
    ${section("Objectif quotidien", block("", seg("goal", GOALS.map(([v, l]) => [v, l, `${v} XP`]), p.dailyGoal)))}
    ${section("Son", `
      ${toggle("data-tts", "Lecture automatique des mots", state.settings.tts)}
      <div data-zone="recorded"></div>
      ${block("Vitesse de la voix", seg("voice", VOICE_SPEEDS, state.settings.voiceSpeed || 1))}
      ${slider("volume", "Volume de la voix", state.settings.volume ?? 100)}
      ${toggle("data-sfx", "Effets sonores", state.settings.sfx !== false)}
      ${slider("sfxVolume", "Volume des effets sonores", state.settings.sfxVolume ?? 100, state.settings.sfx === false)}
      ${ios ? "" : toggle("data-haptics", "Vibrations", state.settings.haptics !== false)}`)}
    <details class="st-more"><summary>Voix de l'appareil</summary><div data-zone="voices"></div></details>`);

  const $ = (s) => app.querySelector(s);
  const pick = (name, apply) => app.querySelectorAll(`[data-${name}]`).forEach((b) => (b.onclick = () => {
    app.querySelectorAll(`[data-${name}]`).forEach((x) => x.classList.toggle("on", x === b));
    apply(b.dataset[name]); saved();
  }));
  app.querySelectorAll("[data-theme-opt]").forEach((b) => (b.onclick = () => {
    app.querySelectorAll("[data-theme-opt]").forEach((x) => x.classList.toggle("on", x === b));
    setTheme(b.dataset.themeOpt);
  }));
  pick("goal", (v) => commit((s) => { s.profile = { ...s.profile, dailyGoal: +v }; }));
  pick("voice", (v) => { commit((s) => { s.settings.voiceSpeed = +v; }); speak(L.hello, { force: true }); });
  $("[data-lang-theme]").onchange = (e) => setLangTheme(e.target.checked);
  $("[data-sfx]").onchange = (e) => { commit((s) => { s.settings.sfx = e.target.checked; }); if (e.target.checked) sfx("good"); $("[data-slider=sfxVolume]")?.classList.toggle("off", !e.target.checked); };
  // Volumes : on enregistre en glissant, on fait écouter au relâchement
  app.querySelectorAll("[data-slider]").forEach((box) => {
    const key = box.dataset.slider, input = box.querySelector("input"), out = box.querySelector("output");
    const paint = () => { out.textContent = `${input.value} %`; input.style.setProperty("--p", `${input.value}%`); };
    input.oninput = () => { paint(); commit((s) => { s.settings[key] = +input.value; }); };
    input.onchange = () => { saved(); if (key === "volume") speak(L.hello, { force: true }); else sfx("good"); };
    paint();
  });
  $("[data-haptics]")?.addEventListener("change", (e) => { commit((s) => { s.settings.haptics = e.target.checked; }); if (e.target.checked) haptic(40); });
  $("[data-tts]").onchange = (e) => commit((s) => { s.settings.tts = e.target.checked; });

  paintVoices(app);
  loadAudioIndex().then(() => paintRecorded(app));
  const offVoices = onVoices(() => paintVoices(app));
  app._cleanup = () => offVoices();
  return true;
}

function paintRecorded(app) {
  const z = app.querySelector('[data-zone="recorded"]'), info = audioInfo();
  if (!z || !info) return;
  const voices = VOICES[code] || [], cur = mainVoice();
  const rec = state.settings.recordedVoice !== false;
  const many = voices.length > 1;
  // Voix enregistrées (Sara / Nicola, Xiaoxiao / Yunxi) ou voix de l'appareil (iPhone, Android…)
  z.innerHTML = block("Voix utilisée", seg("voice-src", [["rec", "Enregistrée", voices.map((v) => v.name).join(" / ")], ["dev", "De l'appareil", PWA.isIOS() ? "iPhone" : "système"]], rec ? "rec" : "dev"))
    + (rec && many ? block("Voix principale<small>L'autre voix joue le 2e personnage des dialogues et histoires</small>", seg("rec-voice", voices.map((v) => [v.id, v.name, v.sex === "m" ? "homme" : "femme"]), cur)) : "")
    + (rec && code === "zh" ? block("Version des voix", seg("tone-fix", [["1", "Tons corrigés", "recommandé"], ["0", "D'origine", "sans correction"]], tonesFixed() ? "1" : "0")) : "");
  const more = app.querySelector(".st-more");
  if (more) { more.hidden = rec; more.open = !rec; }
  app.querySelectorAll("[data-voice-src]").forEach((b) => (b.onclick = () => {
    commit((s) => { s.settings.recordedVoice = b.dataset.voiceSrc === "rec"; });
    paintRecorded(app); paintVoices(app); saved();
    speak(SAMPLE[code] || L.hello, { force: true });
  }));
  app.querySelectorAll("[data-tone-fix]").forEach((b) => (b.onclick = () => {
    app.querySelectorAll("[data-tone-fix]").forEach((x) => x.classList.toggle("on", x === b));
    commit((s) => { s.settings.toneFix = b.dataset.toneFix === "1"; });
    Promise.all(voices.map((v) => loadAudioIndex(v.id))).then(() => speak(SAMPLE[code] || L.hello, { force: true }));
  }));
  app.querySelectorAll("[data-rec-voice]").forEach((b) => (b.onclick = () => {
    app.querySelectorAll("[data-rec-voice]").forEach((x) => x.classList.toggle("on", x === b));
    commit((s) => { s.settings.recVoice = { ...(s.settings.recVoice || {}), [code]: b.dataset.recVoice }; });
    loadAudioIndex(b.dataset.recVoice).then(() => speak(SAMPLE[code] || L.hello, { force: true }));
  }));
}

function voiceHelp() {
  const ua = navigator.userAgent || "";
  if (/iPhone|iPad|iPod/.test(ua) || (/Macintosh/.test(ua) && navigator.maxTouchPoints > 1)) return "Sur iPhone, seules les voix de base sont accessibles aux sites web.";
  if (/Android/.test(ua)) return "Astuce : dans les paramètres Android, « Synthèse vocale » › moteur Google › installez la langue.";
  if (/Edg\//.test(ua)) return "Astuce : les voix « Natural » d'Edge sont les plus réalistes.";
  return "Astuce : Edge (voix « Natural ») et Chrome (voix « Google ») ont les voix les plus naturelles.";
}
function paintVoices(app) {
  const z = app.querySelector('[data-zone="voices"]');
  if (!z) return;
  const list = listVoices(), chosen = state.settings.voiceName?.[code] || "";
  const best = list[0];
  z.innerHTML = list.length ? `
    <p class="st-note">${state.settings.recordedVoice === false ? "Utilisée pour toutes les phrases." : "Utilisée pour ce qui n'est pas enregistré."}</p>
    <div class="voice-row">
      <select data-voice-pick aria-label="Voix de l'appareil">
        <option value="" ${!chosen ? "selected" : ""}>Automatique${best ? ` — ${esc(best.name)}` : ""}</option>
        ${list.map((x) => `<option value="${esc(x.name)}" ${chosen === x.name ? "selected" : ""}>${esc(x.name)} · ${esc(x.tag)}</option>`).join("")}
      </select>
      <button class="btn ghost small" data-voice-test>▶️</button>
    </div>
    <p class="st-note">${voiceHelp()}</p>`
    : `<p class="st-note">Aucune voix ${code === "zh" ? "mandarin" : "italienne"} sur cet appareil. ${voiceHelp()}</p>`;
  z.querySelector("[data-voice-pick]")?.addEventListener("change", (e) => { setVoice(e.target.value); speak(SAMPLE[code] || L.hello, { force: true, device: true }); });
  z.querySelector("[data-voice-test]")?.addEventListener("click", () => speak(SAMPLE[code] || L.hello, { force: true, device: true }));
}

/* --------------------------- Notifications --------------------------- */
// Catégories : enregistrées dans les réglages et envoyées avec le résumé de
// progression, que le serveur consulte avant chaque notification.
export const NOTIF_KINDS = [
  ["msg", "💬", "Messages"],
  ["friend", "👥", "Demandes d'ami"],
  ["defi", "⚔️", "Défis et résultats"],
  ["react", "👏", "Réactions à mes activités"],
  ["wotd", "✨", "Mot du jour (le matin, vers 9 h)"],
];
const HOURS = [[18, "18 h"], [19, "19 h"], [20, "20 h"], [21, "21 h"], [22, "22 h"]];

async function renderNotifications(app) {
  app.innerHTML = page("Notifications", `<div data-zone="notif"><p class="st-note">…</p></div>`);
  const z = app.querySelector('[data-zone="notif"]');
  const paint = async () => {
    const st = await PWA.pushState();
    if (!z.isConnected) return;
    let install = "";
    if (!PWA.isStandalone()) {
      if (PWA.canPrompt()) install = section("", action("data-install", "📲", "Installer l'application"));
      else if (PWA.isIOS()) install = `<p class="st-note">Sur iPhone : dans Safari, touchez <b>Partager</b> › <b>Sur l'écran d'accueil</b>, puis ouvrez l'application installée.</p>`;
    }
    const n = state.settings.notif || {};
    const msg = {
      unsupported: "Les notifications ne sont pas disponibles sur ce navigateur.",
      "needs-install": "Sur iPhone, installez d'abord l'application pour recevoir des notifications.",
      "needs-login": "Connectez-vous à votre compte pour recevoir des notifications.",
      denied: "Notifications bloquées : autorisez-les pour ce site dans les réglages du navigateur.",
    }[st];
    z.innerHTML = install + (msg ? `<p class="st-note">${msg}</p>${st === "needs-login" ? section("", item("compte", "☁️", "Se connecter")) : ""}`
      : st === "off" ? section("", action("data-push-on", "🔔", "Activer les notifications", "primary"))
      : `${section("Me prévenir pour", NOTIF_KINDS.map(([k, ico, l]) => toggle(`data-n="${k}"`, `${ico} ${l}`, n[k] !== false)).join(""))}
         ${section("Rappel de série", `${toggle("data-remind", "🔥 Me rappeler si je n'ai rien fait", state.settings.streakReminder !== false)}
           ${block("Heure du rappel", seg("hour", HOURS, state.settings.remindHour || 20))}`)}
         ${section("", action("data-push-off", "🔕", "Désactiver sur cet appareil", "danger"))}`);
    const $ = (s) => z.querySelector(s);
    $("[data-install]")?.addEventListener("click", async () => { if (await PWA.promptInstall()) toast("Application installée ✓", "ok"); });
    $("[data-push-on]")?.addEventListener("click", async (e) => {
      e.currentTarget.disabled = true;
      try { await PWA.enablePush(); commit((s) => { s.settings.pushOn = true; }); toast("Notifications activées 🔔", "ok"); } catch (err) { toast(err.message, "warn"); }
      paint();
    });
    $("[data-push-off]")?.addEventListener("click", async () => { await PWA.disablePush(); commit((s) => { s.settings.pushOn = false; }); toast("Notifications désactivées"); paint(); });
    z.querySelectorAll("[data-n]").forEach((t) => (t.onchange = () => commit((s) => { s.settings.notif = { ...(s.settings.notif || {}), [t.dataset.n]: t.checked }; })));
    $("[data-remind]")?.addEventListener("change", (e) => commit((s) => { s.settings.streakReminder = e.target.checked; }));
    z.querySelectorAll("[data-hour]").forEach((b) => (b.onclick = () => {
      z.querySelectorAll("[data-hour]").forEach((x) => x.classList.toggle("on", x === b));
      commit((s) => { s.settings.remindHour = +b.dataset.hour; }); saved();
    }));
  };
  await paint();
  const off = PWA.onPwa(() => paint());
  app._cleanup = off;
  return true;
}

/* ------------------------------- Cours ------------------------------- */
function renderCours(app) {
  app.innerHTML = page("Cours", `
    ${section("Langue apprise", Object.values(LANGS).map((l) => `<button type="button" class="st-item st-act st-radio ${l.code === code ? "on" : ""}" data-lang="${l.code}">
      <span class="st-ico"><span class="flag mini">${flagSVG(l.code)}</span></span><span class="st-t">${l.label}</span>${l.code === code ? `<span class="st-check">${icon("check", { size: 18, stroke: 3 })}</span>` : ""}</button>`).join(""))}
    <p class="st-note">Chaque langue garde sa propre progression.</p>
    ${section("Niveau", item("test-niveau", "🧭", "Test de niveau", esc(state.placement?.label || "")))}
    <p class="st-note">Quelques questions pour commencer directement au bon palier. Votre progression n'est jamais effacée.</p>
    ${code === "zh" ? section("Pinyin au-dessus des caractères", block("", seg("pyq", PINYIN_MODES, state.settings.pinyinQuiz || "auto"))) : ""}`);
  app.querySelectorAll("[data-lang]").forEach((b) => (b.onclick = () => { if (b.dataset.lang !== code) setLang(b.dataset.lang); }));
  app.querySelectorAll("[data-pyq]").forEach((b) => (b.onclick = () => {
    app.querySelectorAll("[data-pyq]").forEach((x) => x.classList.toggle("on", x === b));
    commit((s) => { s.settings.pinyinQuiz = b.dataset.pyq; }); saved();
  }));
  return true;
}

/* ----------------------------- Nouveautés ----------------------------- */
function renderNews(app) {
  const list = CHANGELOG.filter((e) => !e.lang || e.lang === code);
  const seen = state.settings.newsSeen || "";
  app.innerHTML = page("Nouveautés", list.map((e) => `
    <article class="nw ${e.at > seen ? "new" : ""}">
      <p class="nw-when">${esc(whenLabel(e.at))}${e.at > seen ? ` <span class="nw-tag">Nouveau</span>` : ""}</p>
      <h3 class="nw-title"><span>${e.emoji || "✨"}</span>${esc(e.title)}</h3>
      <ul>${e.items.map((x) => `<li>${esc(x)}</li>`).join("")}</ul>
    </article>`).join(""));
  markNewsSeen();
  return true;
}
