/* =====================================================================
   Vue « Ma série » (#serie) — ouverte depuis la flamme de l'en-tête
   série du jour, semaine, gels, récompenses, rappel et moment idéal,
   calendrier de pratique, XP des 30 jours, records.
   ===================================================================== */
import { state } from "../core/storage.js";
import * as P from "../core/progress.js";
import { esc, ring } from "../core/ui.js";
import { mascot } from "../core/mascot.js";
import { heatmap, xpCurve } from "./dashboard.js";
import { recordsCard, momentCard, bindSuivi } from "./suivi.js";

const DAYS = ["L", "M", "M", "J", "V", "S", "D"];

function weekRow() {
  const now = new Date(), monday = new Date(now);
  monday.setDate(now.getDate() - ((now.getDay() + 6) % 7));
  const today = P.dayKey();
  return DAYS.map((label, k) => {
    const d = new Date(monday); d.setDate(monday.getDate() + k);
    const key = P.dayKey(d), active = (state.dayLog?.[key] || 0) > 0, frozen = (state.frozenDays || []).includes(key);
    return `<div style="--k:${k}" class="ss-day ${active ? "on" : ""} ${frozen && !active ? "frozen" : ""} ${key === today ? "today" : ""} ${key > today ? "future" : ""}"><small>${label}</small><span>${active ? "✓" : frozen ? "🧊" : ""}</span></div>`;
  }).join("");
}

export function renderSerie(app) {
  const n = P.streakCount(), today = P.dayKey();
  const doneToday = (state.dayLog?.[today] || 0) > 0;
  const goal = state.profile?.dailyGoal || 50, xp = P.dailyXp(), gp = Math.min(100, Math.round((xp / goal) * 100));
  const end = new Date(); end.setHours(24, 0, 0, 0);
  const hLeft = Math.max(0, Math.floor((end - Date.now()) / 36e5)), mLeft = Math.max(0, Math.floor(((end - Date.now()) % 36e5) / 6e4));
  const freezes = state.streakFreezes || 0, toFreeze = P.FREEZE_EVERY - (n % P.FREEZE_EVERY);
  const next = P.nextStreakReward(n);
  const prevStep = [...P.STREAK_REWARDS].reverse().find(([d]) => d <= n)?.[0] || 0;
  const remind = state.settings.remindHour || 20;

  app.innerHTML = `
  <a class="back-link" href="#parcours">← Parcours</a>
  <section class="card sr-hero ${doneToday ? "lit" : ""}">
    <div class="sr-flame" aria-hidden="true">🔥</div>
    <div class="sr-main">
      <p class="sr-num"><b>${n}</b> jour${n > 1 ? "s" : ""} de série</p>
      <p class="sr-status">${doneToday ? "✅ Série prolongée aujourd'hui, bravo !" : n ? `⏳ Faites un exercice aujourd'hui pour la garder : encore ${hLeft} h ${String(mLeft).padStart(2, "0")}.` : "Faites un exercice pour allumer votre série."}</p>
    </div>
    <span class="sr-mascot">${mascot(doneToday ? "cheer" : "idle", { size: 72 })}</span>
    <div class="ss-week sr-week">${weekRow()}</div>
    ${doneToday ? "" : `<a class="btn primary" href="#seance">▶ Séance du jour (≈ 10 min)</a>`}
  </section>

  <div class="sr-grid">
    <section class="card sr-goal">
      ${ring(gp, 92, 9, `${xp}`)}
      <div><p class="eyebrow">Objectif du jour</p><h3>${xp} / ${goal} XP</h3>
        <p class="small muted">${gp >= 100 ? "Objectif atteint 🎉" : `Encore ${goal - xp} XP aujourd'hui.`}</p>
        <a class="link-btn small" href="#reglages-preferences">Changer l'objectif</a></div>
    </section>

    <section class="card sr-freeze">
      <h2 class="h3">🧊 Gels de série</h2>
      <div class="sr-ice">${Array.from({ length: P.FREEZE_MAX }, (_, i) => `<span class="${i < freezes ? "on" : ""}">🧊</span>`).join("")}<b>${freezes} / ${P.FREEZE_MAX}</b></div>
      <p class="small muted">Si vous oubliez un jour, un gel protège automatiquement votre série. Vous en gagnez un tous les ${P.FREEZE_EVERY} jours de série (${P.FREEZE_MAX} au maximum).</p>
      ${freezes < P.FREEZE_MAX ? `<p class="small">Prochain gel dans <b>${toFreeze} jour${toFreeze > 1 ? "s" : ""}</b>.</p>` : `<p class="small">Réserve pleine 👍</p>`}
    </section>

    <section class="card dash-wide sr-rewards">
      <h2 class="h3">🎁 Récompenses de série</h2>
      ${next ? `<p class="small">Prochaine récompense dans <b>${next[0] - n} jour${next[0] - n > 1 ? "s" : ""}</b> : ${esc(next[1])}.</p>
        <div class="sv-bar"><i style="width:${Math.round(((n - prevStep) / (next[0] - prevStep)) * 100)}%"></i></div>` : `<p class="small">Toutes les récompenses sont débloquées 🏆</p>`}
      <ol class="sr-steps">${P.STREAK_REWARDS.map(([d, what]) => `<li class="${n >= d ? "ok" : ""}"><b>${d} j</b><span>${esc(what)}</span><em>${n >= d ? "✓ Débloqué" : `${d - n} j`}</em></li>`).join("")}</ol>
      <a class="link-btn small" href="#personnaliser">Voir mes cadres, avatars et bannières →</a>
    </section>

    <section class="card sr-remind">
      <h2 class="h3">⏰ Rappel de série</h2>
      <p class="small">${state.settings.streakReminder === false ? "Le rappel est désactivé." : `Si votre série est en danger, une notification vous prévient vers <b>${remind} h</b>.`}</p>
      <a class="link-btn small" href="#reglages-notifications">Régler les notifications →</a>
    </section>
    ${momentCard()}

    ${heatmap()}
    ${xpCurve()}
    ${recordsCard()}
  </div>`;
  bindSuivi(app, () => { const y = scrollY; renderSerie(app); scrollTo(0, y); });
  return true;
}
