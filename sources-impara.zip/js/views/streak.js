/* =====================================================================
   Écran de série 🔥 : affiché une fois par jour, à la première activité
   qui rapporte des XP (après l'écran de résultat).
   ===================================================================== */
import { state } from "../core/storage.js";
import * as P from "../core/progress.js";
import { esc } from "../core/ui.js";
import { sfx, haptic } from "../core/fx.js";
import { mascot } from "../core/mascot.js";

const DAYS = ["L", "M", "M", "J", "V", "S", "D"];
const busy = () => document.body.classList.contains("focus-mode") || document.body.classList.contains("chat-mode") || document.querySelector(".modal, .streak-screen");

function message(n) {
  if (n === 1) return ["C'est parti !", "Reviens demain pour allumer ta série 🔥"];
  if ([3, 7, 14, 30, 50, 100, 200, 365].includes(n)) return [`Palier de ${n} jours atteint !`, "Incroyable régularité, continue comme ça !"];
  return ["Série prolongée !", `Reviens demain pour passer à ${n + 1} jours.`];
}

/** Semaine en cours (lundi → dimanche) : jours actifs d'après le journal d'XP */
function week() {
  const now = new Date(), monday = new Date(now);
  monday.setDate(now.getDate() - ((now.getDay() + 6) % 7));
  const today = P.dayKey();
  return DAYS.map((label, k) => {
    const d = new Date(monday); d.setDate(monday.getDate() + k);
    const key = P.dayKey(d);
    return { label, key, today: key === today, active: (state.dayLog?.[key] || 0) > 0, frozen: (state.frozenDays || []).includes(key), future: key > today };
  });
}

export function maybeShowStreak() {
  if (!P.hasStreakCelebration() || busy()) return;
  const n = P.takeStreakCelebration();
  const [title, sub] = message(n);
  const days = week();
  const el = document.createElement("div");
  el.className = "streak-screen";
  el.setAttribute("role", "dialog");
  el.innerHTML = `
    <div class="ss-inner">
      <div class="ss-top"><div class="ss-flame" aria-hidden="true">🔥</div><span class="ss-mascot">${mascot("cheer", { size: 96 })}</span></div>
      <p class="ss-num"><b data-n>${Math.max(0, n - 1)}</b></p>
      <p class="ss-label">jour${n > 1 ? "s" : ""} de série</p>
      <h2>${esc(title)}</h2>
      <div class="ss-week">${days.map((d, k) => `<div class="ss-day ${d.active ? "on" : ""} ${d.frozen && !d.active ? "frozen" : ""} ${d.today ? "today" : ""} ${d.future ? "future" : ""}" style="--k:${k}">
        <small>${d.label}</small><span>${d.active ? "✓" : d.frozen ? "🧊" : ""}</span></div>`).join("")}</div>
      <p class="ss-sub">${esc(sub)}</p>
      <div class="ss-extra">
        <span title="Un gel sauve votre série si vous manquez un jour. Vous en gagnez un tous les 7 jours (2 au maximum).">🧊 ${state.streakFreezes || 0} gel${(state.streakFreezes || 0) > 1 ? "s" : ""} de série</span>
        ${(() => { const r = P.nextStreakReward(n); return r ? `<span>🎁 Dans ${r[0] - n} jour${r[0] - n > 1 ? "s" : ""} : ${esc(r[1])}</span>` : ""; })()}
      </div>
      <button class="ss-go">Continuer</button>
    </div>`;
  document.body.appendChild(el);
  requestAnimationFrame(() => el.classList.add("in"));
  haptic([30, 60, 30]); sfx("streak");
  // Le compteur passe de n-1 à n
  setTimeout(() => { const b = el.querySelector("[data-n]"); b.textContent = n; b.classList.add("bump"); }, 650);
  const close = () => { el.classList.remove("in"); setTimeout(() => el.remove(), 250); };
  el.querySelector(".ss-go").onclick = close;
  el.querySelector(".ss-go").focus();
}
