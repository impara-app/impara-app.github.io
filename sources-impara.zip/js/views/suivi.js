/* =====================================================================
   suivi.js — Cartes avancées du Suivi
   bilan de la semaine (partageable), objectif de la semaine, niveau estimé,
   radar de compétences, prévision, évolution de la précision, temps d'étude,
   moment idéal, courbe du vocabulaire, révisions à venir, records.
   ===================================================================== */
import { LEVELS, lvlLabel } from "../data/curriculum.js";
import { state, commit } from "../core/storage.js";
import * as P from "../core/progress.js";
import { esc, toast, celebrate } from "../core/ui.js";
import { L } from "../core/lang.js";
import { SKILLS, weekStart, dayKey, minutesOn } from "../core/stats.js";

const MONTHS = ["janv.", "févr.", "mars", "avr.", "mai", "juin", "juil.", "août", "sept.", "oct.", "nov.", "déc."];
const DAYS = ["dim.", "lun.", "mar.", "mer.", "jeu.", "ven.", "sam."];
const fmtDate = (d) => `${d.getDate()} ${MONTHS[d.getMonth()]}`;
const addDays = (d, n) => { const x = new Date(d); x.setDate(x.getDate() + n); return x; };
const plural = (n, w) => `${n} ${w}${n > 1 ? "s" : ""}`;
const pct = (a, b) => (b ? Math.round((a / b) * 100) : 0);
const fmtMin = (m) => (m >= 60 ? `${Math.floor(m / 60)} h ${String(m % 60).padStart(2, "0")}` : `${m} min`);

/* ------------------------------ Données ------------------------------ */
/** Les 7 jours d'une semaine (lundi → dimanche), décalée de `off` semaines en arrière */
function weekDays(off = 0) {
  const mon = new Date(weekStart() + "T12:00:00"); mon.setDate(mon.getDate() - 7 * off);
  return Array.from({ length: 7 }, (_, i) => addDays(mon, i));
}
function weekData(off = 0, upto = 7) {
  const days = weekDays(off).slice(0, upto), keys = days.map(dayKey), wk = keys[0];
  const inWeek = (ts) => { if (!ts) return false; const k = dayKey(new Date(ts)); return k >= keys[0] && k <= keys[keys.length - 1]; };
  const xp = keys.reduce((n, k) => n + (state.dayLog?.[k] || 0), 0);
  const min = keys.reduce((n, k) => n + minutesOn(k), 0);
  const lessons = Object.values(state.lessons || {}).filter((l) => l.passed && inWeek(l.date)).length;
  const words = Object.values(state.vocab || {}).filter((w) => w.added > 1e12 && inWeek(w.added)).length;
  const W = state.stats?.w?.[wk] || {};
  const ok = Object.values(W).reduce((n, v) => n + v[0], 0), tot = Object.values(W).reduce((n, v) => n + v[1], 0);
  const days_ = keys.filter((k) => (state.dayLog?.[k] || 0) > 0).length;
  return { xp, min, lessons, words, acc: tot ? pct(ok, tot) : null, answers: tot, reviews: state.stats?.rev?.[wk] || 0, days: days_, keys };
}
/** Réponses par compétence sur les `n` dernières semaines */
function skillTotals(n = 6) {
  const weeks = Object.keys(state.stats?.w || {}).sort().slice(-n), out = {};
  SKILLS.forEach(([k]) => (out[k] = [0, 0]));
  weeks.forEach((wk) => Object.entries(state.stats.w[wk]).forEach(([k, v]) => { if (out[k]) { out[k][0] += v[0]; out[k][1] += v[1]; } }));
  return out;
}

/* ------------------------- 1. Bilan de la semaine ------------------------- */
function delta(a, b, unit = "%") {
  if (a == null || b == null) return "";
  if (unit === "pts") { const d = a - b; return d ? `<em class="${d > 0 ? "up" : "down"}">${d > 0 ? "+" : ""}${d} pts</em>` : `<em>=</em>`; }
  if (!b) return a ? `<em class="up">nouveau</em>` : "";
  const d = Math.round(((a - b) / b) * 100);
  return d ? `<em class="${d > 0 ? "up" : "down"}">${d > 0 ? "+" : ""}${d} %</em>` : `<em>=</em>`;
}
export function weekCard() {
  // Comparaison juste : les mêmes jours de la semaine dernière (lundi → même jour)
  const nd = ((new Date().getDay() + 6) % 7) + 1;
  const w = weekData(0), p = weekData(1, nd);
  const tiles = [
    ["⚡", w.xp, "XP", delta(w.xp, p.xp)], ["⏱️", fmtMin(w.min), "d'étude", delta(w.min, p.min)],
    ["✅", w.lessons, plural(w.lessons, "leçon").replace(/^\d+ /, ""), delta(w.lessons, p.lessons)], ["📒", w.words, w.words > 1 ? "nouveaux mots" : "nouveau mot", delta(w.words, p.words)],
    ["🎯", w.acc == null ? "–" : `${w.acc} %`, "de bonnes réponses", delta(w.acc, p.acc, "pts")], ["📅", `${w.days}/${nd}`, w.days > 1 ? "jours actifs" : "jour actif", delta(w.days, p.days)],
  ];
  const mon = weekDays(0)[0];
  return `<section class="card dash-wide sv-week">
    <div class="dw-head"><h2 class="h3">🗓️ Bilan de la semaine</h2><span class="muted small">depuis lundi ${fmtDate(mon)} · comparé aux mêmes jours de la semaine dernière</span></div>
    <div class="sv-tiles">${tiles.map(([i, v, l, d]) => `<div class="sv-tile"><span>${i}</span><b>${v}</b><small>${l}</small>${d}</div>`).join("")}</div>
    <button type="button" class="btn ghost small" data-share-week>📤 Partager mon bilan en image</button>
  </section>`;
}
async function shareWeek() {
  const w = weekData(0), p = weekData(1), c = document.createElement("canvas"), W = 1080, H = 1350;
  c.width = W; c.height = H;
  const g = c.getContext("2d"), zh = L.code === "zh";
  const grad = g.createLinearGradient(0, 0, W, H);
  grad.addColorStop(0, zh ? "#c23b32" : "#1e8e5a"); grad.addColorStop(1, zh ? "#7a1f1a" : "#0f5235");
  g.fillStyle = grad; g.fillRect(0, 0, W, H);
  g.fillStyle = "#fff"; g.textAlign = "center";
  g.font = "800 64px system-ui, sans-serif"; g.fillText(`Ma semaine sur ${L.brand}`, W / 2, 150);
  g.font = "500 38px system-ui, sans-serif"; g.globalAlpha = .85;
  g.fillText(`${L.label} · ${lvlLabel(P.currentLevel())} · ${state.profile?.pseudo || ""}`, W / 2, 215); g.globalAlpha = 1;
  const items = [["⚡", `${w.xp}`, "XP", p.xp], ["⏱️", fmtMin(w.min), "d'étude", p.min], ["✅", `${w.lessons}`, "leçons", p.lessons], ["📒", `${w.words}`, "nouveaux mots", p.words], ["🎯", w.acc == null ? "–" : `${w.acc} %`, "de réussite", null], ["🔥", `${P.streakCount()}`, "jours de série", null]];
  items.forEach(([ic, v, l], i) => {
    const x = 90 + (i % 2) * 470, y = 300 + Math.floor(i / 2) * 300;
    g.fillStyle = "rgba(255,255,255,.14)"; g.beginPath(); g.roundRect?.(x, y, 430, 250, 36) ?? g.rect(x, y, 430, 250); g.fill();
    g.fillStyle = "#fff"; g.textAlign = "left";
    g.font = "64px system-ui, sans-serif"; g.fillText(ic, x + 36, y + 95);
    g.font = "800 84px system-ui, sans-serif"; g.fillText(v, x + 36, y + 190);
    g.font = "500 36px system-ui, sans-serif"; g.globalAlpha = .85; g.fillText(l, x + 36, y + 232); g.globalAlpha = 1;
  });
  g.textAlign = "center"; g.font = "600 34px system-ui, sans-serif"; g.globalAlpha = .8;
  g.fillText("impara-app.github.io", W / 2, H - 70);
  const blob = await new Promise((r) => c.toBlob(r, "image/png"));
  const file = new File([blob], "ma-semaine.png", { type: "image/png" });
  if (navigator.canShare?.({ files: [file] })) { try { await navigator.share({ files: [file], title: "Ma semaine" }); return; } catch (e) { if (e?.name === "AbortError") return; } }
  const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = "ma-semaine.png"; a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 4000);
  toast("Image enregistrée : vous pouvez l'envoyer à vos amis 📤", "ok");
}

/* ------------------------ 2. Objectif de la semaine ------------------------ */
const GOALS = { lessons: ["✅", "leçons", [3, 5, 8]], xp: ["⚡", "XP", [300, 600, 1000]], reviews: ["🃏", "cartes révisées", [50, 100, 200]], min: ["⏱️", "minutes d'étude", [60, 120, 180]] };
const goalNow = (kind) => { const w = weekData(0); return kind === "lessons" ? w.lessons : kind === "xp" ? w.xp : kind === "reviews" ? w.reviews : w.min; };
export function weekGoalCard() {
  const g = state.weekGoal, wk = weekStart();
  if (!g || g.week !== wk || g.edit) {
    return `<section class="card sv-wgoal">
      <h2 class="h3">🏁 Objectif de la semaine</h2>
      <p class="small muted">Choisissez un défi jusqu'à dimanche soir :</p>
      <div class="sv-goal-pick">${Object.entries(GOALS).map(([k, [ic, lab, opts]]) => `<div class="sv-gp-row"><span>${ic} ${lab}</span>${opts.map((n, i) => `<button type="button" class="chip-btn" data-wgoal="${k}:${n}">${["Facile", "Moyen", "Ambitieux"][i]} · ${n}</button>`).join("")}</div>`).join("")}</div>
    </section>`;
  }
  const [ic, lab] = GOALS[g.kind], now = goalNow(g.kind), p = Math.min(100, pct(now, g.target)), left = 7 - ((new Date().getDay() + 6) % 7) - 1;
  if (p >= 100 && !g.done) { setTimeout(() => { celebrate(); toast("🏁 Objectif de la semaine atteint, bravo !", "ok"); }, 600); commit((s) => { s.weekGoal = { ...s.weekGoal, done: true }; }); }
  return `<section class="card sv-wgoal">
    <div class="dw-head"><h2 class="h3">🏁 Objectif de la semaine</h2><button type="button" class="link-btn small" data-wgoal-edit>Changer</button></div>
    <p class="sv-wg-big">${ic} <b>${Math.min(now, g.target)}</b> / ${g.target} ${lab}</p>
    <div class="sv-bar"><i style="width:${p}%"></i></div>
    <p class="small muted">${p >= 100 ? "🎉 Objectif atteint ! Rendez-vous lundi pour un nouveau défi." : left > 0 ? `Encore ${g.target - now} en ${plural(left, "jour")} (${Math.ceil((g.target - now) / (left + 1))} par jour).` : `Dernier jour : encore ${g.target - now} !`}</p>
  </section>`;
}

/* --------------------------- 3. Niveau estimé --------------------------- */
export function levelEstimateCard() {
  let comp = -1, prod = -1, compPlus = false, prodPlus = false;
  LEVELS.forEach((l, i) => {
    const e = state.epreuve?.[l.id], sec = e?.bestSec || (e ? [e.best, e.best, e.best] : [0, 0, 0]), ex = P.isExamPassed(l.id);
    if (ex || (sec[0] + sec[1]) / 2 >= 60) comp = i; else if (i === comp + 1 && (sec[0] + sec[1]) / 2 >= 40) compPlus = true;
    if (ex || sec[2] >= 60) prod = i; else if (i === prod + 1 && sec[2] >= 40) prodPlus = true;
  });
  // Les leçons d'un palier bien avancées comptent comme un « + »
  const cur = LEVELS.indexOf(P.currentLevel()), lp = P.levelProgress(cur).pct;
  if (lp >= 50 && comp === cur - 1) compPlus = true;
  if (lp >= 50 && prod === cur - 1) prodPlus = true;
  const name = (i, plus) => (i < 0 ? (plus ? `${lvlLabel(LEVELS[0])} en cours` : "Débutant") : `${lvlLabel(LEVELS[i])}${plus ? "+" : ""}`);
  const next = LEVELS[Math.min(LEVELS.length - 1, Math.max(comp, prod) + 1)];
  const hasEpreuve = Object.keys(state.epreuve || {}).length;
  return `<section class="card sv-level">
    <h2 class="h3">🧭 Mon vrai niveau</h2>
    <div class="sv-lv-row"><div><small>Compréhension</small><b>${name(comp, compPlus)}</b><span class="muted small">écouter, lire</span></div>
      <div><small>Production</small><b>${name(prod, prodPlus)}</b><span class="muted small">écrire, construire</span></div></div>
    <p class="small muted">${[["vos examens réussis"], hasEpreuve ? ["vos épreuves type " + (L.code === "zh" ? "HSK" : "CELI")] : [], state.placement ? ["votre test de niveau"] : []].flat().reduce((t, x, i, a) => t + (i ? (i === a.length - 1 ? " et " : ", ") : "D'après ") + x, "")}. Votre parcours en est au palier ${lvlLabel(P.currentLevel())}.</p>
    <a class="btn ghost small" href="#epreuve-${next.id}">⏱️ Passer l'épreuve ${esc(lvlLabel(next))} pour affiner</a>
  </section>`;
}

/* ------------------------- 4. Radar de compétences ------------------------- */
export function radarCard() {
  const T = skillTotals(6), N = SKILLS.length, R = 92, C = 120, MIN = 8;
  const val = (k) => (T[k][1] >= MIN ? T[k][0] / T[k][1] : null);
  const pt = (i, r) => { const a = -Math.PI / 2 + (i * 2 * Math.PI) / N; return [C + r * Math.cos(a), C + r * Math.sin(a)]; };
  const grid = [0.25, 0.5, 0.75, 1].map((f) => `<polygon points="${SKILLS.map((_, i) => pt(i, R * f).map((x) => x.toFixed(1)).join(",")).join(" ")}" class="rd-grid"/>`).join("");
  const axes = SKILLS.map((_, i) => `<line x1="${C}" y1="${C}" x2="${pt(i, R)[0].toFixed(1)}" y2="${pt(i, R)[1].toFixed(1)}" class="rd-axis"/>`).join("");
  const shape = SKILLS.map(([k], i) => pt(i, R * Math.max(0.06, val(k) ?? 0)).map((x) => x.toFixed(1)).join(",")).join(" ");
  const labels = SKILLS.map(([k, lab, ic], i) => { const [x, y] = pt(i, R + 22), v = val(k);
    return `<text x="${x.toFixed(1)}" y="${y.toFixed(1)}" class="rd-l" text-anchor="${x < C - 5 ? "end" : x > C + 5 ? "start" : "middle"}">${ic} ${lab}<tspan x="${x.toFixed(1)}" dy="15" class="rd-v">${v == null ? "?" : Math.round(v * 100) + " %"}</tspan></text>`; }).join("");
  const known = SKILLS.filter(([k]) => val(k) != null);
  const weak = known.sort((a, b) => val(a[0]) - val(b[0]))[0];
  const missing = SKILLS.filter(([k]) => val(k) == null).map(([, l]) => l.toLowerCase());
  return `<section class="card sv-radar">
    <h2 class="h3">🕸️ Mes compétences</h2>
    <svg viewBox="-60 -20 360 290" class="rd" role="img" aria-label="Radar de compétences">${grid}${axes}<polygon points="${shape}" class="rd-shape"/>${labels}</svg>
    <p class="small muted">Taux de bonnes réponses sur les 6 dernières semaines.${missing.length ? ` Pas encore assez de réponses en ${missing.join(", ")} (« ? »).` : ""}</p>
    ${weak ? `<a class="btn primary small" href="${weak[3]}">${weak[2]} S'entraîner : ${weak[1].toLowerCase()} (${Math.round(val(weak[0]) * 100)} %)</a>` : ""}
  </section>`;
}

/* ------------------------------ 5. Prévision ------------------------------ */
export function forecastCard() {
  const lvl = P.currentLevel(), li = LEVELS.indexOf(lvl);
  const since = Date.now() - 14 * 864e5;
  const recent = Object.values(state.lessons || {}).filter((l) => l.passed && !l.placed && Date.parse(l.date) > since).length;
  const remaining = lvl.lessons.filter((l) => !P.isLessonDone(l.id)).length + (P.isCheckpointPassed(lvl) ? 0 : 1) + (P.isExamPassed(lvl.id) ? 0 : 1);
  const mins = Array.from({ length: 14 }, (_, i) => minutesOn(dayKey(addDays(new Date(), -i)))).reduce((a, b) => a + b, 0);
  const perLesson = recent && mins > 20 ? Math.max(6, Math.min(30, mins / recent)) : 12;
  const rate = recent / 14, extra = 10 / perLesson;
  const nextLvl = LEVELS[li + 1];
  let body;
  if (!remaining) body = `<p>Palier ${esc(lvlLabel(lvl))} terminé 🎉${nextLvl ? ` Prochaine étape : ${esc(lvlLabel(nextLvl))}.` : ""}</p>`;
  else if (!rate) body = `<p>Terminez une leçon pour lancer la prévision : l'appli calcule votre rythme sur les 14 derniers jours.</p>`;
  else {
    const d1 = Math.ceil(remaining / rate), d2 = Math.ceil(remaining / (rate + extra)), gain = d1 - d2;
    const target = nextLvl ? `le niveau ${esc(lvlLabel(nextLvl))}` : `la fin du palier ${esc(lvlLabel(lvl))}`;
    const allLeft = LEVELS.slice(li + 1).reduce((n, l) => n + l.lessons.length + 2, remaining);
    body = `<p class="sv-fc-big">À votre rythme, vous atteindrez ${target} vers le <b>${fmtDate(addDays(new Date(), d1))}</b></p>
      <p class="small">📈 Rythme actuel : ${(rate * 7).toFixed(1).replace(".", ",")} leçon${rate * 7 >= 2 ? "s" : ""} par semaine · ${plural(remaining, "étape")} restante${remaining > 1 ? "s" : ""}.</p>
      ${gain > 0 ? `<p class="small sv-fc-tip">💡 Avec <b>10 minutes de plus par jour</b>, ce serait le ${fmtDate(addDays(new Date(), d2))} : ${plural(gain, "jour")} gagné${gain > 1 ? "s" : ""}.</p>` : ""}
      ${li + 1 < LEVELS.length - 1 ? `<p class="small muted">Tout le parcours jusqu'à ${esc(lvlLabel(LEVELS[LEVELS.length - 1]))} : vers ${MONTHS[addDays(new Date(), Math.ceil(allLeft / rate)).getMonth()]} ${addDays(new Date(), Math.ceil(allLeft / rate)).getFullYear()}.</p>` : ""}`;
  }
  return `<section class="card sv-fc"><h2 class="h3">🔮 Prévision</h2>${body}</section>`;
}

/* ---------------------- 6. Évolution de la précision ---------------------- */
export function precisionCard() {
  const weeks = Object.keys(state.stats?.w || {}).sort().slice(-10);
  const pts = weeks.map((wk) => { const v = Object.values(state.stats.w[wk]); const ok = v.reduce((n, x) => n + x[0], 0), t = v.reduce((n, x) => n + x[1], 0); return { wk, t, a: t ? ok / t : 0 }; }).filter((p) => p.t >= 5);
  if (pts.length < 2) return `<section class="card sv-prec"><h2 class="h3">🎯 Ma précision</h2><p class="small muted">${pts.length ? `Cette semaine : <b>${Math.round(pts[0].a * 100)} %</b> de bonnes réponses. ` : ""}La courbe apparaîtra après deux semaines de quiz : elle montre vos progrès même quand vous ne les sentez pas.</p></section>`;
  const lo = Math.max(0, Math.floor((Math.min(...pts.map((p) => p.a)) - 0.12) * 10) / 10), hi = Math.min(1, Math.ceil((Math.max(...pts.map((p) => p.a)) + 0.08) * 10) / 10);
  const W = 300, H = 110, pad = 14, X = (i) => pad + (i * (W - 2 * pad)) / (pts.length - 1), Y = (a) => H - pad - ((a - lo) / (hi - lo || 1)) * (H - 2 * pad);
  const line = pts.map((p, i) => `${i ? "L" : "M"}${X(i).toFixed(1)},${Y(p.a).toFixed(1)}`).join(" ");
  const diff = Math.round((pts[pts.length - 1].a - pts[0].a) * 100);
  return `<section class="card sv-prec">
    <div class="dw-head"><h2 class="h3">🎯 Ma précision</h2><span class="small ${diff >= 0 ? "sv-up" : "sv-down"}">${diff >= 0 ? "+" : ""}${diff} pts en ${plural(pts.length - 1, "semaine")}</span></div>
    <svg viewBox="0 0 ${W} ${H}" class="sv-line" aria-hidden="true">
      ${[lo, (lo + hi) / 2, hi].map((a) => `<line x1="0" x2="${W}" y1="${Y(a)}" y2="${Y(a)}" class="sv-gl"/><text x="${W - 2}" y="${Y(a) - 3}" text-anchor="end" class="sv-gt">${Math.round(a * 100)} %</text>`).join("")}
      <path d="${line}" class="sv-pl"/>${pts.map((p, i) => `<circle cx="${X(i).toFixed(1)}" cy="${Y(p.a).toFixed(1)}" r="3.5" class="sv-pd"><title>Semaine du ${fmtDate(new Date(p.wk + "T12:00"))} : ${Math.round(p.a * 100)} % (${p.t} réponses)</title></circle>`).join("")}
    </svg>
    <p class="small muted">Bonnes réponses par semaine. Cette semaine : <b>${Math.round(pts[pts.length - 1].a * 100)} %</b>.</p>
  </section>`;
}

/* ---------------------------- 7. Temps d'étude ---------------------------- */
export function timeCard() {
  const days = Array.from({ length: 14 }, (_, i) => addDays(new Date(), i - 13));
  const vals = days.map((d) => minutesOn(dayKey(d))), max = Math.max(15, ...vals);
  const today = vals[13], week = weekData(0).min;
  const month = Object.entries(state.studyTime || {}).filter(([k]) => k.slice(0, 7) === dayKey().slice(0, 7)).reduce((n, [, s]) => n + Math.round(s / 60), 0);
  const first = Object.keys(state.studyTime || {}).sort()[0];
  return `<section class="card sv-time">
    <h2 class="h3">⏱️ Temps d'étude</h2>
    <div class="sv-t3"><div><b>${fmtMin(today)}</b><small>aujourd'hui</small></div><div><b>${fmtMin(week)}</b><small>cette semaine</small></div><div><b>${fmtMin(month)}</b><small>ce mois-ci</small></div></div>
    <div class="sv-bars">${days.map((d, i) => `<span title="${fmtDate(d)} : ${vals[i]} min"><i style="height:${Math.max(vals[i] ? 6 : 0, (vals[i] / max) * 100)}%"></i><small>${i % 2 ? "" : DAYS[d.getDay()][0].toUpperCase()}</small></span>`).join("")}</div>
    <p class="small muted">${first ? `Temps actif dans l'appli (sans les pauses), mesuré depuis le ${fmtDate(new Date(first + "T12:00"))}` : "Le temps passé à apprendre (sans les pauses) s'affichera ici dès aujourd'hui."}</p>
  </section>`;
}

/* ---------------------------- 8. Moment idéal ---------------------------- */
const SLOTS = [["🌅 Matin", 5, 12, "le matin"], ["☀️ Midi", 12, 14, "à midi"], ["🌤️ Après-midi", 14, 18, "l'après-midi"], ["🌆 Soir", 18, 22, "le soir"], ["🌙 Nuit", 22, 29, "la nuit"]];
export function momentCard() {
  const H = state.stats?.h || {};
  const slot = SLOTS.map(([lab, a, b, when]) => { let ok = 0, t = 0, byH = []; for (let h = a; h < b; h++) { const v = H[h % 24] || [0, 0]; ok += v[0]; t += v[1]; byH.push([h % 24, v[1]]); } return { lab, when, ok, t, acc: t ? ok / t : 0, hour: byH.sort((x, y) => y[1] - x[1])[0][0] }; });
  const total = slot.reduce((n, s) => n + s.t, 0);
  const good = slot.filter((s) => s.t >= 15), best = good.sort((a, b) => b.acc - a.acc)[0];
  const remind = state.settings.remindHour || 20;
  return `<section class="card sv-moment">
    <h2 class="h3">🕗 Mon moment idéal</h2>
    ${total < 30 ? `<p class="small muted">Encore quelques quiz à différents moments de la journée et l'appli vous dira quand vous réussissez le mieux.</p>` : `
    <ul class="sv-slots">${SLOTS.map(([lab]) => { const s = slot.find((x) => x.lab === lab); return `<li class="${s === best ? "best" : ""}"><span>${lab}</span><span class="sv-sbar"><i style="width:${s.t ? Math.round(s.acc * 100) : 0}%"></i></span><b>${s.t ? Math.round(s.acc * 100) + " %" : "–"}</b><small>${s.t}</small></li>`; }).join("")}</ul>
    ${best ? `<p class="small">✨ Vous réussissez le mieux <b>${best.when}</b> (${Math.round(best.acc * 100)} % de bonnes réponses), surtout vers ${best.hour} h.</p>
      ${best.hour !== remind ? `<button type="button" class="btn ghost small" data-remind="${best.hour}">⏰ Régler mon rappel de série à ${best.hour} h</button>` : `<p class="small muted">Votre rappel de série est déjà réglé à ${remind} h 👍</p>`}` : ""}`}
  </section>`;
}

/* ------------------------- 9. Courbe du vocabulaire ------------------------- */
const MILES = [[100, "les premiers échanges"], [250, "se débrouiller en voyage"], [500, "une conversation simple"], [1000, "la vie de tous les jours"], [2000, "lire des textes simples"], [4000, "être autonome"]];
export function vocabGrowthCard() {
  const words = Object.values(state.vocab || {}), total = words.length;
  const N = 12, ends = Array.from({ length: N }, (_, i) => { const d = new Date(weekStart() + "T23:59:59"); d.setDate(d.getDate() - 7 * (N - 1 - i) + 6); return d; });
  const pts = ends.map((d) => words.filter((w) => (w.added || 0) <= d.getTime()).length);
  pts[N - 1] = total;
  const next = MILES.find(([n]) => n > total), prev = [...MILES].reverse().find(([n]) => n <= total);
  const max = Math.max(next ? next[0] : total, ...pts, 10), W = 300, H = 110, pad = 8;
  const X = (i) => pad + (i * (W - 2 * pad)) / (N - 1), Y = (v) => H - pad - (v / max) * (H - 2 * pad);
  const line = pts.map((v, i) => `${i ? "L" : "M"}${X(i).toFixed(1)},${Y(v).toFixed(1)}`).join(" ");
  const gained = total - pts[N - 5 >= 0 ? N - 5 : 0];
  return `<section class="card sv-vocab">
    <div class="dw-head"><h2 class="h3">📚 Mon vocabulaire</h2><span class="muted small">${plural(total, "mot")}${gained > 0 ? ` · +${gained} en 4 semaines` : ""}</span></div>
    <svg viewBox="0 0 ${W} ${H}" class="sv-line" aria-hidden="true">
      ${MILES.filter(([n]) => n <= max).map(([n]) => `<line x1="0" x2="${W}" y1="${Y(n)}" y2="${Y(n)}" class="sv-gl"/><text x="2" y="${Y(n) - 3}" class="sv-gt">${n}</text>`).join("")}
      <path d="${line} L${X(N - 1)},${H - pad} L${X(0)},${H - pad} Z" class="sv-area"/><path d="${line}" class="sv-pl"/>
    </svg>
    <p class="small">${prev ? `✅ <b>${prev[0]} mots</b> : ${prev[1]}. ` : ""}${next ? `Prochain cap : <b>${next[0]} mots</b> (${next[1]}), encore ${next[0] - total}.` : "Vous avez dépassé tous les caps 🏆"}</p>
  </section>`;
}

/* ------------------------- 10. Révisions à venir ------------------------- */
export function upcomingCard() {
  const today = dayKey(), days = Array.from({ length: 7 }, (_, i) => addDays(new Date(), i));
  const cnt = days.map(() => 0);
  Object.values(state.srs || {}).forEach((c) => {
    if (!c.due) return;
    if (c.due <= today) { cnt[0]++; return; }
    const i = days.findIndex((d) => dayKey(d) === c.due);
    if (i > 0) cnt[i]++;
  });
  const max = Math.max(5, ...cnt), sum = cnt.reduce((a, b) => a + b, 0), big = cnt.indexOf(Math.max(...cnt));
  return `<section class="card sv-up">
    <div class="dw-head"><h2 class="h3">🃏 Révisions à venir</h2><span class="muted small">${plural(sum, "carte")} sur 7 jours</span></div>
    <div class="sv-bars sv-bars7">${days.map((d, i) => `<span title="${fmtDate(d)} : ${cnt[i]} cartes"><b>${cnt[i] || ""}</b><i style="height:${Math.max(cnt[i] ? 8 : 0, (cnt[i] / max) * 100)}%" class="${i === 0 ? "today" : ""}"></i><small>${i ? DAYS[d.getDay()] : "auj."}</small></span>`).join("")}</div>
    ${cnt[0] ? `<a class="btn primary small" href="#reviser">Réviser les ${cnt[0]} cartes du jour</a>` : `<p class="small muted">Rien à réviser aujourd'hui 👍</p>`}
    ${big > 0 && cnt[big] >= 20 ? `<p class="small muted">Grosse journée ${DAYS[days[big].getDay()]} (${cnt[big]} cartes) : en réviser un peu avant allège la charge.</p>` : ""}
  </section>`;
}

/* ------------------------------ 11. Records ------------------------------ */
function computeRecords() {
  const log = state.dayLog || {}, keys = Object.keys(log).filter((k) => log[k] > 0).sort();
  let bestDay = { xp: 0, k: null };
  keys.forEach((k) => { if (log[k] > bestDay.xp) bestDay = { xp: log[k], k }; });
  let bestStreak = { n: 0, k: null }, run = 0, prev = null;
  keys.forEach((k) => { const d = new Date(k + "T12:00"); run = prev && Math.round((d - prev) / 864e5) === 1 ? run + 1 : 1; prev = d; if (run >= bestStreak.n) bestStreak = { n: run, k }; });
  bestStreak.n = Math.max(bestStreak.n, P.streakCount());
  const minutes = Object.values(state.studyTime || {}).reduce((a, b) => a + b, 0) / 60;
  const days = Object.keys(state.studyTime || {});
  const bestMin = days.reduce((m, k) => Math.max(m, minutesOn(k)), 0);
  return { bestDay, bestStreak, perfect: state.records?.perfect || 0, perfectAt: state.records?.perfectAt || 0, run: state.stats?.best || 0, runAt: state.stats?.bestAt || 0, total: state.stats?.total || 0, minutes: Math.round(minutes), bestMin, words: Object.keys(state.vocab || {}).length };
}
export function recordsCard() {
  const r = computeRecords(), week = Date.now() - 7 * 864e5, isNew = (ts) => ts && ts > week;
  const dayTs = r.bestDay.k ? Date.parse(r.bestDay.k + "T12:00") : 0, strTs = r.bestStreak.k ? Date.parse(r.bestStreak.k + "T12:00") : 0;
  const items = [
    ["🏅", `${r.bestDay.xp} XP`, "meilleure journée", r.bestDay.k ? fmtDate(new Date(dayTs)) : "", isNew(dayTs)],
    ["🔥", `${r.bestStreak.n} j`, "plus longue série", "", isNew(strTs) && r.bestStreak.n > 1],
    ["💯", r.perfect, plural(r.perfect, "quiz parfait").replace(/^\d+ /, ""), "", isNew(r.perfectAt)],
    ["🎯", r.run, "bonnes réponses d'affilée", "", isNew(r.runAt) && r.run >= 5],
    ["❓", r.total, "questions répondues", "", false],
    ["⏱️", fmtMin(r.bestMin), "plus longue journée d'étude", "", false],
  ];
  // Fête des nouveaux records (une seule fois)
  const seen = state.records?.seen || 0, fresh = [[dayTs, `meilleure journée : ${r.bestDay.xp} XP`], [r.runAt, `${r.run} bonnes réponses d'affilée`], [r.perfectAt, `${r.perfect} quiz parfaits`]].filter(([t]) => t > seen && t > week && t < Date.now() + 1);
  if (fresh.length && seen) setTimeout(() => { celebrate({ sound: "combo" }); toast(`🏆 Nouveau record : ${fresh[0][1]} !`, "ok"); }, 500);
  if (!seen || fresh.length) commit((s) => { s.records = { ...(s.records || {}), seen: Date.now() }; });
  return `<section class="card dash-wide sv-rec">
    <h2 class="h3">🏆 Mes records</h2>
    <div class="sv-rec-grid">${items.map(([ic, v, l, sub, nw]) => `<div class="sv-rc ${nw ? "new" : ""}">${nw ? `<em>Nouveau !</em>` : ""}<span>${ic}</span><b>${v}</b><small>${l}${sub ? ` · ${sub}` : ""}</small></div>`).join("")}</div>
  </section>`;
}

/* ------------------------ 12. Historique cliquable ------------------------ */
export function historyCard() {
  const H = state.history || [];
  return `<section class="card history-card dash-wide">
    <h2 class="h3">🕘 Activité récente</h2>
    ${H.length ? `<ul class="history sv-hist">${H.slice(0, 12).map((h, i) => `
      <li><details>
        <summary><span class="h-dot ${h.passed ? "ok" : "ko"}"></span><span class="h-label">${esc(h.label)}</span><span class="h-score">${h.score}/${h.total}</span><time>${new Date(h.date).toLocaleDateString("fr-FR", { day: "numeric", month: "short" })}</time></summary>
        <div class="sv-h-body">
          ${h.mistakes?.length ? `<ol class="sv-h-mk">${h.mistakes.map((m) => `<li><p>${esc(m.p)}</p>${m.g ? `<p class="no"><s>${esc(m.g)}</s></p>` : ""}<p class="yes">✓ <b>${esc(m.e)}</b></p>${m.w ? `<p class="why">🔎 ${esc(m.w)}</p>` : ""}</li>`).join("")}</ol>`
            : h.mistakes ? "" : h.score === h.total ? `<p class="small muted">Aucune erreur 🎉</p>` : `<p class="small muted">${h.href ? "Le détail des erreurs n'est pas disponible pour cette activité." : "Le détail n'est disponible que pour les activités faites depuis cette mise à jour."}</p>`}
          ${h.href ? `<a class="btn ghost small" href="${esc(h.href)}" data-reload>🔁 Refaire</a>` : ""}
        </div></details></li>`).join("")}</ul>`
      : `<p class="empty">Aucune activité pour l'instant. <a href="#parcours">Commencez votre première leçon</a> !</p>`}
  </section>`;
}

/* ------------------------------ Événements ------------------------------ */
export function bindSuivi(app, rerender) {
  app.querySelector("[data-share-week]")?.addEventListener("click", () => shareWeek().catch(() => toast("Partage impossible sur cet appareil", "warn")));
  app.querySelectorAll("[data-wgoal]").forEach((b) => (b.onclick = () => {
    const [kind, n] = b.dataset.wgoal.split(":");
    commit((s) => { s.weekGoal = { week: weekStart(), kind, target: +n }; });
    toast("Objectif de la semaine enregistré 🏁", "ok"); rerender();
  }));
  app.querySelector("[data-wgoal-edit]")?.addEventListener("click", () => { commit((s) => { s.weekGoal = { ...s.weekGoal, edit: true }; }); rerender(); });
  app.querySelector("[data-remind]")?.addEventListener("click", (e) => {
    const h = +e.currentTarget.dataset.remind;
    commit((s) => { s.settings.remindHour = h; });
    toast(`⏰ Rappel de série réglé à ${h} h`, "ok"); rerender();
  });
}
