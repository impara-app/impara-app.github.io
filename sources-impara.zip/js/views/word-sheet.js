/* =====================================================================
   word-sheet.js — Fiche détaillée d'un mot (Mes mots › Liste)
   - prononciation (normale / lente), pinyin toujours visible en mandarin
   - leçon d'origine, état de révision (flashcards)
   - phrases d'exemple des leçons qui contiennent le mot
   - italien : conjugaison complète des verbes, genre des noms
   - mandarin : chaque caractère avec son pinyin, son sens, ses traits et ses clés
   ===================================================================== */
import { LEVELS, getLesson, lvlLabel } from "../data/curriculum.js";
import { state } from "../core/storage.js";
import { esc, speak, tri, splitDialog, dragClose } from "../core/ui.js";
import { L } from "../core/lang.js";
import { charReading } from "../core/pinyin.js";
import { lookup, keysFor } from "../core/words.js";
import { TENSES, PERSONS, conjugate, parseVerb } from "../core/conjug-it.js";

const isZh = () => L.label === "Mandarin";
const HAN = /[㐀-鿿]/;
const pyOf = (w) => (isZh() ? w.py || [...w.zh].map((c) => charReading(c) || "").filter(Boolean).join(" ") : w.py || "");
const ART = /^(il|lo|la|i|gli|le|l'|un|uno|una|un')\s*/i;
const GENDER = { il: "masculin", lo: "masculin", un: "masculin", uno: "masculin", la: "féminin", una: "féminin", "un'": "féminin", i: "masculin pluriel", gli: "masculin pluriel", le: "féminin pluriel" };
const MONTHS = ["janv.", "févr.", "mars", "avr.", "mai", "juin", "juil.", "août", "sept.", "oct.", "nov.", "déc."];

/** Exemples des leçons contenant le mot (3 max) */
function examplesFor(w, forms = []) {
  const core = isZh() ? w.zh : w.zh.replace(ART, "").replace(/[?!.]$/, "").trim();
  if (!core || core.length < 2 && !isZh()) return [];
  const alt = [core, ...forms].map((x) => x.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")).join("|");
  const re = isZh() ? null : new RegExp(`(^|[^\\p{L}])(${alt})([^\\p{L}]|$)`, "iu");
  const out = [], seen = new Set();
  for (const lv of LEVELS) for (const l of lv.lessons) for (const s of l.sections || []) for (const ex of (s.examples || []).flatMap(splitDialog)) {
    const [t, py, fr] = tri(ex);
    if (!t || t === w.zh || String(t).length > 110 || seen.has(t)) continue;
    if (isZh() ? String(t).includes(core) : re.test(t)) { seen.add(t); out.push({ t, py, fr: String(fr).split(" — ")[0] }); if (out.length >= 3) return out; }
  }
  return out;
}

function srsLine(w) {
  const c = state.srs?.[w.zh];
  if (!c) return "🆕 Pas encore révisé en flashcards";
  const today = new Date().toISOString().slice(0, 10);
  const due = c.due && c.due <= today ? "à revoir aujourd'hui" : c.due ? `prochaine révision le ${+c.due.slice(8, 10)} ${MONTHS[+c.due.slice(5, 7) - 1]}` : "";
  const lvl = Math.min(6, c.box || 0);
  return `${lvl >= 4 ? "✅ Bien connu" : "🔁 En cours d'apprentissage"} · ${"●".repeat(lvl)}${"○".repeat(Math.max(0, 6 - lvl))}${due ? ` · ${due}` : ""}${c.lapses ? ` · raté ${c.lapses} fois` : ""}`;
}

/** Italien : le mot est-il un verbe qu'on sait conjuguer ? */
function verbOf(w) {
  if (isZh()) return null;
  const v = w.zh.toLowerCase().trim();
  if (!/^[a-zàèéìòù]+(are|ere|ire|rre)(si)?$/.test(v)) return null;
  return parseVerb(v) && conjugate(v, "presente", 0) ? v : null;
}

function conjHtml(v, tense) {
  const rows = PERSONS.map((p, i) => conjugate(v, tense, i)?.show).filter(Boolean);
  if (rows.length < 6) return `<p class="muted small">Ce temps n'est pas encore disponible pour ce verbe.</p>`;
  return `<table class="ws-conj"><tbody>${rows.map((f, i) => `<tr data-say="${esc(`${PERSONS[i].split("/")[0]} ${f}`)}"><th>${esc(PERSONS[i])}</th><td>${esc(f)}</td><td><button type="button" class="speak mini" aria-label="Écouter">🔊</button></td></tr>`).join("")}</tbody></table>`;
}

export function openWordSheet(w) {
  const py = pyOf(w);
  const lesson = w.lessonId ? getLesson(w.lessonId) : null;
  const lv = LEVELS.find((l) => l.id === w.levelId);
  const verb = verbOf(w);
  const exs = examplesFor(w, verb ? Object.keys(TENSES).flatMap((t) => PERSONS.map((_, i) => conjugate(verb, t, i)?.show).filter(Boolean)).map((f) => f.replace(/o\/a$|i\/e$/, (m) => m[0])) : []);
  const art = !isZh() && !verb && (w.zh.match(ART) || [])[1]?.toLowerCase();
  const tenses = verb ? Object.entries(TENSES).filter(([t]) => conjugate(verb, t, 0)) : [];
  const chars = isZh() ? [...w.zh].filter((c) => HAN.test(c)) : [];

  const root = document.createElement("div");
  root.className = "ws-backdrop";
  root.innerHTML = `<div class="ws" role="dialog" aria-modal="true" aria-label="${esc(w.zh)}">
    <button type="button" class="ws-x" aria-label="Fermer">✕</button>
    <div class="ws-head">
      <div class="ws-say"><button type="button" class="speak" data-say="${esc(w.zh)}" aria-label="Écouter">🔊</button><button type="button" class="speak slow" data-say="${esc(w.zh)}" data-slow aria-label="Écouter lentement">🐢</button></div>
      <div><p class="ws-w ${L.wordClass}">${esc(w.zh)}</p>${py ? `<p class="ws-py">${esc(py)}</p>` : ""}<p class="ws-fr">${esc(w.fr)}</p></div>
    </div>
    <div class="ws-chips">
      ${lv ? `<span class="tag" style="--lvl:${lv.color}">${esc(lvlLabel(lv))}</span>` : ""}
      ${art && GENDER[art] ? `<span class="chip">${GENDER[art] === "masculin" || GENDER[art] === "masculin pluriel" ? "♂" : "♀"} ${GENDER[art]}</span>` : ""}
      ${verb ? `<span class="chip">Verbe en -${verb.slice(-3).replace(/si$/, "")}</span>` : ""}
      ${w.from === "perso" ? `<span class="tag perso">Ajouté par vous</span>` : ""}
    </div>
    ${w.note ? `<p class="ws-note">📝 ${esc(w.note)}</p>` : ""}
    <p class="ws-srs small muted">${srsLine(w)}</p>
    ${verb && tenses.length ? `<section class="ws-sec"><h3>Conjugaison</h3>
      <div class="ws-tenses" role="tablist">${tenses.map(([t, x], i) => `<button type="button" role="tab" class="${i ? "" : "on"}" data-tense="${t}">${esc(x.label)}</button>`).join("")}</div>
      <div class="ws-conj-box">${conjHtml(verb, tenses[0][0])}</div></section>` : ""}
    ${chars.length ? `<section class="ws-sec"><h3>${chars.length > 1 ? "Les caractères" : "Le caractère"}</h3>
      <div class="ws-chars">${chars.map((c) => { const e = lookup(c); return `<button type="button" class="ws-char" data-char="${esc(c)}"><b class="zh">${esc(c)}</b><small>${esc(charReading(c) || "")}</small>${e && c !== w.zh ? `<em>${esc(String(e.fr).split(/[;,(]/)[0])}</em>` : ""}</button>`; }).join("")}</div>
      <div class="ws-strokes" data-strokes></div><div data-keys></div></section>` : ""}
    ${exs.length ? `<section class="ws-sec"><h3>Dans une phrase</h3><ul class="ws-ex">${exs.map((x) => `<li><button type="button" class="speak mini" data-say="${esc(x.t)}" aria-label="Écouter la phrase">🔊</button><span><span class="${L.wordClass}">${esc(x.t)}</span>${isZh() && x.py ? `<small class="py">${esc(x.py)}</small>` : ""}<small>${esc(x.fr)}</small></span></li>`).join("")}</ul></section>` : ""}
    ${lesson ? `<a class="btn ghost ws-lesson" href="#lecon-${lesson.id}">${esc(lesson.emoji || "📘")} Revoir la leçon : ${esc(lesson.title)} →</a>` : ""}
  </div>`;
  document.body.appendChild(root);
  document.documentElement.classList.add("modal-open");
  requestAnimationFrame(() => root.classList.add("show"));
  const close = () => { root.remove(); document.documentElement.classList.remove("modal-open"); removeEventListener("hashchange", close); removeEventListener("keydown", esc_); };
  const esc_ = (e) => { if (e.key === "Escape") close(); };
  addEventListener("hashchange", close); addEventListener("keydown", esc_);
  dragClose(root.querySelector(".ws"), close);
  root.addEventListener("click", (e) => {
    if (e.target === root || e.target.closest(".ws-x")) return close();
    const s = e.target.closest("[data-say]");
    if (s) { speak(s.dataset.say, { force: true, slow: e.target.closest("[data-slow]") ? true : undefined }); return; }
    const t = e.target.closest("[data-tense]");
    if (t) { root.querySelectorAll("[data-tense]").forEach((b) => b.classList.toggle("on", b === t)); root.querySelector(".ws-conj-box").innerHTML = conjHtml(verb, t.dataset.tense); return; }
    const c = e.target.closest("[data-char]");
    if (c) showChar(c.dataset.char);
  });
  speak(w.zh, { force: true });
  async function showChar(c) {
    root.querySelectorAll("[data-char]").forEach((b) => b.classList.toggle("on", b.dataset.char === c));
    const box = root.querySelector("[data-strokes]"); if (box) box.innerHTML = "";
    import("../core/hanzi.js").then((m) => m.strokeAnim(box, c, { size: 110 })).catch(() => {});
    const k = root.querySelector("[data-keys]"); if (k) k.innerHTML = await keysFor(c).catch(() => "");
  }
  if (chars.length) showChar(chars[0]);
}
