-- =====================================================================
--  Impara — défis v2 : 25 et 50 questions, mode « vitesse » ou « précision »
--  mode = 'speed'     : points = 100 par bonne réponse − 3 par seconde
--  mode = 'precision' : seules les bonnes réponses comptent (égalité possible)
--  mode = null        : anciens défis (score puis temps)
--  Réexécutable sans risque.
-- =====================================================================
alter table public.challenges add column if not exists mode text;
alter table public.challenges drop constraint if exists challenges_mode_check;
alter table public.challenges add constraint challenges_mode_check check (mode is null or mode in ('speed', 'precision'));
alter table public.challenges drop constraint if exists challenges_n_check;
alter table public.challenges add constraint challenges_n_check check (n between 5 and 50);

drop function if exists public.create_challenge(uuid, int);
create or replace function public.create_challenge(p_opponent uuid, p_n int default 10, p_mode text default 'speed')
returns uuid language plpgsql security definer set search_path = '' as $$
declare new_id uuid;
begin
  if not public.are_friends(auth.uid(), p_opponent) then raise exception 'not_friends'; end if;
  if coalesce(p_n, 10) not in (5, 10, 15, 25, 50) then raise exception 'invalid_n'; end if;
  insert into public.challenges (challenger, opponent, n, mode)
  values (auth.uid(), p_opponent, coalesce(p_n, 10), case when p_mode = 'precision' then 'precision' else 'speed' end)
  returning id into new_id;
  return new_id;
end;
$$;
revoke execute on function public.create_challenge(uuid, int, text) from public, anon;
grant execute on function public.create_challenge(uuid, int, text) to authenticated;

select column_name from information_schema.columns where table_name = 'challenges' and column_name = 'mode';
