-- =====================================================================
--  Impara — « Découvrir » : chiffres de la communauté, classement général
--  et profils publics. Réexécutable sans risque.
--
--  Vie privée : seuls les joueurs qui ont choisi d'apparaître
--  (profiles.discover = true, réglage dans l'appli) sont listés et leur
--  profil est visible. Les autres ne comptent que dans les totaux.
--  Les fonctions ne renvoient que des chiffres de progression (jamais
--  le fuseau horaire, les réglages de notification ou les mots ratés).
-- =====================================================================
alter table public.profiles add column if not exists discover boolean not null default false;

-- Chiffres + classement (XP total et semaine en cours) pour une langue
create or replace function public.discover_overview(p_lang text, p_week text)
returns jsonb language plpgsql stable security definer set search_path = '' as $$
declare me uuid := auth.uid(); res jsonb;
begin
  if me is null then raise exception 'not_authenticated'; end if;
  with st as (
    select us.user_id, us.summary, us.updated_at,
           coalesce((us.summary->>'xp')::numeric::bigint, 0) as xp
    from public.user_stats us where us.lang = p_lang
  ), pub as (
    select p.id, p.username, p.pseudo, p.avatar, p.color, p.frame,
           st.xp, coalesce((st.summary->>'streak')::numeric::int, 0) as streak,
           st.summary->>'level' as level, coalesce((st.summary->>'words')::numeric::int, 0) as words
    from public.profiles p join st on st.user_id = p.id
    where p.discover or p.id = me
  )
  select jsonb_build_object(
    'players',  (select count(*) from public.profiles),
    'learners', (select count(*) from st),
    'active',   (select count(distinct user_id) from public.user_stats where updated_at > now() - interval '7 days'),
    'xp',       (select coalesce(sum(xp), 0) from st),
    'visible',  (select count(*) from public.profiles where discover),
    'me_visible', (select discover from public.profiles where id = me),
    'my_rank',  (select 1 + count(*) from st where st.xp > coalesce((select xp from st where user_id = me), 0)),
    'top', coalesce((select jsonb_agg(to_jsonb(t)) from (
              select * from pub where pub.id <> me or (select discover from public.profiles where id = me)
              order by xp desc, username limit 100) t), '[]'::jsonb),
    'week', coalesce((select jsonb_agg(to_jsonb(t)) from (
              select p.id, p.username, p.pseudo, p.avatar, p.color, p.frame, w.xp
              from public.weekly_xp w join public.profiles p on p.id = w.user_id
              where w.lang = p_lang and w.week = p_week and w.xp > 0 and p.discover
              order by w.xp desc, p.username limit 50) t), '[]'::jsonb)
  ) into res;
  return res;
end;
$$;

-- Profil public d'un joueur (s'il apparaît dans Découvrir, ou s'il est ami / soi-même)
create or replace function public.discover_profile(p_username text)
returns jsonb language plpgsql stable security definer set search_path = '' as $$
declare me uuid := auth.uid(); p public.profiles; rel text;
begin
  if me is null then raise exception 'not_authenticated'; end if;
  select * into p from public.profiles where username = lower(p_username);
  if p.id is null then return null; end if;
  if not (p.discover or p.id = me or public.are_friends(me, p.id)) then return jsonb_build_object('hidden', true); end if;
  select case when p.id = me then 'me'
              when public.are_friends(me, p.id) then 'friend'
              when exists (select 1 from public.friendships f where f.status = 'pending' and f.requester = me and f.addressee = p.id) then 'sent'
              when exists (select 1 from public.friendships f where f.status = 'pending' and f.requester = p.id and f.addressee = me) then 'received'
              else 'none' end into rel;
  return jsonb_build_object(
    'id', p.id, 'username', p.username, 'pseudo', p.pseudo, 'avatar', p.avatar,
    'color', p.color, 'frame', p.frame, 'banner', p.banner, 'since', p.created_at, 'rel', rel,
    'stats', coalesce((select jsonb_object_agg(us.lang, jsonb_build_object(
        'xp', us.summary->'xp', 'streak', us.summary->'streak', 'level', us.summary->'level',
        'levelName', us.summary->'levelName', 'pct', us.summary->'pct', 'lessons', us.summary->'lessons',
        'words', us.summary->'words', 'week', us.summary->'week', 'weekXp', us.summary->'weekXp',
        'days', us.summary->'days', 'updated_at', us.updated_at))
      from public.user_stats us where us.user_id = p.id), '{}'::jsonb)
  );
end;
$$;

revoke all on function public.discover_overview(text, text) from public, anon;
revoke all on function public.discover_profile(text) from public, anon;
grant execute on function public.discover_overview(text, text) to authenticated;
grant execute on function public.discover_profile(text) to authenticated;

select 'ok';
