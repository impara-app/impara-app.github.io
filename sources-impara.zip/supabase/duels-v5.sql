-- =====================================================================
--  Impara — duels v5 : mode « écoute » + déroulé des réponses (replay)
--  - mode 'listen' : uniquement des questions audio ;
--  - challenge_recaps : les réponses de chaque joueur, question par question.
--    On voit les siennes tout de suite, celles de l'adversaire seulement
--    quand les DEUX ont joué (pas de triche sur un défi « sur son terrain »).
--  À exécuter après duels-v4.sql. Réexécutable sans risque.
-- =====================================================================

alter table public.challenges drop constraint if exists challenges_mode_check;
alter table public.challenges add constraint challenges_mode_check check (mode is null or mode in ('speed', 'precision', 'survival', 'listen'));

create or replace function public.create_challenge(
  p_opponent uuid, p_n int default 10, p_mode text default 'speed', p_live boolean default false,
  p_words jsonb default null, p_rematch uuid default null)
returns uuid language plpgsql security definer set search_path = '' as $$
declare new_id uuid; m text; k int;
begin
  if not public.are_friends(auth.uid(), p_opponent) then raise exception 'not_friends'; end if;
  m := case when p_mode in ('precision', 'survival', 'listen') then p_mode else 'speed' end;
  k := case when m = 'survival' then 50 else coalesce(p_n, 10) end;
  if k not in (5, 10, 15, 25, 50) then raise exception 'invalid_n'; end if;
  if p_words is not null and (jsonb_typeof(p_words) <> 'array' or jsonb_array_length(p_words) not between 12 and 40) then
    raise exception 'invalid_words';
  end if;
  if p_rematch is not null and not exists (
    select 1 from public.challenges c where c.id = p_rematch
      and ((c.challenger = auth.uid() and c.opponent = p_opponent) or (c.challenger = p_opponent and c.opponent = auth.uid()))) then
    raise exception 'invalid_rematch';
  end if;
  insert into public.challenges (challenger, opponent, n, mode, live, words, rematch_of)
  values (auth.uid(), p_opponent, k, m, coalesce(p_live, false), p_words, p_rematch)
  returning id into new_id;
  return new_id;
end;
$$;

-- ------------------------------------------------------ Déroulé des réponses
create table if not exists public.challenge_recaps (
  challenge_id uuid not null references public.challenges (id) on delete cascade,
  user_id      uuid not null references public.profiles (id) on delete cascade,
  recap        jsonb not null check (jsonb_typeof(recap) = 'array' and pg_column_size(recap) < 20000),
  created_at   timestamptz not null default now(),
  primary key (challenge_id, user_id)
);
alter table public.challenge_recaps enable row level security;
drop policy if exists "voir les déroulés" on public.challenge_recaps;
create policy "voir les déroulés" on public.challenge_recaps for select to authenticated
  using (
    (select auth.uid()) = user_id
    or exists (select 1 from public.challenges c where c.id = challenge_id
      and (select auth.uid()) in (c.challenger, c.opponent)
      and c.challenger_score is not null and c.opponent_score is not null)
  );
revoke all on public.challenge_recaps from anon;
grant select on public.challenge_recaps to authenticated;

-- Score + déroulé, une seule fois, quand le défi est accepté
drop function if exists public.submit_challenge(uuid, text, int, int, int);
create or replace function public.submit_challenge(p_id uuid, p_lang text, p_score int, p_total int, p_ms int, p_recap jsonb default null)
returns void language plpgsql security definer set search_path = '' as $$
declare c public.challenges;
begin
  select * into c from public.challenges where id = p_id for update;
  if not found or c.status <> 'accepted' then raise exception 'challenge_not_playable'; end if;
  if p_total < 1 or p_total > c.n or p_score < 0 or p_score > p_total or p_ms < 0 then raise exception 'invalid_score'; end if;
  if char_length(coalesce(p_lang, '')) not between 2 and 8 then raise exception 'invalid_lang'; end if;
  if c.challenger = auth.uid() and c.challenger_score is null then
    update public.challenges set challenger_lang = p_lang, challenger_score = p_score, challenger_total = p_total,
           challenger_ms = p_ms, updated_at = now() where id = p_id;
  elsif c.opponent = auth.uid() and c.opponent_score is null then
    update public.challenges set opponent_lang = p_lang, opponent_score = p_score, opponent_total = p_total,
           opponent_ms = p_ms, updated_at = now() where id = p_id;
  else
    raise exception 'already_played';
  end if;
  if p_recap is not null and jsonb_typeof(p_recap) = 'array' and jsonb_array_length(p_recap) <= 50 and pg_column_size(p_recap) < 20000 then
    insert into public.challenge_recaps (challenge_id, user_id, recap) values (p_id, auth.uid(), p_recap)
    on conflict (challenge_id, user_id) do nothing;
  end if;
end;
$$;
revoke execute on function public.submit_challenge(uuid, text, int, int, int, jsonb) from public, anon;
grant execute on function public.submit_challenge(uuid, text, int, int, int, jsonb) to authenticated;

select count(*) as recaps from public.challenge_recaps;
