// =====================================================================
//  Fonction serveur « notify » (Supabase Edge Function)
//  - { action: "vapid" } : renvoie la clé publique des notifications
//    (les clés sont créées automatiquement au premier appel) ;
//  - appel des déclencheurs SQL (avec le secret partagé) : envoie la
//    notification au bon destinataire (message, ami, défi).
//  Déploiement : sans vérification JWT (les déclencheurs n'ont pas de
//  session) ; la sécurité repose sur le secret généré dans la base.
// =====================================================================
import webpush from "npm:web-push@3.6.7";
import { createClient } from "npm:@supabase/supabase-js@2.45.4";

const SITE = "https://impara-app.github.io/";
// Clé serveur : ancienne « service_role » ou nouvelle clé secrète (sb_secret_…)
function serverKey(): string {
  const legacy = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
  if (legacy) return legacy;
  const raw = Deno.env.get("SUPABASE_SECRET_KEYS") ?? "";
  try { const v = JSON.parse(raw); return typeof v === "string" ? v : Object.values(v)[0] as string; } catch { return raw; }
}
const sb = createClient(Deno.env.get("SUPABASE_URL")!, serverKey(), {
  auth: { persistSession: false, autoRefreshToken: false },
});
const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, apikey, content-type, x-client-info",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};
const json = (b: unknown, status = 200) =>
  new Response(JSON.stringify(b), { status, headers: { ...cors, "Content-Type": "application/json" } });

async function setting(k: string): Promise<string | null> {
  const { data } = await sb.rpc("notify_get_setting", { k });
  return data ?? null;
}

let vapid: { publicKey: string; privateKey: string } | null = null;
async function getVapid() {
  if (vapid) return vapid;
  let raw = await setting("vapid");
  if (!raw) {
    const keys = webpush.generateVAPIDKeys();
    await sb.rpc("notify_set_setting", { k: "vapid", v: JSON.stringify(keys) });
    raw = await setting("vapid"); // relu : si deux appels simultanés, une seule paire est gardée
  }
  vapid = JSON.parse(raw!);
  webpush.setVapidDetails("https://impara-app.github.io", vapid!.publicKey, vapid!.privateKey);
  return vapid!;
}

type Profile = { username: string; pseudo: string | null } | null;
async function profile(id: string): Promise<Profile> {
  const { data } = await sb.from("profiles").select("username, pseudo").eq("id", id).maybeSingle();
  return data;
}
const name = (p: Profile) => p?.pseudo || p?.username || "Un ami";

// Préférences de notification de l'utilisateur (résumé le plus récent) : { msg, friend, defi, react }
async function allowed(userId: string, cat: string) {
  if (!cat) return true;
  const { data } = await sb.from("user_stats").select("summary").eq("user_id", userId).order("updated_at", { ascending: false }).limit(1);
  const n = (data?.[0]?.summary as { notif?: Record<string, boolean> } | undefined)?.notif;
  return !(n && n[cat] === false);
}

async function sendTo(userId: string, payload: Record<string, unknown>, cat = "") {
  if (!(await allowed(userId, cat))) return;
  const { data: subs } = await sb.from("push_subscriptions").select("*").eq("user_id", userId);
  await Promise.all((subs ?? []).map(async (s) => {
    try {
      await webpush.sendNotification(
        { endpoint: s.endpoint, keys: { p256dh: s.p256dh, auth: s.auth } },
        JSON.stringify(payload),
        { TTL: 86400 },
      );
    } catch (e) {
      const code = (e as { statusCode?: number }).statusCode;
      if (code === 404 || code === 410) await sb.from("push_subscriptions").delete().eq("endpoint", s.endpoint);
      else console.error("push error", code, String(e));
    }
  }));
}

const LANG_NAMES: Record<string, string> = { it: "italien", zh: "mandarin" };
function activityText(a: { kind: string; lang: string | null; data: Record<string, unknown> }): string {
  const d = a.data || {}, lang = LANG_NAMES[a.lang ?? ""] ?? "";
  switch (a.kind) {
    case "exam": return `niveau ${d.level} terminé en ${lang} 🎓`;
    case "streak": return `série de ${d.n} jours 🔥`;
    case "words": return `${d.n} mots appris en ${lang} 📒`;
    case "xp": return `${d.n} XP en ${lang} ⚡`;
    case "start": return `début du ${lang} 🌱`;
    case "defi_win": return `victoire en défi ⚔️`;
    case "story": return `histoire lue 📖`;
    default: return "nouvelle étape";
  }
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  const body = await req.json().catch(() => ({}));

  if (body.action === "vapid") return json({ publicKey: (await getVapid()).publicKey });

  const secret = await setting("notify_secret");
  if (!secret || req.headers.get("x-notify-secret") !== secret) return json({ error: "forbidden" }, 403);
  await getVapid();

  // Rappel de série (envoyé chaque soir par la tâche planifiée SQL)
  if (body.action === "streak" && typeof body.user === "string") {
    const n = Number(body.streak) || 0;
    await sendTo(body.user, {
      title: `🔥 Ta série de ${n} jour${n > 1 ? "s" : ""} est en danger !`,
      body: "3 minutes suffisent : touche ici pour une séance express ⚡",
      url: `${SITE}#express`, tag: "streak",
    });
    return json({ ok: true });
  }

  // Mot du jour (envoyé le matin par la tâche planifiée SQL)
  if (body.action === "wotd" && typeof body.user === "string" && body.word) {
    const lang = body.lang === "zh" ? "mandarin" : "italien";
    await sendTo(body.user, {
      title: `✨ Mot du jour en ${lang} : ${String(body.word).slice(0, 30)}`,
      body: `${body.py ? `${String(body.py).slice(0, 40)} — ` : ""}${String(body.fr ?? "").slice(0, 100)}`,
      url: `${SITE}#parcours`, tag: "wotd",
    }, "wotd");
    return json({ ok: true });
  }

  const { table, op, id, old } = body;
  if (!["messages", "friendships", "challenges", "activity_reactions"].includes(table)) return json({ ok: true });
  const { data: row } = await sb.from(table).select("*").eq("id", id).maybeSingle();
  if (!row) return json({ ok: true });

  if (table === "activity_reactions" && op === "INSERT") {
    const { data: act } = await sb.from("activities").select("*").eq("id", row.activity_id).maybeSingle();
    if (act && act.user_id !== row.user_id) {
      const p = await profile(row.user_id);
      await sendTo(act.user_id, { title: `${row.emoji} ${name(p)} a réagi`, body: `À votre activité : ${activityText(act)}`, url: `${SITE}#amis-fil`, tag: `react-${act.id}` }, "react");
    }
  } else if (table === "messages" && op === "INSERT") {
    const p = await profile(row.sender);
    await sendTo(row.recipient, { title: `💬 ${name(p)}`, body: String(row.body).slice(0, 140), url: p?.username ? `${SITE}#chat-${p.username}` : `${SITE}#messages`, tag: `msg-${row.sender}` }, "msg");
  } else if (table === "friendships") {
    if (op === "INSERT" && row.status === "pending") {
      const p = await profile(row.requester);
      await sendTo(row.addressee, { title: "👥 Nouvelle demande d'ami", body: `${name(p)} (@${p?.username}) veut devenir votre ami.`, url: `${SITE}#amis`, tag: "friend" }, "friend");
    } else if (op === "UPDATE" && old?.status === "pending" && row.status === "accepted") {
      const p = await profile(row.addressee);
      await sendTo(row.requester, { title: "🎉 Demande acceptée", body: `${name(p)} a accepté votre demande d'ami.`, url: `${SITE}#ami-${p?.username ?? ""}`, tag: "friend" }, "friend");
    }
  } else if (table === "challenges") {
    const url = `${SITE}#defi-${row.id}`;
    if (op === "INSERT") {
      const p = await profile(row.challenger);
      // « sur 10 questions » · « en mort subite » · « … sur vos points faibles 🎯 »
      const what = (row.mode === "survival" ? "en mort subite 💀" : `sur ${row.n} questions`) + (row.words ? " sur vos points faibles 🎯" : "");
      await sendTo(row.opponent, row.rematch_of
        ? { title: "🔁 Revanche !", body: `${name(p)} veut sa revanche ${what}${row.live ? " (en direct)" : ""}.`, url: row.live ? url : `${SITE}#amis-defis`, tag: `defi-${row.id}` }
        : row.live
        ? { title: "⚡ Défi en direct !", body: `${name(p)} vous défie en direct ${what} : rejoignez-le maintenant !`, url, tag: `defi-${row.id}` }
        : { title: "⚔️ Nouveau défi !", body: `${name(p)} vous défie ${what}.`, url: `${SITE}#amis-defis`, tag: `defi-${row.id}` }, "defi");
    } else if (op === "UPDATE" && old) {
      if (old.status === "pending" && row.status === "accepted") {
        const p = await profile(row.opponent);
        await sendTo(row.challenger, { title: row.live ? "⚡ Duel accepté" : "⚔️ Défi accepté", body: row.live ? `${name(p)} vous attend dans le duel en direct !` : `${name(p)} a accepté votre défi : à vous de jouer !`, url, tag: `defi-${row.id}` }, "defi");
      } else if (old.status === "pending" && row.status === "declined") {
        const p = await profile(row.opponent);
        await sendTo(row.challenger, { title: "Défi refusé", body: `${name(p)} a refusé votre défi.`, url: `${SITE}#amis`, tag: `defi-${row.id}` }, "defi");
      } else if (row.status === "accepted") {
        const justPlayed = old.challenger_score == null && row.challenger_score != null ? row.challenger
          : old.opponent_score == null && row.opponent_score != null ? row.opponent : null;
        if (justPlayed) {
          const other = justPlayed === row.challenger ? row.opponent : row.challenger;
          const p = await profile(justPlayed);
          const both = row.challenger_score != null && row.opponent_score != null;
          await sendTo(other, both
            ? { title: "🏁 Résultat du défi", body: `${name(p)} a joué : découvrez qui a gagné !`, url, tag: `defi-${row.id}` }
            : { title: "⏱️ À vous de jouer", body: `${name(p)} a terminé le défi. Saurez-vous faire mieux ?`, url, tag: `defi-${row.id}` }, "defi");
        }
      }
    }
  }
  return json({ ok: true });
});
