-- =====================================================================
--  Impara — notifications push (à exécuter après social.sql)
--  - push_subscriptions : un abonnement par appareil ;
--  - private.settings   : secrets générés automatiquement (jamais lisibles
--    par les utilisateurs) : clés VAPID et secret partagé avec la fonction ;
--  - déclencheurs : un message, une demande d'ami ou un défi appellent la
--    fonction serveur `notify`, qui envoie la notification.
--  Réexécutable sans risque.
-- =====================================================================
create extension if not exists pg_net with schema extensions;

create table if not exists public.push_subscriptions (
  endpoint   text primary key check (char_length(endpoint) < 1000),
  user_id    uuid not null references auth.users (id) on delete cascade,
  p256dh     text not null check (char_length(p256dh) < 200),
  auth       text not null check (char_length(auth) < 100),
  created_at timestamptz not null default now()
);
create index if not exists push_subscriptions_user on public.push_subscriptions (user_id);
alter table public.push_subscriptions enable row level security;
drop policy if exists "voir ses abonnements" on public.push_subscriptions;
create policy "voir ses abonnements" on public.push_subscriptions for select to authenticated
  using ((select auth.uid()) = user_id);
revoke all on public.push_subscriptions from anon;
grant select on public.push_subscriptions to authenticated;

create or replace function public.save_push_subscription(p_endpoint text, p_p256dh text, p_auth text)
returns void language plpgsql security definer set search_path = '' as $$
begin
  if auth.uid() is null then raise exception 'not_authenticated'; end if;
  if p_endpoint !~ '^https://' then raise exception 'invalid_endpoint'; end if;
  -- Un appareil = un abonnement : il passe au compte actuellement connecté
  delete from public.push_subscriptions where endpoint = p_endpoint;
  insert into public.push_subscriptions (endpoint, user_id, p256dh, auth) values (p_endpoint, auth.uid(), p_p256dh, p_auth);
end;
$$;

create or replace function public.remove_push_subscription(p_endpoint text)
returns void language sql security definer set search_path = '' as $$
  delete from public.push_subscriptions where endpoint = p_endpoint and user_id = auth.uid();
$$;

-- ----------------------------------------------------- Réglages privés
create schema if not exists private;
revoke all on schema private from public, anon, authenticated;
create table if not exists private.settings (key text primary key, value text not null);
alter table private.settings enable row level security; -- aucune règle : seul le serveur y accède
insert into private.settings (key, value)
  values ('notify_secret', encode(extensions.gen_random_bytes(24), 'hex'))
  on conflict (key) do nothing;

create or replace function public.notify_get_setting(k text)
returns text language sql stable security definer set search_path = '' as $$
  select value from private.settings where key = k;
$$;
-- Le premier qui écrit gagne : une clé n'est jamais remplacée
create or replace function public.notify_set_setting(k text, v text)
returns void language sql security definer set search_path = '' as $$
  insert into private.settings (key, value) values (k, v) on conflict (key) do nothing;
$$;

revoke execute on function public.notify_get_setting(text), public.notify_set_setting(text, text) from public, anon, authenticated;
grant execute on function public.notify_get_setting(text), public.notify_set_setting(text, text) to service_role;
revoke execute on function public.save_push_subscription(text, text, text), public.remove_push_subscription(text) from public, anon;
grant execute on function public.save_push_subscription(text, text, text), public.remove_push_subscription(text) to authenticated;

-- --------------------------------------------------------- Déclencheurs
create or replace function private.notify_push()
returns trigger language plpgsql security definer set search_path = '' as $$
declare secret text;
begin
  select value into secret from private.settings where key = 'notify_secret';
  perform net.http_post(
    url := 'https://brfysaduoqeozqqazbaa.supabase.co/functions/v1/notify',
    body := jsonb_build_object('table', TG_TABLE_NAME, 'op', TG_OP, 'id', NEW.id,
                               'old', case when TG_OP = 'UPDATE' then to_jsonb(OLD) else null end),
    headers := jsonb_build_object('Content-Type', 'application/json', 'x-notify-secret', secret),
    timeout_milliseconds := 5000
  );
  return NEW;
exception when others then
  return NEW; -- une notification ratée ne doit jamais bloquer l'action
end;
$$;

drop trigger if exists push_on_message   on public.messages;
drop trigger if exists push_on_friend    on public.friendships;
drop trigger if exists push_on_challenge on public.challenges;
create trigger push_on_message   after insert           on public.messages    for each row execute function private.notify_push();
create trigger push_on_friend    after insert or update on public.friendships for each row execute function private.notify_push();
create trigger push_on_challenge after insert or update on public.challenges  for each row execute function private.notify_push();
