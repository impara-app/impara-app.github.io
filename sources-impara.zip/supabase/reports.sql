-- =====================================================================
--  Impara — signalements (« Signaler un problème » dans les exercices)
--  Tout le monde peut envoyer un signalement (même sans compte), personne
--  ne peut les lire depuis l'appli : on les consulte dans Supabase
--  (Table Editor › reports). Réexécutable sans risque.
-- =====================================================================
create table if not exists public.reports (
  id         bigint generated always as identity primary key,
  created_at timestamptz not null default now(),
  user_id    uuid default auth.uid(),
  kind       text not null check (kind in ('traduction', 'formulation', 'prononciation', 'reponse', 'bug', 'autre')),
  comment    text check (char_length(comment) <= 1000),
  lang       text check (char_length(lang) <= 8),
  place      text check (char_length(place) <= 200),
  context    jsonb not null default '{}'::jsonb check (pg_column_size(context) < 8000),
  status     text not null default 'nouveau' check (status in ('nouveau', 'corrigé', 'ignoré'))
);
create index if not exists reports_created on public.reports (created_at desc);
alter table public.reports enable row level security;

drop policy if exists "envoyer un signalement" on public.reports;
create policy "envoyer un signalement" on public.reports for insert to anon, authenticated
  with check (status = 'nouveau' and (user_id is null or user_id = auth.uid()));

revoke all on public.reports from anon, authenticated;
grant insert on public.reports to anon, authenticated;
grant usage on sequence public.reports_id_seq to anon, authenticated;

-- Garde-fou anti-abus : 30 signalements par heure maximum pour tout le site
create or replace function private.reports_limit() returns trigger language plpgsql security definer set search_path = '' as $$
begin
  if (select count(*) from public.reports where created_at > now() - interval '1 hour') >= 30 then
    raise exception 'too_many_reports';
  end if;
  return new;
end;
$$;
drop trigger if exists reports_limit on public.reports;
create trigger reports_limit before insert on public.reports for each row execute function private.reports_limit();

select 'ok';
