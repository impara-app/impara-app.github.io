-- =====================================================================
--  Impara — social v3 : défi en direct + fil d'activité avec réactions
--  À exécuter après social.sql, push.sql et defis-v2.sql.
--  Réexécutable sans risque.
-- =====================================================================

-- ------------------------------------------------------ Défi en direct
alter table public.challenges add column if not exists live boolean not null default false;

drop function if exists public.create_challenge(uuid, int, text);
create or replace function public.create_challenge(p_opponent uuid, p_n int default 10, p_mode text default 'speed', p_live boolean default false)
returns uuid language plpgsql security definer set search_path = '' as $$
declare new_id uuid;
begin
  if not public.are_friends(auth.uid(), p_opponent) then raise exception 'not_friends'; end if;
  if coalesce(p_n, 10) not in (5, 10, 15, 25, 50) then raise exception 'invalid_n'; end if;
  insert into public.challenges (challenger, opponent, n, mode, live)
  values (auth.uid(), p_opponent, coalesce(p_n, 10), case when p_mode = 'precision' then 'precision' else 'speed' end, coalesce(p_live, false))
  returning id into new_id;
  return new_id;
end;
$$;
revoke execute on function public.create_challenge(uuid, int, text, boolean) from public, anon;
grant execute on function public.create_challenge(uuid, int, text, boolean) to authenticated;

-- --------------------------------------------------- Fil d'activité
create table if not exists public.activities (
  id         bigint generated always as identity primary key,
  user_id    uuid not null default auth.uid() references public.profiles (id) on delete cascade,
  kind       text not null check (kind ~ '^[a-z_]{2,20}$'),
  lang       text check (lang is null or char_length(lang) between 2 and 8),
  data       jsonb not null default '{}'::jsonb check (pg_column_size(data) < 2000),
  created_at timestamptz not null default now()
);
create index if not exists activities_user on public.activities (user_id, created_at desc);
create index if not exists activities_recent on public.activities (created_at desc);
alter table public.activities enable row level security;

drop policy if exists "voir activités amis" on public.activities;
drop policy if exists "publier son activité" on public.activities;
drop policy if exists "supprimer son activité" on public.activities;
create policy "voir activités amis" on public.activities for select to authenticated
  using ((select auth.uid()) = user_id or public.are_friends((select auth.uid()), user_id));
create policy "publier son activité" on public.activities for insert to authenticated
  with check ((select auth.uid()) = user_id);
create policy "supprimer son activité" on public.activities for delete to authenticated
  using ((select auth.uid()) = user_id);

-- Garde-fou : 40 activités par jour et par personne au maximum
create or replace function private.activities_limit()
returns trigger language plpgsql security definer set search_path = '' as $$
begin
  if (select count(*) from public.activities where user_id = NEW.user_id and created_at > now() - interval '1 day') >= 40 then
    raise exception 'too_many_activities';
  end if;
  return NEW;
end;
$$;
drop trigger if exists activities_limit on public.activities;
create trigger activities_limit before insert on public.activities for each row execute function private.activities_limit();

-- ------------------------------------------------------- Réactions 👏
create table if not exists public.activity_reactions (
  id          bigint generated always as identity primary key,
  activity_id bigint not null references public.activities (id) on delete cascade,
  user_id     uuid not null default auth.uid() references public.profiles (id) on delete cascade,
  emoji       text not null check (emoji in ('👏', '🔥', '💪', '😮', '❤️')),
  created_at  timestamptz not null default now(),
  unique (activity_id, user_id)
);
create index if not exists activity_reactions_activity on public.activity_reactions (activity_id);
alter table public.activity_reactions enable row level security;

create or replace function public.can_see_activity(p_activity bigint)
returns boolean language sql stable security definer set search_path = '' as $$
  select exists (select 1 from public.activities a where a.id = p_activity
                 and (a.user_id = auth.uid() or public.are_friends(auth.uid(), a.user_id)));
$$;
revoke execute on function public.can_see_activity(bigint) from public, anon;
grant execute on function public.can_see_activity(bigint) to authenticated;

drop policy if exists "voir réactions" on public.activity_reactions;
drop policy if exists "réagir" on public.activity_reactions;
drop policy if exists "changer sa réaction" on public.activity_reactions;
drop policy if exists "retirer sa réaction" on public.activity_reactions;
create policy "voir réactions" on public.activity_reactions for select to authenticated
  using (public.can_see_activity(activity_id));
create policy "réagir" on public.activity_reactions for insert to authenticated
  with check ((select auth.uid()) = user_id and public.can_see_activity(activity_id));
create policy "changer sa réaction" on public.activity_reactions for update to authenticated
  using ((select auth.uid()) = user_id) with check ((select auth.uid()) = user_id);
create policy "retirer sa réaction" on public.activity_reactions for delete to authenticated
  using ((select auth.uid()) = user_id);

revoke all on public.activities, public.activity_reactions from anon;
grant select, insert, delete on public.activities to authenticated;
grant select, insert, update, delete on public.activity_reactions to authenticated;

-- ------------------------------------------------------ Temps réel
do $$
begin
  if not exists (select 1 from pg_publication_tables where pubname = 'supabase_realtime' and tablename = 'activities') then
    alter publication supabase_realtime add table public.activities;
  end if;
  if not exists (select 1 from pg_publication_tables where pubname = 'supabase_realtime' and tablename = 'activity_reactions') then
    alter publication supabase_realtime add table public.activity_reactions;
  end if;
end $$;

-- ------------------------------------- Notification quand on réagit
drop trigger if exists push_on_reaction on public.activity_reactions;
create trigger push_on_reaction after insert on public.activity_reactions for each row execute function private.notify_push();

select 'ok' as social_v3;
