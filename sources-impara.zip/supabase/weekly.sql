-- =====================================================================
--  Impara — historique du classement de la semaine
--  Une ligne par personne, par semaine (UTC, « 2026-W45 ») et par langue.
--  Visible de soi et de ses amis. Réexécutable sans risque.
-- =====================================================================
create table if not exists public.weekly_xp (
  user_id    uuid not null references public.profiles (id) on delete cascade,
  week       text not null check (week ~ '^[0-9]{4}-W[0-9]{2}$'),
  lang       text not null check (char_length(lang) between 2 and 8),
  xp         int  not null default 0 check (xp between 0 and 1000000),
  updated_at timestamptz not null default now(),
  primary key (user_id, week, lang)
);
create index if not exists weekly_xp_week on public.weekly_xp (week);
alter table public.weekly_xp enable row level security;

drop policy if exists "voir xp semaine amis"  on public.weekly_xp;
drop policy if exists "créer son xp semaine"  on public.weekly_xp;
drop policy if exists "modifier son xp semaine" on public.weekly_xp;
create policy "voir xp semaine amis" on public.weekly_xp for select to authenticated
  using ((select auth.uid()) = user_id or public.are_friends((select auth.uid()), user_id));
create policy "créer son xp semaine" on public.weekly_xp for insert to authenticated
  with check ((select auth.uid()) = user_id);
create policy "modifier son xp semaine" on public.weekly_xp for update to authenticated
  using ((select auth.uid()) = user_id) with check ((select auth.uid()) = user_id);
revoke all on public.weekly_xp from anon;
grant select, insert, update on public.weekly_xp to authenticated;

-- Reprise de l'existant : la dernière semaine connue de chacun
insert into public.weekly_xp (user_id, week, lang, xp)
select user_id, summary->>'week', lang, coalesce((summary->>'weekXp')::int, 0)
from public.user_stats
where summary->>'week' ~ '^[0-9]{4}-W[0-9]{2}$' and coalesce((summary->>'weekXp')::int, 0) > 0
on conflict (user_id, week, lang) do update set xp = greatest(public.weekly_xp.xp, excluded.xp);

select * from public.weekly_xp order by week desc;
