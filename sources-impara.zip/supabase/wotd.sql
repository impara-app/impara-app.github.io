-- =====================================================================
--  Impara — notification « Mot du jour » (à exécuter après push.sql)
--  Toutes les heures, on cherche les personnes pour qui il est l'heure
--  choisie (9 h par défaut, dans LEUR fuseau horaire), qui ont activé
--  les notifications et n'ont pas coupé le mot du jour. Le mot est
--  calculé par l'application et envoyé dans le résumé (summary.wotd :
--  30 jours d'avance, puis rotation). Un seul envoi par jour et par personne.
-- =====================================================================
create extension if not exists pg_cron;

create table if not exists private.wotd_sent (
  user_id uuid not null,
  day     date not null,
  primary key (user_id, day)
);
alter table private.wotd_sent enable row level security;

create or replace function private.send_wotd()
returns int language plpgsql security definer set search_path = '' as $$
declare r record; secret text; n int := 0; w jsonb;
begin
  select value into secret from private.settings where key = 'notify_secret';
  delete from private.wotd_sent where day < current_date - 7;
  for r in
    with s as (
      select us.user_id, us.lang, us.summary, us.updated_at,
             case when exists (select 1 from pg_catalog.pg_timezone_names z where z.name = us.summary->>'tz')
                  then us.summary->>'tz' else 'UTC' end as tz
      from public.user_stats us
      where exists (select 1 from public.push_subscriptions p where p.user_id = us.user_id)
        and us.summary ? 'wotd'
    ), l as (
      select distinct on (user_id) user_id, lang, summary, (now() at time zone tz) as local_now
      from s order by user_id, updated_at desc       -- la langue utilisée en dernier
    )
    select user_id, lang, summary, local_now::date as local_day, extract(hour from local_now)::int as hr,
           coalesce((summary->>'wotdHour')::int, 9) as at_hour,
           coalesce((summary->'notif'->>'wotd')::boolean, true) as wanted
    from l
  loop
    continue when r.hr <> r.at_hour or not r.wanted;
    w := null;
    select e.value into w from jsonb_array_elements(r.summary->'wotd') as e
      where e.value->>'d' = to_char(r.local_day, 'YYYY-MM-DD') limit 1;
    if w is null and jsonb_array_length(r.summary->'wotd') > 0 then
      -- personne inactive depuis longtemps : on tourne dans la liste connue
      w := (r.summary->'wotd')->(extract(doy from r.local_day)::int % jsonb_array_length(r.summary->'wotd'));
    end if;
    continue when w is null;
    insert into private.wotd_sent (user_id, day) values (r.user_id, r.local_day) on conflict do nothing;
    continue when not found;
    perform net.http_post(
      url := 'https://brfysaduoqeozqqazbaa.supabase.co/functions/v1/notify',
      body := jsonb_build_object('action', 'wotd', 'user', r.user_id, 'lang', r.lang, 'word', w->>'w', 'py', w->>'py', 'fr', w->>'fr'),
      headers := jsonb_build_object('Content-Type', 'application/json', 'x-notify-secret', secret),
      timeout_milliseconds := 5000
    );
    n := n + 1;
  end loop;
  return n;
end;
$$;
revoke execute on function private.send_wotd() from public, anon, authenticated;

select cron.unschedule(jobid) from cron.job where jobname = 'impara-wotd';
select cron.schedule('impara-wotd', '0 * * * *', 'select private.send_wotd()');

select jobid, jobname, schedule from cron.job where jobname = 'impara-wotd';
