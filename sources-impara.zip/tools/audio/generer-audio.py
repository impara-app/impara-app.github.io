#!/usr/bin/env python3
"""
Impara · Xuéxí — fabrique la voix naturelle de l'appli (une seule fois).

Ce script lit les phrases de texts-it.json et texts-zh.json (dans le même
dossier), les fait prononcer par les voix neuronales « Natural » de
Microsoft (service de lecture à voix haute d'Edge, sans compte ni clé),
puis les regroupe en quelques gros fichiers prêts à mettre en ligne :

    audio/it/index.json, audio/it/p0.bin, p1.bin…
    audio/zh/index.json, audio/zh/p0.bin, …

Utilisation (Mac ou PC, Python 3.9 ou plus récent) :
    pip install edge-tts
    python generer-audio.py              # les deux langues
    python generer-audio.py --essai      # 3 phrases par langue, pour écouter avant
    python generer-audio.py --lang zh    # une seule langue

Le script peut être relancé sans risque : il reprend là où il s'était arrêté
(les phrases déjà enregistrées sont gardées dans le dossier « clips »).
"""
import argparse
import asyncio
import json
import os
import sys
import time

try:
    import edge_tts
except ImportError:
    sys.exit("Il manque le module edge-tts. Installez-le avec :  pip install edge-tts")

HERE = os.path.dirname(os.path.abspath(__file__))
VOICES = {"it": "it-IT-ElsaNeural", "zh": "zh-CN-XiaoxiaoNeural"}
# Un peu plus posé que la vitesse normale : on apprend la langue
RATES = {"it": "-5%", "zh": "-12%"}
PACK_MAX = 9 * 1024 * 1024    # 9 Mo par fichier (envoi en ligne plus simple)
PARALLEL = 6


async def say(text, voice, rate, path, tries=4):
    for k in range(tries):
        try:
            tmp = path + ".part"
            await edge_tts.Communicate(text, voice, rate=rate).save(tmp)
            if os.path.getsize(tmp) < 500:
                raise RuntimeError("fichier vide")
            os.replace(tmp, path)
            return True
        except Exception as e:  # réseau, limite de débit… on réessaie un peu plus tard
            if k == tries - 1:
                print(f"\n  ✗ échec pour « {text[:40]} » : {e}")
                return False
            await asyncio.sleep(2 + 3 * k)


async def record(lang, items, voice, rate):
    folder = os.path.join(HERE, "clips", lang)
    os.makedirs(folder, exist_ok=True)
    todo = [it for it in items if not os.path.exists(os.path.join(folder, it["id"] + ".mp3"))]
    print(f"[{lang}] {len(items)} phrases · déjà prêtes : {len(items) - len(todo)} · à enregistrer : {len(todo)} · voix {voice}")
    sem = asyncio.Semaphore(PARALLEL)
    done = 0
    start = time.time()

    async def one(it):
        nonlocal done
        async with sem:
            await say(it["t"], voice, rate, os.path.join(folder, it["id"] + ".mp3"))
            done += 1
            if done % 25 == 0 or done == len(todo):
                left = (time.time() - start) / done * (len(todo) - done)
                print(f"\r  {done}/{len(todo)} · reste environ {int(left // 60)} min {int(left % 60):02d} s   ", end="", flush=True)

    await asyncio.gather(*(one(it) for it in todo))
    if todo:
        print()
    return folder


def pack(lang, items, folder, voice):
    out = os.path.join(HERE, "audio", lang)
    os.makedirs(out, exist_ok=True)
    for f in os.listdir(out):
        os.remove(os.path.join(out, f))
    clips, packs = {}, []
    buf, n = bytearray(), 0
    missing = 0
    for it in items:
        p = os.path.join(folder, it["id"] + ".mp3")
        if not os.path.exists(p):
            missing += 1
            continue
        data = open(p, "rb").read()
        if len(buf) + len(data) > PACK_MAX and buf:
            name = f"p{n}.bin"
            open(os.path.join(out, name), "wb").write(buf)
            packs.append(name)
            buf, n = bytearray(), n + 1
        clips[it["id"]] = [n, len(buf), len(data)]
        buf += data
    if buf:
        name = f"p{n}.bin"
        open(os.path.join(out, name), "wb").write(buf)
        packs.append(name)
    json.dump({"voice": voice, "packs": packs, "clips": clips}, open(os.path.join(out, "index.json"), "w"), separators=(",", ":"))
    size = sum(os.path.getsize(os.path.join(out, p)) for p in packs) / 1e6
    print(f"[{lang}] ✓ {len(clips)} phrases dans {len(packs)} fichier(s), {size:.1f} Mo → {out}" + (f" · {missing} manquante(s) : relancez le script" if missing else ""))


async def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--lang", choices=["it", "zh"], help="une seule langue")
    ap.add_argument("--essai", action="store_true", help="enregistre 3 phrases par langue dans le dossier « essai »")
    ap.add_argument("--voix-it", default=VOICES["it"], help="ex. it-IT-IsabellaNeural, it-IT-DiegoNeural")
    ap.add_argument("--voix-zh", default=VOICES["zh"], help="ex. zh-CN-XiaoyiNeural, zh-CN-YunxiNeural")
    a = ap.parse_args()
    voices = {"it": a.voix_it, "zh": a.voix_zh}
    for lang in ([a.lang] if a.lang else ["it", "zh"]):
        items = json.load(open(os.path.join(HERE, f"texts-{lang}.json"), encoding="utf8"))["items"]
        if a.essai:
            os.makedirs(os.path.join(HERE, "essai"), exist_ok=True)
            sample = [it for it in items if len(it["t"]) > 12][:3]
            for i, it in enumerate(sample):
                p = os.path.join(HERE, "essai", f"{lang}-{i + 1}.mp3")
                await say(it["t"], voices[lang], RATES[lang], p)
                print(f"[{lang}] {p}  ←  {it['t']}")
            continue
        folder = await record(lang, items, voices[lang], RATES[lang])
        pack(lang, items, folder, voices[lang])
    if not a.essai:
        print("\nTerminé ! Envoyez à Claude le contenu du dossier « audio » (sous-dossiers it et zh).")


if __name__ == "__main__":
    asyncio.run(main())
