import json, os, sys, time, numpy as np, lameenc
from kokoro_onnx import Kokoro
from misaki import zh as mzh
TX="/home/claude/impara/impara-comptes/tools/audio"
OUT="/tmp/claude-0/kok/clips"
VOICE={"it":"if_sara","zh":"zf_xiaoxiao"}; SPEED={"it":0.95,"zh":0.9}
k=Kokoro("kokoro-v1.0.onnx","voices-v1.0.bin"); g=mzh.ZHG2P()
def mp3(s,sr,path):
    s=np.concatenate([np.zeros(int(sr*0.05)), s, np.zeros(int(sr*0.15))])
    e=lameenc.Encoder(); e.set_bit_rate(40); e.set_in_sample_rate(sr); e.set_channels(1); e.set_quality(2)
    pcm=(np.clip(s,-1,1)*32767).astype(np.int16).tobytes(); open(path+".part","wb").write(e.encode(pcm)+e.flush()); os.replace(path+".part",path)
for lang in sys.argv[1:]:
    items=json.load(open(f"{TX}/texts-{lang}.json"))["items"]
    os.makedirs(f"{OUT}/{lang}",exist_ok=True)
    todo=[it for it in items if not os.path.exists(f"{OUT}/{lang}/{it['id']}.mp3")]
    t0=time.time(); fails=0
    for i,it in enumerate(todo):
        try:
            if lang=="zh": s,sr=k.create(g(it["t"]), voice=VOICE[lang], speed=SPEED[lang], is_phonemes=True)
            else: s,sr=k.create(it["t"], voice=VOICE[lang], speed=SPEED[lang], lang="it")
            mp3(s,sr,f"{OUT}/{lang}/{it['id']}.mp3")
        except Exception as ex:
            fails+=1; print("FAIL",lang,it["t"][:40],ex,flush=True)
        if i%50==0: print(lang,i,len(todo),round(time.time()-t0),"s",flush=True)
    print("DONE",lang,len(todo),"fails",fails,flush=True)
