import json, os, sys, time, numpy as np, lameenc
sys.path.insert(0,'/tmp/claude-0/kok')
import tonefix as tf
TX="/home/claude/impara/impara-comptes/tools/audio"
items=json.load(open(f"{TX}/texts-zh.json"))["items"]
def mp3(s,sr,path):
    s=np.concatenate([np.zeros(int(sr*0.05)), s, np.zeros(int(sr*0.15))])
    e=lameenc.Encoder(); e.set_bit_rate(40); e.set_in_sample_rate(sr); e.set_channels(1); e.set_quality(2)
    pcm=(np.clip(s,-1,1)*32767).astype(np.int16).tobytes(); open(path+".part","wb").write(e.encode(pcm)+e.flush()); os.replace(path+".part",path)
for voice in sys.argv[1:]:
    out=f"/tmp/claude-0/kok/clips2/{voice}"; os.makedirs(out,exist_ok=True)
    todo=[it for it in items if not os.path.exists(f"{out}/{it['id']}.mp3")]
    t0=time.time(); fails=0
    for i,it in enumerate(todo):
        try:
            ph=tf.phonemes(it["t"])
            try: a=tf.synth(it["t"],voice,0.9,ph=ph)
            except Exception as ex:
                fails+=1; print("FIXFAIL",it["t"][:30],ex,flush=True); a=tf.K.create(ph,voice=voice,speed=0.9,is_phonemes=True)[0]
            mp3(np.asarray(a,dtype=np.float32),24000,f"{out}/{it['id']}.mp3")
        except Exception as ex:
            print("FAIL",it["t"][:30],ex,flush=True)
        if i%100==0: print(voice,i,len(todo),round(time.time()-t0),"s",flush=True)
    print("DONE",voice,len(todo),"fixfails",fails,flush=True)
