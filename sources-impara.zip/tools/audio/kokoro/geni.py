import json, os, sys, time, numpy as np, lameenc
from kokoro_onnx import Kokoro
k=Kokoro("kokoro-v1.0.onnx","voices-v1.0.bin")
items=json.load(open("/home/claude/impara/impara-comptes/tools/audio/texts-it.json"))["items"]
def mp3(s,sr,path):
    s=np.concatenate([np.zeros(int(sr*0.05)), s, np.zeros(int(sr*0.15))])
    e=lameenc.Encoder(); e.set_bit_rate(40); e.set_in_sample_rate(sr); e.set_channels(1); e.set_quality(2)
    pcm=(np.clip(s,-1,1)*32767).astype(np.int16).tobytes(); open(path+".part","wb").write(e.encode(pcm)+e.flush()); os.replace(path+".part",path)
out="/tmp/claude-0/kok/clips-it/im_nicola"; os.makedirs(out,exist_ok=True)
todo=[it for it in items if not os.path.exists(f"{out}/{it['id']}.mp3")]
t0=time.time()
for i,it in enumerate(todo):
    try:
        s,sr=k.create(it["t"], voice="im_nicola", speed=0.95, lang="it"); mp3(s,sr,f"{out}/{it['id']}.mp3")
    except Exception as ex: print("FAIL",it["t"][:40],ex,flush=True)
    if i%100==0: print(i,len(todo),round(time.time()-t0),"s",flush=True)
print("DONE",flush=True)
