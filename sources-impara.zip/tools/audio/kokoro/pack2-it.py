import json, os, sys
# usage: pack2.py <dossier clips> <dossier sortie> <préfixe> <nom voix>
src, out, prefix, voice = sys.argv[1:5]
PACK_MAX = 9 * 1024 * 1024
items = json.load(open("/home/claude/impara/impara-comptes/tools/audio/texts-it.json"))["items"]
os.makedirs(out, exist_ok=True)
for f in os.listdir(out): os.remove(os.path.join(out, f))
clips, packs, buf, n, missing = {}, [], bytearray(), 0, 0
def flush():
    global buf, n
    name = f"{prefix}{n}.bin"; open(os.path.join(out, name), "wb").write(buf); packs.append(name); buf = bytearray(); n += 1
for it in items:
    p = os.path.join(src, it["id"] + ".mp3")
    if not os.path.exists(p): missing += 1; continue
    data = open(p, "rb").read()
    if len(buf) + len(data) > PACK_MAX and buf: flush()
    clips[it["id"]] = [n, len(buf), len(data)]; buf += data
if buf: flush()
json.dump({"voice": voice, "packs": packs, "clips": clips}, open(os.path.join(out, "index.json"), "w"), separators=(",", ":"))
print(len(clips), "clips", packs, "missing", missing, round(sum(os.path.getsize(os.path.join(out, p)) for p in packs) / 1e6, 1), "Mo")
