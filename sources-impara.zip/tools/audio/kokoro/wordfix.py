"""Mots courts italiens : Kokoro les prononce mal quand ils sont seuls (style « titre »,
vecteur de style des entrées très courtes). On les fait dire dans une phrase porteuse et on
découpe le mot exactement grâce aux durées prédites par le modèle (encodeur enc.onnx).
Chaque variante est notée objectivement : formants de chaque voyelle comparés aux voyelles
italiennes attendues + absence de voisement avant p / t / k. On garde la meilleure."""
import numpy as np, onnxruntime as ort, parselmouth
from kokoro_onnx import Kokoro

K = Kokoro("/tmp/claude-0/kok/kokoro-v1.0.onnx", "/tmp/claude-0/kok/voices-v1.0.bin")
so = ort.SessionOptions(); so.intra_op_num_threads = 2
ENC = ort.InferenceSession("/tmp/claude-0/kok/enc.onnx", so)
SR = 24000
VOC = K.tokenizer.vocab
# Le son sort ~65 ms AVANT les bornes calculées depuis les durées (mesuré sur Sara et Nicola,
# constant le long de la phrase) : on décale les bornes d'autant.
SHIFT = -int(0.065 * SR)

# Voyelles italiennes (F1, F2) en Hz, voix de femme ; voix d'homme ≈ ×0.86
TARGET = {"i": (310, 2500), "ɪ": (360, 2250), "e": (430, 2250), "ɛ": (580, 2000), "a": (820, 1450),
          "ɔ": (600, 1050), "o": (460, 950), "u": (340, 850), "ʊ": (380, 950)}
STOPS = set("ptk")


def run(ph, voice, speed=0.95, style_len=None):
    """Audio + bornes (en échantillons) de chaque caractère de ph"""
    keep = [i for i, c in enumerate(ph) if c in VOC]
    toks = [VOC[ph[i]] for i in keep]
    v = K.voices[voice]
    style = np.asarray(v[min(style_len or len(toks), len(v)) - 1], dtype=np.float32)
    dur, _ = ENC.run(None, {"tokens": np.array([[0, *toks, 0]], dtype=np.int64), "style": style,
                            "speed": np.array([speed], dtype=np.float32)})
    dur = np.asarray(dur).ravel()
    a, _ = K._infer(toks, style, speed)
    a = np.asarray(a, dtype=np.float32)
    spu = len(a) / dur.sum()
    edges = np.concatenate([[0], np.cumsum(dur)]) * spu   # token j (avec pads) : edges[j]..edges[j+1]
    bounds = {}
    for j, ci in enumerate(keep):
        bounds[ci] = (max(0, int(edges[j + 1]) + SHIFT), max(0, int(edges[j + 2]) + SHIFT))
    return a, bounds


def score(a, bounds, ph, lo, hi, male):
    """Note (plus bas = mieux) des caractères ph[lo:hi] dans l'audio a"""
    s = parselmouth.Sound(a.astype(np.float64), SR)
    fm = s.to_formant_burg(time_step=0.005, max_number_of_formants=5, maximum_formant=5000 if male else 5500)
    pt = s.to_pitch(time_step=0.005)
    k = 0.86 if male else 1.0
    errs, details = [], []
    for ci in range(lo, hi):
        c = ph[ci]
        if ci not in bounds: continue
        b0, b1 = bounds[ci]
        # voyelle allongée « ː » : on étend jusqu'à la fin du ː
        if ci + 1 < hi and ph[ci + 1] == "ː" and ci + 1 in bounds: b1 = bounds[ci + 1][1]
        if c in TARGET:
            stressed = ci > 0 and ph[ci - 1] == "ˈ"
            t0, t1 = b0 / SR, b1 / SR
            ts = np.linspace(t0 + (t1 - t0) * 0.2, t1 - (t1 - t0) * 0.2, 7)
            f1 = [fm.get_value_at_time(1, t) for t in ts]; f2 = [fm.get_value_at_time(2, t) for t in ts]
            f1 = np.nanmedian(f1); f2 = np.nanmedian(f2)
            T1, T2 = TARGET[c][0] * k, TARGET[c][1] * k
            if np.isnan(f1) or np.isnan(f2): errs.append(1.0); continue
            e = max(0, abs(np.log(f1 / T1)) - 0.18) * 2 + max(0, abs(np.log(f2 / T2)) - 0.15) * 2
            errs.append(e * (1.0 if stressed else 0.6)); details.append(f"{c}:{int(f1)}/{int(f2)}")
        elif c in STOPS and ci == lo:
            ts = np.arange(b0 / SR, b1 / SR, 0.005)
            v = [1 if (pt.get_value_at_time(t) and not np.isnan(pt.get_value_at_time(t))) else 0 for t in ts]
            if len(v) > 2 and np.mean(v) > 0.5: errs.append(1.0); details.append(f"{c}:voisé")
    return (float(np.mean(errs)) if errs else 0.0), " ".join(details)


def _quiet(e, center, before, after):
    """position du minimum d'énergie autour de center (fenêtre en secondes)"""
    lo, hi = max(0, center - int(before * SR)), min(len(e), center + int(after * SR))
    return lo + int(np.argmin(e[lo:hi])) if hi > lo else center


def cut(a, bounds, lo, hi, start_win=(0.0, 0.0), end_win=(0.02, 0.04)):
    """Garde les caractères lo..hi-1 ; chaque coupe est posée sur le minimum d'énergie
    le plus proche de la frontière (silence, occlusion) pour ne rien garder du mot voisin"""
    e = np.sqrt(np.convolve(a * a, np.ones(120) / 120, "same"))
    idx = [ci for ci in range(lo, hi) if ci in bounds]
    s0 = _quiet(e, bounds[idx[0]][0], *start_win) if start_win != (0.0, 0.0) else 0
    s1 = _quiet(e, bounds[idx[-1]][1], *end_win)
    seg = a[s0:s1].copy()
    f = int(0.03 * SR); seg[-f:] *= np.linspace(1, 0, f)
    g = int(0.005 * SR); seg[:g] *= np.linspace(0, 1, g)
    return seg


def variants(ph, voice):
    """(nom, audio_coupé, score, détail) pour chaque façon de dire le mot"""
    male = voice.startswith("im")
    out = []
    # 1) seul (comme avant)
    a, b = run(ph, voice)
    out.append(("seul", a, *score(a, b, ph, 0, len(ph), male)))
    # 2) en fin de phrase après une pause : « Ecco: <mot>. »
    pre = "ˈɛkko, "
    full = pre + ph + "."
    a, b = run(full, voice)
    lo, hi = len(pre), len(pre) + len(ph)
    sc, d = score(a, b, full, lo, hi, male)
    out.append(("fin", cut(a, b, lo, hi, start_win=(0.08, 0.02), end_win=(0.0, 0.25)), sc, d))
    # 3) en début de phrase, suivi d'une occlusive (silence propre pour couper) : « <mot> per te. »
    full = ph + " pˈɛr tˈe."
    a, b = run(full, voice)
    sc, d = score(a, b, full, 0, len(ph), male)
    out.append(("début", cut(a, b, 0, len(ph), end_win=(0.02, 0.05)), sc, d))
    return out
