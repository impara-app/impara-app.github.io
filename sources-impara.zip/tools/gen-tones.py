"""Génère js/data/zh-tones.js : caractères de référence pour comparer les 4 tons.
REF  : syllabe sans ton -> [car. 1er ton, 2e, 3e, 4e] (jusqu'à 3 caractères courants lus ainsi par défaut, ou "")
READ : lecture par défaut (celle d'une voix de synthèse sur le caractère seul) des caractères du cours
Dépendances : pip install pypinyin wordfreq"""
import json, re, sys, unicodedata
from pypinyin import pinyin
from pypinyin.pinyin_dict import pinyin_dict
import wordfreq

ROOT = "/home/claude/impara/impara-comptes/js/data/"
freq = wordfreq.get_frequency_dict("zh")
MARKS = {"āēīōūǖ": 1, "áéíóúǘ": 2, "ǎěǐǒǔǚ": 3, "àèìòùǜ": 4}
def tone(s):
    for k, t in MARKS.items():
        if any(c in k for c in s): return t
    return 0
def base(s):
    d = unicodedata.normalize("NFD", s)
    return unicodedata.normalize("NFC", re.sub(r"[̀-̄̌]", "", d.replace("ü", "v").replace("ü", "v"))).replace("v", "ü")

# Pour chaque (syllabe, ton) : les 3 caractères les plus fréquents lus ainsi par défaut
# (plusieurs, pour en avoir toujours un AUTRE que le caractère à deviner)
cands = {}
for cp, reads in pinyin_dict.items():
    ch = chr(cp)
    r = reads.split(",")  # la 1re lecture est la plus courante (celle lue sur le caractère seul)
    f = freq.get(ch, 0)
    if f < 1e-6: continue    # caractère assez courant
    t = tone(r[0])
    if not t: continue
    cands.setdefault((base(r[0]), t), []).append((f, ch))
top = {k: "".join(c for _, c in sorted(v, reverse=True)[:3]) for k, v in cands.items()}

src = "".join(open(ROOT + f, encoding="utf8").read() for f in ["zh.js", "zh-hsk1-plus.js", "zh-hsk2-plus.js", "zh-hsk3-plus.js", "stories-zh.js", "dialogues-zh.js"])
chars = sorted({c for c in src if "一" <= c <= "鿿"})
default = {c: pinyin(c)[0][0] for c in chars}
bases = sorted({base(default[c]) for c in chars})
ref = {}
for b in bases:
    row = [top.get((b, t), "") for t in (1, 2, 3, 4)]
    if sum(1 for x in row if x) >= 2: ref[b] = row
out = "/* Généré par tools/gen-tones.py (pypinyin + wordfreq) : caractères de référence pour comparer les tons. */\n"
out += "export const REF = " + json.dumps(ref, ensure_ascii=False, separators=(",", ":")) + ";\n"
out += "export const READ = " + json.dumps(default, ensure_ascii=False, separators=(",", ":")) + ";\n"
open(ROOT + "zh-tones.js", "w", encoding="utf8").write(out)
print(len(ref), "syllabes ;", len(out.encode()), "octets")
print({k: ref[k] for k in list(ref)[:8]}, ref.get("ma"), ref.get("hao"))
